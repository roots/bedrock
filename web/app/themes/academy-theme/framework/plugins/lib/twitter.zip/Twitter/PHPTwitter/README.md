PHPTwitter
==========

An easy to use PHP Twitter class.


Example
==========

An example showing how to authenticate a user through implementing the OAuth flow and can be found in index.php as well as a simple API call demonstrating how to fetch the current users' profile.


