Theme Name: North
Description: One Page Parallax Theme.
Version: 2.6.0
Author: Veented
Author URI: http://themeforest.net/user/Veented
License: GNU General Public License
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Theme Support Page: http://veented.com/support/north/
