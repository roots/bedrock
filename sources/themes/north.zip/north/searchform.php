<form class="search-form relative" id="search-form" action="<?php echo home_url(); ?>/">
	<input name="s" id="s" type="text" value="" placeholder="<?php _e('Quick Search..','north') ?>" class="search">
	<button class="search-button"><i class="fa fa-search"></i></button>
</form>					