<?php 

define('VNTD_WIDGETS', dirname( __FILE__ ));

// Load theme widgets

include_once( VNTD_WIDGETS . '/lib/widget-flickr.php');