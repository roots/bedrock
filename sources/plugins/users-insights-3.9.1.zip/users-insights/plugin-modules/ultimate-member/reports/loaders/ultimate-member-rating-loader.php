<?php

class USIN_Ultimate_Member_Rating_Loader extends USIN_Numeric_Meta_Field_Loader{
	
	public $max_items = 10;
}