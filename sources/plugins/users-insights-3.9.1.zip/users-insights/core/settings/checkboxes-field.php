<?php

class USIN_Checkboxes_Field extends USIN_Settings_Field{


	protected $default = array();
	protected $type = self::TYPE_CHECKBOXES;


}