<?php

class USIN_Standard_Report extends USIN_Report {
	
	//standard reports are usually represented as a pie chart
	public $type = self::PIE;
	public $subtype = 'standard';

}