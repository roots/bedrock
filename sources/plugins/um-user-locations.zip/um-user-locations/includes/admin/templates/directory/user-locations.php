<?php if ( ! defined( 'ABSPATH' ) ) exit;

global $post_id;

$user_fields = array();
foreach ( UM()->builtin()->all_user_fields() as $key => $arr ) {
	$user_fields[ $key ] = isset( $arr['title'] ) ? $arr['title'] : '';
}
$_um_infowindow_fields = get_post_meta( $post_id, '_um_user_location_infowindow_data', true );

$_um_user_location_fields = get_post_meta( $post_id, '_um_user_location_fields', true );
$_um_user_location_fields = empty( $_um_user_location_fields ) ? '' : $_um_user_location_fields; ?>

<div class="um-admin-metabox">

	<?php $fields = array(
		array(
			'id'        => '_um_show_map',
			'type'      => 'checkbox',
			'label'     => __( 'Show Map', 'um-user-locations' ),
			'value'     => UM()->query()->get_meta_value( '_um_show_map' ),
		),
		array(
			'id'                    => '_um_user_location_fields',
			'type'                  => 'select',
			'label'                 => __( 'Show this user location field at the map', 'um-user-locations' ),
			'tooltip'               => __( 'If empty, map will be hidden', 'um-user-locations' ),
			'value'                 => $_um_user_location_fields,
			'options'               => UM()->User_Locations()->fields()->location_fields,
			'conditional'           => array( '_um_show_map', '=', 1 ),
		),
		array(
			'id'            => '_um_map_height',
			'type'          => 'number',
			'label'         => __( 'Map height', 'um-user-locations' ),
			'value'         => UM()->query()->get_meta_value( '_um_map_height', null, UM()->options()->get( 'user_location_map_height' ) ),
			'size'          => 'small',
			'conditional'   => array( '_um_show_map', '=', 1 ),
		),
		array(
			'id'            => '_um_map_search_by_moving',
			'type'          => 'checkbox',
			'label'         => __( 'Enable user location search field', 'um-user-locations' ),
			'tooltip'       => __( 'Make it possible to search users via search field and when dragging a map', 'um-user-locations' ),
			'conditional'   => array( '_um_show_map', '=', 1 ),
			'value'         => UM()->query()->get_meta_value( '_um_map_search_by_moving' ),
		),

		array(
			'id'                    => '_um_user_location_infowindow_data',
			'type'                  => 'multi_selects',
			'label'                 => __( 'Choose field(s) to display in marker\'s infowindow', 'um-user-locations' ),
			'value'                 => $_um_infowindow_fields,
			'conditional'           => array( '_um_show_map', '=', 1 ),
			'add_text'              => __( 'Add New Field', 'um-user-locations' ),
			'options'               => $user_fields,
			'show_default_number'   => 0,
			'sorting'               => true,
		),
	);

	UM()->admin_forms( array(
		'class'     => 'um-member-directory-user-locations um-half-column',
		'prefix_id' => 'um_metadata',
		'fields'    => $fields
	) )->render_form(); ?>

	<div class="um-admin-clear"></div>

</div>