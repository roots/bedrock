<?php
namespace um_ext\um_user_locations\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class Profile
 *
 * @package um_ext\um_user_locations\core
 */
class Profile {


	/**
	 * Profile constructor.
	 */
	function __construct() {
		add_filter( 'um_submit_form_data', array( &$this, 'save_location' ), 10, 2 );
		add_filter( 'um_admin_pre_save_field_to_form', array( &$this, 'save_location_fields' ), 10, 1 );
	}


	/**
	 * Save user_location lat/lng
	 *
	 * @param array $post_data
	 * @param string $mode
	 *
	 * @return array
	 */
	function save_location( $post_data, $mode ) {
		$location_type = array();

		if ( isset( $post_data['custom_fields'] ) and $mode == 'profile' ) {
			$custom_fields = unserialize( $post_data['custom_fields'] );
			foreach ( $custom_fields as $key => $val ) {
				if ( $val['type'] == 'user_location' ) {
					$location_type[] = $val['metakey'];
				}
			}

			if ( ! empty( $location_type ) ) {
				foreach ( $location_type as $value ) {
					update_user_meta( $post_data['user_id'], $value . '_lat', $post_data[ $value . '_lat' ] );
					update_user_meta( $post_data['user_id'], $value . '_lng', $post_data[ $value . '_lng' ] );
					update_user_meta( $post_data['user_id'], $value . '_url', $post_data[ $value . '_url' ] );
				}
			}

		}

		return $post_data;
	}


	/**
	 * Save our user tags filters
	 *
	 * @param array $args
	 * @return array
	 */
	function save_location_fields( $args ) {
		if ( $args['type'] == 'user_location' ) {
			$store = get_option( 'um_map_user_fields', array() );

			$store[] = $args['metakey'];
			$store = array_unique( $store );
			update_option( 'um_map_user_fields', $store );
		}

		return $args;
	}
}