<?php
namespace um_ext\um_user_locations\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class Fields
 * @package um_ext\um_user_locations\core
 */
class Fields {


	/**
	 * @var array
	 */
	var $location_fields = array();


	/**
	 * Fields constructor.
	 */
	function __construct() {
		add_filter( 'init', array( &$this, 'init_variables' ), 2 );

		add_filter( 'um_core_fields_hook', array( &$this, 'add_location_field' ) );

		add_filter( 'um_edit_field_register_user_location', array( &$this, 'location_field_html' ), 10, 2 );
		add_filter( 'um_edit_field_profile_user_location', array( &$this, 'location_field_html' ), 10, 2 );

		add_filter( 'um_view_field_value_user_location', array( &$this, 'view_field_user_location' ), 10, 2 );
	}


	/**
	 * Set location fields variable
	 */
	function init_variables() {
		$map_fields = get_option( 'um_map_user_fields', array() );

		if ( ! empty( $map_fields ) ) {
			$map_fields = array_map( function( $item ) use ( $map_fields ) {
				$field_title = UM()->fields()->get_field_title( $map_fields[ $item ] );

				if ( ! empty( $field_title ) ) {
					$item = $field_title;
				} else {
					$item = $map_fields[ $item ];
				}
				return $item;
			}, array_flip( $map_fields ) );
		}

		$this->location_fields = $map_fields;
	}


	/**
	 * @param $fields
	 *
	 * @return mixed
	 */
	function add_location_field( $fields ) {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return $fields;
		}

		$fields['user_location'] = array(
			'name' => __( 'User Location', 'um-user-locations' ),
			'col1' => array( '_title', '_metakey', '_help', '_default', '_visibility' ),
			'col2' => array( '_label', '_placeholder', '_public', '_roles' ),
			'col3' => array( '_required', '_editable', '_icon' ),
			'validate' => array(
				'_title' => array(
					'mode' => 'required',
					'error' => __( 'You must provide a title', 'um-user-locations' )
				),
				'_metakey' => array(
					'mode' => 'unique',
				),
			)
		);

		return $fields;
	}


	/**
	 * @param $output
	 * @param $data
	 *
	 * @return string
	 */
	function location_field_html( $output, $data ) {
		/**
		 * @var $metakey
		 * @var $conditional
		 * @var $default
		 * @var $placeholder
		 */
		extract( $data );
		wp_enqueue_script('um-user-location-field');

		ob_start();
		?>

		<div class="um-field um-field-<?php echo esc_attr( $metakey ); ?> um-field-user-location" <?php echo $conditional ?> data-key="<?php echo esc_attr( $metakey ); ?>">
			<?php echo isset( $label ) ? UM()->fields()->field_label( $label, $metakey, $data ) : ''; ?>
			<div class="um-field-area">
				<?php if ( isset( $icon ) && $icon && isset( $field_icons ) && $field_icons == 'field' ) { ?>
					<div class="um-field-icon"><i class="<?php echo esc_attr( $icon ) ?>"></i></div>
				<?php }
				$field_name = $metakey . UM()->form()->form_suffix;
				$field_value = UM()->fields()->field_value( $metakey, $default, $data );
				$lat_value = UM()->fields()->field_value( $metakey . '_lat', '', $data );
				$lng_value = UM()->fields()->field_value( $metakey . '_lng', '', $data );
				$url_value = UM()->fields()->field_value( $metakey . '_url', '', $data );
				?>
				<input class="<?php echo esc_attr( UM()->fields()->get_class( $metakey, $data ) ) ?> um_user_location_g_autocomplete" type="text"
				       name="<?php echo esc_attr( $field_name ) ?>" id="<?php echo esc_attr( $field_name ) ?>" value="<?php echo esc_attr( $field_value ) ?>"
				       placeholder="<?php echo esc_attr( $placeholder ) ?>" data-key="<?php echo esc_attr( $metakey ) ?>" />
				<a href="javascript:void(0);" class="um_current_user_location"><i class="um-faicon-map-marker" aria-hidden="true"></i></a>
				<input type="hidden" name="<?php echo esc_attr( $metakey . '_lat' . UM()->form()->form_suffix ); ?>" class="um_lat_param" data-key="<?php echo esc_attr( $metakey ) ?>_lat" value="<?php echo esc_attr( $lat_value ); ?>" />
				<input type="hidden" name="<?php echo esc_attr( $metakey . '_lng' . UM()->form()->form_suffix ); ?>" class="um_lng_param" data-key="<?php echo esc_attr( $metakey ) ?>_lng" value="<?php echo esc_attr( $lng_value ); ?>" />
				<input type="hidden" name="<?php echo esc_attr( $metakey . '_url' . UM()->form()->form_suffix ); ?>" class="um_url_param" data-key="<?php echo esc_attr( $metakey ) ?>_url" value="<?php echo esc_attr( $url_value ); ?>" />
				<div class="um_user_location_g_autocomplete_map"></div>
			</div>

		</div>

		<?php

		$output .= ob_get_clean();
		return $output;
	}


	/**
	 * Customize instagram photo in profile view
	 * @param  string $output
	 * @param  array $data
	 * @return string
	 */
	public function view_field_user_location( $output, $data ) {
		wp_enqueue_script( 'um-user-location-field' );

		$lat_value = UM()->fields()->field_value( $data['metakey'] . '_lat', '', $data );
		$lng_value = UM()->fields()->field_value( $data['metakey'] . '_lng', '', $data );
		$url_value = UM()->fields()->field_value( $data['metakey'] . '_url', '', $data );

		if ( '' !== $lat_value && '' !== $lng_value ) {
			if ( '' !== $url_value ) {
				$output = '<a href="' . esc_url( $url_value ) . '" target="_blank">' . $output . '</a>';
			}

			$output = '<div class="um-user-locations-map-field-text">' . $output . '</div><div class="um-user-locations-map-field-view" data-lat="' . esc_attr( $lat_value ) . '" data-lng="' . esc_attr( $lng_value ) . '"></div>';
		}

		return $output;
	}


}