<?php
namespace um_ext\um_user_locations\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class Member_Directory
 *
 * @package um_ext\um_user_locations\core
 */
class Member_Directory {


	/**
	 * Member_Directory constructor.
	 */
	function __construct() {
		add_action( 'um_before_member_directory_save', array( &$this, 'delete_map_fields' ), 10, 1 );
		add_action( 'um_members_directory_before_head', array( &$this, 'header_add_map' ), 10, 3 );

		add_filter( 'um_prepare_user_query_args', array( &$this, 'search_by_coord' ), 40, 2 );
		add_action( 'um_pre_users_query', array( &$this, 'search_by_coord_meta' ), 10, 3 );

		add_filter( 'um_ajax_get_members_data', array( &$this, 'add_maps_args' ), 10, 3 );
		add_filter( 'um_ajax_get_members_response', array( &$this, 'add_maps_fields' ), 10, 2 );

		/* @todo filters integration */
//		add_filter( 'um_members_directory_custom_field_types_supported_filter', array( &$this, 'add_location_fields_type' ), 10, 1 );
//		add_filter( 'um_custom_field_filter_type', array( &$this, 'add_location_filter_type' ), 10, 2 );
//
//		add_action( 'um_member_directory_filter_type_user_location', array( &$this, 'user_location_filter' ), 10, 5 );

	}


	/**
	 * @param $post_id
	 */
	function delete_map_fields( $post_id ) {
		delete_post_meta( $post_id, '_um_user_location_infowindow_data' );
	}


	/**
	 * @param $options
	 *
	 * @return mixed
	 */
	function add_location_fields_type( $options ) {
		$options[] = 'user_location';
		return $options;
	}


	/**
	 * @param $type
	 * @param $field_data
	 *
	 * @return string
	 */
	function add_location_filter_type( $type, $field_data ) {
		if ( isset( $field_data['type'] ) && $field_data['type'] == 'user_location' ) {
			$type = 'user_location';
		}

		return $type;
	}


	/**
	 * @param $field_key
	 * @param $directory_data
	 */
	function user_location_filter( $field_key, $directory_data, $unique_hash, $attrs, $default_value ) {

		if ( $default_value === false ) {
			$default_filters = array();
			if ( ! empty( $directory_data['search_filters'] ) ) {
				$default_filters = maybe_unserialize( $directory_data['search_filters'] );
			}

			if ( isset( $default_filters[ $field_key . '_lat' ] ) && isset( $default_filters[ $field_key . '_lng' ] ) && UM()->member_directory()->filter_types[ $field_key ] == 'user_location' ) {
				return;
			}
		}


		$filter_from_url_lat = ! empty( $_GET[ 'filter_' . $field_key . '_lat_' . $unique_hash ] ) ? $_GET[ 'filter_' . $field_key . '_lat_' . $unique_hash ] : $default_value;
		$filter_from_url_lng = ! empty( $_GET[ 'filter_' . $field_key . '_lng_' . $unique_hash ] ) ? $_GET[ 'filter_' . $field_key . '_lng_' . $unique_hash ] : $default_value;
		$filter_from_url_distance = ! empty( $_GET[ 'filter_' . $field_key . '_dist_' . $unique_hash ] ) ? $_GET[ 'filter_' . $field_key . '_dist_' . $unique_hash ] : $default_value;

		ob_start();
		?>

		<input class="um-form-field um_user_location_g_autocomplete" type="text"
		       id="<?php echo $field_key ?>" name="<?php echo $field_key ?>"
		       placeholder="<?php esc_attr_e( stripslashes( $attrs['label'] ), 'um-user-locations' ); ?>"
		       aria-label="<?php esc_attr_e( stripslashes( $attrs['label'] ), 'um-user-locations' ); ?>" />

		<a href="javascript:void(0);" class="um_current_user_location"><i class="um-faicon-map-marker" aria-hidden="true"></i></a>
		<input type="hidden" name="<?php echo $field_key ?>_lat" class="um_lat_param" data-key="<?php echo $field_key ?>_lat" value="<?php echo $filter_from_url_lat ?>" />
		<input type="hidden" name="<?php echo $field_key ?>_lng" class="um_lng_param" data-key="<?php echo $field_key ?>_lng" value="<?php echo $filter_from_url_lng ?>" />

		<?php if ( ! empty( $directory_data['map_search_by_position'] ) && empty( $directory_data['map_search_display_distance'] ) ) {

			if ( isset( $directory_data['map_search_min_radius'] ) && isset( $directory_data['map_search_max_radius'] ) ) {
				if ( is_numeric( $directory_data['map_search_min_radius'] ) && is_numeric( $directory_data['map_search_max_radius'] ) &&
				     $directory_data['map_search_min_radius'] < $directory_data['map_search_max_radius'] ) {

					$single_placeholder = $directory_data['map_search_distance_unit'] == 'km' ? __( '{value} kilometer', 'um-user-locations' ) : __( '{value} mile', 'um-user-locations' );
					$plural_placeholder = $directory_data['map_search_distance_unit'] == 'km' ? __( '{value} kilometers', 'um-user-locations' ) : __( '{value} miles', 'um-user-locations' ); ?>

					<input type="hidden" id="<?php echo $field_key; ?>_distance" name="<?php echo $field_key; ?>_distance" class="um_range_distance" value="<?php echo $filter_from_url_distance ?>" />
					<div class="um-location-slider" data-field_name="<?php echo $field_key; ?>_distance" data-min="<?php echo $directory_data['map_search_min_radius'] ?>" data-max="<?php echo $directory_data['map_search_max_radius'] ?>"></div>
					<div class="um-location-slider-range" data-placeholder-s="<?php echo esc_attr( $single_placeholder ); ?>" data-placeholder-p="<?php echo esc_attr( $plural_placeholder ); ?>" data-label="<?php esc_attr_e( 'Distance', 'um-user-locations' ) ?>"></div>

				<?php }
			}
		}

		ob_end_flush();
	}


	/**
	 * @param $args
	 * @param $form_id
	 * @param bool $not_searched
	 */
	function header_add_map( $args, $form_id, $not_searched ) {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return;
		}

		if ( empty( $args['show_map'] ) ) {
			return;
		}

		if ( empty( $args['user_location_fields'] ) ) {
			return;
		}

		wp_enqueue_script( 'um-user-location-clustering' );

		$hash = UM()->member_directory()->get_directory_hash( $form_id );

		$height = ! empty( $args['map_height'] ) ? absint( $args['map_height'] ) : UM()->options()->get( 'user_location_map_height' );
		$height = empty( $height ) ? '300px' : absint( $height ) . 'px';

		$zoom = 1;
		$lat = 0;
		$lng = 0;

		$map_sw = '';
		$map_ne = '';
		$dynamic_search = false;
		if ( ! empty( $args['map_search_by_moving'] ) ) {
			$dynamic_search = true;

			if ( isset( $_GET[ 'map_sw_' . $hash ] ) ) {
				$sw_array = explode( ',', $_GET[ 'map_sw_' . $hash ] );
				$sw_array = array_map( 'floatval', $sw_array );
				$map_sw = implode( ',', $sw_array );
			}

			if ( isset( $_GET[ 'map_ne_' . $hash ] ) ) {
				$ne_array = explode( ',', $_GET[ 'map_ne_' . $hash ] );
				$ne_array = array_map( 'floatval', $ne_array );
				$map_ne = implode( ',', $ne_array );
			}
		}

		if ( ! empty( $args['user_location_infowindow_data'] ) ) {
			$args['user_location_infowindow_data'] = maybe_unserialize( $args['user_location_infowindow_data'] );
		} else {
			$args['user_location_infowindow_data'] = array();
		}

		UM()->get_template( 'infowindow.php', um_user_locations_plugin, array( 'infowindow_fields' => $args['user_location_infowindow_data'] ), true );

		$t_args = array(
			'args'              => $args,
			'not_searched'      => $not_searched,
			'zoom'              => $zoom,
			'lat'               => $lat,
			'lng'               => $lng,
			'dynamic_search'    => $dynamic_search,
			'map_sw'            => $map_sw,
			'map_ne'            => $map_ne,
			'height'            => $height,
		);

		UM()->get_template( 'map.php', um_user_locations_plugin, $t_args, true );
	}


	/**
	 * @param $query_args
	 * @param $directory_data
	 *
	 * @return mixed
	 */
	function search_by_coord( $query_args, $directory_data ) {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return $query_args;
		}

		if ( ! empty( $directory_data['show_map'] ) ) {

			if ( ! empty( $directory_data['map_search_by_moving'] ) ) {

				if ( ! isset( $_POST['map_ne'] ) ) {
					$ne_lat = 90;
					$ne_lng = 180;
				} else {
					$ne_array = explode( ',', $_POST['map_ne'] );
					$ne_array = array_map( 'floatval', $ne_array );

					$ne_lat = $ne_array[0];
					$ne_lng = $ne_array[1];
				}

				if ( ! isset( $_POST['map_sw'] ) ) {
					$sw_lat = -90;
					$sw_lng = -180;
				} else {
					$sw_array = explode( ',', $_POST['map_sw'] );
					$sw_array = array_map( 'floatval', $sw_array );

					$sw_lat = $sw_array[0];
					$sw_lng = $sw_array[1];
				}

				$directory_data['user_location_fields'] = maybe_unserialize( $directory_data['user_location_fields'] );
				if ( is_string( $directory_data['user_location_fields'] ) ) {
					$directory_data['user_location_fields'] = array( $directory_data['user_location_fields'] );
				}

				if ( ! empty( $directory_data['user_location_fields'] ) ) {
					if ( empty( $query_args['meta_query'] ) ) {
						$query_args['meta_query'] = array();
					}

					if ( count( $directory_data['user_location_fields'] ) > 1 ) {
						$location_query = array( 'relation' => 'OR' );
					}
					foreach ( $directory_data['user_location_fields'] as $field_key ) {
						$subquery = array(
							'relation' => 'AND',
							array(
								'key'       => $field_key . '_lat',
								'value'     => array( $sw_lat, $ne_lat ),
								'compare'   => 'BETWEEN',
								'type'      => 'DECIMAL(16,14)'
							),
							array(
								'key'       => $field_key . '_lng',
								'value'     => array( $sw_lng, $ne_lng ),
								'compare'   => 'BETWEEN',
								'type'      => 'DECIMAL(17,14)'
							),
						);

						if ( count( $directory_data['user_location_fields'] ) > 1 ) {
							$location_query[] = $subquery;
						} else {
							$query_args['meta_query'][] = $subquery;
						}
					}

					if ( count( $directory_data['user_location_fields'] ) > 1 ) {
						$query_args['meta_query'][] = $location_query;
					}
				}
			}
		}

		return $query_args;
	}


	/**
	 * Replace WP native users query variables to search in radius
	 *
	 * @param $query
	 */
	function change_wp_native_users_query( $query ) {
		if ( ! empty( $query->query_vars['um_location_search'] ) ) {

			$clauses = $query->meta_query->get_clauses();
			$having = ' HAVING ';
			$having_array = array();
			foreach ( $query->query_vars['um_location_search']['fields'] as $field_key ) {
				$query->query_fields .= str_replace('{lat_value}', $clauses[ $field_key . '_lat' ]['alias'] . '.meta_value', str_replace('{lng_value}', $clauses[ $field_key . '_lng' ]['alias'] . '.meta_value', str_replace('{key}', $field_key, $query->query_vars['um_location_search']['select'] ) ) );
				$having_array[] = str_replace('{key}', $field_key, $query->query_vars['um_location_search']['having'] );
			}

			$having .= '( ' . implode( ' OR ', $having_array ) . ' )';

			$query->query_where .= $having;
		}
	}


	/**
	 * @param $query
	 * @param $directory_data
	 * @param $sortby
	 */
	function search_by_coord_meta( $query, $directory_data, $sortby ) {
		global $wpdb;

		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return;
		}

		if ( ! empty( $directory_data['show_map'] ) ) {

			if ( ! empty( $directory_data['map_search_by_moving'] ) ) {

				if ( ! isset( $_POST['map_ne'] ) ) {
					$ne_lat = 90;
					$ne_lng = 180;
				} else {
					$ne_array = explode( ',', $_POST['map_ne'] );
					$ne_array = array_map( 'floatval', $ne_array );

					$ne_lat = $ne_array[0];
					$ne_lng = $ne_array[1];
				}

				if ( ! isset( $_POST['map_sw'] ) ) {
					$sw_lat = -90;
					$sw_lng = -180;
				} else {
					$sw_array = explode( ',', $_POST['map_sw'] );
					$sw_array = array_map( 'floatval', $sw_array );

					$sw_lat = $sw_array[0];
					$sw_lng = $sw_array[1];
				}

				$directory_data['user_location_fields'] = maybe_unserialize( $directory_data['user_location_fields'] );
				if ( is_string( $directory_data['user_location_fields'] ) ) {
					$directory_data['user_location_fields'] = array( $directory_data['user_location_fields'] );
				}

				if ( ! empty( $directory_data['user_location_fields'] ) ) {

					$where = array();
					foreach ( $directory_data['user_location_fields'] as $i => $field_key ) {

						if ( $sw_lng > $ne_lng ) {
							$where[] = $wpdb->prepare( "( CAST( umm_locations_lat{$i}.um_value AS DECIMAL(16,14) ) BETWEEN %f AND %f AND ( CAST( umm_locations_lng{$i}.um_value AS DECIMAL(17,14) ) BETWEEN %f AND %f OR CAST( umm_locations_lng{$i}.um_value AS DECIMAL(17,14) ) BETWEEN %f AND %f ) AND umm_locations_lat{$i}.um_value != '' AND umm_locations_lng{$i}.um_value != '' )", $sw_lat, $ne_lat, $sw_lng, 180, -180, $ne_lng );
						} else {
							$where[] = $wpdb->prepare( "( CAST( umm_locations_lat{$i}.um_value AS DECIMAL(16,14) ) BETWEEN %f AND %f AND CAST( umm_locations_lng{$i}.um_value AS DECIMAL(17,14) ) BETWEEN %f AND %f AND umm_locations_lat{$i}.um_value != '' AND umm_locations_lng{$i}.um_value != '' )", $sw_lat, $ne_lat, $sw_lng, $ne_lng );
						}

						$query->joins[] = $wpdb->prepare( "LEFT JOIN {$wpdb->prefix}um_metadata umm_locations_lat{$i} ON ( umm_locations_lat{$i}.user_id = u.ID AND umm_locations_lat{$i}.um_key = %s )", $field_key . '_lat' );
						$query->joins[] = $wpdb->prepare( "LEFT JOIN {$wpdb->prefix}um_metadata umm_locations_lng{$i} ON ( umm_locations_lng{$i}.user_id = u.ID AND umm_locations_lng{$i}.um_key = %s )", $field_key . '_lng' );
					}

					$query->where_clauses[] = '(' . implode( ' OR ', $where ) . ')';
				}
			}
		}

	}


	/**
	 * @param array $data_array
	 * @param int $user_id
	 * @param array $directory_data
	 *
	 * @return array
	 */
	function add_maps_args( $data_array, $user_id, $directory_data ) {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return $data_array;
		}

		if ( empty( $directory_data['user_location_fields'] ) ) {
			return $data_array;
		}

		$directory_data['user_location_fields'] = maybe_unserialize( $directory_data['user_location_fields'] );
		if ( is_string( $directory_data['user_location_fields'] ) ) {
			$directory_data['user_location_fields'] = array( $directory_data['user_location_fields'] );
		}

		if ( ! empty( $directory_data['map_search_by_moving'] ) && ! empty( $_POST['map_ne'] ) && ! empty( $_POST['map_sw'] ) ) {
			$ne_array = explode( ',', $_POST['map_ne'] );
			$ne_array = array_map( 'floatval', $ne_array );

			$sw_array = explode( ',', $_POST['map_sw'] );
			$sw_array = array_map( 'floatval', $sw_array );

			$ne_lat = $ne_array[0];
			$ne_lng = $ne_array[1];

			$sw_lat = $sw_array[0];
			$sw_lng = $sw_array[1];
		}


		if ( ! empty( $directory_data['user_location_infowindow_data'] ) ) {
			$directory_data['user_location_infowindow_data'] = maybe_unserialize( $directory_data['user_location_infowindow_data'] );

			if ( is_array( $directory_data['user_location_infowindow_data'] ) ) {
				foreach ( $directory_data['user_location_infowindow_data'] as $key ) {
					if ( ! $key ) {
						continue;
					}

					$value = um_filtered_value( $key );

					if ( ! $value ) {
						continue;
					}

					$data_array[ $key ] = $value;
				}
			}
		}

		foreach ( $directory_data['user_location_fields'] as $metakey ) {
			$user_lat = get_user_meta( $user_id, $metakey . '_lat', true );
			$user_lng = get_user_meta( $user_id, $metakey . '_lng', true );

			if ( $user_lat !== '' && $user_lng !== '' ) {

				if ( ! empty( $directory_data['map_search_by_moving'] ) && ! empty( $_POST['map_ne'] ) && ! empty( $_POST['map_sw'] ) ) {

					if ( floatval( $user_lat ) >= $sw_lat && floatval( $user_lat ) <= $ne_lat ) {

						if ( $sw_lng > $ne_lng ) {
							if ( ( floatval( $user_lng ) >= $sw_lng && floatval( $user_lng ) <= 180 ) || ( floatval( $user_lng ) >= -180 && floatval( $user_lng ) <= $ne_lng ) ) {
								$data_array[ $metakey . '_lat' ] = $user_lat;
								$data_array[ $metakey . '_lng' ] = $user_lng;

								$data_array['avatar_url'] = um_get_user_avatar_url( $user_id );
							}
						} else {
							if ( $user_lng >= $sw_lng && $user_lng <= $ne_lng ) {
								$data_array[ $metakey . '_lat' ] = $user_lat;
								$data_array[ $metakey . '_lng' ] = $user_lng;

								$data_array['avatar_url'] = um_get_user_avatar_url( $user_id );
							}
						}
					}

				} else {
					$data_array[ $metakey . '_lat' ] = $user_lat;
					$data_array[ $metakey . '_lng' ] = $user_lng;

					$data_array['avatar_url'] = um_get_user_avatar_url( $user_id );
				}
			}
		}

		return $data_array;
	}


	/**
	 * @param array $response
	 * @param array $directory_data
	 *
	 * @return array
	 */
	function add_maps_fields( $response, $directory_data ) {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return $response;
		}

		if ( empty( $directory_data['user_location_fields'] ) ) {
			return $response;
		}

		$directory_data['user_location_fields'] = maybe_unserialize( $directory_data['user_location_fields'] );
		if ( is_string( $directory_data['user_location_fields'] ) ) {
			$directory_data['user_location_fields'] = array( $directory_data['user_location_fields'] );
		}

		$response['map_fields'] = $directory_data['user_location_fields'];

		return $response;
	}

}