<?php if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class UM_User_Locations
 */
class UM_User_Locations {


	/**
	 * @var
	 */
	private static $instance;


	/**
	 * @return UM_User_Locations
	 */
	static public function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	/**
	 * UM_User_Locations constructor.
	 */
	function __construct() {
		add_filter( 'um_call_object_User_Locations', array( &$this, 'get_this' ) );

		if ( UM()->is_request( 'admin' ) ) {
			$this->admin();
		}

		$this->profile();
		$this->fields();
		$this->enqueue();
		$this->member_directory();
	}


	/**
	 * @return $this
	 */
	function get_this() {
		return $this;
	}


	/**
	 * @return um_ext\um_user_locations\core\Member_Directory()
	 */
	function member_directory() {
		if ( empty( UM()->classes['um_user_locations_member_directory'] ) ) {
			UM()->classes['um_user_locations_member_directory'] = new um_ext\um_user_locations\core\Member_Directory();
		}
		return UM()->classes['um_user_locations_member_directory'];
	}


	/**
	 * @return um_ext\um_user_locations\core\Enqueue()
	 */
	function enqueue() {
		if ( empty( UM()->classes['um_user_locations_enqueue'] ) ) {
			UM()->classes['um_user_locations_enqueue'] = new um_ext\um_user_locations\core\Enqueue();
		}
		return UM()->classes['um_user_locations_enqueue'];
	}


	/**
	 * @return um_ext\um_user_locations\core\Fields()
	 */
	function fields() {
		if ( empty( UM()->classes['um_user_locations_fields'] ) ) {
			UM()->classes['um_user_locations_fields'] = new um_ext\um_user_locations\core\Fields();
		}
		return UM()->classes['um_user_locations_fields'];
	}


	/**
	 * @return um_ext\um_user_locations\core\Profile()
	 */
	function profile() {
		if ( empty( UM()->classes['um_user_locations_profile'] ) ) {
			UM()->classes['um_user_locations_profile'] = new um_ext\um_user_locations\core\Profile();
		}
		return UM()->classes['um_user_locations_profile'];
	}


	/**
	 * @return um_ext\um_user_locations\core\Profile()
	 */
	function admin() {
		if ( empty( UM()->classes['um_user_locations_admin'] ) ) {
			UM()->classes['um_user_locations_admin'] = new um_ext\um_user_locations\core\Admin();
		}
		return UM()->classes['um_user_locations_admin'];
	}


	/**
	 * @return array
	 */
	function get_locale() {
		$default_locale = UM()->options()->get( 'um_google_lang_as_default' );
		if ( $default_locale ) {
			$locale = get_locale();
		} else {
			$locale = UM()->options()->get( 'um_google_lang' );
		}

		$locale = explode( '_', $locale );

		return $locale;
	}

}


if ( ! function_exists( 'um_init_user_locations' ) ) {


	/**
	 * Create class copy
	 */
	function um_init_user_locations() {
		if ( function_exists( 'UM' ) ) {
			UM()->set_class( 'User_Locations', true );
		}
	}
}
add_action( 'plugins_loaded', 'um_init_user_locations', -10, 1 );