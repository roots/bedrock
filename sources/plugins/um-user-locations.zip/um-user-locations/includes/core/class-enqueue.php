<?php
namespace um_ext\um_user_locations\core;


if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Class Enqueue
 *
 * @package um_ext\um_user_locations\core
 */
class Enqueue {


	/**
	 * Enqueue constructor.
	 */
	function __construct() {
		add_action( 'wp_enqueue_scripts', array( &$this, 'enqueue_gmap' ) );
	}


	/**
	 *
	 */
	function enqueue_gmap() {
		$key = UM()->options()->get( 'um_google_maps_js_api_key' );
		if ( empty( $key ) ) {
			return;
		}

		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG || defined( 'UM_SCRIPT_DEBUG' ) ) ? '' : '.min';

		wp_register_style( 'um_user_location_members', um_user_locations_url . 'assets/css/members' . $suffix . '.css' );
		wp_enqueue_style( 'um_user_location_members' );

		wp_register_script(
			'um-user-location-field',
			um_user_locations_url . 'assets/js/user_location_field' . $suffix . '.js',
			array( 'jquery', 'wp-hooks', 'wp-i18n' ),
			um_user_locations_version,
			true
		);

		$start_zoom = UM()->options()->get( 'um_google_maps_starting_zoom' );
		$start_zoom = empty( $start_zoom ) ? 12 : $start_zoom;
		$start_lat = UM()->options()->get( 'um_google_maps_starting_coord_lat' );
		$start_lat = empty( $start_lat ) ? 0 : $start_lat;
		$start_lng = UM()->options()->get( 'um_google_maps_starting_coord_lng' );
		$start_lng = empty( $start_lng ) ? 0 : $start_lng;

		$locale = UM()->User_Locations()->get_locale();
		wp_localize_script('um-user-location-field', 'um_user_location_var', array(
			'api_key'       => UM()->options()->get( 'um_google_maps_js_api_key' ),
			'is_ssl'        => is_ssl(),
			'region'        => $locale[1],
			'start_coords'  => array(
				'lat'   => $start_lat,
				'lng'   => $start_lng,
				'zoom'  => $start_zoom,
			),
		));


		wp_register_script( 'um-maps', um_user_locations_url . 'assets/js/map' . $suffix . '.js', array( 'wp-util', 'wp-hooks', 'wp-i18n', 'um_members' ), um_user_locations_version, true );
		wp_localize_script('um-maps', 'um_user_location_map', array(
			'cluster_url'   => um_user_locations_url . 'assets/img/clusters/m',
			'api_key'       => UM()->options()->get( 'um_google_maps_js_api_key' ),
			'is_ssl'        => is_ssl(),
			'region'        => $locale[1],
		));

		wp_register_script(
			'um-user-location-clustering',
			um_user_locations_url . 'assets/js/libs/markerclustererplus.min.js',
			array('jquery', 'um-maps'),
			um_user_locations_version,
			true
		);
	}

}