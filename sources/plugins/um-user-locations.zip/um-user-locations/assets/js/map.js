if ( typeof ( wp.UM ) !== 'object' ) {
	wp.UM = {};
}

if ( typeof ( wp.UM.member_directory ) !== 'object' ) {
	wp.UM.member_directory = {};
}

wp.UM.member_directory.map = {
	infowindow: {
		customize: function() {
			var iwOuter = jQuery('.gm-style-iw');

			var iwBackground = iwOuter.prev();

			// Removes background shadow DIV
			iwBackground.children(':nth-child(2)').css({'display' : 'none'});

			// Removes white background DIV
			iwBackground.children(':nth-child(4)').css({'display' : 'none'});

			// Moves the infowindow 115px to the right.
			iwOuter.parent().parent().css({left: '115px'});

			// Moves the shadow of the arrow 76px to the left margin.
			iwBackground.children(':nth-child(1)').attr('style', function(i,s){ return s + 'left: 76px !important;'});

			// Moves the arrow 76px to the left margin.
			iwBackground.children(':nth-child(3)').attr('style', function(i,s){ return s + 'left: 76px !important;'});

			// Changes the desired tail shadow color.
			iwBackground.children(':nth-child(3)').find('div').children().css({'box-shadow': 'rgba(72, 181, 233, 0.6) 0px 1px 6px', 'z-index' : '1'});

			// Reference to the div that groups the close button elements.
			var iwCloseBtn = iwOuter.next();

			// Apply the desired effect to the close button
			iwCloseBtn.css({
				opacity: '1',
				right: '48px',
				top: '20px',
				'border-radius': '50%'
			});

			// The API automatically applies 0.7 opacity to the button after the mouseout event. This function reverses this event to the desired value.
			iwCloseBtn.mouseout(function(){
				jQuery(this).css({opacity: '1'});
			});
		},
		close: function( directory, flush ) {
			var hash = um_members_get_hash( directory );

			if ( typeof wp.UM.member_directory.map.blocks[ hash ] === 'undefined' ) {
				return;
			}

			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['infowindows'] !== 'undefined' ) {
				jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['infowindows'], function( user_id ) {
					jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ], function( field ) {
						wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ].close();
					});
				});
			}

			if ( flush ) {
				wp.UM.member_directory.map.blocks[ hash ]['infowindows'] = {};
			}
		}
	},

	remove_markers: function( directory ) {
		var hash = um_members_get_hash( directory );

		if ( typeof wp.UM.member_directory.map.blocks[ hash ] === 'undefined' ) {
			return;
		}

		if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'] === 'undefined' ) {
			wp.UM.member_directory.map.blocks[ hash ]['markers'] = {};
			return;
		}

		if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'] !== 'undefined' ) {
			jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'], function( user_id ) {
				jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ], function( field ) {
					wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ].setMap( null );
				});
			});
		}
		wp.UM.member_directory.map.blocks[ hash ]['markers'] = {};

		wp.UM.member_directory.map.blocks[ hash ]['marker_clusterer'].clearMarkers();
	},

	is_dynamically_searched: function( directory ) {
		return !! directory.find('.um-member-directory-map[data-dynamic-search="1"]').length;
	},

	get_map: function( directory ) {
		var hash = um_members_get_hash( directory );

		if ( typeof wp.UM.member_directory.map.blocks[ hash ] !== 'undefined' ) {
			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['map'] !== 'undefined' ) {
				return wp.UM.member_directory.map.blocks[ hash ]['map'];
			}
		}

		return null;
	},

	move_map: function( map, directory ) {
		if ( um_is_directory_busy( directory ) ) {
			return;
		}

		var bounds =  map.getBounds();
		var ne = bounds.getNorthEast();
		var sw = bounds.getSouthWest();
		var zoom = map.getZoom();

		um_members_show_preloader( directory );

		um_set_url_from_data( directory, 'map_ne',ne.lat() + ',' + ne.lng() );
		um_set_url_from_data( directory, 'map_sw',sw.lat() + ',' + sw.lng() );
		um_set_url_from_data( directory, 'map_zoom', zoom );

		//set 1st page after filtration
		directory.data( 'page', 1 );
		um_set_url_from_data( directory, 'page', '' );

		um_ajax_get_members( directory );

		directory.data( 'searched', 1 );
		directory.find( '.um-member-directory-sorting-options' ).prop( 'disabled', false );
		directory.find( '.um-member-directory-view-type' ).removeClass( 'um-disabled' );
	},

	init: function( directory ) {
		// page first loading
		var directory_map = directory.find( '.um-member-directory-map' );

		if ( directory_map.hasClass( 'um-map-inited' ) ) {
			return;
		}

		var hash = um_members_get_hash( directory );

		wp.UM.member_directory.map.blocks[ hash ] = [];

		var latlng = new google.maps.LatLng( directory_map.data( 'lat' ), directory_map.data( 'lng' ) );
		var zoom = directory_map.data( 'zoom' );
		if ( typeof zoom == 'undefined' ) {
			zoom = 12;
		}

		var map_args = wp.hooks.applyFilters( 'um_user_locations_map_args_init', {
			center: latlng,
			zoom: zoom
		}, hash, directory );

		wp.UM.member_directory.map.blocks[ hash ]['map'] = new google.maps.Map( directory_map[0], map_args );

		if ( wp.UM.member_directory.map.is_dynamically_searched( directory ) ) {
			var map_ne = um_get_data_for_directory( directory, 'map_ne' );
			var map_sw = um_get_data_for_directory( directory, 'map_sw' );
			var map_zoom = um_get_data_for_directory( directory, 'map_zoom' );

			if ( typeof map_ne !== 'undefined' && typeof map_sw !== 'undefined' ) {
				directory_map.removeClass( wp.UM.member_directory.map.classes.hidden );

				var map_ne_array = map_ne.split(',');
				var map_sw_array = map_sw.split(',');

				var bounds = new google.maps.LatLngBounds();
				bounds.extend( new google.maps.LatLng( map_sw_array[0], map_sw_array[1] ) );
				bounds.extend( new google.maps.LatLng( map_ne_array[0], map_ne_array[1] ) );

				wp.UM.member_directory.map.blocks[ hash ]['map'].setZoom( parseInt( map_zoom ) );

				if ( map_sw_array[1]*1 > map_ne_array[1]*1 ) {
					var adjust_lng = ( 180 - map_sw_array[1]*1 + ( -180 - map_ne_array[1]*1 )*-1 ) / 2;

					var c_lng;
					if ( map_sw_array[1]*1 + adjust_lng <= 180 ) {
						c_lng = map_sw_array[1]*1 + adjust_lng;
					} else {
						c_lng = map_ne_array[1]*1 - adjust_lng;
					}

					var center = new google.maps.LatLng( ( map_ne_array[0]*1 + map_sw_array[0]*1 ) / 2, c_lng );

					wp.UM.member_directory.map.blocks[ hash ]['map'].setCenter( center );
				} else {
					wp.UM.member_directory.map.blocks[ hash ]['map'].setCenter( bounds.getCenter() );
				}
			}

			if ( typeof wp.UM.member_directory.map.listeners[ hash ] === 'undefined' ) {
				wp.UM.member_directory.map.listeners[ hash ] = [];
			}
			wp.UM.member_directory.map.listeners[ hash ]['moving'] = google.maps.event.addListener( wp.UM.member_directory.map.blocks[ hash ]['map'], 'idle', function() {

				if ( ! wp.UM.member_directory.map.listeners[ hash ]['skip_first_idle'] ) {
					wp.UM.member_directory.map.listeners[ hash ]['skip_first_idle'] = true;
					return;
				}

				wp.UM.member_directory.map.move_map( this, directory );
			});

			directory.find('.um_user_location_g_autocomplete').each(function() {

				var autocomplete = new google.maps.places.Autocomplete( jQuery(this).get(0), {
					types: ['geocode']
				});

				var location_search = jQuery(this);
				var value = um_get_data_for_directory( directory, 'location_search' );
				if ( typeof value !== 'undefined' ) {
					location_search.val( value );
				}

				autocomplete.addListener( 'place_changed', function(e) {
					if ( um_is_directory_busy( directory ) ) {
						return;
					}

					um_members_show_preloader( directory );

					var place = this.getPlace();

					place = wp.hooks.applyFilters( 'um_user_locations_place_changed_autocomplete', place, directory );

					var lat = place.geometry.location.lat();
					var lng = place.geometry.location.lng();

					um_set_url_from_data( directory, 'location_search', location_search.val() );

					if ( directory.find('.um-member-directory-map').length ) {
						directory_map.removeClass( wp.UM.member_directory.map.classes.hidden );

						wp.UM.member_directory.map.blocks[ hash ]['map'].setCenter({
							lat: parseFloat(lat),
							lng: parseFloat(lng)
						});
						wp.UM.member_directory.map.blocks[ hash ]['map'].fitBounds( place.geometry.viewport );

						var zoom = wp.UM.member_directory.map.blocks[ hash ]['map'].getZoom();
						var ne = place.geometry.viewport.getNorthEast();
						var sw = place.geometry.viewport.getSouthWest();

						um_set_url_from_data( directory, 'map_ne', ne.lat() + ',' + ne.lng() );
						um_set_url_from_data( directory, 'map_sw', sw.lat() + ',' + sw.lng() );
						um_set_url_from_data( directory, 'map_zoom', zoom );

						wp.hooks.doAction( 'um_user_locations_after_place_changed_autocomplete', place, directory, wp.UM.member_directory.map.blocks[ hash ]['map'] );
					}

					//set 1st page after filtration
					directory.data( 'page', 1 );
					um_set_url_from_data( directory, 'page', '' );

					um_ajax_get_members( directory );

					directory.data( 'searched', 1 );
					directory.find( '.um-member-directory-sorting-options' ).prop( 'disabled', false );
					directory.find( '.um-member-directory-view-type' ).removeClass( 'um-disabled' );
				});
			});
		}

		directory_map.addClass( 'um-map-inited' );

		return directory_map;
	},

	ajax: {
		request: function( request, directory ) {

			if ( wp.UM.member_directory.map.is_dynamically_searched( directory ) ) {
				var map_ne = um_get_data_for_directory( directory, 'map_ne' );
				var map_sw = um_get_data_for_directory( directory, 'map_sw' );

				if ( typeof map_ne !== 'undefined' && typeof map_sw !== 'undefined' ) {
					request.map_ne = map_ne;
					request.map_sw = map_sw;
				}
			}

			return request;
		},
		response: function( directory, data ) {
			var hash = um_members_get_hash( directory );
			var directory_map = directory.find('.um-member-directory-map');

			directory_map.removeClass( wp.UM.member_directory.map.classes.hidden );

			var map = wp.UM.member_directory.map.get_map( directory );

			var current_markers = {};
			Object.getOwnPropertyNames( current_markers ).forEach(function ( prop ) {
				delete current_markers[ prop ];
			});

			jQuery.each( data.users, function( key ) {
				var userdata = data.users[ key ];

				if ( typeof current_markers[ userdata.id ] === 'undefined' ) {
					current_markers[ userdata.id ] = {};
				}

				jQuery.each( data.map_fields, function( k, field ) {
					if ( typeof userdata[ field + '_lat' ] !== 'undefined' && typeof userdata[ field + '_lng' ] !== 'undefined' ) {
						var latlng = new google.maps.LatLng( userdata[ field + '_lat' ], userdata[ field + '_lng' ] );

						var suffix;
						if ( userdata['avatar_url'].indexOf( '?' ) === -1 ) {
							suffix = '?um_avatar_marker=1';
						} else {
							suffix = '&um_avatar_marker=1';
						}

						var infowindow_template = wp.template( 'um-user-location-map-marker-infowindow' );

						var infowindow_attr = {
							content: infowindow_template( {
								'field': field,
								'userdata': userdata
							} ),
							maxWidth: 350
						};
						infowindow_attr = wp.hooks.applyFilters( 'um_user_locations_infowindow_data', infowindow_attr, hash, userdata.id );

						current_markers[ userdata.id ][ field ] = {
							position:       latlng,
							map:            map,
							title:          userdata.display_name + ' ' + field,
							member_anchor:  userdata.card_anchor,
							zIndex:         key + 1,
							icon:           {
								url:        userdata['avatar_url'] + suffix,
								scaledSize: new google.maps.Size(32, 32),
								size:       new google.maps.Size(36, 40),
								anchor:     new google.maps.Point(18, 18)
							},
							shape:          {
								coords: [ 18, 18, 20 ],
								type:   'circle'
							},
							optimized:      false,
							infowindow:     infowindow_attr
						};
					}

				});
			});

			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'] === 'undefined' ) {
				wp.UM.member_directory.map.blocks[ hash ]['markers'] = {};
			}

			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['infowindows'] === 'undefined' ) {
				wp.UM.member_directory.map.blocks[ hash ]['infowindows'] = {};
			}

			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['marker_clusterer'] !== 'undefined' ) {
				wp.UM.member_directory.map.blocks[ hash ]['marker_clusterer'].clearMarkers();
			}


			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'] !== 'undefined' ) {
				jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'], function( user_id ) {
					jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ], function( field ) {
						if ( typeof current_markers[ user_id ] === 'undefined' || typeof current_markers[ user_id ][ field ] === 'undefined' ) {
							wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ].setMap( null );
							wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ].close();

							delete wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ];
							if ( ! Object.keys( wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ] ).length ) {
								delete wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ];
							}

							delete wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ];
							if ( ! Object.keys( wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ] ).length ) {
								delete wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ];
							}
						} else {
							delete current_markers[ user_id ][ field ];

							if ( ! Object.keys( current_markers[ user_id ] ).length ) {
								delete current_markers[ user_id ];
							}
						}
					});
				});
			}

			jQuery.each( current_markers, function( user_id ) {
				if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ] === 'undefined' ) {
					wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ] = {};
				}

				if ( typeof wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ] == 'undefined' ) {
					wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ] = {};
				}

				jQuery.each( current_markers[ user_id ], function( field ) {
					wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ] = new google.maps.Marker( current_markers[ user_id ][ field ] );
					wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ] = new google.maps.InfoWindow( current_markers[ user_id ][ field ][ 'infowindow' ] );

					// Click on marker
					wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ].addListener('click', function() {
						wp.UM.member_directory.map.infowindow.close( directory );

						wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ]['status'] = 'open';

						wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ].open(
							map,
							wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ]
						);
					});

					google.maps.event.addListener( wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ], 'closeclick', function() {
						wp.UM.member_directory.map.blocks[ hash ]['infowindows'][ user_id ][ field ]['status'] = 'closed';
					});
				});
			});

			var markers = [];
			if ( typeof wp.UM.member_directory.map.blocks[ hash ]['markers'] !== 'undefined' ) {
				jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'], function( user_id ) {
					jQuery.each( wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ], function( field ) {
						markers.push( wp.UM.member_directory.map.blocks[ hash ]['markers'][ user_id ][ field ] );
					});
				});
			}

			// Add a marker clusterer to manage the markers.
			wp.UM.member_directory.map.blocks[ hash ]['marker_clusterer'] = new MarkerClusterer( map, markers,
				{imagePath: um_user_location_map.cluster_url});
		}
	},
	blocks: [],
	listeners: [],
	classes: {
		hidden: 'um-member-directory-hidden-map'
	}
};


// hide map if isn't search
wp.hooks.addAction( 'um_member_directory_clear_not_searched', 'um_user_locations', function( directory ) {
	if ( ! directory.find('.um-member-directory-map').length ) {
		return;
	}

	directory.find('.um-member-directory-map').addClass( wp.UM.member_directory.map.classes.hidden );
});

// show header if there is map
wp.hooks.addFilter( 'um_member_directory_generate_header', 'um_user_locations', function( generate, directory ) {
	if ( ! directory.find('.um-member-directory-map').length ) {
		return;
	}

	generate = true;
	return generate;
}, 10 );

// fetch user locations markers to map after ajax response
wp.hooks.addAction( 'um_member_directory_loaded', 'um_user_locations', function( directory, data ) {
	if ( ! directory.find('.um-member-directory-map').length ) {
		return;
	}

	wp.UM.member_directory.map.ajax.response( directory, data );
}, 10 );

// extends AJAX request arguments
wp.hooks.addFilter( 'um_member_directory_filter_request', 'um_user_locations', function( request ) {
	var directory = jQuery( '.um-directory[data-hash="' + request.directory_id + '"]' );

	if ( ! directory.length ) {
		return request;
	}

	request = wp.UM.member_directory.map.ajax.request( request, directory );
	return request;
}, 10 );

// ignore show after search/filtering option if we display individual User tag page
wp.hooks.addFilter( 'um_member_directory_ignore_after_search', 'um_user_locations', function( ignore, directory ) {
	if ( ! directory.find('.um-member-directory-map').length ) {
		return;
	}

	if ( wp.UM.member_directory.map.is_dynamically_searched( directory ) ) {
		var map_ne = um_get_data_for_directory( directory, 'map_ne' );
		var map_sw = um_get_data_for_directory( directory, 'map_sw' );

		if ( typeof map_ne !== 'undefined' && typeof map_sw !== 'undefined' ) {
			ignore = true;
		}
	}

	return ignore;
}, 10 );


function um_generate_location_distance_label( slider, ui ) {
	var placeholder = '';
	var placeholder_s = slider.siblings( '.um-location-slider-range' ).data( 'placeholder-s' );
	var placeholder_p = slider.siblings( '.um-location-slider-range' ).data( 'placeholder-p' );


	if ( ui ) {
		if ( ui.value == 1 ) {
			placeholder = placeholder_s.replace( '\{value\}', ui.value )
				.replace( '\{field_label\}', slider.siblings( '.um-location-slider-range' )
					.data('label') );
		} else {
			placeholder = placeholder_p.replace( '\{value\}', ui.value )
				.replace( '\{field_label\}', slider.siblings( '.um-location-slider-range' )
					.data('label') );
		}
	} else {
		if ( slider.slider( 'value' ) == 1 ) {
			placeholder = placeholder_s.replace( '\{value\}', slider.slider( "value" ) )
				.replace( '\{field_label\}', slider.siblings( '.um-location-slider-range' )
					.data('label') );
		} else {
			placeholder = placeholder_p.replace( '\{value\}', slider.slider( "value" ) )
				.replace( '\{field_label\}', slider.siblings( '.um-location-slider-range' )
					.data('label') );
		}
	}
	slider.siblings( '.um-location-slider-range' ).html( placeholder );
}

// in directory loop
wp.hooks.addAction( 'um_member_directory_on_init', 'um_user_locations', function( directory, hash ) {
	//distance slider
	directory.find('.um-location-slider').each( function() {
		var slider = jQuery( this );

		var value = um_get_data_for_directory( directory, 'map_dist' );
		if ( typeof value == 'undefined' ) {
			value = parseInt( slider.data('min') );
		}

		slider.slider({
			range: false,
			min: parseInt( slider.data('min') ),
			max: parseInt( slider.data('max') ),
			value: value,
			create: function( event, ui ) {
				//console.log( ui );
			},
			step: 1,
			slide: function( event, ui ) {
				um_generate_location_distance_label( slider, ui );
				var value = ( ui ) ? ui.value : slider.slider( 'value' );
				slider.siblings( '.um_range_distance' ).val( value );
			},
			stop: function( event, ui ) {

				if ( ! um_is_directory_busy( directory ) ) {
					if ( directory.find('[name="location_lat"]').val() !== '' && directory.find('[name="location_lng"]').val() !== '' ) {
						um_set_url_from_data( directory, 'map_dist', ui.value );

						//set 1st page after filtration
						directory.data( 'page', 1 );
						um_set_url_from_data( directory, 'page', '' );
						um_ajax_get_members( directory );

						directory.find( '.um-member-directory-sorting-options' ).prop( 'disabled', false );
						directory.find( '.um-member-directory-view-type' ).removeClass( 'um-disabled' );
					}
				}
			}
		});

		um_generate_location_distance_label( slider );
		slider.siblings( ".um_range_distance" ).val( slider.slider( 'value' ) );
	});


	directory.find('.um_current_user_location').on('click', function() {
		var $obj = jQuery(this);
		var directory = $obj.parents('.um-directory');
		var autocomplete = $obj.siblings('.um_user_location_g_autocomplete');

		if ( navigator.geolocation || ! um_user_location_var.is_ssl ) {
			navigator.geolocation.getCurrentPosition(function( data ) {
				if ( typeof data.coords != 'undefined' ) {
					// init google geocoder
					geocoder = new google.maps.Geocoder();

					// run geocoder
					geocoder.geocode( {
						latLng : new google.maps.LatLng( data.coords.latitude, data.coords.longitude ),
						region : um_user_location_map.region
					}, function( results, status ) {
						if ( status == google.maps.GeocoderStatus.OK ) { // on success
							if ( typeof results[0].formatted_address != 'undefined' ) {

								var current_location = results[0].formatted_address;
								autocomplete.val( current_location );

								if ( ! um_is_directory_busy( directory ) ) {
									um_members_show_preloader( directory );

									um_set_url_from_data( directory, 'location_search', current_location );

									if ( directory.find('.um-member-directory-map').length ) {
										directory.find('.um-member-directory-map').removeClass( wp.UM.member_directory.map.classes.hidden );

										wp.UM.member_directory.map.blocks[ hash ]['map'].setCenter({
											lat: parseFloat( data.coords.latitude ),
											lng: parseFloat( data.coords.longitude )
										});
										wp.UM.member_directory.map.blocks[ hash ]['map'].fitBounds( results[0].geometry.viewport );

										var zoom = wp.UM.member_directory.map.blocks[ hash ]['map'].getZoom();
										var ne = results[0].geometry.viewport.getNorthEast();
										var sw = results[0].geometry.viewport.getSouthWest();

										um_set_url_from_data( directory, 'map_ne',ne.lat() + ',' + ne.lng() );
										um_set_url_from_data( directory, 'map_sw',sw.lat() + ',' + sw.lng() );
										um_set_url_from_data( directory, 'map_zoom', zoom );
									}

									//set 1st page after filtration
									directory.data( 'page', 1 );
									um_set_url_from_data( directory, 'page', '' );

									um_ajax_get_members( directory );

									directory.data( 'searched', 1 );
									directory.find( '.um-member-directory-sorting-options' ).prop( 'disabled', false );
									directory.find( '.um-member-directory-view-type' ).removeClass( 'um-disabled' );
								}

							}
						} else { // on failed
							jQuery.support.cors = true;
							jQuery.ajax({
								url: 'https://freegeoip.app/json/',
								type: 'GET',
								crossDomain: true,
								dataType: 'jsonp',
								success: function ( response ) {
									if ( typeof response.country_name != 'undefined' ) {

										var current_location = response.country_name + ',' + response.region_name + ',' + response.city;
										$obj.prev().val( current_location );

										if ( ! um_is_directory_busy( directory ) ) {
											um_members_show_preloader( directory );

											if ( directory.find('.um-member-directory-map').length ) {
												directory.find('.um-member-directory-map').removeClass( wp.UM.member_directory.map.classes.hidden );

												wp.UM.member_directory.map.blocks[ hash ]['map'].setCenter({
													lat: parseFloat( data.coords.latitude ),
													lng: parseFloat( data.coords.longitude )
												});
												wp.UM.member_directory.map.blocks[ hash ]['map'].fitBounds( results[0].geometry.viewport );

												var zoom = wp.UM.member_directory.map.blocks[ hash ]['map'].getZoom();
												var ne = results[0].geometry.viewport.getNorthEast();
												var sw = results[0].geometry.viewport.getSouthWest();

												um_set_url_from_data( directory, 'map_ne',ne.lat() + ',' + ne.lng() );
												um_set_url_from_data( directory, 'map_sw',sw.lat() + ',' + sw.lng() );
												um_set_url_from_data( directory, 'map_zoom', zoom );
											}

											um_set_url_from_data( directory, 'location_search', current_location );

											//set 1st page after filtration
											directory.data( 'page', 1 );
											um_set_url_from_data( directory, 'page', '' );

											um_ajax_get_members( directory );

											directory.data( 'searched', 1 );
											directory.find( '.um-member-directory-sorting-options' ).prop( 'disabled', false );
											directory.find( '.um-member-directory-view-type' ).removeClass( 'um-disabled' );
										}

									} else {
										alert( wp.i18n.__( 'Can not get your current location', 'um-user-locations' ) );
									}
								},
								error: function ( data ) {
									alert( wp.i18n.__( 'Can not get your current location', 'um-user-locations' ) );
								}
							});
						}
					});
				}
			});
		}
		return false;
	});
}, 10 );


function UMInitUserLocationDirectory() {
	jQuery( '.um-directory' ).each( function() {
		var directory = jQuery(this);
		wp.UM.member_directory.map.init( directory );
	});
}


var um_ul_script = document.createElement('script');
um_ul_script.src = '//maps.googleapis.com/maps/api/js?key=' + um_user_location_map.api_key + '&libraries=places&callback=UMInitUserLocationDirectory';
if ( um_user_location_map.region ) {
	um_ul_script.src += '&language=' + um_user_location_map.region;
}
document.body.appendChild( um_ul_script );