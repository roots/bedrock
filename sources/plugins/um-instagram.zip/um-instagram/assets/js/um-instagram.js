if (typeof (window.UM) !== 'object') {
	window.UM = {};
}

window.UM.instagram = {
	ajax: {
		disconnect: function (request) {

			request = jQuery.extend(request || {}, {
				action: 'um_instagram_disconnect',
				dataType: 'json',
				metakey: UM.instagram.block.content.attr('data-metakey'),
				um_user_id: UM.instagram.block.content.attr('data-user_id'),
				nonce: um_scripts.nonce
			});

			return jQuery.ajax({
				method: 'POST',
				url: wp.ajax.settings.url,
				data: request,
				dataType: 'json',
				success: function (response) {
					if (typeof (response) === 'object') {
						console.log(response.message);
					}
				},
				error: function (e) {
					console.log(e);
				}
			});
		},
		get_photos: function (request) {

			request = jQuery.extend(request || {}, {
				action: 'um_instagram_get_photos',
				dataType: 'json',
				metakey: UM.instagram.block.content.attr('data-metakey'),
				um_user_id: UM.instagram.block.content.attr('data-user_id'),
				nonce: um_scripts.nonce
			});

			return jQuery.ajax({
				method: 'POST',
				url: wp.ajax.settings.url,
				data: request,
				dataType: 'json',
				beforeSend: function (xhr) {
					UM.instagram.block.preload.css({'backgroundImage': 'url(' + um_instagram.image_loader + ')'}).fadeIn();
				},
				success: function (response) {
					if (typeof (response) === 'object') {

						UM.instagram.data = jQuery.extend(UM.instagram.data, {
							details: response.details || false,
							offset: 0,
							shownPhotos: response.photos.slice(0, 6),
							photos: response.photos,
							total: response.photos.length
						});

						UM.instagram.template.paginate(UM.instagram.data);
						UM.instagram.template.photos(UM.instagram.data);
						UM.instagram.preload();
					}
				},
				error: function (e) {
					console.log(e);
				}
			});
		}
	},
	block: {
		connect: null,
		content: jQuery('#um-ig-content'),
		disconnect: null,
		gallery: jQuery('#um-ig-show_photos'),
		input: null,
		navigation: null,
		paginate: null,
		preload: jQuery('#um-ig-preload'),
		wrap: jQuery('#um-ig-photo-wrap')
	},
	data: {
		offset: 0,
		photos: {},
		total: 0
	},
	getBlocks: function () {
		if (UM.instagram.block.content.length) {
			UM.instagram.block.connect = UM.instagram.block.content.siblings('.um-connect-instagram');
			UM.instagram.block.disconnect = UM.instagram.block.content.siblings('.um-ig-photos_disconnect');
			UM.instagram.block.input = UM.instagram.block.content.siblings('.um-ig-photos_metakey');
			UM.instagram.block.navigation = UM.instagram.block.content.find('.um-ig-photo-navigation');
			UM.instagram.block.paginate = UM.instagram.block.content.find('.um-ig-paginate');
		}
		return UM.instagram.block;
	},
	preload: function () {

		// Show preload
		UM.instagram.block.content.addClass('hidden');
		UM.instagram.block.preload.show();

		// Make square thumbnails
		setTimeout(function () {
			UM.instagram.resize();

			// Remove preload
			UM.instagram.block.content.removeClass('hidden').fadeIn();
			UM.instagram.block.preload.hide();
		}, 800);

		// Add photo opacity effects on hover
		UM.instagram.block.content.find('a img').hover(function (e) {
			jQuery(e.currentTarget).stop().animate({"opacity": 0.7});
		}, function (e) {
			jQuery(e.currentTarget).stop().animate({"opacity": 1});
		});
	},
	resize: function () {
		var $cells = UM.instagram.block.gallery.find('.um-ig-cell').removeAttr('style');
		$cells.find('img').removeAttr('style');

		$cells.each(function (i, item) {
			var $cell = jQuery(item);
			var size = $cell.width();

			// var $img = $cell.find('img');
			// if ($img.height() > $img.width()) {
			// 	$img.css({
			// 		position: 'relative',
			// 		top: -($img.height() - size) / 2 + 'px'
			// 	});
			// }
			// if ($img.height() < $img.width()) {
			// 	var newWidth = size * $img.width() / $img.height();
			// 	$img.css({
			// 		height: size + 'px',
			// 		maxWidth: newWidth + 'px',
			// 		position: 'relative',
			// 		left: -(newWidth - size) / 2 + 'px'
			// 	});
			// }
			$cell.css({height: size + 'px', width: size + 'px'});
		});

		return $cells;
	},
	setup: function () {
		UM.instagram.getBlocks();

		if (!UM.instagram.block.content.length) {
			return;
		}

		// Disconnect Instagram account
		if (UM.instagram.block.disconnect && UM.instagram.block.disconnect.length) {
			UM.instagram.block.disconnect.on('click', function () {
				UM.instagram.block.input.val('');
				UM.instagram.block.connect.show().siblings().hide();
				UM.instagram.ajax.disconnect();
			});
		}

		// Photos
		if (!UM.instagram.block.gallery.length) {
			UM.instagram.ajax.get_photos({get_details: true}).done(function (response) {
				if (typeof (response) === 'object' && !response.has_error) {
					UM.instagram.setup();
				} else if (UM.instagram.block.content.closest('.um').hasClass('um-viewing')) {
					UM.instagram.block.content.closest('.um-field.um-field-instagram_photo').hide();
				}
			});
			return;
		}

		// Navigation
		UM.instagram.template.navigation(UM.instagram.data);

		// Details
		if (UM.instagram.data.details) {
			UM.instagram.block.content.append(UM.instagram.data.details);
			UM.instagram.block.paginate = jQuery('#um-ig-content .um-ig-paginate');
			UM.instagram.template.paginate(UM.instagram.data);
		}

		jQuery(window).on('resize', UM.instagram.resize);
	},
	showNext: function () {

		var offset = Math.min(UM.instagram.data.offset + 6, UM.instagram.data.photos.length);

		UM.instagram.block.preload.css({height: UM.instagram.block.content.height() + 'px'});
		UM.instagram.data = jQuery.extend(UM.instagram.data, {
			offset: offset,
			shownPhotos: UM.instagram.data.photos.slice(offset, offset + 6)
		});

		UM.instagram.template.paginate(UM.instagram.data);
		UM.instagram.template.photos(UM.instagram.data);
		UM.instagram.preload();

		if (offset + 6 >= UM.instagram.data.total) {
			UM.instagram.block.nav_next.hide();
		}
		UM.instagram.block.nav_previous.show();
	},
	showPrev: function () {
		var offset = Math.max(UM.instagram.data.offset - 6, 0);

		UM.instagram.block.preload.css({height: UM.instagram.block.content.height() + 'px'});
		UM.instagram.data = jQuery.extend(UM.instagram.data, {
			offset: offset,
			shownPhotos: UM.instagram.data.photos.slice(offset, offset + 6)
		});

		UM.instagram.template.paginate(UM.instagram.data);
		UM.instagram.template.photos(UM.instagram.data);
		UM.instagram.preload();

		if (offset - 6 < 0) {
			UM.instagram.block.nav_previous.hide();
		}
		UM.instagram.block.nav_next.show();
	},
	template: {
		navigation: function (data, parent) {
			data = data || UM.instagram.data;
			parent = parent || UM.instagram.block.content;

			if (UM.instagram.block.navigation.length) {
				return UM.instagram.block.navigation;
			}
			if (UM.instagram.data.photos <= 6) {
				return false;
			}

			var html = '';
			html += '<div class="um-ig-photo-navigation">';
			html += '	<a href="javascript:void(0);" class="nav-left nav-show"><i class="um-faicon-arrow-left"></i></a>';
			html += '	<a href="javascript:void(0);" class="nav-right nav-show"><i class="um-faicon-arrow-right"></i></a>';
			html += '</div>';

			UM.instagram.block.navigation = parent.append(html).find('.um-ig-photo-navigation');

			// Previous
			UM.instagram.block.nav_previous = UM.instagram.block.navigation.find('a.nav-left');
			UM.instagram.block.nav_previous.on('click', UM.instagram.showPrev);
			if (UM.instagram.data.offset - 6 < 0) {
				UM.instagram.block.nav_previous.hide();
			}

			// Next
			UM.instagram.block.nav_next = UM.instagram.block.navigation.find('a.nav-right');
			UM.instagram.block.nav_next.on('click', UM.instagram.showNext);
			if (UM.instagram.data.offset + 6 > UM.instagram.data.total) {
				UM.instagram.block.nav_next.hide();
			}

			return UM.instagram.block.gallery;
		},
		paginate: function (data, wrapper) {
			wrapper = wrapper || UM.instagram.block.paginate;
			data = jQuery.extend(UM.instagram.data, {
				firstSeen: data.offset + 1,
				lastSeen: Math.min(data.offset + 6, data.total)
			});

			var html = '<span>' + data.firstSeen + ' - ' + data.lastSeen + '/' + data.total + '</span>';

			wrapper.html(html);
		},
		photos: function (data, wrapper) {
			wrapper = wrapper || UM.instagram.block.wrap;
			data = jQuery.extend(UM.instagram.data, data || {});

			if (!data.shownPhotos) {
				console.log('UM Instagram Warning: Empty photos data.');
				return false;
			}

			var html = '';

			html += '<div class="um-ig-grid" id="um-ig-show_photos" data-offset="' + data.offset + '" data-photos-count="' + data.total + '">';

			for (var i in data.shownPhotos) {
				var photo = data.shownPhotos[i];

				html += '<div class="um-ig-cell">';
				html += '	<a class="um-photo-modal" href="' + photo.images.standard_resolution.url + '" data-src="' + photo.images.standard_resolution.url + '">';
				html += '		<img class="um-lazy" src="' + photo.images.thumbnail.url + '" data-original="' + photo.images.standard_resolution.url + '" />';
				html += '	</a>';
				html += '</div>';
			}

			while (++i < 6 || i % 6 !== 0) {
				html += '<div class="um-ig-photo-placeholder"></div>';
			}

			html += '</div>';

			return UM.instagram.block.gallery = wrapper.html(html).find('#um-ig-show_photos');
		}
	}
};

jQuery(function () {
	UM.instagram.setup();
});