ERROR: You must supply at least one file or directory to process.

Run "phpcbf --help" for usage information

