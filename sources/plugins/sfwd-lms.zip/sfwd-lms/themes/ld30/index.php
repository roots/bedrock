<?php
/**
 * LearnDash ld30 template init.
 *
 * @package LearnDash
 */
require_once __DIR__ . '/includes/class-ld-themes-register.php';
require_once __DIR__ . '/includes/class-ld-settings-section-theme-ld30.php';
