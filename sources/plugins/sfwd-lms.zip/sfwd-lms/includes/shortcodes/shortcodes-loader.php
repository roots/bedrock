<?php
/**
 * LearnDash Shortcodes Loader.
 *
 * @package LearnDash
 * @subpackage Shorrcodes
 */

require_once __DIR__ . '/ld_certificate.php';
require_once __DIR__ . '/ld_quiz_complete.php';
require_once __DIR__ . '/ld_course_resume.php';
