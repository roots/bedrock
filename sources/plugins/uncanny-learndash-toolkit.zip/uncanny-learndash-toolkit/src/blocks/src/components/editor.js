export const ToolkitPlaceholder = ({ children }) => {
	return (
		<div className="uo-ult-toolkit-content">
			{ children }
		</div>
	);
}