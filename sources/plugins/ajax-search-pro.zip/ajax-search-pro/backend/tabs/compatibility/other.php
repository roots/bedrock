<div class="item">
    <?php
    $o = new wpdreamsCustomPostTypesAll("meta_box_post_types", __('Display the Ajax Search Pro meta box on these post types', 'ajax-search-pro'),
        $com_options['meta_box_post_types']);
    ?>
</div>