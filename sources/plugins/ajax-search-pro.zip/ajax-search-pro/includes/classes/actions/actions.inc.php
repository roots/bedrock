<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASP_CLASSES_PATH . "actions/class-asp-abstract.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-cookies.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-footerstuff.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-stylesheets.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-compatibility.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-customfonts.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-indextable.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-updates.php");
require_once(ASP_CLASSES_PATH . "actions/class-asp-otheractions.php");