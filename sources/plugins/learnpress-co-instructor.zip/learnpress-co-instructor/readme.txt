
== Changelog ==
= 3.0.6 =
~ Fixed bug send email notification withou enable send mail.

= 3.0.5 =
+ Update pre get posts

= 3.0.4 =
+ Fix co-instructor courses tab in profile

= 3.0.3 =
+ Compatible wit Learnpress Assignment 3.0.0

= 3.0.2 =
+ Update single course template

= 3.0.1 =
+ Fix issue instructor can view course item

= 3.0.0 =
+ Compatible with Learnpress 3.0.0

