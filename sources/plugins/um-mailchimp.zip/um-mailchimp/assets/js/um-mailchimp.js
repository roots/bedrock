/*
 Plugin Name: Ultimate Member - MailChimp
 Description: Frontend panel scripts
 Version: 2.2.4
 Author: Ultimate Member
 Author URI: http://ultimatemember.com/
 */

if ( typeof (window.UM) !== 'object' ) {
	window.UM = {};
}

window.UM.mailchimp = {
	block: {},
	data: {},
	handler: {
		toggleAudienceSection: function (input) {
			UM.mailchimp.block.section = jQuery(input).closest('.um-account-fieldset').find('section.um-account-fieldset-dropdown');
			input.checked ? UM.mailchimp.block.section.show(200) : UM.mailchimp.block.section.hide(200);
		}
	},
	setup: function () {
		UM.mailchimp.block.checkboxes = jQuery('.um-account-fieldset > .um-field-checkbox input[type="checkbox"]');
		UM.mailchimp.block.checkboxes.on('change', function (e) {
			UM.mailchimp.handler.toggleAudienceSection(e.target);
		}).each(function (i, item) {
			UM.mailchimp.handler.toggleAudienceSection(item);
		});
	}
};

jQuery(function () {
	UM.mailchimp.setup();
});