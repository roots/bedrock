<?php if ( ! defined( 'ABSPATH' ) ) exit;


/**
 * Field option "Select a audience"
 *
 * @param string $val
 */
function um_admin_field_edit_hook_mailchimp_list( $val ) {

	$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();
	if ( ! $wp_lists ) {
		return;
	}
	?>

	<p>
		<label for="_mailchimp_list"><?php _e( 'Select a audience', 'um-mailchimp' ); ?> <?php UM()->tooltip( __( 'You can set up audiences or integrations in Ultimate Member > MailChimp', 'um-mailchimp' ) ); ?></label>
		<select name="_mailchimp_list" id="_mailchimp_list" style="width: 100%">

			<?php foreach ( $wp_lists as $wp_list ) { ?>
				<option value="<?php echo esc_attr( $wp_list->ID ); ?>" <?php selected( $wp_list->ID, $val ); ?>><?php echo $wp_list->post_title; ?></option>
			<?php } ?>

		</select>
	</p>

	<?php
}
add_action( 'um_admin_field_edit_hook_mailchimp_list', 'um_admin_field_edit_hook_mailchimp_list' );


/**
 * Field option "Automatically add users to this audience"
 *
 * @param string $val
 */
function um_admin_field_edit_hook_mailchimp_auto_subscribe( $val ) {
	?>
	<p>
		<label for="_mailchimp_auto_subscribe">
			<?php
			_e( 'Automatically add users to this audience', 'um-mailchimp' );
			UM()->tooltip( __( 'If turned on users will be subscribed to audience on form submit. When turned on this audience will appear selected.', 'um-mailchimp' ) );
			?>
		</label>
		<input type="checkbox" name="_mailchimp_auto_subscribe" id="_mailchimp_auto_subscribe" value="1" <?php checked( $val, '1' ) ?> />
	</p>
	<?php
}
add_action( 'um_admin_field_edit_hook_mailchimp_auto_subscribe', 'um_admin_field_edit_hook_mailchimp_auto_subscribe' );


/**
 * Hidden fields on the Registration page
 *
 * @hook 'um_after_register_fields'
 * @deprecated since version 2.2.0
 *
 * @param type $val
 * @return boolean
 */
function um_mailchimp_after_register_fields( $val ) {

	$wp_lists = UM()->Mailchimp()->api()->get_wp_lists();
	if ( ! $wp_lists ) {
		return;
	}

	foreach ( $wp_lists as $wp_list ) {
		if ( $wp_list->_um_status && $wp_list->_um_reg_status ) {
			echo '<input type="hidden" name="um-mailchimp[' . esc_attr( $wp_list->ID ) . ']" value="1" />';
		}
	}
}