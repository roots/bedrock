<?php
namespace um_ext\um_mailchimp\core;

// Exit if accessed directly.
if ( !defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for AJAX handlers
 *
 * @example UM()->classes['um_mailchimp_ajax']
 * @example UM()->Mailchimp()->ajax()
 */
class Ajax {

	/**
	 * Class constructor
	 */
	public function __construct() {

		add_action( 'wp_ajax_um_mailchimp_clear_log', array( $this, 'ajax_clear_log' ) );
		add_action( 'wp_ajax_um_mailchimp_get_merge_fields', array( $this, 'ajax_get_merge_fields' ) );

		add_action( 'wp_ajax_um_mailchimp_test_subscribe', array( $this, 'ajax_test_subscribe' ) );
		add_action( 'wp_ajax_um_mailchimp_test_update', array( $this, 'ajax_test_update' ) );
		add_action( 'wp_ajax_um_mailchimp_test_unsubscribe', array( $this, 'ajax_test_unsubscribe' ) );
		add_action( 'wp_ajax_um_mailchimp_test_delete', array( $this, 'ajax_test_delete' ) );
	}


	/**
	 * Clear file mailchimp.log
	 */
	public function ajax_clear_log() {
		UM()->admin()->check_ajax_nonce();

		UM()->Mailchimp()->log()->clear();
	}


	/**
	 * AJAX handler: Get metabox "Merge User Meta"
	 */
	public function ajax_get_merge_fields() {
		check_ajax_referer( 'um_mailchimp_get_merge_fields', 'nonce' );

		$list_id = filter_input( INPUT_POST, 'list_id' );
		if ( empty( $list_id ) ) {
			wp_send_json_error( 'Empty list ID' );
		}

		ob_start();
		include_once um_mailchimp_path . 'includes/admin/templates/merge.php';
		$content = ob_get_clean();

		wp_send_json_success( array(
			'list'					 => UM()->Mailchimp()->api()->mc_get_list( $list_id ),
			'merge_content'	 => $content
		) );
	}


	/**
	 * AJAX handler: Test subscribe
	 */
	public function ajax_test_subscribe() {
		UM()->admin()->check_ajax_nonce();

		$data = ! empty( $_POST['test_data'] ) ? $_POST['test_data'] : array();
		if ( method_exists( UM(), 'clean_array' ) ) {
			$data = UM()->clean_array( $data );
		}

		if ( ! empty( $data['_um_test_email'] ) && is_email( $data['_um_test_email'] ) ) {
			$email = $data['_um_test_email'];
			unset( $data['_um_test_email'] );
		} else {
			wp_send_json_error( __( 'Please enter email', 'um-mailchimp' ) );
		}

		if ( ! empty( $data['list_id'] ) ) {
			$list_id = $data['list_id'];
			unset( $data['list_id'] );
		} else {
			wp_send_json_error( __( 'Please select list', 'um-mailchimp' ) );
		}

		$status = apply_filters( 'um_mailchimp_default_subscription_status', 'subscribed', 'subscribe', $list_id, $email );

		$request_data = array(
			'email_address' => $email,
			'status'        => $status
		);

		$merge_fields = UM()->Mailchimp()->api()->prepare_data( $data );
		if( $merge_fields ){
			$request_data['merge_fields'] = $merge_fields;
		}

		$response = UM()->Mailchimp()->api()->call()->post( "lists/{$list_id}/members/", $request_data );

		wp_send_json_success( array(
			'result'    => ! empty( $response['id'] ),
			'message'   => json_encode( UM()->Mailchimp()->log()->remove_links( $response ) )
		) );
	}


	/**
	 * AJAX handler: Test update
	 */
	public function ajax_test_update() {
		UM()->admin()->check_ajax_nonce();

		$data = ! empty( $_POST['test_data'] ) ? $_POST['test_data'] : array();
		if ( method_exists( UM(), 'clean_array' ) ) {
			$data = UM()->clean_array( $data );
		}

		if ( ! empty( $data['_um_test_email'] ) && is_email( $data['_um_test_email'] ) ) {
			$email = $data['_um_test_email'];
			unset( $data['_um_test_email'] );
		} else {
			wp_send_json_error( __( 'Please enter email', 'um-mailchimp' ) );
		}

		if ( ! empty( $data['list_id'] ) ) {
			$list_id = $data['list_id'];
			unset( $data['list_id'] );
		} else {
			wp_send_json_error( __( 'Please select list', 'um-mailchimp' ) );
		}

		$status = apply_filters( 'um_mailchimp_default_subscription_status', 'subscribed', 'update', $list_id, $email );

		$request_data = array(
			'email_address' => $email,
			'status'        => $status
		);
		
		$merge_fields = UM()->Mailchimp()->api()->prepare_data( $data );
		if( $merge_fields ){
			$request_data['merge_fields'] = $merge_fields;
		}

		$subscriber_hash = UM()->Mailchimp()->api()->get_user_hash( $email );
		$response = UM()->Mailchimp()->api()->call()->patch( "lists/{$list_id}/members/{$subscriber_hash}", $request_data );

		wp_send_json_success( array(
			'result'    => ! empty( $response['id'] ),
			'message'   => json_encode( UM()->Mailchimp()->log()->remove_links( $response ) )
		) );
	}


	/**
	 * AJAX handler: Test unsubscribe
	 */
	public function ajax_test_unsubscribe() {
		UM()->admin()->check_ajax_nonce();

		$data = ! empty( $_POST['test_data'] ) ? $_POST['test_data'] : array();
		if ( method_exists( UM(), 'clean_array' ) ) {
			$data = UM()->clean_array( $data );
		}

		if ( ! empty( $data['_um_test_email'] ) && is_email( $data['_um_test_email'] ) ) {
			$email = $data['_um_test_email'];
			unset( $data['_um_test_email'] );
		} else {
			wp_send_json_error( __( 'Please enter email', 'um-mailchimp' ) );
		}

		if ( ! empty( $data['list_id'] ) ) {
			$list_id = $data['list_id'];
			unset( $data['list_id'] );
		} else {
			wp_send_json_error( __( 'Please select list', 'um-mailchimp' ) );
		}

		$request_data = array(
			'email_address' => $email,
			'status'        => 'unsubscribed'
		);

		$subscriber_hash = UM()->Mailchimp()->api()->get_user_hash( $email );
		$response = UM()->Mailchimp()->api()->call()->patch( "lists/{$list_id}/members/{$subscriber_hash}", $request_data );

		wp_send_json_success( array(
			'result'    => ! empty( $response['id'] ),
			'message'   => json_encode( UM()->Mailchimp()->log()->remove_links( $response ) )
		) );
	}


	/**
	 * AJAX handler: Test delete
	 */
	public function ajax_test_delete() {
		UM()->admin()->check_ajax_nonce();

		$data = ! empty( $_POST['test_data'] ) ? $_POST['test_data'] : array();
		if ( method_exists( UM(), 'clean_array' ) ) {
			$data = UM()->clean_array( $data );
		}

		if ( ! empty( $data['_um_test_email'] ) && is_email( $data['_um_test_email'] ) ) {
			$email = $data['_um_test_email'];
			unset( $data['_um_test_email'] );
		} else {
			wp_send_json_error( __( 'Please enter email', 'um-mailchimp' ) );
		}

		if ( ! empty( $data['list_id'] ) ) {
			$list_id = $data['list_id'];
			unset( $data['list_id'] );
		} else {
			wp_send_json_error( __( 'Please select list', 'um-mailchimp' ) );
		}

		$subscriber_hash = UM()->Mailchimp()->api()->get_user_hash( $email );
		$response = UM()->Mailchimp()->api()->call()->delete( "lists/{$list_id}/members/{$subscriber_hash}" );

		wp_send_json_success( array(
			'result'    => empty( $response ),
			'message'   => empty( $response ) ? '' : json_encode( $response )
		) );
	}

}