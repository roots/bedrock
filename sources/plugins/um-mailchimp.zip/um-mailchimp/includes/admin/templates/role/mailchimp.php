<div class="um-admin-metabox">

	<?php
	$role = $object['data'];

	UM()->admin_forms( array(
		'class'			 => 'um-role-mailchimp um-half-column',
		'prefix_id'	 => 'role',
		'fields'		 => array(
			array(
				'id'			 => '_um_can_manage_mc_groups',
				'type'		 => 'checkbox',
				'label'		 => __( 'Can manage groups?', 'um-mailchimp' ),
				'tooltip'	 => __( 'Display audience groups fields under Account?', 'um-mailchimp' ),
				'value'		 => isset( $role['_um_can_manage_mc_groups'] ) ? $role['_um_can_manage_mc_groups'] : 1,
			),
			array(
				'id'			 => '_um_can_manage_mc_tags',
				'type'		 => 'checkbox',
				'label'		 => __( 'Can manage tags?', 'um-mailchimp' ),
				'tooltip'	 => __( 'Display audience `Tags` field under Account?', 'um-mailchimp' ),
				'value'		 => isset( $role['_um_can_manage_mc_tags'] ) ? $role['_um_can_manage_mc_tags'] : 1,
			),
			array(
				'id'					 => '_um_can_create_mc_tags',
				'type'				 => 'checkbox',
				'label'				 => __( 'Can create tags?', 'um-mailchimp' ),
				'tooltip'			 => __( 'Display audience `Add New Tags` field under Account?', 'um-mailchimp' ),
				'value'				 => isset( $role['_um_can_create_mc_tags'] ) ? $role['_um_can_create_mc_tags'] : 0,
				'conditional'	 => array( '_um_can_manage_mc_tags', '=', 1 )
			),
		)
	) )->render_form();
	?>

	<div class="um-admin-clear"></div>
</div>