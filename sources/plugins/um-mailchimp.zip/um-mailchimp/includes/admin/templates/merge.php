<?php
if ( !defined( 'ABSPATH' ) ) exit;

/* Get $list_id */
if ( empty( $list_id ) && !empty( $post_id ) ) {
	$list_id = get_post_meta( $post_id, '_um_list', true );
}
if ( empty( $list_id ) ) {
	$lists = UM()->Mailchimp()->api()->get_lists();
	if ( count( $lists ) ) {
		$list_id = current( array_keys( $lists ) );
	}
}

/* Get fields relationships */
$merged = get_post_meta( $post_id, '_um_merge', true );

/* Get Ultimate Member's fields and split them by types */
$options_array = array();
$options_date = array();
$options_string = array();

$merge_vars = UM()->builtin()->all_user_fields();
foreach ( $merge_vars as $k => $var ) {
	if ( empty( $var['title'] ) ) {
		continue;
	}

	$options_string[$k] = $var['title'];

	switch ( $k ) {
		case 'gender':
		case 'role_radio':
		case 'role_select':
			$options_array[$k] = $var['title'];
			break;

		case 'user_registered':
			$options_date[$k] = $var['title'];
			break;

		default:
			$options_string[$k] = $var['title'];
			break;
	}

	$type = UM()->fields()->get_field_type( $k );
	switch ( $type ) {
		case 'multiselect':
		case 'radio':
		case 'select':
		case 'user_tags':
			$options_array[$k] = $var['title'];
			break;

		case 'date':
		case 'time':
			$options_date[$k] = $var['title'];
			break;

		default:
			$options_string[$k] = $var['title'];
			break;
	}
}

/* Get MailChimp's fields and prepare data to display */
$fields = array();

$mc_merge_fields = UM()->Mailchimp()->api()->mc_get_merge_fields( $list_id );
foreach ( $mc_merge_fields as $arr ) {

	$_label = $arr['name'] . ' <sup>(' . $arr['tag'] . ')</sup>';
	$_tooltip = __( 'Type: ', 'um-mailchimp' ) . $arr['type'];
	$_options = array();
	$_value = isset( $merged[$arr['tag']] ) ? $merged[$arr['tag']] : '';
	$_description = '';

	// Type
	switch ( $arr['type'] ) {
		case 'dropdown':
		case 'radio':
			$_options = $options_array;
			if ( isset( $arr['options'] ) && is_array( $arr['options']['choices'] ) ) {
				$_tooltip .= '<br>' . __( 'Choices: ', 'um-mailchimp' ) . implode( ', ', $arr['options']['choices'] );
				if ( $_value ) {
					$field_data = UM()->builtin()->get_a_field( $_value );
					if ( empty( $field_data['options'] ) || array_values( $field_data['options'] ) !== array_values( $arr['options']['choices'] ) ) {
						$_description .= __( "Warning! Choices doesn't match", 'um-mailchimp' );
						$_description .= ' <span class="um_tooltip dashicons dashicons-editor-help" title="' . __( 'MC Choices: ', 'um-mailchimp' ) . implode( ', ', (array) $arr['options']['choices'] ) . '<br><br>' . __( 'UM Choices: ', 'um-mailchimp' ) . implode( ', ', (array) $field_data['options'] ) . '"></span>';
					}
				}
			}
			break;

		case 'birthday':
		case 'date':
			$_options = $options_date;
			break;

		default:
			$_options = $options_string;
			break;
	}

	// Required
	if ( empty( $arr['required'] ) ) {
		$_options = array_merge( array( '0' => __( '~Ignore this field~', 'um-mailchimp' ) ), $_options );
	} else {
		$_label .= ' <span class="um_tooltip dashicons dashicons-warning" title="' . __( 'This field is required', 'um-mailchimp' ) . '"></span>';
		if ( empty( $_value ) ) {
			$_description .= __( "Warning! This fiels is required", 'um-mailchimp' );
		}
	}

	$fields[] = array(
		'id'					 => $arr['tag'],
		'type'				 => 'select',
		'size'				 => 'long',
		'label'				 => $_label,
		'tooltip'			 => $_tooltip,
		'options'			 => apply_filters( 'um_mailchimp_merge_field_options', $_options, $arr, $list_id ),
		'value'				 => $_value,
		'description'	 => $_description,
	);
}
?>

<div class="um-admin-metabox">

	<?php
	UM()->admin_forms( array(
		'class'			 => 'um-form-mailchimp-merge um-half-column',
		'fields'		 => $fields,
		'prefix_id'	 => 'mailchimp[_um_merge]'
	) )->render_form();
	?>

	<div class="um-admin-clear"></div>
</div>