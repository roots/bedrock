<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<p class="folder-info">
	<?php echo $count; ?> <?php echo $text; ?>
	&nbsp;
	&bull;
	&nbsp;
	<?php echo $access_type; ?>
</p>