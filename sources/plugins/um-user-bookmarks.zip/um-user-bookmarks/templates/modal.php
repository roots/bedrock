<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="um-user-bookmarks-modal">
	<div class="um-user-bookmarks-modal-content"><?php _e( 'Loading..', 'um-user-bookmarks' ) ?></div>
</div>