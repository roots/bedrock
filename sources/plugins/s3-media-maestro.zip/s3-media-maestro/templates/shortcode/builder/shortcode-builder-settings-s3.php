<script type="text/x-template" id="s3mm-shortcode-builder-settings-s3">
    <div class="s3mm-shortcode-builder-settings-s3 s3mm-shortcode-builder-settings">
        <s3mm-notices></s3mm-notices>
        <s3mm-form-field classes="first">
            <span class="desc"><?php printf( __( 'If you have media files in a separate AWS S3 account that you\'d like add, you can enter those credentials here. This is only for a one time use, these settings are not sticky and will not override the global S3 Keys defined in the <a href="%s" target="_blank">S3 Media Maestro Amazon S3 settings page</a>.', 's3mm' ), add_query_arg( array( 'page' => 's3mm' ), admin_url( 'options-general.php' ) ) ); ?></span>
        </s3mm-form-field>
        <s3mm-form-field>
            <label><?php esc_html_e( 'S3 Access Key ID', 's3mm' ); ?></label>
            <input class="text-password" type="text" placeholder="<?php esc_html_e( 'S3 Access Key ID', 's3mm' ); ?>" v-model.trim="s3AccessKey">
            <span class="desc"><?php _e( 'This is usually a string of characters like this: <code>AKTFIOHGHWW53KA8ETA</code>', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field>
            <label><?php esc_html_e( 'S3 Secret Key', 's3mm' ); ?></label>
            <input spellcheck="false" class="text-password" type="text" placeholder="<?php esc_html_e( 'S3 Secret Key', 's3mm' ); ?>" v-model.trim="s3SecretKey">
            <span class="desc"><?php _e( 'This is usually a string of characters like this: <code>J1u5mip523JFQPJVYEMzqE6qG+Y3bZC7tfm/37T3</code>', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field v-if="s3Loaded">
            <span class="label"><?php esc_html_e( 'S3 Bucket', 's3mm' ); ?></span>
            <s3mm-form-field-buckets builder="true"></s3mm-form-field-buckets>
            <span class="desc"><?php esc_html_e( 'The amazon s3 bucket that will be used to serve your files.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field v-if="s3Loaded" classes="last">
            <label><?php esc_html_e( 'S3 Expiry', 's3mm' ); ?></label>
            <div class="input-with-end-label">
                <input type="text" v-model="s3expiry" placeholder="Default S3 Expiry"/>
                <span class="end-label"><?php esc_html_e( 'minutes', 's3mm' ); ?></span>
            </div>
            <span class="desc"><?php _e( 'The expiry time of an s3 link. Recommend between <code>1 to 30</code> minutes.', 's3mm' ); ?></span>
        </s3mm-form-field>
    </div>
</script>
