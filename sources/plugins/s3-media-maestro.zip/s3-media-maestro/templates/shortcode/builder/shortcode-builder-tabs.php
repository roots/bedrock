<script type="text/x-template" id="s3mm-shortcode-builder-tabs">
    <div class="s3mm-shortcode-builder-tabs">
        <div class="s3mm-shortcode-builder-tabs-nav">
            <a v-for="tab in tabs" href="#" class="tab" :class="{ 'active' : tab.isActive }" @click.prevent="selectTab( tab )">
                {{ tab.name }}
            </a>
        </div>
        <div class="s3mm-shortcode-builder-tabs-content">
            <slot></slot>
        </div>
    </div>
</script>