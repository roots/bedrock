<script type="text/x-template" id="s3mm-shortcode-builder">
    <div id="s3mm-shortcode-builder-modal" class="s3mm-shortcode-builder s3mm-mfp-hide">

        <div class="s3mm-shortcode-builder-title">
            <h1><img src="<?php echo $this->image( 's3mm-icon.svg' ); ?>" alt="<?php esc_html_e( 'S3 Media Maestro' , 's3mm' ); ?>" /> <?php esc_html_e( 'Insert', 's3mm' ); ?> {{ title }}</h1>
        </div>

        <s3mm-shortcode-builder-shortcode></s3mm-shortcode-builder-shortcode>

        <s3mm-shortcode-builder-types>
            <s3mm-shortcode-builder-type id="video" title="<?php esc_html_e( 'Video', 's3mm' ); ?>" icon="dashicons-format-video" :active="true">
                <s3mm-shortcode-builder-type-video></s3mm-shortcode-builder-type-video>
            </s3mm-shortcode-builder-type>

            <s3mm-shortcode-builder-type id="audio" title="<?php esc_html_e( 'Audio', 's3mm' ); ?>" icon="dashicons-playlist-audio">
                <s3mm-shortcode-builder-type-audio></s3mm-shortcode-builder-type-audio>
            </s3mm-shortcode-builder-type>

            <s3mm-shortcode-builder-type id="file" title="<?php esc_html_e( 'File', 's3mm' ); ?>" icon="dashicons-media-default">
                <s3mm-shortcode-builder-type-file></s3mm-shortcode-builder-type-file>
            </s3mm-shortcode-builder-type>
        </s3mm-shortcode-builder-types>

        <div class="s3mm-shortcode-builder-toolbar">
            <div class="s3mm-shortcode-builder-toolbar-inner">
                <div class="s3mm-shortcode-builder-toolbar-primary">
                    <button class="button button-secondary button-large" @click.prevent="close">
                        <i class="fa fa-window-close-o" aria-hidden="true"></i>
						<?php esc_html_e( 'Cancel', 's3mm' ); ?>
                    </button>
                    <button v-if="! isBlock" class="button button-primary button-large" :class="{ 'disabled' : ready }" @disabled="ready" @click.prevent="insertShortcode">
                        <i class="fa fa-download" aria-hidden="true"></i>
						<?php esc_html_e( 'Insert', 's3mm' ); ?> {{ title }} <?php esc_html_e( 'Shortcode', 's3mm' ); ?>
                    </button>
	                <button v-if="isBlock" class="button button-primary button-large" :class="{ 'disabled' : ready }" @disabled="ready" @click.prevent="insertShortcodeBlock">
		                <i class="fa fa-download" aria-hidden="true"></i>
		                <?php esc_html_e( 'Insert', 's3mm' ); ?> {{ title }} <?php esc_html_e( 'Block', 's3mm' ); ?>
	                </button>
                </div>
            </div>
        </div>
    </div>
</script>
