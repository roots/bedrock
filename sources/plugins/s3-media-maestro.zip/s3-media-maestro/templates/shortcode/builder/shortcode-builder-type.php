<script type="text/x-template" id="s3mm-shortcode-builder-type">
    <div v-show="isActive" class="s3mm-shortcode-builder-type">
        <slot></slot>
    </div>
</script>