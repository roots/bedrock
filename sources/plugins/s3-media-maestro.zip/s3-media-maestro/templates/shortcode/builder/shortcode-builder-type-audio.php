<script type="text/x-template" id="s3mm-shortcode-builder-type-audio">
    <div class="s3mm-shortcode-builder-type-audio s3mm-shortcode-builder-type">
        <s3mm-shortcode-builder-tabs>
            <s3mm-shortcode-builder-tab id="file" name="<?php esc_html_e( 'Audio', 's3mm' ); ?>" :selected="true">
                <s3mm-form-field classes="first">
                    <label for="audioSource"><?php esc_html_e( 'Audio Source', 's3mm' ); ?></label>
                    <select id="audioSource" v-model="source">
                        <option disabled value=""><?php esc_html_e( 'Select Audio Type', 's3mm' ); ?></option>
                        <option value="s3"><?php esc_html_e( 'S3 Audio', 's3mm' ); ?></option>
                        <option value="non-s3"><?php esc_html_e( 'Non-S3 Audio', 's3mm' ); ?></option>
                        <option value="cloudfront"><?php esc_html_e( 'CloudFront Audio', 's3mm' ); ?></option>
                    </select>
                </s3mm-form-field>

                <s3mm-shortcode-builder-form-s3 v-if="source === 's3'" label="<?php esc_html_e( 'Select an Audio File', 's3mm' ); ?>" icon="fa-volume-up" typeLabel="<?php esc_html_e( 'Audio File', 's3mm' ); ?>" type="audio"></s3mm-shortcode-builder-form-s3>
                <s3mm-shortcode-builder-form-non-s3 v-if="source === 'non-s3'" label="<?php esc_html_e( 'Select an Audio File', 's3mm' ); ?>" icon="fa-volume-up" typeLabel="<?php esc_html_e( 'Audio File', 's3mm' ); ?>" type="audio"></s3mm-shortcode-builder-form-non-s3>
                <s3mm-shortcode-builder-form-cloudfront v-if="source === 'cloudfront'" label="<?php esc_html_e( 'Select an Audio File', 's3mm' ); ?>" icon="fa-volume-up" typeLabel="<?php esc_html_e( 'Audio File', 's3mm' ); ?>" type="audio"></s3mm-shortcode-builder-form-cloudfront>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab id="player" name="<?php esc_html_e( 'Player', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-player></s3mm-shortcode-builder-settings-player>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab v-if="source === 's3'" id="s3-settings" name="<?php esc_html_e( 'S3 Settings', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-s3></s3mm-shortcode-builder-settings-s3>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab v-if="source === 'cloudfront'" id="cloudfront-settings" name="<?php esc_html_e( 'CloudFront Settings', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-cloudfront></s3mm-shortcode-builder-settings-cloudfront>
            </s3mm-shortcode-builder-tab>

	        <?php if ( $this->is_wpcw_unit_enabled() ) { ?>
		        <s3mm-shortcode-builder-tab v-if="source === 's3'" id="wpcw-settings" name="<?php esc_html_e( 'WP Courseware Settings', 's3mm' ); ?>">
			        <s3mm-shortcode-builder-settings-wpcw></s3mm-shortcode-builder-settings-wpcw>
		        </s3mm-shortcode-builder-tab>
	        <?php } ?>

	        <?php if ( $this->is_wpcw_course_enabled() ) { ?>
		        <s3mm-shortcode-builder-tab v-if="(source === 's3') && isUnitModal" id="wpcw-settings" name="<?php esc_html_e( 'WP Courseware Settings', 's3mm' ); ?>">
			        <s3mm-shortcode-builder-settings-wpcw></s3mm-shortcode-builder-settings-wpcw>
		        </s3mm-shortcode-builder-tab>
	        <?php } ?>
        </s3mm-shortcode-builder-tabs>
    </div>
</script>
