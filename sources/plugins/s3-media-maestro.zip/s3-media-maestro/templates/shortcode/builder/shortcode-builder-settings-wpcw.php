<script type="text/x-template" id="s3mm-shortcode-builder-settings-wpcw">
	<div class="s3mm-shortcode-builder-settings-wpcw s3mm-shortcode-builder-settings">
		<s3mm-notices></s3mm-notices>

		<s3mm-form-field classes="first">
			<span v-if="builderType === 'video'" class="label"><?php esc_html_e( 'Video is required to play to progress to the next unit?', 's3mm' ); ?></span>
			<span v-if="builderType === 'audio'" class="label"><?php esc_html_e( 'Audio file is required to play to progress to the next unit?', 's3mm' ); ?></span>
			<div class="checkbox">
				<label for="requireMedia">
					<input type="checkbox" id="requireMedia" value="no" v-model="requireMedia"/>
					<span v-if="builderType === 'video'" class="checkbox-label"><?php esc_html_e( 'Yes, this video is required to play before progressing to the next unit.', 's3mm' ); ?></span>
					<span v-if="builderType === 'audio'" class="checkbox-label"><?php esc_html_e( 'Yes, this audio file is required to play before progressing to the next unit.', 's3mm' ); ?></span>
				</label>
			</div>
			<span v-if="builderType === 'video'"
			      class="desc"><?php esc_html_e( 'By making this video required the "mark as completed" button will be hidden and seeking forward on the video will be disabled. When the video is complete the previous and next buttons will be shown or the user will progress to the next unit automatically depending on the settings below. If more than one video is required, the system will wait until the last video requirement is met before being allowed to progress to the next unit.', 's3mm' ); ?></span>
			<span v-if="builderType === 'audio'"
			      class="desc"><?php esc_html_e( 'By making this audio file required the "mark as completed" button will be hidden and seeking forward on the audio will be disabled. When the audio file is complete the previous and next buttons will be shown or the user will progress to the next unit automatically depending on the settings below. If more than one audio file is required, the system will wait until the last audio requirement is met before being allowed to progress to the next unit.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field v-if="requireMedia">
			<span class="label"><?php esc_html_e( 'Progress Control', 's3mm' ); ?></span>
			<span class="radio">
		        <label for="controlType">
			        <input type="radio" id="controlType" value="button" v-model="controlType"/>
			        <span class="radio-label"><?php esc_html_e( 'Next / Previous Button', 's3mm' ); ?></span>
		        </label>
	        </span>
			<span class="radio">
		        <label for="controlTypeAuto">
			        <input type="radio" id="controlTypeAuto" value="auto" v-model="controlType"/>
			        <span class="radio-label"><?php esc_html_e( 'Progress Automatically', 's3mm' ); ?></span>
		        </label>
	        </span>
			<span v-if="builderType === 'video'"
			      class="desc"><?php esc_html_e( 'Choose the progress control type that will determine how the user will progress to the next unit once the video is complete. If there is more than one video the progress control settings from the last video will be used.', 's3mm' ); ?></span>
			<span v-if="builderType === 'audio'"
			      class="desc"><?php esc_html_e( 'Choose the progress control type that will determine how the user will progress to the next unit once the audio is complete. If there is more than one audio file the progress control settings from the last audio file will be used.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field v-if="requireMedia" classes="last">
			<label v-if="builderType === 'video'"><?php esc_html_e( 'Video Percent ( optional )', 's3mm' ); ?></label>
			<label v-if="builderType === 'audio'"><?php esc_html_e( 'Audio Percent ( optional )', 's3mm' ); ?></label>
			<div class="input-with-end-label">
				<input type="text" v-model="mediaPercent" placeholder="<?php esc_html__( 'Video Percent', 's3mm' ); ?>"/>
				<span class="end-label"><?php esc_html_e( '%', 's3mm' ); ?></span>
			</div>
			<span v-if="builderType === 'video'" class="desc"><?php _e( 'The amount of time that should elapse before the video is considered complete. If using a playlist, this setting applies to each video within the playlist.', 's3mm' ); ?></span>
			<span v-if="builderType === 'audio'" class="desc"><?php _e( 'The amount of time that should elapse before the audio is considered complete. If using a playlist, this setting applies to each audio file within the playlist.', 's3mm' ); ?></span>
		</s3mm-form-field>
	</div>
</script>
