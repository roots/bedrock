<script type="text/x-template" id="s3mm-shortcode-builder-settings-link">
    <div class="s3mm-shortcode-builder-settings-link s3mm-shortcode-builder-settings">
        <s3mm-form-field classes="first">
            <label for="linkAnchor"><?php esc_html_e( 'Link Anchor Text', 's3mm' ); ?></label>
            <input type="text" id="linkAnchor" v-model="linkAnchor" placeholder="<?php esc_html_e( 'Link Anchor Text', 's3mm' ); ?>">
            <span class="desc"><?php esc_html_e( 'The text to use for the download link.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field>
            <label for="linkAttributes"><?php esc_html_e( 'Link Attributes', 's3mm' ); ?></label>
            <input type="text" id="linkAttributes" v-model="linkAttributes" placeholder="<?php esc_html_e( 'Link Attributes', 's3mm' ); ?>">
            <span class="desc"><?php esc_html_e( 'The optional HTML attributes to add to the link.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field classes="last">
            <label for="linkNewTab"><?php esc_html_e( 'Open link in new tab?', 's3mm' ); ?></label>
            <select id="linkNewTab" v-model="linkNewTab">
                <option disabled value=""><?php esc_html_e( 'Please select', 's3mm' ); ?></option>
                <option value="yes"><?php esc_html_e( 'Yes', 's3mm' ); ?></option>
                <option value="no"><?php esc_html_e( 'No', 's3mm' ); ?></option>
            </select>
        </s3mm-form-field>
    </div>
</script>
