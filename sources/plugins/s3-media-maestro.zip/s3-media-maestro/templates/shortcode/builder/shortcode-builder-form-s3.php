<script type="text/x-template" id="s3mm-shortcode-builder-form-s3">
    <div class="s3mm-shortcode-builder-form-s3 s3mm-shortcode-builder-form">
        <s3mm-form-field>
            <span class="label"><?php _e( 'S3 {{ upperCaseType }} Bucket', 's3mm' ); ?></span>
            <s3mm-form-field-buckets></s3mm-form-field-buckets>
            <span class="desc"><?php esc_html_e( 'The amazon s3 bucket that will be used to select your files.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field classes="last">
            <span class="label"><?php _e( 'S3 {{ upperCaseType }} Files', 's3mm' ); ?></span>
            <s3mm-form-field-files></s3mm-form-field-files>
            <span class="desc"><?php esc_html_e( 'The {{ type }} files to be inserted.', 's3mm' ); ?></span>
        </s3mm-form-field>
    </div>
</script>