<script type="text/x-template" id="s3mm-shortcode-builder-type-file">
    <div class="s3mm-shortcode-builder-type-file s3mm-shortcode-builder-type">
        <s3mm-shortcode-builder-tabs>
            <s3mm-shortcode-builder-tab id="file" name="<?php esc_html_e( 'File', 's3mm' ); ?>" :selected="true">
                <s3mm-form-field classes="first">
                    <label for="fileSource"><?php esc_html_e( 'File Source', 's3mm' ); ?></label>
                    <select id="fileSource" v-model="source">
                        <option disabled value=""><?php esc_html_e( 'Select File Type', 's3mm' ); ?></option>
                        <option value="s3"><?php esc_html_e( 'S3 File', 's3mm' ); ?></option>
                        <option value="cloudfront"><?php esc_html_e( 'CloudFront File', 's3mm' ); ?></option>
                    </select>
                </s3mm-form-field>

                <s3mm-shortcode-builder-form-s3 v-if="source === 's3'" label="<?php esc_html_e( 'Select a File', 's3mm' ); ?>" icon="fa-file" typeLabel="<?php esc_html_e( 'File', 's3mm' ); ?>" type="file"></s3mm-shortcode-builder-form-s3>
                <s3mm-shortcode-builder-form-cloudfront v-if="source === 'cloudfront'" label="<?php esc_html_e( 'Select a File', 's3mm' ); ?>" icon="fa-file" typeLabel="<?php esc_html_e( 'File', 's3mm' ); ?>" type="file"></s3mm-shortcode-builder-form-cloudfront>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab id="link-settings" name="<?php esc_html_e( 'Link', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-link></s3mm-shortcode-builder-settings-link>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab v-if="source === 's3'" id="s3-settings" name="<?php esc_html_e( 'S3 Settings', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-s3></s3mm-shortcode-builder-settings-s3>
            </s3mm-shortcode-builder-tab>

            <s3mm-shortcode-builder-tab v-if="source === 'cloudfront'" id="cloudfront-settings" name="<?php esc_html_e( 'CloudFront Settings', 's3mm' ); ?>">
                <s3mm-shortcode-builder-settings-cloudfront></s3mm-shortcode-builder-settings-cloudfront>
            </s3mm-shortcode-builder-tab>
        </s3mm-shortcode-builder-tabs>
    </div>
</script>
