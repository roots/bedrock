<script type="text/x-template" id="s3mm-shortcode-builder-settings-player">
	<div class="s3mm-shortcode-builder-settings-player s3mm-shortcode-builder-settings">
		<s3mm-form-field classes="first">
			<span class="label"><?php esc_html_e( 'Player Type', 's3mm' ); ?></span>
			<?php foreach ( $this->get_media_players() as $player_id => $player ) { ?>
				<span class="radio">
                    <label for="<?php printf( 'player%s', $player_id ); ?>">
                        <input type="radio" id="<?php printf( 'player%s', $player_id ); ?>" value="<?php echo $player_id; ?>" v-model="playerType"/>
	                    <?php if ( ! empty( $player['url'] ) ) { ?>
		                    <span class="radio-label"><a target="_blank" href="<?php echo esc_url_raw( $player['url'] ); ?>"><?php echo esc_attr( $player['name'] ); ?></a></span>
	                    <?php } else { ?>
		                    <span class="radio-label"><?php echo esc_attr( $player['name'] ); ?></span>
	                    <?php } ?>
                    </label>
                </span>
			<?php } ?>
			<span class="desc"><?php esc_html_e( 'Choose the player type to be used to play your audio / video files.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<?php foreach ( $this->get_media_players() as $player_id => $player ) { ?>
			<s3mm-form-field v-if="playerType === '<?php echo $player_id; ?>' && builderType === 'video'">
				<label for="playerSkin"><?php esc_html_e( 'Player Skin', 's3mm' ); ?></label>
				<select id="playerSkin" v-model="playerSkin">
					<option disabled value=""><?php esc_html_e( 'Select a Skin', 's3mm' ); ?></option>
					<?php if ( ! empty( $player['skins'] ) ) { ?>
						<?php foreach ( $player['skins'] as $skin_key => $skin ) { ?>
							<option value="<?php echo $skin_key; ?>"><?php echo ( $skin['label'] ) ? $skin['label'] : ucfirst( $skin_key ); ?></option>
						<?php } ?>
					<?php } ?>
				</select>
				<span class="desc"><?php esc_html_e( 'The look and feel of the player when it is displayed.', 's3mm' ); ?></span>
			</s3mm-form-field>
		<?php } ?>

		<s3mm-form-field v-if="builderType === 'video'">
			<label><?php esc_html_e( 'Player Splash Image', 's3mm' ); ?></label>
			<div class="input-with-end-button splash-image">
				<input type="text" v-model.trim="playerSplashImg" placeholder="<?php esc_html_e( 'Player Splash Image', 's3mm' ); ?>"/>
				<button class="button button-primary end-button" @click.prevent="displayMediaUploader">
					<i class="fa fa-picture-o" aria-hidden="true"></i>
					<?php esc_html_e( 'Select Image', 's3mm' ); ?>
				</button>
			</div>
			<span class="desc"><?php esc_html_e( 'Select an image or enter a full url of an image to display before playback of a video.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field>
			<label for="playerVolume"><?php esc_html_e( 'Player Volume', 's3mm' ); ?></label>
			<select id="playerVolume" v-model="playerVolume">
				<option disabled value=""><?php esc_html_e( 'Select Volume', 's3mm' ); ?></option>
				<?php for ( $volume = 100; $volume >= 0; $volume -= 5 ) { ?>
					<option value="<?php echo( $volume / 100 ); ?>"><?php echo $volume; ?>%</option>
				<?php } ?>
			</select>
			<span class="desc"><?php esc_html_e( 'The default volume of the player when initially displayed.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field>
			<span class="label"><?php esc_html_e( 'Player Size', 's3mm' ); ?></span>
			<span class="radio">
                <label for="playerSizeResponsive">
                    <input type="radio" id="playerSizeResponsive" value="responsive" v-model="playerSize"/>
                    <span class="radio-label"><?php esc_html_e( 'Responsive', 's3mm' ); ?></span>
                </label>
            </span>
			<span class="radio">
                <label for="playerSizeFixed">
                    <input type="radio" id="playerSizeFixed" value="fixed" v-model="playerSize"/>
                    <span class="radio-label"><?php esc_html_e( 'Fixed', 's3mm' ); ?></span>
                </label>
            </span>
			<span class="desc"><?php esc_html_e( 'The default size of the video / audio player.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field v-if="playerSize === 'fixed' && builderType === 'video'">
			<label for="playerWidth"><?php esc_html_e( 'Video Player Width', 's3mm' ); ?></label>
			<div class="input-with-end-label">
				<input type="text" placeholder="<?php esc_html_e( 'Video Player Width', 's3mm' ); ?>" id="playerWidth" v-model="playerWidth">
				<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
			</div>
			<span class="desc"><?php esc_html_e( 'The width of the video player.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field v-if="playerSize === 'fixed' && builderType === 'video'">
			<label for="playerHeight"><?php esc_html_e( 'Video Player Height', 's3mm' ); ?></label>
			<div class="input-with-end-label">
				<input id="playerHeight" v-model="playerHeight" placeholder="<?php esc_html_e( 'Video Player Height', 's3mm' ); ?>" type="text">
				<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
			</div>
			<span class="desc"><?php esc_html_e( 'The height of the video player.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field v-if="playerSize === 'fixed' && builderType === 'audio'">
			<label for="playerAudioWidth"><?php esc_html_e( 'Audio Player Width', 's3mm' ); ?></label>
			<div class="input-with-end-label">
				<input id="playerAudioWidth" v-model="playerAudioWidth" placeholder="<?php esc_html_e( 'Audio Player Width', 's3mm' ); ?>" type="text">
				<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
			</div>
			<span class="desc"><?php esc_html_e( 'The default width of audio player.', 's3mm' ); ?></span>
		</s3mm-form-field>


		<s3mm-form-field v-if="playerSize === 'fixed' && builderType === 'audio'">
			<label for="playerAudioHeight"><?php esc_html_e( 'Audio Player Height:', 's3mm' ); ?></label>
			<div class="input-with-end-label">
				<input id="playerAudioHeight" v-model="playerAudioHeight" placeholder="<?php esc_html_e( 'Audio Player Height', 's3mm' ); ?>" type="text">
				<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
			</div>
			<span class="desc"><?php esc_html_e( 'The default height of audio player.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<s3mm-form-field>
			<label for="playerPreLoad"><?php esc_html_e( 'Player Metadata', 's3mm' ); ?></label>
			<select id="playerPreLoad" v-model="playerPreLoad">
				<option disabled value=""><?php esc_html_e( 'Select Metadata Setting', 's3mm' ); ?></option>
				<option value="auto"><?php esc_html_e( 'Auto (Recommended)', 's3mm' ); ?></option>
				<option value="metadata"><?php esc_html_e( 'Metadata', 's3mm' ); ?></option>
				<option value="none"><?php esc_html_e( 'None', 's3mm' ); ?></option>
			</select>
			<span class="desc"><?php esc_html_e( 'Should the player metadata be loaded.', 's3mm' ); ?></span>
		</s3mm-form-field>

		<?php if ( $this->is_protection_enabled() ) { ?>
			<s3mm-form-field>
				<span class="label"><?php esc_html_e( 'Protect Source', 's3mm' ); ?></span>
				<span class="radio">
                <label for="playerProtecSrcYes">
                    <input type="radio" id="playerProtecSrcYes" value="yes" v-model="playerProtectSrc"/>
                    <span class="radio-label"><?php esc_html_e( 'Yes', 's3mm' ); ?></span>
                </label>
            </span>
				<span class="radio">
                <label for="playerProtecSrcNo">
                    <input type="radio" id="playerProtecSrcNo" value="no" v-model="playerProtectSrc"/>
                    <span class="radio-label"><?php esc_html_e( 'No', 's3mm' ); ?></span>
                </label>
            </span>
				<span class="desc"><?php esc_html_e( 'This setting will allow you to protect your video/audio "source" so others cannot download your video/audio file.', 's3mm' ); ?></span>
			</s3mm-form-field>
		<?php } ?>

		<s3mm-form-field classes="last">
			<span class="label"><?php esc_html_e( 'Other Player Settings', 's3mm' ); ?></span>
			<div class="checkbox">
				<label for="playerAutoPlay">
					<input type="checkbox" id="playerAutoPlay" value="yes" v-model="playerAutoPlay"/>
					<span class="checkbox-label"><?php esc_html_e( 'Autoplay', 's3mm' ); ?></span>
				</label>
			</div>

			<div class="checkbox">
				<label for="playerLoop">
					<input type="checkbox" id="playerLoop" value="yes" v-model="playerLoop"/>
					<span class="checkbox-label"><?php esc_html_e( 'Loop Playback', 's3mm' ); ?></span>
				</label>
			</div>
		</s3mm-form-field>
	</div>
</script>
