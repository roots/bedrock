<script type="text/x-template" id="s3mm-shortcode-builder-tab">
    <div v-show="isActive" class="s3mm-shortcode-builder-tab">
        <slot></slot>
    </div>
</script>