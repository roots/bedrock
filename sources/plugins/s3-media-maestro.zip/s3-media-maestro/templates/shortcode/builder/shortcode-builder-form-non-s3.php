<script type="text/x-template" id="s3mm-shortcode-builder-form-non-s3">
	<div class="s3mm-shortcode-builder-form-non-s3 s3mm-shortcode-builder-form">
        <s3mm-form-field>
            <label for="nonS3Files"><?php esc_html_e( 'Non-S3 {{ upperCaseType}} File Url', 's3mm' ); ?></label>

            <input v-if="type === 'file'" type="text" id="nonS3Files" v-model="nonS3Files" placeholder="<?php esc_html_e( 'Non-S3 File Url', 's3mm' ); ?>">
            <input v-if="type === 'audio'" type="text" id="nonS3Files" v-model="nonS3Files" placeholder="<?php esc_html_e( 'Non-S3 Audio File Url', 's3mm' ); ?>">
            <input v-if="type === 'video'" type="text" id="nonS3Files" v-model="nonS3Files" placeholder="<?php esc_html_e( 'Non-S3 Video File Url', 's3mm' ); ?>">

            <span v-if="type !== 'file'" class="desc"><?php _e( '<strong>( Required )</strong> The URL of the {{ type }} file to play. If adding multiple {{ type }} URLs, separate each one with a comma and be sure to use the same file type for all {{ type }} files in a playlist.', 's3mm' ); ?></span>

            <span v-if="type === 'file'" class="desc"><?php _e( '<strong>( Required )</strong> The URL of the file.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field>
            <label for="nonS3Titles"><?php _e( 'Non-S3 {{ upperCaseType }} File Titles', 's3mm' ); ?></label>

            <input v-if="type === 'file'" type="text" id="nonS3Titles" v-model="nonS3Titles" placeholder="<?php esc_html_e( 'Non-S3 File Titles', 's3mm' );?>">
            <input v-if="type === 'audio'" type="text" id="nonS3Titles" v-model="nonS3Titles" placeholder="<?php esc_html_e( 'Non-S3 Audio File Titles', 's3mm' );?>">
            <input v-if="type === 'video'" type="text" id="nonS3Titles" v-model="nonS3Titles" placeholder="<?php esc_html_e( 'Non-S3 Video File Titles', 's3mm' );?>">

            <span v-if="type !== 'file'" class="desc"><?php _e( '<strong>( Optional )</strong> These are the friendly titles for your {{ type }} files. Comma separate each {{ type }} title. They will match the {{ type }} file names in the field above respectively.', 's3mm' ); ?></span>

            <span v-if="type === 'file'" class="desc"><?php _e( '<strong>( Optional )</strong> These are the friendly titles for your files. Comma separate each title. They will match the file names in the field above respectively.', 's3mm' ); ?></span>
        </s3mm-form-field>
	</div>
</script>