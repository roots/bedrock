<script type="text/x-template" id="s3mm-shortcode-builder-shortcode">
    <div class="s3mm-shortcode-builder-shortcode">
        <div class="s3mm-shortcode-builder-display-inner">
            {{ s3mmShortCode }}
        </div>
    </div>
</script>