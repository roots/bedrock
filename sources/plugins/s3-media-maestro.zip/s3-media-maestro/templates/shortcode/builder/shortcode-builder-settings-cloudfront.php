<script type="text/x-template" id="s3mm-shortcode-builder-settings-cloudfront">
    <div class="s3mm-shortcode-builder-settings-cloudfront s3mm-shortcode-builder-settings">
        <s3mm-form-field classes="first">
            <span class="desc"><?php printf( __( 'If you have media files in a separate CloudFront distribution that you’d like add, you can enter that here. This is only for a one time use, these settings are not sticky and will not override the global CloudFront URL defined in the <a href="%s" target="_blank">S3 Media Maestro CloudFront settings page.</a>', 's3mm' ), add_query_arg( array( 'page' => 's3mm', 'tab' => 'cloudfront' ), admin_url( 'options-general.php' ) ) ); ?></span>
        </s3mm-form-field>
        <s3mm-form-field>
            <label for="cfExpiry"><?php esc_html_e( 'Cloudfront Expiry', 's3mm' ); ?></label>
            <div class="input-with-end-label">
                <input type="text" id="cfExpiry" v-model="cfExpiry" placeholder="<?php esc_html_e( 'Cloudfront Expiry', 's3mm' ); ?>">
                <span class="end-label"><?php esc_html_e( 'minutes', 's3mm' ); ?></span>
            </div>
            <span class="desc"><?php _e( 'The expiry time for a Cloudfront link. Recommend between <code>1 to 30</code> minutes.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field classes="last">
            <label for="cfDistUrl"><?php esc_html_e( 'Cloudfront Distribution URL', 's3mm' ); ?></label>
            <div class="input-with-beg-label">
                <span class="beg-label"><?php esc_html_e( 'https://', 's3mm' ); ?></span>
                <input type="text" id="cfDistUrl" v-model="cfDistUrl" placeholder="<?php esc_html_e( 'Cloudfront Distribution Url', 's3mm' ); ?>">
            </div>
            <span class="desc"><?php _e( '<strong>( Optional )</strong> This is your CloudFront Distribution Url. It may look something like the following: <code>d1svrlpdgjcqn.cloudfront.net</code>', 's3mm' ); ?></span>
        </s3mm-form-field>
    </div>
</script>
