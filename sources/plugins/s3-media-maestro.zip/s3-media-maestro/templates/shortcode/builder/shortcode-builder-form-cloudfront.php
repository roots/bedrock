<script type="text/x-template" id="s3mm-shortcode-builder-form-cloudfront">
	<div class="s3mm-shortcode-builder-form-cloudfront s3mm-shortcode-builder-form">
        <s3mm-form-field>
            <label for="cfFiles"><?php _e( 'CloudFront {{ upperCaseType }} File', 's3mm' ); ?></label>

            <input v-if="type === 'file'" type="text" id="cfFiles" v-model="cfFiles" placeholder="<?php esc_html_e( 'CloudFront File', 's3mm' );?>">
            <input v-if="type === 'audio'" type="text" id="cfFiles" v-model="cfFiles" placeholder="<?php esc_html_e( 'CloudFront Audio File', 's3mm' );?>">
            <input v-if="type === 'video'" type="text" id="cfFiles" v-model="cfFiles" placeholder="<?php esc_html_e( 'CloudFront Video File', 's3mm' );?>">

            <span v-if="type !== 'file'" class="desc"><?php _e( '<strong>( Required )</strong> Just the {{ type }} filename. If adding mulitple {{ type }} files, seperate each one with a comma and be sure to use the same {{ type }} file type. Also, if your {{ type }} files are in folders within your s3 bucket, then simply add the folder to the beginning of the file name. For example: <code>/folder/folder/file.mp4</code>.', 's3mm' ); ?></span>

            <span v-if="type === 'file'" class="desc"><?php _e( '<strong>( Required )</strong> Just the filename.', 's3mm' ); ?></span>
        </s3mm-form-field>

        <s3mm-form-field v-if="type !== 'file'">
            <label for="cfTitles"><?php _e( 'CloudFront {{ upperCaseType }} File Titles', 's3mm' ); ?></label>

            <input v-if="type === 'file'" type="text" id="cfTitles" v-model="cfTitles" placeholder="<?php esc_html_e( 'CloudFront File Titles', 's3mm' );?>">
            <input v-if="type === 'audio'" type="text" id="cfTitles" v-model="cfTitles" placeholder="<?php esc_html_e( 'CloudFront Audio File Titles', 's3mm' );?>">
            <input v-if="type === 'video'" type="text" id="cfTitles" v-model="cfTitles" placeholder="<?php esc_html_e( 'CloudFront Video File Titles', 's3mm' );?>">

            <span v-if="type !== 'file'" class="desc"><?php _e( '<strong>( Optional )</strong> These are the friendly titles for your {{ type }} files. Comma separate each {{ type }} title. They will match the {{ type }} file names in the field above respectively.', 's3mm' ); ?></span>

            <span v-if="type === 'file'" class="desc"><?php _e( '<strong>( Optional )</strong> These are the friendly titles for your files. Comma separate each title. They will match the file names in the field above respectively.', 's3mm' ); ?></span>
        </s3mm-form-field>
	</div>
</script>