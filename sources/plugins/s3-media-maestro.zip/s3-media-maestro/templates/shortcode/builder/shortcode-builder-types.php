<script type="text/x-template" id="s3mm-shortcode-builder-types">
    <div class="s3mm-shortcode-builder-inner">
        <div class="s3mm-shortcode-builder-sidebar">
            <div class="s3mm-shortcode-builder-sidebar-inner">
                <a v-for="type in types" :key="type.id" href="#" class="type-link" :class="{ 'active' : type.isActive }" @click.prevent="selectType( type )">
                    <span class="dashicons" :class="type.icon"></span>
                    {{ type.title }}
                </a>
                <div class="separator"></div>
            </div>
        </div>

        <div class="s3mm-shortcode-builder-content">
            <div class="s3mm-shortcode-builder-content-inner">
                <slot></slot>
            </div>
        </div>
    </div>
</script>