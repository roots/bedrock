<script type="text/x-template" id="s3mm-form-field-files">
	<div class="s3mm-form-field-files">

		<transition name="fade" mode="out-in">
			<div v-if="hasNotices">
				<div v-for="(notice, index) in notices" class="s3mm-notice notice is-dismissible" :key="index" :class="`notice-` + notice.type">
					<p v-html="notice.message"></p>
					<button type="button" class="notice-dismiss" @click.prevent="removeNotice( index )">
						<span class="screen-reader-text"><?php esc_html_e( 'Dismiss this notice.', 's3mm' ); ?></span>
					</button>
				</div>
			</div>
		</transition>

		<input type="hidden" v-model="s3Files"/>
		<input type="hidden" v-model="s3Titles"/>

		<p class="file-selection">
			<button v-if="! filesForm || filesFormLoading" class="button button-secondary select-files"
			        :class="{ 'disabled' : filesFormLoading }"
			        @click.prevent="loadFilesForm"
			        @disabled="filesFormLoading">
				<span v-if="filesFormLoading" class="s3mm-spinner spinner left is-active"></span>
				<i v-if="! filesFormLoading" class="fa fa-files-o left" aria-hidden="true"></i>
				{{ filesFormLoading ? '<?php esc_html_e( 'Loading Files...', 's3mm' ); ?>' : '<?php esc_html_e( 'Select File(s)', 's3mm' ); ?>' }}
			</button>
		</p>

		<div v-if="filesForm" class="files-form">
			<div class="files-breadcrumb">
                <span v-if="! prefix" class="breadcrumb">
                    <span class="dividier">&nbsp;/&nbsp;</span>
                    <span><code>{{ s3Bucket }}</code></span>
                </span>

				<span v-if="prefix" v-for="(breadcrumb, index) in getBreadcrumbs" :key="index" class="breadcrumb">
                    <span v-if="index === 0" class="dividier">&nbsp;/&nbsp;</span>
                    <a v-if="index === 0" @click.prevent="selectBreadcrumb( '' )" href="#">{{ s3Bucket }}</a>

                    <span class="dividier">&nbsp;/&nbsp;</span>

                    <a v-if="! isLastBreadcrumb( index )" @click.prevent="selectBreadcrumb( breadcrumb, index )" href="#">{{ breadcrumb }}</a>
                    <span v-if="isLastBreadcrumb( index )"><code>{{ breadcrumb }}</code></span>
                </span>
			</div>

			<div style="display:none;" id="s3mm-upload-template" class="file-upload-template dz-preview dz-file-preview">
				<div class="dz-details">
					<div class="dz-progress progress">
						<span class="dz-filename progress-filname"><span data-dz-name></span> ( <span class="dz-size" data-dz-size></span> ) <span class="dz-progress-upload-speed">&nbsp;</span></span>
						<span class="progress-percentage"> <span class="dz-upload-progress">0%</span></span>
						<div class="determinate dz-upload" style="width: 0%" data-dz-uploadprogress></div>
					</div>
				</div>
				<div class="dz-error-message"><span data-dz-errormessage></span></div>
			</div>

			<div v-show="fileUploadPreview" id="s3mm-upload-preview" class="file-upload-preview"></div>

			<div class="file-upload-form" :class="{ 'active' : fileUploadFormDisplay }">
				<div id="s3mm-upload-files" class="uploader">
					<?php esc_html_e( 'Drop files here to upload', 's3mm' ); ?>
					<?php esc_html_e( 'or', 's3mm' ); ?><br/>
					<button class="button button-secondary uploader-select-files">
						<i class="fa fa-cloud-upload" aria-hidden="true"></i>
						<?php esc_html_e( 'Select Files', 's3mm' ); ?>
					</button>
				</div>

				<div class="uploader-actions">
					<a href="#" class="button button-secondary" @click.prevent="closeFileUploader">
						<i class="fa fa-times" aria-hidden="true"></i>
						<?php esc_html_e( 'Cancel', 's3mm' ); ?>
					</a>
				</div>
			</div>

			<div v-if="! fileUploadFormDisplay" class="file-list">
				<div v-if="refreshing" class="refreshing">
					<span class="s3mm-spinner spinner left is-active"></span>
					<?php esc_html_e( 'Refreshing Files...', 's3mm' ); ?>
				</div>

				<div v-if="loadingFolder" class="refreshing">
					<span class="s3mm-spinner spinner left is-active"></span>
					<?php esc_html_e( 'Loading...', 's3mm' ); ?>
				</div>

				<ul v-if="hasFiles && ! refreshing && ! loadingFolder">
					<li v-for="(file, index) in files" :key="file.key">
						<a v-if="file.folder === false" href="#" @click.prevent="selectFile( file )" :class="{ 'active' : selectedFile( file ) }">
							<i v-if="! selectedFile( file )" class="fa fa-plus-circle left add-icon" aria-hidden="true"></i>
							<i v-if="selectedFile( file )" class="fa fa-minus-circle left remove-icon" aria-hidden="true"></i>
							<i class="fa fa-file left" aria-hidden="true"></i>
							{{ file.name }}
						</a>
						<a v-if="file.folder === true" href="#" @click.prevent="selectFolder( file )" class="folder">
							<i class="fa fa-folder left" aria-hidden="true"></i>
							<i class="fa fa-angle-double-right arrow-icon" aria-hidden="true"></i>
							{{ file.name }}
						</a>
					</li>
				</ul>

				<a v-if="filesMarker !== '' && ! refreshing && ! loadingFolder" href="#" class="s3mm-s3-load-more-files" @click.prevent="loadMoreFiles">{{ filesAdditionalLoading ?
					'<?php esc_html_e( 'Loading more files...', 's3mm' ); ?>' : '<?php esc_html_e( 'Click to load more files...', 's3mm' ); ?>' }}</a>

				<div v-if="! hasFiles && ! refreshing && ! loadingFolder" class="no-files"><?php esc_html_e( 'No files available. Bucket is empty.', 's3mm' ); ?></div>
			</div>

			<transition name="fade" mode="out-in">
				<div v-if="newFolderNotice.message" class="s3mm-notice notice is-dismissible folder-new-notices" :class="noticeType">
					<p v-html="newFolderNotice.message"></p>
					<button type="button" class="notice-dismiss" @click.prevent="removeNewFolderNotice">
						<span class="screen-reader-text"><?php esc_html_e( 'Dismiss this notice.', 's3mm' ); ?></span>
					</button>
				</div>
			</transition>

			<div v-if="canCreateFolder" class="folder-new">
				<s3mm-form-field>
					<input type="text" placeholder="<?php esc_html_e( 'New Folder Name', 's3mm' ); ?>" class="create-new-folder" v-model="newFolderName"/>
				</s3mm-form-field>

				<div class="folder-new-actions">
					<button class="button button-primary" :class="{ 'disabled' : createFolderLoading }" @click.prevent="saveNewFolder" @disabled="createFolderLoading">
						<i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : createFolderLoading, 'fa-floppy-o' : ! createFolderLoading }" aria-hidden="true"></i>
						{{ createFolderLoading ? '<?php esc_html_e( 'Saving...', 's3mm' ); ?>' : '<?php esc_html_e( 'Save', 's3mm' ); ?>' }}
					</button>
					<button class="button button-secondary" :class="{ 'disabled' : createFolderLoading }" @click.prevent="cancelNewFolder" @disabled="createFolderLoading">
						<i class="fa fa-times" aria-hidden="true"></i>
						<?php esc_html_e( 'Cancel', 's3mm' ); ?>
					</button>
				</div>
			</div>

			<div v-if="! fileUploadFormDisplay" class="file-actions">
				<span v-if="selecting" class="s3mm-spinner spinner left is-active"></span>

				<a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="refreshFiles" @disabled="loading">
					<i class="fa fa-retweet" aria-hidden="true"></i>
				</a>

				<a v-if="hasSelected" href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="clearSelected" @disabled="loading">
					<i class="fa fa-ban" aria-hidden="true"></i>
					<?php esc_html_e( 'Clear', 's3mm' ); ?>
				</a>

				<a v-if="hasSelected" href="#" class="button button-secondary" :class="{ 'disabled' : loading || filesDeleting }" @click.prevent="deleteSelected" @disabled="loading || filesDeleting">
					<i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : filesDeleting, 'fa-trash' : ! filesDeleting }" aria-hidden="true"></i>
					{{ filesDeleting ? '<?php esc_html_e( 'Deleting...', 's3mm' ); ?>' : '<?php esc_html_e( 'Delete', 's3mm' ); ?>' }}
				</a>

				<a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="uploadNewFiles" @disabled="loading">
					<i class="fa fa-plus" aria-hidden="true"></i>
					<?php esc_html_e( 'Upload Files', 's3mm' ); ?>
				</a>

				<a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="createFolder" @disabled="loading">
					<i class="fa fa-folder" aria-hidden="true"></i>
					<?php esc_html_e( 'Create Folder', 's3mm' ); ?>
				</a>

				<a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="closeFilesForm" @disaled="loading">
					<i class="fa fa-times" aria-hidden="true"></i>
					{{ s3Files ? '<?php esc_html_e( 'Close', 's3mm' ); ?>' : '<?php esc_html_e( 'Cancel', 's3mm' ); ?>' }}
				</a>
			</div>
		</div>

		<div v-if="hasSelected" class="selected-titles">
			<span class="label"><?php _e( 'S3 {{ builderTypeTitle}} Titles', 's3mm' ); ?></span>
			<ul>
				<li v-for="(file, index) in selected" :key="index" class="selected-title">
					<span class="selected-title-label"><code>{{ file }}</code></span>
					<input class="selected-title-input" type="text" placeholder="<?php esc_html_e( 'Title', 's3mm' ); ?>" :id="index" @input="addTitle( $event, file, index )">
				</li>
			</ul>
		</div>
	</div>
</script>
