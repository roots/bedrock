<script type="text/x-template" id="s3mm-form-field">
    <div class="s3mm-form-field" :class="fieldClasses">
        <slot></slot>
    </div>
</script>