<script type="text/x-template" id="s3mm-notices">
    <div v-if="hasNotices" class="s3mm-notices">
        <transition name="fade" mode="out-in">
            <div v-for="(notice, index) in notices" :key="notice.id" class="s3mm-notice notice is-dismissible" :class="noticeType( notice )">
                <p v-html="notice.message"></p>
                <button type="button" class="notice-dismiss" @click.prevent="removeNotice( index )">
                    <span class="screen-reader-text"><?php esc_html_e( 'Dismiss this notice', 's3mm' ); ?></span>
                </button>
            </div>
        </transition>
        <slot></slot>
    </div>
</script>