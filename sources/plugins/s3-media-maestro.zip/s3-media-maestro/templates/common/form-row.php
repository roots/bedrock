<script type="text/x-template" id="s3mm-form-row">
    <tr valign="top" class="s3mm-form-row">
        <th scope="row" valign="top" class="label-cell">
            <div class="label-cell-content">
                <slot name="label"></slot>
            </div>
        </th>
        <td scope="row" valign="top" class="input-cell">
            <div class="input-cell-content">
                <slot name="input"></slot>
            </div>
        </td>
    </tr>
</script>