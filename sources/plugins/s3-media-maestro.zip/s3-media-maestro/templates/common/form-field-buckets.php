<script type="text/x-template" id="s3mm-form-field-buckets">
    <div class="s3mm-form-field-buckets">
        <input type="hidden" v-model="bucket"/>
        <input type="hidden" v-model="region"

        <p class="bucket-selection">
            <span v-if="bucket" class="selected-bucket">
                <code><i class="fa fa-archive" aria-hidden="true"></i> {{ bucket }} {{ regionLabel }}</code>
            </span>

            <button v-if="! bucketForm && ! bucketFormLoading && bucket" class="button button-secondary change-bucket" @click.prevent="loadBucketForm">
                <i class="fa fa-retweet left" aria-hidden="true"></i>
				<?php esc_html_e( 'Change', 's3mm' ); ?>
            </button>

            <button v-if="( ! bucketForm && ! bucket ) || bucketFormLoading" class="button button-secondary select-bucket"
                    :class="{ 'disabled' : bucketFormLoading, 'bucket-loading' : ( bucket && bucketFormLoading ) }"
                    @click.prevent="loadBucketForm"
                    @disabled="bucketFormLoading">
                <span v-if="bucketFormLoading" class="s3mm-spinner spinner left is-active"></span>
                <i v-if="! bucketFormLoading" class="fa fa-folder left" aria-hidden="true"></i>
                {{ bucketFormLoading ? '<?php esc_html_e( 'Loading Buckets...', 's3mm' ); ?>' : '<?php esc_html_e( 'Select a bucket', 's3mm' ); ?>' }}
            </button>
        </p>

        <div v-if="bucketForm" class="bucket-form">
            <div class="bucket-list">
                <div v-if="refreshing" class="refreshing">
                    <span class="s3mm-spinner spinner left is-active"></span>
					<?php esc_html_e( 'Refreshing Buckets...', 's3mm' ); ?>
                </div>

                <ul v-if="! refreshing">
                    <li v-for="(bucket, index) in buckets" :key="index">
                        <a href="#" @click.prevent="selectBucket( bucket )" :class="{ 'active' : selectedBucket( bucket ) }">
                            <i class="fa fa-archive" aria-hidden="true"></i>
                            {{ bucket.name }}
                        </a>
                    </li>
                </ul>
            </div>

            <transition name="fade" mode="out-in">
                <div v-if="newBucketNotice.message" class="s3mm-notice notice is-dismissible" :class="noticeType">
                    <p v-html="newBucketNotice.message"></p>
                    <button type="button" class="notice-dismiss" @click.prevent="removeNotice">
                        <span class="screen-reader-text"><?php esc_html_e( 'Dismiss this notice.', 's3mm' ); ?></span>
                    </button>
                </div>
            </transition>

            <div v-if="newBucket" class="bucket-new">
                <s3mm-form-field>
                    <input type="text" placeholder="<?php esc_html_e( 'Create New Bucket', 's3mm' ); ?>" class="create-new-bucket" v-model="newBucketName"/>
                </s3mm-form-field>

                <s3mm-form-field>
                    <select v-model="newBucketRegion" placeholder="<?php esc_html_e( 'Select a Region', 's3mm' ); ?>">
                        <option disabled value=""><?php esc_html_e( 'Select a Region', 's3mm' ); ?></option>
                        <option v-for="(val, key, index) in regions" :key="key" :value="key" v-text="val"></option>
                    </select>
                </s3mm-form-field>

                <div class="bucket-new-actions">
                    <button class="button button-primary" :class="{ 'disabled' : loading }" @click.prevent="saveNewBucket" @disabled="loading">
                        <i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : loading, 'fa-floppy-o' : ! loading }" aria-hidden="true"></i>
                        {{ loading ? '<?php esc_html_e( 'Saving...', 's3mm' ); ?>' : '<?php esc_html_e( 'Save', 's3mm' ); ?>' }}
                    </button>
                    <button class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="newBucket = false" @disabled="loading">
                        <i class="fa fa-times" aria-hidden="true"></i>
						<?php esc_html_e( 'Cancel', 's3mm' ); ?>
                    </button>
                </div>
            </div>

            <div class="bucket-actions">
                <span v-if="selecting" class="s3mm-spinner spinner left is-active"></span>

                <a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="refreshBuckets" @disabled="loading">
                    <i class="fa fa-retweet" aria-hidden="true"></i>
                </a>

                <a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="createNewBucket" @disabled="loading">
                    <i class="fa fa-plus" aria-hidden="true"></i>
					<?php esc_html_e( 'Create a new bucket', 's3mm' ); ?>
                </a>

                <a href="#" class="button button-secondary" :class="{ 'disabled' : loading }" @click.prevent="closeBucketForm" @disaled="loading">
                    <i class="fa fa-times" aria-hidden="true"></i>
					<?php esc_html_e( 'Cancel', 's3mm' ); ?>
                </a>
            </div>
        </div>
    </div>
</script>