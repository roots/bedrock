<script type="text/x-template" id="s3mm-form">
    <form class="s3mm-form" @submit.prevent="save">
        <table class="s3mm-form-table">
            <tbody>
                <slot></slot>
                <tr class="s3mm-form-row" valign="top">
                    <th colspan="2">
                        <div class="s3mm-form-submit">
                            <button type="submit" class="button button-primary" :class="formButtonClass" @disabled="isLoading">
                                <i v-if="isLoading" class="fa fa-circle-o-notch fa-spin left" aria-hidden="true"></i>
                                {{ formButtonText }}
                            </button>
                        </div>
                    </th>
                </tr>
            </tbody>
        </table>
    </form>
</script>