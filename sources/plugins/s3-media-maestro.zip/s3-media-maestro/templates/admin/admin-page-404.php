<script type="text/x-template" id="s3mm-admin-page-404">
    <div class="metabox-holder s3mm-admin-page-404 s3mm-admin-page">
        <h2><?php esc_html_e( '404 - Settings page not found.', 's3mm' ); ?></h2>
        <p><?php esc_html_e( 'Sorry, but this settings page does not seem to exist. Please try a different link.', 's3mm' ); ?></p>
    </div>
</script>