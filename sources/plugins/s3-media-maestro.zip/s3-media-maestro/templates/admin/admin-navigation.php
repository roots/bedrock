<script type="text/x-template" id="s3mm-admin-navigation">
    <h2 class="nav-tab-wrapper s3mm-nav-tab-wrapper s3mm-admin-navigation">
		<?php foreach ( $this->get_admin_pages() as $slug => $page ) { ?>
			<?php if ( $this->show_in_menu( $page ) ) { ?>
				<?php if ( $this->is_page_default( $page ) ) { ?>
                    <router-link :to="{ path: 'options-general.php', query: { page: 's3mm' } }"
                                 class="nav-tab"
                                 active-class="nav-tab-active"
                                 exact-active-class="nav-tab-active" exact>
						<?php echo $this->get_page_label( $page ); ?>
                    </router-link>
				<?php } else { ?>
                    <router-link :to="{ path: 'options-general.php', query: { page: 's3mm', tab: '<?php echo $slug; ?>' } }"
                                 class="nav-tab"
                                 active-class="nav-tab-active"
                                 exact-active-class="nav-tab-active" exact>
						<?php echo $this->get_page_label( $page ); ?>
                    </router-link>
				<?php } ?>
			<?php } ?>
		<?php } ?>
    </h2>
</script>