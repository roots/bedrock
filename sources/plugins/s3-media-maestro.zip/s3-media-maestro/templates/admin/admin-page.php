<script type="text/x-template" id="s3mm-admin-page">
    <transition name="fade" mode="out-in">
        <router-view v-if="isLoaded"></router-view>
    </transition>
</script>