<script type="text/x-template" id="s3mm-admin-page-settings">
    <div class="metabox-holder s3mm-admin-page-settings s3mm-admin-page">
        <h2><?php esc_html_e( 'Other Settings', 's3mm' ); ?></h2>
        <p><?php esc_html_e( 'Below are other settings of the plugin that should be reviewed and set if needed.', 's3mm' ); ?></p>
        <s3mm-form>
            <s3mm-form-row>
                <div slot="label">
                    <h3><?php esc_html_e( 'License Key:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <input spellcheck="false" class="license-field text-password" :class="licenseUpdating" v-model.trim="licenseKey" placeholder="<?php esc_html_e( 'License Key', 's3mm' ); ?>" type="text"/>

                        <button v-if="! licenseValid" class="button button-primary license-button" :class="{ 'disabled' : activating }" @click.prevent="activateLicense" @disabled="activating">
                            <i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : activating, 'fa-check-circle' : ! activating }" aria-hidden="true"></i>
                            {{ activating ? '<?php esc_html_e( 'Activating...', 's3mm' ); ?>' : '<?php esc_html_e( 'Activate', 's3mm' ); ?>' }}
                        </button>

                        <button v-if="licenseValid" class="button button-secondary license-button" :class="{ 'disabled' : deactivating }" @click.prevent="deactivateLicense" @disabled="deactivating">
                            <i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : deactivating, 'fa-times-circle' : ! deactivating }" aria-hidden="true"></i>
                            {{ deactivating ? '<?php esc_html_e( 'Deactivating...', 's3mm' ); ?>' : '<?php esc_html_e( 'Deactivate', 's3mm' ); ?>' }}
                        </button>

                        <span class="desc"><?php printf( __( 'Enter your license key to recieve automatic updates and support. You can find your license key on your <a href="%s" target="_blank">member portal licenses page</a>.', 's3mm' ), $this->member_portal_license_url() ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row>
                <div slot="label">
                    <h3><?php esc_html_e( 'Powered By Link:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <span class="radio">
                            <label for="poweredbylinkyes">
                                <input type="radio" id="poweredbylinkyes" value="yes" v-model="poweredByLink">
                                <span class="label">Yes</span>
                            </label>
                        </span>
                        <span class="radio">
                            <label for="poweredbylinkno">
                                <input type="radio" id="poweredbylinkno" value="no" v-model="poweredByLink">
                                <span class="label">No</span>
                            </label>
                        </span>
                        <span class="desc"><?php _e( 'Do you want to show a <code>Powered by S3 Media Maestro</code> link at the bottom of the media player?', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row v-if="poweredByLink === 'yes'">
                <div slot="label">
                    <h3><?php esc_html_e( 'Affiliate ID:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <input class="form-field" v-model="affiliateId" placeholder="<?php esc_html_e( 'Affiliate ID', 's3mm' ); ?>" type="text"/>
                        <span class="desc"><?php printf( __( '(Optional) Earn some money by providing your Affiliate ID, which will turn the Powered by S3 Media Maestro into an affiliate link that earns you a percentage of every sale! If you are not an affiliate, <a target="_blank" href="%s">login to the member portal</a> to register and get your ID.', 's3mm' ), $this->member_portal_url() ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
        </s3mm-form>
    </div>
</script>