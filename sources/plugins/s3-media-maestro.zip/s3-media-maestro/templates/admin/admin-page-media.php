<script type="text/x-template" id="s3mm-admin-page-media">
	<div class="metabox-holder s3mm-admin-page-media s3mm-admin-page">
		<h2><?php esc_html_e( 'Media Player - Settings', 's3mm' ); ?></h2>
		<p><?php esc_html_e( 'Below are the settings for the video and audio players.', 's3mm' ); ?></p>
		<s3mm-form>
			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Type:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<?php foreach ( $this->get_media_players() as $player_id => $player ) { ?>
							<span class="radio">
                                <label for="<?php printf( 'player%s', $player_id ); ?>">
                                    <input type="radio" id="<?php printf( 'player%s', $player_id ); ?>" value="<?php echo $player_id; ?>" v-model="playerType"/>
	                                <?php if ( ! empty( $player['url'] ) ) { ?>
		                                <span class="radio-label"><a target="_blank" href="<?php echo esc_url_raw( $player['url'] ); ?>"><?php echo esc_attr( $player['name'] ); ?></a></span>
	                                <?php } else { ?>
		                                <span class="radio-label"><?php echo esc_attr( $player['name'] ); ?> ?></span>
	                                <?php } ?>
                                </label>
                            </span>
						<?php } ?>
						<span class="desc"><?php esc_html_e( 'Choose the player type to be used to play your video / audio files.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Skin:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<?php foreach ( $this->get_media_players() as $player_id => $player ) { ?>
						<s3mm-form-field v-if="playerType === '<?php echo $player_id; ?>'">
							<select id="playerSkin" v-model="playerSkin">
								<option disabled value=""><?php esc_html_e( 'Select a Skin', 's3mm' ); ?></option>
								<?php if ( ! empty( $player['skins'] ) ) { ?>
									<?php foreach ( $player['skins'] as $skin_key => $skin ) { ?>
										<option value="<?php echo $skin_key; ?>"><?php echo ( $skin['label'] ) ? $skin['label'] : ucfirst( $skin_key ); ?></option>
									<?php } ?>
								<?php } ?>
							</select>
							<span class="desc"><?php esc_html_e( 'The look and feel of the player when it is displayed.', 's3mm' ); ?></span>
						</s3mm-form-field>
					<?php } ?>
				</div>
			</s3mm-form-row>

			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Splash Image:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<div class="input-with-end-button splash-image">
							<input type="text" v-model.trim="playerSplashImg" placeholder="<?php esc_html_e( 'Player Splash Image', 's3mm' ); ?>"/>
							<input type="hidden" v-model.trim="playerSplashImgId"/>
							<button class="button button-primary end-button" @click.prevent="displayMediaUploader">
								<i class="fa fa-picture-o" aria-hidden="true"></i>
								<?php esc_html_e( 'Select Image', 's3mm' ); ?>
							</button>
						</div>
						<span class="desc"><?php esc_html_e( 'Select an image or enter a full url of an image to display before playback of a video.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Volume:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<select id="playerVolume" v-model="playerVolume">
							<option disabled value=""><?php esc_html_e( 'Select Volume', 's3mm' ); ?></option>
							<?php for ( $volume = 100; $volume >= 0; $volume -= 5 ) { ?>
								<option value="<?php echo( $volume / 100 ); ?>"><?php echo $volume; ?>%</option>
							<?php } ?>
						</select>
						<span class="desc"><?php esc_html_e( 'The default volume of the player when initially displayed.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Size:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
                        <span class="radio">
                            <label for="playerSizeResponsive">
                                <input type="radio" id="playerSizeResponsive" value="responsive" v-model="playerSize"/>
                                <span class="radio-label"><?php esc_html_e( 'Responsive', 's3mm' ); ?></span>
                            </label>
                        </span>

						<span class="radio">
                            <label for="playerSizeFixed">
                                <input type="radio" id="playerSizeFixed" value="fixed" v-model="playerSize"/>
                                <span class="radio-label"><?php esc_html_e( 'Fixed', 's3mm' ); ?></span>
                            </label>
                        </span>

						<span class="desc"><?php esc_html_e( 'The default size of the video / audio player.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row v-if="playerSize === 'fixed'">
				<div slot="label">
					<h3><?php esc_html_e( 'Video Player Width:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<div class="input-with-end-label">
							<input v-model="playerWidth" placeholder="<?php esc_html_e( 'Video Player Width', 's3mm' ); ?>" type="text"/>
							<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
						</div>
						<span class="desc"><?php esc_html_e( 'The default width of video player.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row v-if="playerSize === 'fixed'">
				<div slot="label">
					<h3><?php esc_html_e( 'Video Player Height:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<div class="input-with-end-label">
							<input v-model="playerHeight" placeholder="<?php esc_html_e( 'Video Player Height', 's3mm' ); ?>" type="text"/>
							<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
						</div>
						<span class="desc"><?php esc_html_e( 'The default height of video player.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row v-if="playerSize === 'fixed'">
				<div slot="label">
					<h3><?php esc_html_e( 'Audio Player Width:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<div class="input-with-end-label">
							<input v-model="playerAudioWidth" placeholder="<?php esc_html_e( 'Audio Player Width', 's3mm' ); ?>" type="text"/>
							<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
						</div>
						<span class="desc"><?php esc_html_e( 'The default width of audio player.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row v-if="playerSize === 'fixed'">
				<div slot="label">
					<h3><?php esc_html_e( 'Audio Player Height:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<div class="input-with-end-label">
							<input v-model="playerAudioHeight" placeholder="<?php esc_html_e( 'Audio Player Height', 's3mm' ); ?>" type="text"/>
							<span class="end-label"><?php esc_html_e( 'pixels', 's3mm' ); ?></span>
						</div>
						<span class="desc"><?php esc_html_e( 'The default height of audio player.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>

			<s3mm-form-row>
				<div slot="label">
					<h3><?php esc_html_e( 'Player Metadata:', 's3mm' ); ?></h3>
				</div>
				<div slot="input">
					<s3mm-form-field>
						<select id="playerPreLoad" v-model="playerPreLoad">
							<option disabled value=""><?php esc_html_e( 'Select Metadata Setting', 's3mm' ); ?></option>
							<option value="auto"><?php esc_html_e( 'Auto (Recommended)', 's3mm' ); ?></option>
							<option value="metadata"><?php esc_html_e( 'Metadata', 's3mm' ); ?></option>
							<option value="none"><?php esc_html_e( 'None', 's3mm' ); ?></option>
						</select>
						<span class="desc"><?php esc_html_e( 'The default settings to determine if the player metadata should be loaded.', 's3mm' ); ?></span>
					</s3mm-form-field>
				</div>
			</s3mm-form-row>
			<?php if ( $this->is_protection_enabled() ) { ?>
				<s3mm-form-row>
					<div slot="label">
						<h3><?php esc_html_e( 'Player Protect Source:', 's3mm' ); ?></h3>
					</div>
					<div slot="input">
						<s3mm-form-field>
                        <span class="radio">
                            <label for="playerProtectSrcYes">
                                <input type="radio" id="playerProtectSrcYes" value="yes" v-model="playerProtectSrc"/>
                                <span class="radio-label"><?php esc_html_e( 'Yes', 's3mm' ); ?></span>
                            </label>
                        </span>

							<span class="radio">
                            <label for="playerProtectSrcNo">
                                <input type="radio" id="playerProtectSrcNo" value="no" v-model="playerProtectSrc"/>
                                <span class="radio-label"><?php esc_html_e( 'No', 's3mm' ); ?></span>
                            </label>
                        </span>

							<span class="desc"><?php esc_html_e( 'This setting will allow you to protect your video/audio "source" so others cannot download your video/audio file.', 's3mm' ); ?></span>
						</s3mm-form-field>
					</div>
				</s3mm-form-row>
			<?php } ?>
		</s3mm-form>
	</div>
</script>
