<script type="text/x-template" id="s3mm-admin-page-cloudfront">
    <div class="metabox-holder s3mm-admin-page-cloudfront s3mm-admin-page">
        <h2><?php esc_html_e( 'Amazon Cloudfront - Settings', 's3mmm' ); ?></h2>
        <p><?php esc_html_e( 'Please specify your Amazon Cloudfront settings to use Cloudfront features.', 's3mm' ); ?></p>
        <s3mm-form>
            <s3mm-form-row>
                <div slot="label">
                    <h3><?php esc_html_e( 'Cloudfront Dist URL:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <div class="input-with-beg-label">
                            <span class="beg-label"><?php esc_html_e( 'https://', 's3mm' ); ?></span>
                            <input v-model="cfDistUrl" placeholder="<?php esc_html_e( 'Cloudfront Distribution Url', 's3mm' ); ?>" type="text"/>
                        </div>
                        <span class="desc">
                            <?php _e( 'This is your CloudFront Distribution Url. It may look something like: <code>d1svrlpdgjcqn.cloudfront.net</code>. <strong>Required for CloudFront features to work.</strong>', 's3mm' ); ?>
                        </span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row v-if="cfDistUrl">
                <div slot="label">
                    <h3><?php esc_html_e( 'Cloudfront Key Pair ID:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <input style="display:none;" type="password" name="s3mm_autofill_fake_password" tabindex="-1">
                        <input spellcheck="false" class="text-password" v-model.trim="cfKey" placeholder="<?php esc_html_e( 'Cloudfront Key Pair ID', 's3mm' ); ?>" type="text"/>
                        <span class="desc"><?php _e( 'This is usually a string of characters like <code>AKTFIOHGHWW53KA8ETA</code>', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>

            <s3mm-form-row v-if="cfDistUrl">
                <div slot="label">
                    <h3><?php esc_html_e( 'Cloudfront Private Key:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <textarea spellcheck="false" class="key" v-model.trim="cfPrivateKey" placeholder="<?php esc_html_e( 'Cloudfront Private Key', 's3mm' ); ?>"></textarea>
                        <span class="desc">
                            <?php _e( 'Your <code>private key</code> for the Amazon CloudFront. Please copy the entire key from begining to ending like the following:', 's3mm' ); ?><br />
                            <code>
                                <?php _e( '-----BEGIN RSA PRIVATE KEY-----<br/>
                                AKTFIOHGHWW53KA8ETAAKTFIOHGHWW5AKTFIOHGHWW53KA8<br/>
                                AKTFIOHGHWW53KA8ETAAKTFIOHGHWW5AKTFIOHGHWW53KA8<br/>
                                AKTFIOHGHWW53KA8ETAAKTFIOHGHWW5AKTFIOHGHWW53KA8<br/>
                                AKTFIOHGHWW53KA8ETAAKTFIOHGHWW5AKTFIOHGHWW53KA8<br/>
                                AKTFIOHGHWW53KA8ETAAKTFIOHGHWW5AKTFIOHGHWW53KA8<br/>
                                -----END RSA PRIVATE KEY-----', 's3mm' ); ?>
                            </code>
                        </span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>

            <s3mm-form-row v-if="cfDistUrl">
                <div slot="label">
                    <h3><?php esc_html_e( 'Cloudfront Expiry:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <div class="input-with-end-label">
                            <input v-model="cfExpiry" placeholder="<?php esc_html_e( 'Cloudfront Expiry', 's3mm' ); ?>" type="text"/>
                            <span class="end-label"><?php esc_html_e( 'minutes', 's3mm' ); ?></span>
                        </div>
                        <span class="desc"><?php _e( 'The expiry time for a Cloudfront link. Recommend between <code>1 to 30</code> minutes.', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
        </s3mm-form>
    </div>
</script>