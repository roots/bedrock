<script type="text/x-template" id="s3mm-admin-page-system">
    <div class="metabox-holder s3mm-admin-page-system s3mm-admin-page">
        <h2><?php esc_html_e( 'System Information', 's3mm' ); ?></h2>
        <div class="s3mm-message info">
            <p><?php esc_html_e( 'Please download the system info report or copy and paste the information below in the ticket when contacting support.', 's3mm' ); ?></p>
            <div class="actions">
                <button type="submit" class="button button-secondary" :class="{ 'disabled' : loading || downloading }" @click="downloadReport" @disabled="loading">
                    <i class="fa fa-download"></i>
                    {{ downloading ? '<?php esc_html_e( 'Downloading Report...', 's3mm' ); ?>' : '<?php esc_html_e( 'Download System Info Report', 's3mm' ); ?>' }}
                    <span v-if="downloading" class="s3mm-spinner spinner is-active right"></span>
                </button>
            </div>
        </div>
        <textarea class="s3mm-system-report" v-model="systemReport" placeholder="<?php esc_html_e( 'Loading System Report...', 's3mm' ); ?>" @click="selectReport"></textarea>
    </div>
</script>