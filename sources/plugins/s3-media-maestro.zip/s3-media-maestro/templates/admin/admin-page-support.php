<script type="text/x-template" id="s3mm-admin-page-support">
    <div class="metabox-holder s3mm-admin-page-support s3mm-admin-page">
        <h2><?php esc_html_e( 'S3 Media Maestro Support', 's3mm' ); ?></h2>
        <p><?php esc_html_e( 'Below are other settings of the plugin that should be reviewed and set if needed.', 's3mm' ); ?></p>
        <p>
            <a href="#" class="button button-primary" :class="{ 'disabled' : loading }" @click.prevent="openBeacon" @disabled="loading">
                <i class="fa" :class="{ 'fa-circle-o-notch fa-spin' : loading, 'fa-search': ! loading }" aria-hidden="true"></i>
				<?php esc_html_e( 'Search Documentation', 's3mm' ); ?>
            </a>
        </p>
        <p><?php printf( __( 'Can\'t find what you\'re looking for? Submit a support request via the <a target="_blank" href="%s">member portal.</a>', 's3mm' ), $this->member_portal_support_url() ); ?></p>
    </div>
</script>