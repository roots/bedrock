<script type="text/x-template" id="s3mm-admin-header">
    <h2 class="s3mm-admin-title">
        <img class="logo"
             src="<?php echo $this->image( 's3mm-icon.svg' ); ?>"
             alt="<?php esc_html_e( 'S3 Media Maestro', 's3mm' ); ?>"
             @click="clearLicenseCache"/>
        <span class="title"><?php esc_html_e( 'S3 Media Maestro', 's3mm' ); ?></span>
    </h2>
</script>
