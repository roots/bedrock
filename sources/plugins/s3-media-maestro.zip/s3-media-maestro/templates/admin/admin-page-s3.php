<script type="text/x-template" id="s3mm-admin-page-s3">
    <div class="metabox-holder s3mm-admin-page-s3 s3mm-admin-page">
        <h2><?php esc_html_e( 'Amazon S3 - Settings', 's3mm' ); ?></h2>
        <p><?php esc_html_e( 'Please specify your Amazon S3 settings below to use the S3 features.', 's3mm' ); ?></p>
        <s3mm-form>
            <s3mm-form-row>
                <div slot="label">
                    <h3><?php esc_html_e( 'S3 Access Key ID:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <input spellcheck="false" class="text-password" v-model.trim="s3AccessKey" placeholder="<?php esc_html_e( 'S3 Access Key', 's3mm' ); ?>" type="text"/>
                        <span class="desc"><?php _e( 'This is usually a string of characters like this: <code>AKTFIOHGHWW53KA8ETA</code>', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row>
                <div slot="label">
                    <h3><?php esc_html_e( 'S3 Secret Key:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <input spellcheck="false" class="text-password" v-model.trim="s3SecretKey" placeholder="<?php esc_html_e( 'S3 Secret Key', 's3mm' ); ?>" type="text"/>
                        <span class="desc"><?php _e( 'This is usually a string of characters like this: <code>J1u5mip523JFQPJVYEMzqE6qG+Y3bZC7tfm/37T3</code>', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row v-if="s3Loaded">
                <div slot="label">
                    <h3><?php esc_html_e( 'S3 Default Bucket:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <s3mm-form-field-buckets></s3mm-form-field-buckets>
                        <span class="desc"><?php esc_html_e( 'The amazon s3 bucket that will be used to serve your files.', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
            <s3mm-form-row v-if="s3Loaded">
                <div slot="label">
                    <h3><?php esc_html_e( 'S3 Default Expiry:', 's3mm' ); ?></h3>
                </div>
                <div slot="input">
                    <s3mm-form-field>
                        <div class="input-with-end-label">
                            <input type="text" v-model="s3expiry" placeholder="Default S3 Expiry"/>
                            <span class="end-label"><?php esc_html_e( 'minutes', 's3mm' ); ?></span>
                        </div>
                        <span class="desc"><?php _e( 'The default expiry time of an s3 link in minutes. Recommend between <code>1 to 30</code> minutes.', 's3mm' ); ?></span>
                    </s3mm-form-field>
                </div>
            </s3mm-form-row>
        </s3mm-form>
    </div>
</script>