=== S3 Media Maestro ===
Contributors: flyplugins, corycrowley, barellano, natejohnson78
Tags: WordPress Media Protection, S3 Video Player, S3 Audio Player, HTML5 Player for WordPress, Amazon S3 media
Requires PHP: 5.5.0
Requires at least: 4.4
Tested up to: 5.0.3
Stable tag: 3.2.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

S3MM allows you to protect audio, video, and any file that you store up on Amazon S3 and uses an HTML5 player (iDevice support) with Flash fallback

== Description ==

S3 Media Maestro is the leading content protection tool. Cloud based storage is so cheap that many people are hosting their content from cloud solutions like the Amazon S3 service. However, their content is not necessarily protected. People may not realize but when they expose their Amazon S3 content so that their website can stream audio or video, the audio or video file is completely vulnerable. That's where S3  Media Maestro comes into play. S3 Media Maestro allows you to fully lock down your files on Amazon S3, and allows you to create expiring links so that people can not link share your Amazon S3 content. However, we took things a step further because we created S3 Media Maestro with HTML5 so that iDevices would be able to view audio/video. S3 Media Maestro is fully loaded with a [shortcode] generator, built in affiliate program and solid documentation.

== Installation ==

1. Go in to your WordPress Admin Panel.
2. Navigate to Plugins &rarr; Add New and click upload.
3. Browse for the s3-media-maestro.zip file and click upload.
4. Click Activate.

== Frequently Asked Questions ==

  Q: Can you show self hosted media with S3 Media Maestro?
  A: Yes, however, it will not be protected. For instance if you upload your video or audio file to your web server, you can still play it with the S3 Media Maestro and all it's features, except it won't be protected, because there is no security method to lock down your video.

  Q: How do I update S3 Media Maestro?
  A: Update S3 Media Maestro just like you would a plugin that is installed from the WordPress Plugin library.

  Q: Where can I find a training video?
  A: You can find our training video in one of two places: 1) The documentation section of the S3 Media Maestro plugin 2) Check out our YouTube channel http://www.youtube.com/flyplugins

  Q: Where can I find documentation?
  A: You can find documentation with in the S3 Media Maestro plugin under the documentation page or go to http://support.s3mediamaestro.com.

== Changelog ==
= 3.2.3 =
* Rollback: Video player source protection.
* Fix: Full screen mode on Android devices when rotated did not display correctly.

= 3.2.2 =
* New: Video player source protection.
* New: Compatibility with Thrive Themes.
* Fix: Conflict with LearnPress.

= 3.2.1 =
* New: WordPress 5.0 / Gutenberg support S3 Video and Audio files.
* Fix: Updated Amazon S3 SDK to latest version.

= 3.2.0 =
* New: Full Integration with WP Courseware.
* New: WP Courseware - Require video to be viewed prior to enabling "Mark as complete" button.
* New: WP Courseware - Automatically complete unit when video view requirement has been met.
* New: WP Courseware - Automatically complete unit and navigate to next unit when video view requirement has been met.
* New: Ability to add folders inside a bucket via shortcode builder.
* New: Ability to delete assets in a bucket / folder via shortcode builder.

= 3.1.1 =
* Fix: Issue with playlist scroll bar not scrolling correctly.
* Fix: Using escape key to exit full screen video did not resize properly upon return.
* Fix: Vimeo videos did not have the proper width and height.
* Fix: License updating issue with Cloudflare.
* Fix: Updated Amazon S3 SDK to latest version.

= 3.1.0 =
* New: Amazon S3 File Uploader that uploads directly to Amazon S3 making file uploads faster.
* New: File browser now allows navigation by folder.
* Fix: Number of files listed was limited to 1000 files.
* Fix: Prevent password managers from autofilling and prompting to save S3 and Cloudfront details.

= 3.0.6 =
* New: OptimizePress builder and landing pages compatability.
* New: Filters 's3mm_s3_file_name' and 's3mm_cloudfront_file_name' to adjust a file name.
* Fix: Divi Builder responive layout issue when video is inserted into an accordion.
* Fix: Deactivating a non-valid license would throw an error.
* Fix: License updater issue on some server configurations.

= 3.0.5 =
* New: Compatibility with Elementor Builder.
* Fix: Compatibility with other Amazon S3 plugins.
* Fix: Conflict with WordPress SEO plugin.
* Fix: Width and height issue when video player exits full screen mode.
* Fix: Backwards compatibility fix for powered by link.
* Fix: Url encode file names when they contain spaces for CloudFront signed urls.
* Fix: Viewing update changelog caused an error.
* Fix: Audio player speed css alignment.

= 3.0.4 =
* New: Compatibility with Beaver Builder.
* Fix: Style conflicts and further compatibility with Divi Builder.
* Fix: Style conflicts and further compatibility with the Divi Builder.
* Fix: S3 and CloudFront signed urls were being requested twice when loading the page.
* Fix: Conflict with iThemes security when saving settings.
* Fix: IE 11 settings page showed a blank screen.
* Fix: Video and audio attributes 'autoplay', 'controls', 'loop', and 'preload' were not loading correctly.
* Fix: Default audio height was set to 30 by default. Should be set to 40 by default.
* Fix: Wrong rest api route and handler was being used to upload files to S3.
* Fix: Error reporting for shortcode builder.
* Fix: Assign the correct bucket region when creating a bucket using the shortcode builder.
* Fix: S3 region was not being displayed in the shortcode builder.
* Fix: Selection of files is reset when the shortcode builder is closed or file type is changed.
* Fix: Title label of the file selection now displays the type of file.

= 3.0.3 =
* Fix: To maintain backwards compatibility, remove leading slashes from file paths when signing urls from CloudFront or Amazon s3.
* Fix: Shortcode builder compatability with Divi Builder and Visual Composer.
* Fix: Update processor was not loading the correct license key before requesting a new file update.
* Fix: Check and load the AWS PHP Sdk conditionally to prevent conflicts with other plugins.

= 3.0.2 =
* Fix: Fix path of license updater which can fail on certain server setups.

= 3.0.1 =
* Fix: Resolved and issue with the license activation process.

= 3.0.0 =
* New: Deep Integration with Amazon AWS.
* New: New and improved shortcode builder.
* New: Ability to create buckets directly from the settings page.
* New: Ability to add video and audio files directly from shortcode builder.
* New: Ability to create buckets directly from shortcode builder.
* New: Abilty to upload multiple files directly from shortcode builder.
* New: AWS Keys are now obfuscated.
* New: License Keys are now obfuscated.
* New: Global defalut settings now available for player skin, splash image, player volume, player responsiveness, player metadata.
* New: Support articles available directly from settings page.
* New: MediaElemntsJS player 4.2.6 (latest version) now included.
* Fix: Playlist will work with all skins.
* Fix: Playlist now supports full screen.
* Fix: Fixed bug so that the license key doesn’t check in on every admin init.
* Tweak: Moved admin settings page under the WordPress Settings menu.

= 2.0.4 =
* New: Added region support for Canada and London.

= 2.0.3 =
* Fix: Fixed issue where CloudFront variables were not declared properly for shortcodes.
* Fix: Fixed issue where plugin license checker didn't have proper conditional statement.
* Fix: Fixed the names of the constructor methods to comply with PHP7.
* Update: Updated the EDDSL plugin checker class.

= 2.0.2 =
* New: Added new bucket regions for Seoul (Asia Pacific), Ohio (U.S.) and Mumbai (Asia Pacific).

= 2.0.1 =
* Fix: Fixed bug where plugin was not communicating with our license server and displaying an "Exceeded license limit" error.

= 2.0 =
* New: Added CloudFront as an option for serving content via CloudFront distribution.
* New: Using native WordPress MediaElements javascript and css.
* New: Added option for turing off MediaElements CSS.
* New: Added titles option for playlists in the shortcode generator.
* New: Added Vimeo capability.

= 1.8.2 =
* New: Added a no-right-click JavaScript so that right click is not allowed on the MediaElements JS player.

= 1.8.1 =
* Fix: Fixed conflict with WP Courseware when configuring WP Courseware email addresses with a long suffix.
* Fix: Fixed function that creates URL for the plugin path.

= 1.8 =
* New: AWS V4 Signing for bucket regions that only support V4. All buckets support V4 but not all buckets support V2 signing.
* New: Default Region setting on the settings page.
* New: Region setting in the shortcode generator.
* New: Updated version of Media Elements JS player.
* New: Playlist feature for video and audio.
* New: Added new shortcode parameter "titles" for playlists.
* New: Added localization template file.

= 1.7 =
* Tweak: Modified affiliate function to reflect our new affiliate system.

= 1.6 =
* New: Ability to embed YouTube videos.
* New: Ability to make videos responsive.
* New: Added default audio/video height and width setting.
* New: New documentation page with new videos.

= 1.53 =
* Fix: Fixed a minor bug with local library files.

= 1.52 =
* Fix: Updated local libraries and MediaElements libraries.

= 1.51 =
* New: Updated localization functions in preparation for full localization.

= 1.5 =
* Fix: Fixed the updater class bug that prevents plugin details to display in the light box.

= 1.4 =
* Base Plugin Release.

