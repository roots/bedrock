<?php
/**
 * S3 Media Maestro Plugin.
 *
 * @sicne 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\Base;

defined( 'ABSPATH' ) || die;

/**
 * Class Plugin.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Plugin extends Base {

	/**
	 * Plugin Instance.
	 *
	 * @since 3.0.0
	 *
	 * @param null $class
	 *
	 * @return Plugin The plugin object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Plugin.
	 *
	 * @since 3.0.0
	 */
	public function load() {
		$this->load_files();
		$this->load_textdomain();
		$this->load_objects();

		/**
		 * Hook: Plugin Loaded.
		 *
		 * @since 3.0.0
		 */
		do_action( 's3mm_loaded' );
	}

	/**
	 * Load Files.
	 *
	 * @since 3.0.0
	 */
	protected function load_files() {
		spl_autoload_register( array( $this, 'autoload' ) );
	}

	/**
	 * Load Plugin Textdomain.
	 *
	 * @since 3.0.0
	 */
	protected function load_textdomain() {
		// Traditional WordPress plugin locale filter
		$locale = apply_filters( 'plugin_locale', get_locale(), $this->domain );
		$mofile = sprintf( '%1$s-%2$s.mo', $this->domain, $locale );

		// Setup paths to current locale file
		$mofile_local  = $this->lang_dir . $mofile;
		$mofile_global = WP_LANG_DIR . '/s3-media-maestro/' . $mofile;

		// Look in global /wp-content/languages/s3-media-maestro folder
		load_textdomain( $this->domain, $mofile_global );

		// Look in local /wp-content/plugins/s3-media-maestro/languages/ folder
		load_textdomain( $this->domain, $mofile_local );

		// Look in global /wp-content/languages/plugins/
		load_plugin_textdomain( $this->domain );
	}

	/**
	 * Load Plugin Objects.
	 *
	 * @since 3.0.0
	 */
	protected function load_objects() {
		$objects = array(
			'Admin',
			'Aws',
			'Api',
			'License',
			'System',
			'Products',
			'Shortcode',
		);

		foreach ( $objects as $object ) {
			$class = __NAMESPACE__ . "\\{$object}";
			if ( class_exists( $class ) ) {
				call_user_func( array( $class, 'get_object' ) );
			}
		}
	}

	/**
	 * Plugin Class Autoloader.
	 *
	 * @since 3.0.0
	 *
	 * @param string $class The class name.
	 *
	 * @return bool|mixed|void
	 */
	public function autoload( $class ) {
		if ( 0 !== strpos( $class, __NAMESPACE__ . '\\', 0 ) ) {
			return;
		}

		static $loaded = array();

		if ( isset( $loaded[ $class ] ) ) {
			return $loaded[ $class ];
		}

		$class = str_replace( __NAMESPACE__ . '\\', '', $class );
		$class = str_replace( array( '\\', '/' ), DIRECTORY_SEPARATOR, __DIR__ . DIRECTORY_SEPARATOR . $class . '.php' );

		if ( false === ( $class = realpath( $class ) ) ) {
			return false;
		}

		return $loaded[ $class ] = ( bool ) require( $class );
	}
}