<?php
/**
 * S3MM Shortcode.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use FLBuilderModel;
use WP_REST_Request;

defined( 'ABSPATH' ) || die;

/**
 * Class Shortcode.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Shortcode extends Base {

	/**
	 * @var Aws The AWS object instance.
	 * @since 3.0.0
	 */
	protected $aws;

	/**
	 * @var array Shortcode Attributes.
	 * @since 3.0.0
	 */
	protected $atts = array();

	/**
	 * @var string Shortcode Content.
	 * @since 3.0.0
	 */
	protected $content = '';

	/**
	 * @var string Shortcode Tag.
	 * @since 3.0.0
	 */
	protected $tag = '';

	/**
	 * @var string Shortcode Html
	 * @since 3.0.0
	 */
	protected $html = '';

	/**
	 * @var string|array The Files for the Shortcode.
	 * @since 3.0.0
	 */
	protected $files = array();

	/**
	 * @var int Player Instance.
	 * @since 3.0.0
	 */
	protected $instance = 0;

	/**
	 * @var bool Should the file be protected.
	 * @sicne 3.2.3
	 */
	protected $protected = false;

	/**
	 * @var bool Is the file third-party like YouTube, Vimeo.
	 * @since 3.2.2
	 */
	protected $third_party = false;

	/**
	 * Shortcode Instance.
	 *
	 * @param null $class The class object.
	 *
	 * @return Shortcode The admin object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Shortcode Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		$this->hooks();
		$this->builder_hooks();
	}

	/**
	 * Shortcode Hooks.
	 *
	 * @since 3.0.0
	 */
	public function hooks() {
		// Register Assets.
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );

		// Current Shortcode.
		add_shortcode( 's3mm', array( $this, 'shortcode' ) );

		// Old Shortcodes.
		add_shortcode( 's3video', array( $this, 'shortcode_video' ) );
		add_shortcode( 's3audio', array( $this, 'shortcode_audio' ) );
		add_shortcode( 's3file', array( $this, 'shortcode_file' ) );

		// WP Courseware Integration.
		add_action( 'wp_ajax_s3mm_auto_navigate_unit', array( $this, 'ajax_auto_navigate_unit' ) );
		add_action( 'wp_ajax_nopriv_s3mm_auto_navigate_unit', array( $this, 'ajax_auto_navigate_unit' ) );

		// Add Protected Query Vars.
		if ( $this->is_protection_enabled() ) {
			add_action( 'query_vars', array( $this, 'maybe_add_protected_url_query_var' ) );
			add_action( 'wp', array( $this, 'maybe_serve_protected_url' ) );
		}

		// Optimizepress Integration.
		add_action( 'op_setup', array( $this, 'optimizepress_shortcode_frontend_integration' ) );
	}

	/**
	 * Register Shortcode Assets.
	 *
	 * @since 3.0.0
	 */
	public function register_assets() {
		// Api.
		$api = Api::get_object();

		// Builder Styles.
		wp_register_style( 's3mm-shortcode-css', $this->css( 'shortcode.css' ), array(), S3MM_VERSION, 'all' );
		wp_register_style( 's3mm-shortcode-wpcw-css', $this->css( 'shortcode-wpcw.css' ), array(), S3MM_VERSION, 'all' );

		// SSL.
		$ssl = is_ssl() ? 'https' : 'http';

		// Builder Scripts.
		wp_register_script( 's3mm-shortcode-js', $this->js( 'shortcode.js' ), array( 'jquery' ), S3MM_VERSION, true );
		wp_localize_script( 's3mm-shortcode-js', 's3mmShortcodeVars', apply_filters( 's3mm_shortcode_js_vars', array(
			'wpcw_enabled' => $this->is_wpcw_enabled() ? 'yes' : 'no',
			'ajax_url'     => admin_url( 'admin-ajax.php', $ssl ),
			'api_url'      => $api->get_url(),
			'api_nonce'    => $api->get_nonce(),
		) ) );
	}

	/**
	 * Enqueue Shortcode Assets.
	 *
	 * @since 3.0.0
	 */
	public function enqueue_assets() {
		wp_enqueue_style( 's3mm-shortcode-css' );
		wp_enqueue_script( 's3mm-shortcode-js' );
	}

	/**
	 * Enqueue WPCW Assets.
	 *
	 * @since 3.2.0
	 */
	public function enqueue_wpcw_assets() {
		wp_enqueue_style( 's3mm-shortcode-wpcw-css' );
	}

	/**
	 * Main S3MM Shortcode.
	 *
	 * @since 3.0.0
	 *
	 * @param array  $atts The shortcode attributes.
	 * @param string $content The shortcode content.
	 * @param string $tag The shortcode tag.
	 *
	 * @return string
	 */
	public function shortcode( $atts, $content = null, $tag ) {
		$this->load_settings();

		$this->atts = shortcode_atts( array(
			'type'             => $this->get_setting( 'type' ),
			'source'           => $this->get_setting( 'source' ),
			's3bucket'         => $this->get_setting( 's3bucket' ),
			's3region'         => $this->get_setting( 's3region' ),
			's3accesskey'      => $this->get_setting( 's3accesskey' ),
			's3secretkey'      => $this->get_setting( 's3secretkey' ),
			'expiry'           => $this->get_setting( 's3expiry' ),
			'files'            => $this->get_setting( 's3files' ),
			'titles'           => $this->get_setting( 's3titles' ),
			'player'           => $this->get_setting( 'player' ),
			'size'             => $this->get_setting( 'playersize' ),
			'height'           => $this->get_setting( 'playerheight' ),
			'width'            => $this->get_setting( 'playerwidth' ),
			'audiowidth'       => $this->get_setting( 'playeraudiowidth' ),
			'audioheight'      => $this->get_setting( 'playeraudioheight' ),
			'preload'          => $this->get_setting( 'playerpreload' ),
			'autoplay'         => $this->get_setting( 'playerautoplay' ),
			'controls'         => $this->get_setting( 'playercontrols' ),
			'loop'             => $this->get_setting( 'playerloop' ),
			'volume'           => $this->get_setting( 'playervolume' ),
			'splash'           => $this->get_setting( 'playersplashimg' ),
			'skin'             => $this->get_setting( 'playerskin' ),
			'protectsrc'       => $this->get_setting( 'playerprotectsrc' ),
			'poweredbylink'    => $this->get_setting( 'poweredbylink' ),
			'affiliateid'      => $this->get_setting( 'affiliateid' ),
			'cfid'             => $this->get_setting( 'cfkey' ),
			'cfkey'            => $this->get_setting( 'cfprivatekey' ),
			'cfurl'            => $this->get_setting( 'cfdisturl' ),
			'linkattributes'   => $this->get_setting( 'linkattributes' ),
			'linknewtab'       => $this->get_setting( 'linknewtab' ),
			'wpcwrequiremedia' => $this->get_setting( 'wpcwrequiremedia' ),
			'wpcwcontroltype'  => $this->get_setting( 'wpcwcontroltype' ),
			'wpcwmediapercent' => $this->get_setting( 'wpcwmediapercent' ),
		), $atts, 's3mm' );

		$this->content = $content;
		$this->tag     = $tag;
		$this->html    = '';

		$files = $this->get_attr( 'files' );

		if ( empty( $files ) ) {
			return sprintf( '<p>%s</p>', esc_html__( 'No S3 or Cloudfront files were specified.', 's3mm' ) );
		}

		$this->maybe_protect();
		$this->enqueue_assets();
		$this->setup_aws();
		$this->set_files();

		ob_start();

		if ( in_array( $this->get_type(), array( 'video', 'audio' ) ) ) {
			switch ( $this->get_attr( 'player', 'mediaelementjs' ) ) {
				case 'mediaelementjs':
					$this->shortcode_mediaelementjs_player();
					break;
			}
		}

		if ( 'file' === $this->get_type() ) {
			$this->shortcode_file_download();
		}

		$this->html = ob_get_clean();

		$this->increment_instance();
		$this->reset_files();

		return apply_filters( 's3mm_shortcode_html', $this->html, $this->atts, $this->content );
	}

	/**
	 * Back Compat Shortcode Video.
	 *
	 * @since 3.0.0
	 *
	 * @param array       $atts The shortcode attributes.
	 * @param string|null $content The content of the shortcode.
	 * @param string      $tag The shortcode tag.
	 *
	 * @return string|null
	 */
	public function shortcode_video( $atts, $content = null, $tag ) {
		if ( empty( $atts ) ) {
			$atts = array();
		}

		$atts['type'] = 'video';

		$new_atts    = $this->merge_back_compat_shortcode_atts( $atts );
		$new_content = $this->merge_back_compat_shortcode_content( $content );

		return $this->shortcode( $new_atts, $new_content, 's3mm' );
	}

	/**
	 * Back Compat Shortcode Audio.
	 *
	 * @since 3.0.0
	 *
	 * @param array       $atts The shortcode attributes.
	 * @param string|null $content The content of the shortcode.
	 * @param string      $tag The shortcode tag.
	 *
	 * @return string|null
	 */
	public function shortcode_audio( $atts, $content = null, $tag ) {
		if ( empty( $atts ) ) {
			$atts = array();
		}

		$atts['type'] = 'audio';

		$new_atts    = $this->merge_back_compat_shortcode_atts( $atts );
		$new_content = $this->merge_back_compat_shortcode_content( $content );

		return $this->shortcode( $new_atts, $new_content, 's3mm' );
	}

	/**
	 * Back Compat Shortcode Files.
	 *
	 * @since 3.0.0
	 *
	 * @param array       $atts The shortcode attributes.
	 * @param string|null $content The content of the shortcode.
	 * @param string      $tag The shortcode tag.
	 *
	 * @return string|null
	 */
	public function shortcode_file( $atts, $content = null, $tag ) {
		if ( empty( $atts ) ) {
			$atts = array();
		}

		$atts['type'] = 'file';

		$new_atts    = $this->merge_back_compat_shortcode_atts( $atts );
		$new_content = $this->merge_back_compat_shortcode_content( $content );

		return $this->shortcode( $new_atts, $new_content, 's3mm' );
	}

	/**
	 * Maybe Protect.
	 *
	 * @since 3.2.3
	 */
	protected function maybe_protect() {
		global $is_safari;

		$is_protected = ( 'yes' === $this->get_attr( 'protectsrc' ) ) &&
		                ( 'file' !== $this->get_type() ) &&
		                $this->is_protection_enabled()
			? true
			: false;

		if ( wp_is_mobile() || $is_safari ) {
			$is_protected = false;
		}

		$this->protected = apply_filters( 's3mm_shortcode_protect_content', $is_protected );
	}

	/**
	 * Get AWS Attributes.
	 *
	 * @since 3.2.2
	 *
	 * @return array The array of aws attributes.
	 */
	protected function get_aws_atts() {
		return array(
			's3bucket'     => $this->get_attr( 's3bucket' ),
			's3region'     => $this->get_attr( 's3region' ),
			's3accesskey'  => $this->get_attr( 's3accesskey' ),
			's3secretkey'  => $this->get_attr( 's3secretkey' ),
			'cfkey'        => $this->get_attr( 'cfid' ),
			'cfprivatekey' => $this->get_attr( 'cfkey' ),
			'cfdisturl'    => $this->get_attr( 'cfurl' ),
			's3expiry'     => $this->get_attr( 'expiry' ),
			'cfexpiry'     => $this->get_attr( 'expiry' ),
		);
	}

	/**
	 * Setup Amazon Web Services
	 *
	 * @since 3.0.0
	 */
	protected function setup_aws() {
		if ( empty( $this->aws ) || $this->aws instanceof Aws ) {
			$this->aws = Aws::get_object();
		}

		$aws_settings = $this->get_aws_atts();

		foreach ( $aws_settings as $setting_key => $setting ) {
			$this->set_setting( $setting_key, $setting );
		}
	}

	/**
	 * Shortcode Get MediaElementsJs Player Settings
	 *
	 * @since 3.0.0
	 *
	 * @return string The MediaElementsJs Player Settings.
	 */
	public function get_mediaelementjs_player_settings_json() {
		$settings = array(
			'pluginPath'        => $this->assets_dir . 'swf',
			'classPrefix'       => 's3mm_mejs__',
			'useFakeFullscreen' => true,
			'startVolume'       => $this->get_attr( 'volume', '0.8' ),
			'renderers'         => [ 'html5', 'vimeo_iframe', 'youtube_iframe', 'flash_video', 'flash_audio' ],
			'stretching'        => $this->get_stretching_mode(),
		);

		if ( 'video' === $this->get_type() ) {
			$settings['poster'] = $this->get_attr( 'splash' );
		}

		if ( $this->is_playlist() ) {
			$settings['playlist'] = $this->get_playlist_src_files();

			$settings['features'] = apply_filters( 's3mm_mediaelementjs_player_playlist_features', array(
				'playpause',
				'current',
				'progress',
				'duration',
				'tracks',
				'volume',
				'playlist',
				'prevtrack',
				'nexttrack',
				'shuffle',
				'loop',
				'speed',
				'fullscreen',
			) );

			if ( 'audio' === $this->get_type() ) {
				$settings['currentMessage'] = apply_filters( 's3mm_mediaelementjs_player_playlist_audio_current_message', esc_html__( 'Now Playing', 's3mm' ) );
			}

			$settings['autoClosePlaylist'] = apply_filters( 's3mm_mediaelementjs_player_playlist_auto_close', true );
		} else {
			$settings['features'] = apply_filters( 's3mm_mediaelementjs_player_features', array(
				'playpause',
				'current',
				'progress',
				'duration',
				'volume',
				'loop',
				'speed',
				'fullscreen',
			) );
		}

		if ( 'fixed' === $this->get_size() && 'video' === $this->get_type() ) {
			$settings['videoWidth']  = absint( $this->get_width() );
			$settings['videoHeight'] = absint( $this->get_height() );
		} elseif ( 'fixed' === $this->get_size() && 'audio' === $this->get_type() ) {
			$settings['audioWidth']  = absint( $this->get_audio_width() );
			$settings['audioHeight'] = absint( $this->get_audio_height() );
		}

		$settings = apply_filters( 's3mm_mediaelementjs_player_settings', $settings );

		return htmlspecialchars( wp_json_encode( $settings ) );
	}

	/**
	 * Shortcode MediaElementsJs Player
	 *
	 * @since 3.0.0
	 */
	protected function shortcode_mediaelementjs_player() {
		printf( '<div class="%s%s%s">', apply_filters( 's3mm_mediaelementjs_player_wrapper_class', 's3mm-mejs-player' ), $this->get_outer_size_class(), $this->get_outer_type_class() );
		printf(
			'<%s %s %s %s %s class="s3mm_mejs__player%s%s" %s %s %s data-s3mm_mejsoptions="%s"%s>',
			$this->get_type(),
			$this->get_autoplay(),
			$this->get_controls(),
			$this->get_loop(),
			$this->get_preload(),
			$this->get_skin_class(),
			$this->get_size_class(),
			$this->get_file_src(),
			$this->get_size_style(),
			$this->get_size_attrs(),
			$this->get_mediaelementjs_player_settings_json(),
			$this->get_player_wpcw_settings()
		);
		foreach ( $this->get_files() as $file ) {
			printf(
				'<source type="%s" src="%s" title="%s" />',
				isset( $file['mime'] ) ? $file['mime'] : '',
				isset( $file['url'] ) ? $file['url'] : '',
				isset( $file['title'] ) ? $file['title'] : ''
			);
		}
		printf( '</%s>', $this->get_type() );
		echo $this->get_powered_by_link();
		printf( '</div>' );
	}

	/**
	 * Shortcode File Download.
	 *
	 * @since 3.0.0
	 */
	protected function shortcode_file_download() {
		$file            = $this->get_file_single();
		$file_url        = isset( $file['url'] ) ? $file['url'] : '';
		$file_new_tab    = 'yes' === $this->get_attr( 'linknewtab' ) ? 'target="_blank"' : '';
		$file_attributes = $this->get_attr( 'linkattributes' );
		$file_text       = $this->content ? $this->content : '';

		printf( '<a href="%s" %s %s>%s</a>', $file_url, $file_new_tab, $file_attributes, $file_text );
	}

	/**
	 * Get Stretching Mode.
	 *
	 * @link https://github.com/mediaelement/mediaelement/blob/master/docs/usage.md#stretching-modes
	 *
	 * @since 3.0.0
	 */
	protected function get_stretching_mode() {
		return $this->is_responsive() ? 'responsive' : 'none';
	}

	/**
	 * Get Type.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_type() {
		return $this->get_attr( 'type', 'video' );
	}

	/**
	 * Get Source.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_source() {
		return $this->get_attr( 'source', 's3' );
	}

	/**
	 * Set Files.
	 *
	 * @since 3.0.0
	 */
	protected function set_files() {
		$files = explode( ',', $this->get_attr( 'files' ) );

		if ( $this->get_attr( 'type' ) === 'file' ) {
			$files = current( $files );
		}

		if ( is_array( $files ) ) {
			foreach ( $files as $key => $file ) {
				$this->files[] = array(
					'file'  => $file,
					'title' => $this->get_file_title( $key, $file ),
					'mime'  => $this->get_file_mime( $file ),
					'url'   => $this->get_file_url( $file ),
				);
			}
		} else {
			$this->files[] = array(
				'file'  => $files,
				'title' => $this->get_file_title( 0, $files ),
				'mime'  => $this->get_file_mime( $files ),
				'url'   => $this->get_file_url( $files ),
			);
		}
	}

	/**
	 * Reset Files.
	 *
	 * @since 3.0.0
	 */
	protected function reset_files() {
		$this->files = array();
	}

	/**
	 * Get Files.
	 *
	 * @since 3.0.0
	 *
	 * @return array|string
	 */
	protected function get_files() {
		return $this->files;
	}

	/**
	 * Get File Single.
	 *
	 * Mainly used for the single file type.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_file_single() {
		$files = $this->get_files();

		return ( is_array( $files ) && 'file' === $this->get_type() ) ? $files[0] : '';
	}

	/**
	 * Get File Single Source.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_file_src() {
		if ( $this->is_playlist() ) {
			return;
		}

		$file = $this->get_file_single();

		return isset( $file['url'] ) ? sprintf( ' src="%s"', $file['url'] ) : '';
	}

	/**
	 * Get Playlist Source Files.
	 *
	 * @since 3.0.0
	 *
	 * @return array $sources The video / audio sources.
	 */
	protected function get_playlist_src_files() {
		$sources = array();

		foreach ( $this->get_files() as $key => $file ) {
			$sources[] = array(
				'title' => isset( $file['title'] ) ? $file['title'] : '',
				'src'   => isset( $file['url'] ) ? $file['url'] : '',
				'type'  => isset( $file['mime'] ) ? $file['mime'] : '',
			);
		}

		return $sources;
	}

	/**
	 * Is Playlist?
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	protected function is_playlist() {
		$files = $this->get_files();

		return is_array( $files ) && count( $files ) > 1;
	}

	/**
	 * Get Titles.
	 *
	 * @since 3.0.0
	 *
	 * @return array|string The file titles.
	 */
	protected function get_titles() {
		return explode( ',', $this->get_attr( 'titles' ) );
	}

	/**
	 * Should be protected?
	 *
	 * @since 3.2.2
	 *
	 * @return bool
	 */
	protected function should_be_protected() {
		return $this->protected;
	}

	/**
	 * Is the file is third party.
	 *
	 * @since 3.2.2
	 *
	 * @return bool
	 */
	protected function is_file_third_party() {
		return $this->third_party;
	}

	/**
	 * Is File Protectable?
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file.
	 *
	 * @return bool $is_protectable Is the file protectable?
	 */
	protected function is_file_protectable( $file ) {
		$is_protectable = false;

		// Protectable Sources.
		$protectable_sources = apply_filters( 's3mm_protectable_sources', array( 'non-s3', 's3' ) );

		// Check File Source.
		if ( in_array( $this->get_source(), $protectable_sources ) ) {
			$is_protectable = true;
		}

		// Check if file is local.
		if ( $this->is_file_local( $file ) ) {
			$is_protectable = true;
		}

		// Check if protection is enabled, last ditch effort.
		if ( ! $this->is_protection_enabled() ) {
			$is_protectable = false;
		}

		return $is_protectable;
	}

	/**
	 * Is File Local?
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file.
	 *
	 * @return bool
	 */
	protected function is_file_local( $file ) {
		return file_exists( Utils::get_local_file_path( $file ) );
	}

	/**
	 * Get AWS File Url.
	 *
	 * @since 3.2.2
	 *
	 * @param string $file The file name.
	 *
	 * @return string $file_url The aws file url.
	 */
	protected function get_aws_file_url( $file ) {
		if ( 'cloudfront' === $this->get_source() ) {
			$file_url = $this->aws->get_cloudfront_signed_url( $file, $this->get_settings() );
		} elseif ( 's3' === $this->get_source() ) {
			$file_url = $this->aws->get_s3_signed_url( $file, $this->get_settings() );
		} else {
			$file_url = $file;
		}

		return $file_url;
	}

	/**
	 * Get File Url.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file The file string.
	 *
	 * @return string The File Url.
	 */
	protected function get_file_url( $file ) {
		return ( $this->should_be_protected() &&
		         $this->is_file_protectable( $file ) &&
		         ! $this->is_file_third_party() )
			? $this->get_protected_file_url( $file )
			: $this->get_aws_file_url( $file );
	}

	/**
	 * Get File Mime Type.
	 *
	 * @param string $file The file.
	 *
	 * @return string The mime type.
	 */
	protected function get_file_mime( $file ) {
		$file_type = wp_check_filetype( $file, wp_get_mime_types() );

		$this->third_party = false;

		if ( empty( $file_type['type'] ) ) {
			if ( strstr( $file, 'youtube' ) ) {
				$this->third_party = true;
				$file_type['type'] = 'video/youtube';
			}
			if ( strstr( $file, 'youtu.be' ) ) {
				$this->third_party = true;
				$file_type['type'] = 'video/youtube';
			}
			if ( strpos( $file, 'vimeo' ) ) {
				$this->third_party = true;
				$file_type['type'] = 'video/vimeo';
			}
		}

		return ! empty( $file_type['type'] ) ? $file_type['type'] : '';
	}

	/**
	 * Get File Title.
	 *
	 * @param int    $key The array key.
	 * @param string $file The file name.
	 *
	 * @return string The file title of the default file name.
	 */
	protected function get_file_title( $key, $file ) {
		$titles = $this->get_titles();

		$default = $this->should_be_protected() ? '' : $file;

		return ! empty( $titles[ $key ] ) ? $titles[ $key ] : $default;
	}

	/**
	 * Get Skin Class.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_skin_class() {
		if ( 'audio' === $this->get_type() ) {
			return ! $this->is_playlist() ? ' s3mm_mejs__audio_single' : '';
		}

		$skin = $this->get_attr( 'skin', 'default' );

		return 'default' !== $skin ? sprintf( ' s3mm_mejs__%s', $skin ) : '';
	}

	/**
	 * Get Size.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_size() {
		return $this->get_attr( 'size', 'responsive' );
	}

	/**
	 * Is Responsive?
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	protected function is_responsive() {
		return 'responsive' === $this->get_size() ? true : false;
	}

	/**
	 * Get Size Style.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_size_style() {
		if ( 'fixed' === $this->get_size() ) {
			return sprintf( 'style="width:%spx;height%spx;"', $this->get_width(), $this->get_height() );
		}

		if ( $this->get_type() === 'audio' ) {
			return sprintf( 'style="max-width:%s;"', '100%' );
		}

		return;
	}

	/**
	 * Get Size Attributes.
	 *
	 * @since 3.1.1
	 *
	 * @return string The size attributes.
	 */
	protected function get_size_attrs() {
		if ( 'fixed' !== $this->get_size() && 'video' !== $this->get_type() ) {
			return '';
		}

		if ( $this->is_responsive() ) {
			return '';
		}

		return sprintf( 'width="%s" height="%s"', $this->get_width(), $this->get_height() );
	}

	/**
	 * Get Outer Size Class.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_outer_size_class() {
		return sprintf( ' s3mm-mejs-player-%s', $this->get_size() );
	}

	/**
	 * Get Outer Type Class.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_outer_type_class() {
		return sprintf( ' s3mm-mejs-player-%s', $this->get_type() );
	}

	/**
	 * Get Size Class.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_size_class() {
		return sprintf( ' s3mm_mejs__%s', $this->get_size() );
	}

	/**
	 * Get Width Style.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_width_style() {
		return 'fixed' === $this->get_size() ? sprintf( 'style="width:%spx;"', $this->get_width() ) : '';
	}

	/**
	 * Get Player Width.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_width() {
		return ( 'audio' === $this->get_type() ) ? $this->get_audio_width() : $this->get_video_width();
	}

	/**
	 * Get Player Height.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_height() {
		return ( 'audio' === $this->get_type() ) ? $this->get_audio_height() : $this->get_video_height();
	}

	/**
	 * Get Video Player Width.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_video_width() {
		return $this->get_attr( 'width', '480' );
	}

	/**
	 * Get Video Player Height.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_video_height() {
		return $this->get_attr( 'height', '270' );
	}

	/**
	 * Get Audio Player Width.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_audio_width() {
		return $this->get_attr( 'audiowidth', '400' );
	}

	/**
	 * Get Audio Player Height.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|string
	 */
	protected function get_audio_height() {
		return $this->get_attr( 'audioheight', '30' );
	}

	/**
	 * Get Player Autoplay.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_autoplay() {
		return filter_var( $this->get_attr( 'autoplay' ), FILTER_VALIDATE_BOOLEAN ) ? 'autoplay' : '';
	}

	/**
	 * Get Player Autoplay - Boolean.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	protected function get_autoplay_bool() {
		return filter_var( $this->get_attr( 'autoplay' ), FILTER_VALIDATE_BOOLEAN ) ? true : false;
	}

	/**
	 * Get Player Controls.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_controls() {
		return filter_var( $this->get_attr( 'controls' ), FILTER_VALIDATE_BOOLEAN ) ? 'controls' : '';
	}

	/**
	 * Get Player Controls - Boolean.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	protected function get_controls_bool() {
		return filter_var( $this->get_attr( 'controls' ), FILTER_VALIDATE_BOOLEAN ) ? true : false;
	}

	/**
	 * Get Player Loop.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_loop() {
		return filter_var( $this->get_attr( 'loop' ), FILTER_VALIDATE_BOOLEAN ) ? 'loop' : '';
	}

	/**
	 * Get Player Loop - Boolean
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	protected function get_loop_bool() {
		return filter_var( $this->get_attr( 'loop' ), FILTER_VALIDATE_BOOLEAN ) ? true : false;
	}

	/**
	 * Get Player Preload.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_preload() {
		return sprintf( 'preload="%s"', $this->get_preload_value() );
	}

	/**
	 * Get Player Preload Value.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_preload_value() {
		return $this->get_attr( 'preload', 'auto' );
	}

	/**
	 * Get Volume.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_volume() {
		return $this->get_attr( 'volume', '0.8' );
	}

	/**
	 * Get Powered By Link.
	 *
	 * @since 3.0.0
	 *
	 * @return string|void
	 */
	protected function get_powered_by_link() {
		$powered_by   = $this->get_attr( 'poweredbylink', 'no' );
		$affiliate_id = $this->get_attr( 'affiliateid' );

		if ( 'no' === $powered_by ) {
			return;
		}

		$url = $this->company_url();

		if ( $affiliate_id ) {
			$url = add_query_arg( array( 'fly' => $affiliate_id ), $url );
		}

		return sprintf( __( '<div class="s3mm-powered-by" %s>Powered By <a href="%s" rel="nofollow" target="_blank">%s</a></div>', 's3mm' ), $this->get_width_style(), $url, $this->plugin_name() );
	}

	/**
	 * Get WP Courseware Required Media Boolean.
	 *
	 * @since 3.2.0
	 *
	 * @return string The require media data control.
	 */
	protected function get_wpcw_requiremedia() {
		$require_media = $this->get_wpcw_requiremedia_bool();

		return $require_media ? 'data-wpcwrequiremedia="true"' : '';
	}

	/**
	 * Get WP Courseware Required Media Boolean.
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if video/audio is required.
	 */
	protected function get_wpcw_requiremedia_bool() {
		return filter_var( $this->get_attr( 'wpcwrequiremedia' ), FILTER_VALIDATE_BOOLEAN ) ? true : false;
	}

	/**
	 * Get WP Courseware Control Type
	 *
	 * @since 3.2.0
	 *
	 * @return string The control type string data control.
	 */
	protected function get_wpcw_controltype() {
		return sprintf( 'data-wpcwcontroltype="%s"', $this->get_attr( 'wpcwcontroltype', 'button' ) );
	}

	/**
	 * Get WP Courseware Media Percent.
	 *
	 * @since 3.2.0
	 *
	 * @return string The media percent string data control.
	 */
	protected function get_wpcw_mediapercent() {
		return sprintf( 'data-wpcwmediapercent="%s"', $this->get_attr( 'wpcwmediapercent', '100' ) );
	}

	/**
	 * Get WP Courseware Integration Settings.
	 *
	 * @since 3.2.0
	 *
	 * @return string The string of WP Courseware Settings.
	 */
	protected function get_player_wpcw_settings() {
		if ( ! $this->is_wpcw_enabled() ) {
			return;
		}

		if ( ! in_array( $this->get_source(), array( 's3' ), true ) ) {
			return;
		}

		if ( $this->get_wpcw_requiremedia_bool() ) {
			$this->enqueue_wpcw_assets();
		}

		return sprintf( ' %s %s %s', $this->get_wpcw_requiremedia(), $this->get_wpcw_controltype(), $this->get_wpcw_mediapercent() );
	}

	/**
	 * Get Shortcode Attribute.
	 *
	 * @since 3.0.0
	 *
	 * @param string $key
	 *
	 * @return string The value of the attribute.
	 */
	public function get_attr( $key, $default = '' ) {
		return isset( $this->atts[ $key ] ) ? $this->atts[ $key ] : $default;
	}

	/**
	 * Back Compat Shortcode Attributes Map.
	 *
	 * @since 3.0.0
	 *
	 * @return array
	 */
	protected function get_back_compat_shortcode_atts_map() {
		return apply_filters( 's3mm_compat_shortcode_atts_map', array(
			'type'           => 'type',
			's3bucket'       => 's3bucket',
			's3region'       => 's3bucketregion',
			's3accesskey'    => 's3accesskey',
			's3secretkey'    => 's3secretkey',
			'expiry'         => 's3expiry',
			'files'          => '',
			's3source'       => 's3url',
			'nons3source'    => 'url',
			'titles'         => 'titles',
			'player'         => '',
			'size'           => 'responsive',
			'height'         => 'height',
			'width'          => 'width',
			'audioheight'    => '',
			'audiowidth'     => '',
			'preload'        => 'preload',
			'autoplay'       => 'autoplay',
			'controls'       => 'controls',
			'loop'           => 'loop',
			'volume'         => 'volume',
			'splash'         => 'splash',
			'skin'           => 'skin',
			'poweredbylink'  => 'hidepoweredby',
			'cf'             => 'cloudfront',
			'cfurl'          => 'distribution',
			'cfid'           => 'cfkeyPairID',
			'cfkey'          => 'cfprivateKey',
			'linkattributes' => 'attributes',
			'linknewtab'     => 'newtab',
		) );
	}

	/**
	 * Merge Back Compat Shortcode Atts.
	 *
	 * @since 3.0.0
	 *
	 * @param array $atts The old attributes.
	 *
	 * @return array $atts The new attributes with proper keys.
	 */
	protected function merge_back_compat_shortcode_atts( $atts ) {
		$bc_atts       = $this->get_back_compat_shortcode_atts_map();
		$new_atts      = array();
		$keys_to_unset = array();

		foreach ( $bc_atts as $bc_new => $bc_old ) {
			if ( '' === $bc_old ) {
				continue;
			}

			if ( is_array( $bc_old ) ) {
				foreach ( $bc_old as $bc_old_key ) {
					if ( ! empty( $atts[ $bc_old_key ] ) ) {
						$new_atts[ $bc_new ] = $atts[ $bc_old_key ];
					}
				}
				continue;
			}

			if ( ! empty ( $atts[ $bc_old ] ) ) {
				$new_atts[ $bc_new ] = $atts[ $bc_old ];
			}
		}

		foreach ( $new_atts as $new_att_key => $new_att_value ) {
			switch ( $new_att_key ) {
				case 'size':
					if ( 'on' === $new_att_value ) {
						$new_atts[ $new_att_key ] = 'responsive';
					}
					break;
				case 'cf':
					if ( $new_att_value ) {
						$new_atts['source'] = 'cloudfront';
					}

					if ( isset( $new_atts['s3source'] ) ) {
						$new_atts['files'] = $new_atts['s3source'];
					}

					unset( $new_atts['cf'] );
					unset( $new_atts['s3source'] );
					unset( $new_atts['nons3source'] );
					break;
				case 's3source':
					if ( $new_att_value ) {
						$new_atts['source'] = 's3';
						$new_atts['files']  = $new_att_value;
						unset( $new_atts['s3source'] );
						unset( $new_atts['nons3source'] );
					}
					break;
				case 'nons3source':
					if ( $new_att_value ) {
						$new_atts['source'] = 'non-s3';
						$new_atts['files']  = $new_att_value;
						unset( $new_atts['s3source'] );
						unset( $new_atts['nons3source'] );
					}
					break;
				case 'poweredbylink':
					if ( 'yes' === $new_att_value ) {
						$new_atts[ $new_att_key ] = 'no';
					}
					if ( 'no' === $new_att_value ) {
						$new_atts[ $new_att_key ] = 'yes';
					}
					break;
				default:
					break;
			}
		}

		return $new_atts;
	}

	/**
	 * Merge Back Compat Shortcode Content.
	 *
	 * @since 3.0.0
	 *
	 * @param null $content
	 *
	 * @return stirng|null $content
	 */
	protected function merge_back_compat_shortcode_content( $content = null ) {
		return $content;
	}

	/**
	 * Get Shortcode Instance.
	 *
	 * @since 3.0.0
	 *
	 * @return int
	 */
	public function get_instance() {
		return $this->instance;
	}

	/**
	 * Increment the Instance Id.
	 *
	 * @since 3.0.0
	 */
	protected function increment_instance() {
		$this->instance ++;
	}

	/**
	 * Get Protected Url.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file name.
	 *
	 * @return string The protected file url.
	 */
	protected function get_protected_file_url( $file ) {
		return add_query_arg( array(
			's3mmid'      => uniqid( 's3mm_' ),
			's3mmprotect' => $this->edcrypt_string( wp_json_encode( array(
				'atts' => $this->atts,
				'file' => $file,
			) ) )
		), home_url( '/' ) );
	}

	/**
	 * Maybe Add Query Var for Protected Url.
	 *
	 * @since 3.2.3
	 *
	 * @param array $vars The query vars.
	 *
	 * @return array $vars The modified query vars.
	 */
	public function maybe_add_protected_url_query_var( $vars ) {
		$vars[] = 's3mmid';
		$vars[] = 's3mmprotect';

		return $vars;
	}

	/**
	 * Maybe Serve Protected Url.
	 *
	 * @since 3.2.3
	 *
	 * @param \WP $wp The wp class object.
	 */
	public function maybe_serve_protected_url( $wp ) {
		if ( ! array_key_exists( 's3mmid', $wp->query_vars ) && ! array_key_exists( 's3mmprotect', $wp->query_vars ) ) {
			return;
		}

		// Decrypt protected information.
		$protected = $wp->query_vars['s3mmprotect'];
		$protected = $this->edcrypt_string( $protected, 'd' );
		$protected = json_decode( $protected, true );

		// File Details.
		$file = $protected['file'];
		$atts = $protected['atts'];

		// Set Atttributes
		$this->atts = $atts;

		// Set Default Context
		stream_context_set_default( array(
			'ssl' => array(
				'verify_peer'      => false,
				'verify_peer_name' => false,
			),
		) );

		// Non-S3 Files.
		if ( 'non-s3' === $this->get_source() ) {
			$this->stream_local_file( $file );
		}

		// S3 File.
		if ( 's3' === $this->get_source() ) {
			$this->stream_s3_file( $file );
		}

		exit;
	}

	/**
	 * Redirect Remote File.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The remote file url.
	 */
	protected function redirect_remote_file( $file ) {
		if ( isset( $_SERVER['HTTP_RANGE'] ) ) {
			header( 'Location: ' . $file );
		}

		exit();
	}

	/**
	 * Stream Remote File.
	 *
	 * @since 3.2.2
	 *
	 * @param string $file The remote file url.
	 * @param array  $headers The remote file headers.
	 */
	protected function stream_remote_file( $file, $headers ) {
		if ( isset( $_SERVER['HTTP_RANGE'] ) ) {
			header( 'Content-Type: ' . $headers['Content-Type'] );
			header( 'Accept-Ranges: ' . $headers['Accept-Ranges'] );
			header( 'Content-Length:' . $headers['Content-Length'] );

			// Readfile.
			readfile( $file );
		}

		exit();
	}

	/**
	 * Stream Local File.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file to stream.
	 */
	protected function stream_local_file( $file ) {
		$file = Utils::get_local_file_path( $file );

		$streamer = new Streamer( $file );
		$streamer->start();
	}

	/**
	 * Stream Remote S3 File.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file stream.
	 */
	protected function stream_s3_file( $file ) {
		// Setup Aws.
		$this->setup_aws();
		$this->aws->set_settings( $this->atts );

		// Set Client.
		$client = $this->aws->get_s3_client();

		// Register Stream Wrapper.
		$client->registerStreamWrapper();

		// Set Bucket & Key.
		$bucket = $this->aws->get_bucket();
		$key    = $file;

		// Check File and Bucket.
		if ( empty( $file ) || empty( $bucket ) ) {
			http_response_code( 404 );
			exit;
		}

		// Begin building the options for the HeadObject request.
		$options = array( 'Bucket' => $bucket, 'Key' => $key );

		// Check if the client sent the If-None-Match header.
		if ( isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) ) {
			$options['IfNoneMatch'] = $_SERVER['HTTP_IF_NONE_MATCH'];
		}

		// Check if the client sent the If-Modified-Since header.
		if ( isset( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ) {
			$options['IfModifiedSince'] = $_SERVER['HTTP_IF_MODIFIED_SINCE'];
		}

		// Try Head Object.
		try {
			$response = $client->headObject( $options );
		} catch ( \Aws\Exception\AwsException $e ) {
			http_response_code( $e->getStatusCode() );
			exit;
		}

		// Set the appropriate status code for the response (e.g., 200, 304).
		$statusCode = $response->get( '@metadata' )['statusCode'];
		http_response_code( $statusCode );

		// Let's carry some headers from the Amazon S3 object over to the web server
		$headers = $response->get( '@metadata' )['headers'];

		// Proxy Headers.
		$proxyHeaders = array(
			'Last-Modified',
			'ETag',
			'Content-Type',
			'Content-Length',
			'Accept-Ranges',
			'Cache-Control',
		);

		foreach ( $proxyHeaders as $header ) {
			if ( $headers[ strtolower( $header ) ] ) {
				header( "{$header}: {$headers[strtolower( $header )]}" );
			}
		}

		// Context.
		$context = stream_context_create( array(
			's3' => array( 'seekable' => true )
		) );

		// Stop output buffering
		if ( ob_get_level() ) {
			ob_end_flush();
		}

		// Flush.
		flush();

		// Only send the body if the file was not modified.
		if ( 200 == $statusCode ) {
			readfile( "s3://{$bucket}/{$key}", false, $context );
		}
	}

	/**
	 * Crypt String.
	 *
	 * Simple method to encrypt or decrypt a plain text string.
	 *
	 * @param string $string The string to encrypt or decrypt.
	 * @param string $action The action. 'e' for encrypt and 'd' for decrypt. Default is 'e'
	 *
	 * @return string
	 */
	protected function edcrypt_string( $string, $action = 'e' ) {
		$output = false;

		// Check for AWS.
		$this->get_settings();

		// Enrcypt Method.
		$encrypt_method = "AES-256-CBC";

		// Keys.
		$secret_key = $this->get_setting( 's3accesskey' );
		$secret_iv  = $this->get_setting( 's3secretkey' );

		// Check Keys.
		if ( ! $secret_key || ! $secret_iv ) {
			return $string;
		}

		// Hash.
		$key = hash( 'sha256', $secret_key );

		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning.
		$iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

		if ( 'e' === $action ) {
			$output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
		} else if ( 'd' === $action ) {
			$output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
		}

		return $output;
	}

	/**
	 * Optimizepress Frontend Integration.
	 *
	 * @since 3.0.0
	 */
	public function optimizepress_shortcode_frontend_integration() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_enqueue_scripts', function () {
			$this->enqueue_assets();
		} );
	}

	/** Course Builder ---------------------------------------------- */

	/**
	 * Shortcode Builder Hooks.
	 *
	 * @since 3.0.0
	 */
	public function builder_hooks() {
		// Builder Media Buttons.
		add_action( 'media_buttons', array( $this, 'builder_buttons' ) );

		// Builder Scripts & Styles.
		add_action( 'admin_enqueue_scripts', array( $this, 'builder_scripts' ), 11 );
		add_action( 'wp_enqueue_scripts', array( $this, 'builder_integrations' ), 100 );

		// Elementor Integration.
		if ( class_exists( '\\Elementor\\Plugin' ) ) {
			add_action( 'elementor/editor/after_enqueue_scripts', array( $this, 'builder_elementor_integration' ) );
		}

		// Optimize Press Integration.
		add_action( 'op_liveeditor_init', array( $this, 'builder_optimizepress_integration' ) );

		// Thrive Editor Integration
		add_action( 'tcb_editor_enqueue_scripts', array( $this, 'builder_thrive_editor_integration' ) );
		add_action( 'tcb_hook_template_redirect', array( $this, 'builder_thrive_editor_integration' ) );

		// Register Blocks.
		add_action( 'init', array( $this, 'register_editor_blocks' ) );

		// Register Assets.
		add_action( 'enqueue_block_editor_assets', array( $this, 'register_editor_assets' ) );

		// Register Endpoints.
		add_filter( 's3mm_api_endoints', array( $this, 'block_api_endpoints' ) );
	}

	/**
	 * Shortcode Builder Buttons.
	 *
	 * @since 3.0.0
	 *
	 * @param string $editor_id The editor id.
	 */
	public function builder_buttons( $editor_id ) {
		printf(
			'<button type="button" id="s3mm-shortcode-builder-button" class="button s3mm-shortcode-builder-button" @click.prevent="open">
                <img src="%s" alt="%s" width="18" height="18" /> %s
			</button>',
			$this->image( 's3mm-icon.svg' ),
			esc_html__( 'S3 Media Maestro', 's3mm' ),
			esc_html__( 'Add S3 / Cloudfront Media', 's3mm' )
		);
	}

	/**
	 * Get Builder Scripts.
	 *
	 * @since 3.0.0
	 */
	protected function get_builder_scripts( $in_footer = true ) {
		// Api.
		$api = Api::get_object();

		// Builder Styles.
		wp_enqueue_style( 's3mm-shortcode-builder-css', $this->css( 'shortcode-builder.css' ), array(), S3MM_VERSION, 'all' );

		// WP Media Scripts.
		wp_enqueue_media();

		// Builder Scripts.
		wp_enqueue_script( 's3mm-shortcode-builder-js', $this->js( 'shortcode-builder.js' ), array( 'jquery' ), S3MM_VERSION, $in_footer );
		wp_localize_script( 's3mm-shortcode-builder-js', 's3mmShortcodeBuilderVars', apply_filters( 's3mm_shortcode_builder_js_vars', array(
			'api_url'   => $api->get_url(),
			'api_nonce' => $api->get_nonce(),
			'i18n'      => array(
				'player_splash_image_title'  => esc_html__( 'Select a Player Splash Image', 's3mm' ),
				'player_splash_image_button' => esc_html__( 'Use this Player Splash Image', 's3mm' ),
				's3_confirm_delete_files'    => esc_html__( 'Are you sure you wish to delete the following files from your Amazon S3 Bucket? This CANNOT be undone. %files%', 's3mm' ),
			),
		) ) );
	}

	/**
	 * Shortcode Builder Scripts.
	 *
	 * @since 3.0.0
	 *
	 * @param string $hook The page hook.
	 */
	public function builder_scripts( $hook ) {
		$allowed_admin_pages = apply_filters( 's3mm_shortcode_builder_allowed_admin_pages', array(
			'post.php',
			'post-new.php',
		) );

		if ( ! in_array( $hook, $allowed_admin_pages ) ) {
			return;
		}

		add_action( 'admin_footer', array( $this, 'builder_templates' ), 0 );

		$this->get_builder_scripts();
	}

	/**
	 * Shortcode Builder Integraions.
	 *
	 * @since 3.0.0
	 */
	public function builder_integrations() {
		// Beaver Builder Integration.
		if ( class_exists( 'FLBuilderModel' ) && FLBuilderModel::is_builder_active() ) {
			add_action( 'wp_footer', array( $this, 'builder_templates' ), 0 );

			$this->get_builder_scripts();
		}
	}

	/**
	 * Shortcode Builder OptimizePress Admin.
	 *
	 * @since 3.0.6
	 */
	public function builder_optimizepress_integration() {
		add_action( 'admin_enqueue_scripts', function () {
			add_action( 'admin_print_scripts', array( $this, 'builder_templates' ), 0 );
			$this->get_builder_scripts();
		}, 100 );
	}

	/**
	 * Shortcode Builder Thrive Integration Admin.
	 *
	 * @since 3.0.6
	 */
	public function builder_thrive_editor_integration() {
		add_action( 'wp_footer', array( $this, 'builder_templates' ), 0 );

		$this->get_builder_scripts();
	}

	/**
	 * Elementor Builder Integration.
	 *
	 * @since 3.0.0
	 */
	public function builder_elementor_integration() {
		add_action( 'wp_footer', array( $this, 'builder_templates' ), 0 );

		$this->get_builder_scripts();
	}

	/**
	 * Shortcode Builder Templates.
	 *
	 * @since 3.0.0
	 */
	public function builder_templates() {
		$templates = apply_filters( 's3mm_shortcode_builder_templates', array(
			'common/notices',
			'common/form-field',
			'common/form-field-buckets',
			'common/form-field-files',
			'shortcode/builder/shortcode-builder',
			'shortcode/builder/shortcode-builder-shortcode',
			'shortcode/builder/shortcode-builder-form-cloudfront',
			'shortcode/builder/shortcode-builder-form-non-s3',
			'shortcode/builder/shortcode-builder-form-s3',
			'shortcode/builder/shortcode-builder-settings-wpcw',
			'shortcode/builder/shortcode-builder-settings-cloudfront',
			'shortcode/builder/shortcode-builder-settings-link',
			'shortcode/builder/shortcode-builder-settings-player',
			'shortcode/builder/shortcode-builder-settings-s3',
			'shortcode/builder/shortcode-builder-tab',
			'shortcode/builder/shortcode-builder-tabs',
			'shortcode/builder/shortcode-builder-type',
			'shortcode/builder/shortcode-builder-type-audio',
			'shortcode/builder/shortcode-builder-type-file',
			'shortcode/builder/shortcode-builder-type-video',
			'shortcode/builder/shortcode-builder-types',
		) );

		foreach ( $templates as $template ) {
			echo $this->get_template( $template );
		}

		?>
		<div id="s3mm-shortcode-builder-instance">
			<s3mm-shortcode-builder :instance="<?php echo $this->get_builder_settings_json(); ?>" v-once></s3mm-shortcode-builder>
		</div>
		<?php
	}

	/**
	 * Get Shortcode Builder Types.
	 *
	 * @since 3.0.0
	 *
	 * @return array The media types.
	 */
	public function get_builder_types() {
		return apply_filters( 's3mm_shortcode_builder_types', array(
			array(
				'slug'    => 'video',
				'label'   => esc_html__( 'Insert Video', 's3mm' ),
				'icon'    => 'fa-video-camera',
				'default' => true,
			),
			array(
				'slug'    => 'audio',
				'label'   => esc_html__( 'Insert Audio', 's3mm' ),
				'icon'    => 'fa-headphones',
				'default' => false,
			),
			array(
				'slug'    => 'file',
				'label'   => esc_html__( 'Insert File', 's3mm' ),
				'icon'    => 'fa-file',
				'default' => false,
			),
		) );
	}

	/**
	 * Get Shortcode Builder Types JSON.
	 *
	 * @since 3.0.0
	 *
	 * @return string The json string of the action links.
	 */
	public function get_builder_types_json() {
		return htmlspecialchars( wp_json_encode( $this->get_builder_types() ) );
	}

	/**
	 * Get Shortcode Builder Settings JSON.
	 *
	 * @since 3.0.0
	 *
	 * @return string The JSON string of the settings.
	 */
	public function get_builder_settings_json() {
		$this->load_settings();

		$shortcode_settings = array(
			'settings' => $this->get_settings(),
			'regions'  => $this->get_regions(),
		);

		return htmlspecialchars( wp_json_encode( $shortcode_settings ) );
	}

	/** Gutenberg Block Support ------------------------------------------------- */

	/**
	 * Register Editor Blocks.
	 *
	 * @since 3.2.1
	 */
	public function register_editor_blocks() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		// S3 Media Block.
		register_block_type( 's3mm/s3media' );
	}

	/**
	 * Register Editor Assets.
	 *
	 * @since 3.2.1
	 */
	public function register_editor_assets() {
		// Api.
		$api = Api::get_object();

		// Enqueue Assets.
		$this->register_assets();
		$this->enqueue_assets();

		// Enqueue Scripts.
		wp_enqueue_script( 's3mm-blocks-js', $this->js( 'blocks.js' ), array( 'wp-i18n', 'wp-editor', 'wp-element', 'wp-blocks', 'wp-components' ), S3MM_VERSION );
		wp_localize_script( 's3mm-blocks-js', 's3mmBlocks', apply_filters( 's3mm_blocks_js_params', array(
			'api_prefix' => $api->get_namespace(),
			'api_url'    => $api->get_url(),
			'api_nonce'  => $api->get_nonce(),
			'icon'       => $this->image( 's3mm-icon.svg' ),
		) ) );

		// Enqueue CSS.
		wp_enqueue_style( 's3mm-blocks-css', $this->css( 'blocks.css' ), array( 'wp-edit-blocks' ), S3MM_VERSION );
	}

	/**
	 * Block Api Endpoints.
	 *
	 * @since 3.2.1
	 *
	 * @param array $endpoints The api endpoints.
	 */
	public function block_api_endpoints( $endpoints ) {
		$s3media_block_endpoint = array(
			'endpoint' => 'block/s3media',
			'method'   => 'GET',
			'callback' => array( $this, 'api_get_block_s3media' ),
		);

		array_push( $endpoints, $s3media_block_endpoint );

		return $endpoints;
	}

	/**
	 * Api: Get Block S3Media.
	 *
	 * @since 3.2.1
	 *
	 * @param object WP_REST_Request The api request.
	 *
	 * @return object WP_REST_Response The api response.
	 */
	public function api_get_block_s3media( WP_REST_Request $request ) {
		$s3_media_shortcode      = $request->get_param( 'shortcode' );
		$s3_media_shortcode_html = '';

		if ( $s3_media_shortcode ) {
			add_filter( 's3mm_shortcode_protect_content', '__return_false' );
			$s3_media_shortcode_html = do_shortcode( $s3_media_shortcode );
		}

		return rest_ensure_response( array( 'shortcode' => $s3_media_shortcode_html ) );
	}

	/** Shortcode Ajax Methods -------------------------------------------------- */

	/**
	 * Ajax: Auto Navigate Unit.
	 *
	 * @since 3.2.0
	 */
	public function ajax_auto_navigate_unit() {
		if ( ! wp_verify_nonce( WPCW_arrays_getValue( $_POST, 'security' ), 'wpcw-progress-nonce' ) ) {
			wp_send_json_success( array( 'success' => false, 'message' => esc_html__( 'Nonce verification failed.', 's3mm' ) ) );
		}

		if ( ! $this->is_wpcw_enabled() ) {
		}

		// Unit Id.
		$unit_id = Utils::post_var( 'id' );

		// Validate the course ID
		if ( ! preg_match( '/unit_complete_(\d+)/', $unit_id, $matches ) ) {
			wp_send_json_success( array( 'success' => false, 'message' => esc_html__( 'There is no associated unit to evaluate.', 's3mm' ) ) );
		}

		$unit_id   = $matches[1];
		$unit_post = get_post( absint( $unit_id ) );

		if ( ! $unit_post ) {
			wp_send_json_success( array( 'success' => false, 'message' => esc_html__( 'There unit does not exist.', 's3mm' ) ) );
		}

		// Unit Frontend Class.
		$unit_frontend = new \WPCW_UnitFrontend( $unit_post );

		// Check if it has parent data.
		if ( ! $unit_frontend->check_unit_doesUnitHaveParentData() ) {
			wp_send_json_success( array( 'success' => false, 'message' => esc_html__( 'Unit does not have parent data.', 's3mm' ) ) );
		}

		// Check if current user has access.
		if ( ! $unit_frontend->check_user_canUserAccessCourse() ) {
			wp_send_json_success( array( 'success' => false, 'message' => esc_html__( 'User cannot access unit.', 's3mm' ) ) );
		}

		// Save Unit Progress.
		WPCW_units_saveUserProgress_Complete( $unit_frontend->fetch_getUserID(), $unit_frontend->fetch_getUnitID(), 'complete' );

		/**
		 * Action: WP Courseware User Completed Unit.
		 *
		 * @since 3.2.0
		 */
		do_action( 'wpcw_user_completed_unit', $unit_frontend->fetch_getUserID(), $unit_frontend->fetch_getUnitID(), $unit_frontend->fetch_getUnitParentData() );

		// Fetch Parent Data.
		$parent_data    = $unit_frontend->fetch_getUnitParentData();
		$next_unit_link = false;

		// Check for Parent Data.
		if ( $parent_data ) {
			$user_progress = new \WPCW_UserProgress( $parent_data->course_id, $unit_frontend->fetch_getUserID() );
			$nextAndPrev   = $user_progress->getNextAndPreviousUnit( absint( $unit_id ) );

			if ( $nextAndPrev['next'] > 0 ) {
				$next_unit_link = get_permalink( absint( $nextAndPrev['next'] ) );
			}
		}

		wp_send_json_success( array( 'success' => true, 'complete' => false, 'location' => esc_url_raw( $next_unit_link ) ) );
	}

	/**
	 * Get Next Unit.
	 *
	 * @since 3.2.0
	 *
	 * @param int $course_id The Course Id.
	 */
	protected function get_next_unit( $course_id ) {
		global $wpdb, $wpcwdb;

		// Convert into an ID => object list
		$items = $wpdb->get_results( $wpdb->prepare( "
				SELECT *
				FROM $wpcwdb->units_meta
				WHERE parent_course_id = %d
				ORDER BY unit_order ASC
			", $this->courseID ) );
		if ( $items ) {
			foreach ( $items as $item ) {
				$this->unitList[ $item->unit_id ] = $item;
			}
		}
	}
}
