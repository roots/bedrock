<?php
/**
 * S3 Media Maestro Utilities.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

defined( 'ABSPATH' ) || die;

/**
 * Utils Class.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Utils {

	/**
	 * Debug Log.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The log message.
	 */
	public static function log( $message ) {
		if ( true === WP_DEBUG ) {
			if ( is_array( $message ) || is_object( $message ) ) {
				error_log( print_r( $message, true ) );
			} else {
				error_log( $message );
			}
		}
	}

	/**
	 * Get $_POST var.
	 *
	 * @since 3.0.0
	 *
	 * @param string $name The name of the variable.
	 *
	 * @return false|mixed False if var does not exist.
	 */
	public static function post_var( $name ) {
		return filter_input( INPUT_POST, $name );
	}

	/**
	 * Get $_REQUEST var.
	 *
	 * @since 3.0.0
	 *
	 * @param string $name The name of the variable.
	 *
	 * @return false|mixed False if var does not exist.
	 */
	public static function request_var( $name ) {
		return filter_input( INPUT_REQUEST, $name );
	}

	/**
	 * Get $_GET var.
	 *
	 * @since 3.0.0
	 *
	 * @param string $name The name of the variable.
	 *
	 * @return false|mixed False if var does not exist.
	 */
	public static function get_var( $name ) {
		return filter_input( INPUT_GET, $name );
	}

	/**
	 * Notice.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The message that should be displayed.
	 * @param string $type The type of error that should be displayed. Default is 'info'.
	 * @param bool   $dismissable If the error should be allowed to be dismissed. Default is 'true'.
	 */
	public static function notice( $message, $type = 'info', $dismissable = true ) {
		$is_dismissable = ( $dismissable ) ? ' is-dismissible' : '';
		printf( '<div class="s3mm-notice notice notice-%1$s%2$s"><p>%3$s</p></div>', esc_attr( $type ), esc_attr( $is_dismissable ), wp_kses_post( $message ) );
	}

	/**
	 * Notice - Error.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The message that should be disaplyed.
	 * @param bool   $echo If to echo the text or return it.
	 * @param bool   $dismissable If the error should be allowed to be dismissed.
	 */
	public static function notice_error( $message, $echo = true, $dismissable = true ) {
		if ( ! $echo ) {
			ob_start();
			self::notice( $message, 'error', $dismissable );

			return ob_get_clean();
		}

		self::notice( $message, 'error', $dismissable );
	}

	/**
	 * Notice - Success.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The message that should be disaplyed.
	 * @param bool   $echo If to echo the text or return it.
	 * @param bool   $dismissable If the error should be allowed to be dismissed.
	 */
	public static function notice_success( $message, $echo = true, $dismissable = true ) {
		if ( ! $echo ) {
			ob_start();
			self::notice( $message, 'success', $dismissable );

			return ob_get_clean();
		}

		self::notice( $message, 'success', $dismissable );
	}

	/**
	 * Notice - Info.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The message that should be disaplyed.
	 * @param bool   $echo If to echo the text or return it.
	 * @param bool   $dismissable If the error should be allowed to be dismissed.
	 */
	public static function notice_info( $message, $echo = true, $dismissable = true ) {
		if ( ! $echo ) {
			ob_start();
			self::notice( $message, 'info', $dismissable );

			return ob_get_clean();
		}

		self::notice( $message, 'info', $dismissable );
	}

	/**
	 * Notice - Warning.
	 *
	 * @since 3.0.0
	 *
	 * @param string $message The message that should be disaplyed.
	 * @param bool   $echo If to echo the text or return it.
	 * @param bool   $dismissable If the error should be allowed to be dismissed.
	 */
	public static function notice_warning( $message, $echo = true, $dismissable = true ) {
		if ( ! $echo ) {
			ob_start();
			self::notice( $message, 'warning', $dismissable );

			return ob_get_clean();
		}

		self::notice( $message, 'warning', $dismissable );
	}

	/**
	 * Admin Notice.
	 *
	 * @since 1.0.0
	 *
	 * @param string $message The message to be displayed
	 * @param string $type The type of message to display. Possibilities could include 'error', 'info', 'warning' and 'success'
	 * @param bool   $dismissable If the message is dismissable. Default is 'true'
	 */
	public static function admin_notice( $message, $type = 'warning', $dismissable = true ) {
		add_action( 'admin_notices', function () use ( $message, $type, $dismissable ) {
			self::notice( $message, $type, $dismissable );
		} );
	}

	/**
	 * Remove Items from Array.
	 *
	 * @since 3.2.0
	 *
	 * @param array $array The array to evaluate.
	 * @param array $items The items to remove.
	 *
	 * @return array $items_array The new items array.
	 */
	public static function remove_items_from_array( $array, $items ) {
		$items_array = array();

		foreach ( $array as $array_value ) {
			if ( ! in_array( $array_value, $items, true ) ) {
				$items_array[] = $array_value;
			}
		}

		return $items_array;
	}

	/**
	 *  Get the file size of any remote resource (using get_headers()),
	 *  either in bytes or - default - as human-readable formatted string.
	 *
	 * @author  Stephan Schmitz <eyecatchup@gmail.com>
	 * @license MIT <http://eyecatchup.mit-license.org/>
	 * @url     <https://gist.github.com/eyecatchup/f26300ffd7e50a92bc4d>
	 *
	 * @param   string  $url Takes the remote object's URL.
	 * @param   boolean $formatSize Whether to return size in bytes or formatted.
	 * @param   boolean $useHead Whether to use HEAD requests. If false, uses GET.
	 *
	 * @return  string Returns human-readable formatted size or size in bytes (default: formatted).
	 */
	public static function get_remote_file_size( $url, $formatSize = false, $useHead = true ) {
		if ( false !== $useHead ) {
			stream_context_set_default( array( 'http' => array( 'method' => 'HEAD' ) ) );
		}

		$head = array_change_key_case( get_headers( $url, 1 ) );

		// content-length of download (in bytes), read from Content-Length: field
		$clen = isset( $head['content-length'] ) ? $head['content-length'] : 0;

		// cannot retrieve file size, return "-1"
		if ( ! $clen ) {
			return - 1;
		}

		if ( ! $formatSize ) {
			return $clen; // return size in bytes
		}

		$size = $clen;
		switch ( $clen ) {
			case $clen < 1024:
				$size = $clen . ' B';
				break;
			case $clen < 1048576:
				$size = round( $clen / 1024, 2 ) . ' KiB';
				break;
			case $clen < 1073741824:
				$size = round( $clen / 1048576, 2 ) . ' MiB';
				break;
			case $clen < 1099511627776:
				$size = round( $clen / 1073741824, 2 ) . ' GiB';
				break;
		}

		return $size; // return formatted size
	}

	/**
	 * Get Attachment Id by Url.
	 *
	 * @since 3.2.3
	 *
	 * @param string $url The url string.
	 *
	 * @return
	 */
	public static function get_attachment_id_by_url( $url ) {
		global $wpdb;

		$attachment = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE guid='%s';", $url ) );

		return $attachment ? $attachment[0] : false;
	}

	/**
	 * Get Local File Path.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file The file to evaluate.
	 *
	 * @return The local file path.
	 */
	public static function get_local_file_path( $file ) {
		if ( filter_var( $file, FILTER_VALIDATE_URL ) !== false ) {
			$file = parse_url( $file, PHP_URL_PATH );
		}

		return ABSPATH . $file;
	}

	/**
	 * Get Host.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public static function get_host() {
		$host = false;

		if ( defined( 'WPE_APIKEY' ) ) {
			$host = 'WP Engine';
		} elseif ( defined( 'PAGELYBIN' ) ) {
			$host = 'Pagely';
		} elseif ( DB_HOST == 'localhost:/tmp/mysql5.sock' ) {
			$host = 'ICDSoft';
		} elseif ( DB_HOST == 'mysqlv5' ) {
			$host = 'NetworkSolutions';
		} elseif ( strpos( DB_HOST, 'ipagemysql.com' ) !== false ) {
			$host = 'iPage';
		} elseif ( strpos( DB_HOST, 'ipowermysql.com' ) !== false ) {
			$host = 'IPower';
		} elseif ( strpos( DB_HOST, '.gridserver.com' ) !== false ) {
			$host = 'MediaTemple Grid';
		} elseif ( strpos( DB_HOST, '.pair.com' ) !== false ) {
			$host = 'pair Networks';
		} elseif ( strpos( DB_HOST, '.stabletransit.com' ) !== false ) {
			$host = 'Rackspace Cloud';
		} elseif ( strpos( DB_HOST, '.sysfix.eu' ) !== false ) {
			$host = 'SysFix.eu Power Hosting';
		} elseif ( strpos( $_SERVER['SERVER_NAME'], 'Flywheel' ) !== false ) {
			$host = 'Flywheel';
		} else {
			// Adding a general fallback for data gathering
			$host = 'DBH: ' . DB_HOST . ', SRV: ' . $_SERVER['SERVER_NAME'];
		}

		return $host;
	}
}
