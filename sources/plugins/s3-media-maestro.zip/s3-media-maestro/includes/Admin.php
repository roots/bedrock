<?php
/**
 * S3MM Admin.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\Base;
use S3MM\Api;

defined( 'ABSPATH' ) || die;

/**
 * Admin Class.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Admin extends Base {

	/**
	 * @var string Admin page slug.
	 * @since 3.0.0
	 */
	protected $slug = 's3mm';

	/**
	 * @var string Admin page hook.
	 * @since 3.0.0
	 */
	protected $hook;

	/**
	 * Admin Instance.
	 *
	 * @since 3.0.0
	 *
	 * @param null $class
	 *
	 * @return Admin The admin object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Admin Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		add_action( 'admin_menu', array( $this, 'admin_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		add_filter( 'plugin_action_links', array( $this, 'action_link' ), 1, 2 );
	}

	/**
	 * Plugin Settings Action Link.
	 *
	 * @since 3.0.0
	 *
	 * @param array $links The plugin action links.
	 * @param string $file The plugin file.
	 *
	 * @return array $links The plugin links.
	 */
	public function action_link( $links, $file ) {
		if ( plugin_basename( S3MM_FILE ) === $file ) {
			array_unshift( $links, sprintf( '<a href="%s">%s</a>', esc_url( $this->get_admin_url() ), esc_html__( 'Settings', 's3mm' ) ) );
		}

		return $links;
	}

	/**
	 * Default Settings.
	 *
	 * @since 3.0.0
	 *
	 * @return array An array of the default settings.
	 */
	public function default_settings() {
		return $this->get_default_settings();
	}

	/**
	 * Admin Page.
	 *
	 * @since 3.0.0
	 */
	public function admin_page() {
		$this->hook = add_submenu_page(
			$this->get_parent_slug(),
			esc_html__( 'S3 Media Maestro Settings', 's3mm' ),
			esc_html__( 'S3 Media Maestro', 's3mm' ),
			'manage_options',
			$this->slug,
			array( $this, 'admin_screen' )
		);

		add_action( "load-{$this->hook}", array( $this, 'load_admin' ) );
	}

	/**
	 * Load Admin.
	 *
	 * @since 3.0.0
	 */
	public function load_admin() {
		$this->load_settings();
	}

	/**
	 * Enqueue Admin Scripts.
	 *
	 * @since 3.0.0
	 *
	 * @param string $hook The admin page hook.
	 */
	public function admin_scripts( $hook ) {
		if ( ! $this->is_admin() ) {
			return;
		}

		// Handle Learnpress Conflict if activated.
		$this->handle_learnpress_conflict();

		// Get Api.
		$api = Api::get_object();

		// Enqueue Styles.
		wp_enqueue_style( 's3mm-admin', $this->css( 'admin.css' ), array(), S3MM_VERSION, 'all' );

		// Enqueue Media Modal.
		wp_enqueue_media();

		// Enqueue Scripts.
		wp_enqueue_script( 's3mm-admin', $this->js( 'admin.js' ), array( 'jquery' ), S3MM_VERSION, true );
		wp_localize_script( 's3mm-admin', 's3mmAdminVars', apply_filters( 's3mm_admin_js_vars', array(
			'admin_url'        => wp_make_link_relative( admin_url( '/' ) ),
			'api_url'          => $api->get_url(),
			'api_nonce'        => $api->get_nonce(),
			'api_action_url'   => esc_url( site_url( '/' ) ),
			'api_action_nonce' => wp_create_nonce( 's3mm-api-action' ),
			'i18n'             => array(
				'player_splash_image_title'  => esc_html__( 'Select a Player Splash Image', 's3mm' ),
				'player_splash_image_button' => esc_html__( 'Use this Player Splash Image', 's3mm' ),
			),
		) ) );
	}

	/**
	 * Get Admin Pages.
	 *
	 * @since 3.0.0
	 *
	 * @return mixed|void
	 */
	public function get_admin_pages() {
		return apply_filters( 's3_admin_pages', array(
			's3'         => array(
				'label'   => esc_html__( 'Amazon: S3', 's3mm' ),
				'show'    => true,
				'default' => true,
			),
			'cloudfront' => array(
				'label' => esc_html__( 'Amazon: Cloudfront', 's3mm' ),
				'show'  => true,
			),
			'media'      => array(
				'label' => esc_html__( 'Media Player', 's3mm' ),
				'show'  => true,
			),
			'settings'   => array(
				'label' => esc_html__( 'Other Settings', 's3mm' ),
				'show'  => true,
			),
			'support'    => array(
				'label' => esc_html__( 'Support', 's3mm' ),
				'show'  => true,
			),
			'system'     => array(
				'label' => esc_html__( 'System Info', 's3mm' ),
				'show'  => true,
			),
			'products'   => array(
				'label' => esc_html__( 'Other Products', 's3mm' ),
				'show'  => true,
			),
		) );
	}

	/**
	 * Get Admin Settings.
	 *
	 * @sicne 3.0.0
	 *
	 * @return string
	 */
	protected function get_admin_settings() {
		$aws = Aws::get_object();

		$admin_settings = array(
			'settings' => $this->get_settings(),
			'regions'  => $aws->get_regions(),
		);

		return htmlspecialchars( wp_json_encode( $admin_settings ) );
	}

	/**
	 * Admin Screen.
	 *
	 * @since 3.0.0
	 */
	public function admin_screen() {
		$templates = apply_filters( 's3mm_admin_templates', array(
			'common/form',
			'common/form-row',
			'common/form-field',
			'common/form-field-buckets',
			'common/notices',
			'admin/admin-header',
			'admin/admin-navigation',
			'admin/admin-page',
			'admin/admin-page-404',
			'admin/admin-page-cloudfront',
			'admin/admin-page-media',
			'admin/admin-page-products',
			'admin/admin-page-s3',
			'admin/admin-page-settings',
			'admin/admin-page-support',
			'admin/admin-page-system',
		) );

		foreach ( $templates as $template ) {
			echo $this->get_template( $template );
		}

		?>
		<div id="s3mm-admin" class="wrap">
			<s3mm-admin-header></s3mm-admin-header>
			<s3mm-notices><?php do_action( 's3mm_admin_notices' ); ?></s3mm-notices>
			<s3mm-admin-navigation></s3mm-admin-navigation>
			<s3mm-admin-page :admin="<?php echo $this->get_admin_settings(); ?>"></s3mm-admin-page>
		</div>
		<?php
	}

	/**
	 * Is Admin Screen?
	 *
	 * @since 3.0.0
	 *
	 * @return bool Is the admin screen.
	 */
	public function is_admin() {
		global $pagenow;

		return (bool) ( filter_input( INPUT_GET, 'page' ) === $this->slug && $pagenow === $this->get_parent_slug() );
	}

	/**
	 * Get Parent Slug.
	 *
	 * @since 3.0.0
	 *
	 * @return string The parent slug.
	 */
	public function get_parent_slug() {
		return esc_attr( apply_filters( 's3mm_admin_slug_parent', 'options-general.php' ) );
	}

	/**
	 * Get base admin url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_base_admin_url() {
		return esc_url_raw( admin_url( $this->get_parent_slug() ) );
	}

	/**
	 * Get Admin Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_admin_url() {
		return esc_url_raw( add_query_arg( array( 'page' => $this->slug ), $this->get_parent_slug() ) );
	}

	/**
	 * Show in menu helper.
	 *
	 * @since 3.0.0
	 *
	 * @param array $page The page array.
	 *
	 * @return bool Show the page in the menu if true, hide otherwise.
	 */
	public function show_in_menu( $page ) {
		return isset( $page['show'] ) ? $page['show'] : false;
	}

	/**
	 * Is Page Default?
	 *
	 * @since 3.0.0
	 *
	 * @param array $page
	 *
	 * @return bool Show the default slug if is default.
	 */
	public function is_page_default( $page ) {
		return isset( $page['default'] ) ? $page['default'] : false;
	}

	/**
	 * Get page url.
	 *
	 * @since 3.0.0
	 *
	 * @param string $slug The page slug.
	 *
	 * @return string The page url.
	 */
	public function get_page_url( $slug ) {
		return esc_url_raw( add_query_arg( array( 'tab' => $slug ), $this->get_admin_url() ) );
	}

	/**
	 * Get page label.
	 *
	 * @since 3.0.0
	 *
	 * @param array $page The page array.
	 *
	 * @return string The page label.
	 */
	public function get_page_label( $page ) {
		return isset( $page['label'] ) ? esc_attr( $page['label'] ) : '';
	}

	/**
	 * Handle LearnPress Conflict.
	 *
	 * @since 3.2.2
	 */
	protected function handle_learnpress_conflict() {
		if ( is_plugin_active( 'learnpress/learnpress.php' ) ) {
			add_filter( 'learn-press/admin-default-scripts', function ( $scripts ) {
				return array();
			} );
		}
	}
}
