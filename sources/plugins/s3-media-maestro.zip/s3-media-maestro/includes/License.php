<?php
/**
 * S3 Media Maestro License Handler.
 *
 * @packcage S3MM
 * @since 3.0.0
 */

namespace S3MM;

use S3MM\Utils;
use S3MM\Updater;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || die;

/**
 * Class License.
 *
 * @package S3MM
 * @since 3.0.0
 */
class License extends Base {

	/**
	 * @var array The License Cache.
	 * @since 3.0.0
	 */
	protected $cache = array(
		'status' => 's3mm_license_status',
	);

	/**
	 * License Instance.
	 *
	 * @param null $class The class instance.
	 *
	 * @return License The license object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load License Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		add_action( 'admin_init', array( $this, 'init_license' ), 0 );
		add_action( 'admin_init', array( $this, 'check_status' ), 10 );
		add_filter( 's3mm_api_endoints', array( $this, 'api_endpoints' ) );
	}

	/**
	 * Get License Id.
	 *
	 * @since 3.0.0
	 *
	 * @return int $license_id The license id.
	 */
	public function get_id() {
		return absint( apply_filters( 's3mm_license_id', 1504 ) );
	}

	/**
	 * Get License Name.
	 *
	 * @since 3.0.0
	 *
	 * @return string $license_name The license name.
	 */
	public function get_name() {
		return urlencode( esc_attr( apply_filters( 's3mm_license_name', 'S3 Media Maestro' ) ) );
	}

	/**
	 * Get Author.
	 *
	 * @since 3.0.0
	 *
	 * @return string $license_author The license author.
	 */
	public function get_author() {
		return esc_attr( apply_filters( 's3mm_license_author', 'Fly Plugins' ) );
	}

	/**
	 * Get Beta.
	 *
	 * @since 3.0.0
	 *
	 * @return bool $beta If the license is a beta version.
	 */
	public function get_beta() {
		return (bool) apply_filters( 's3mm_license_beta', false );
	}

	/**
	 * Get License Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string $license_url The license url.
	 */
	public function get_url() {
		return esc_url_raw( trailingslashit( apply_filters( 's3mm_license_url', 'https://flyplugins.com/' ) . 'license-updater' ) );
	}

	/**
	 * Get License Keys Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string $license_keys_url The url to the member portal license keys.
	 */
	public function get_keys_url() {
		return apply_filters( 's3mm_license_keys_url', 'https://flyplugins.com/member-portal/license-keys/' );
	}

	/**
	 * Get License Key.
	 *
	 * @since 3.0.0
	 *
	 * @return string|bool The license key string if exists. False if empty.
	 */
	public function get_key() {
		return trim( $this->get_setting( 'licensekey' ) );
	}

	/**
	 * Update License Key.
	 *
	 * @since 3.0.0
	 *
	 * @param string $key The new license key.
	 *
	 * @return bool True on update, false otherwise.
	 */
	public function update_key( $key ) {
		$this->set_setting( 'licensekey', trim( $key ) );

		return $this->save_settings();
	}

	/**
	 * Delete License Key.
	 *
	 * @since 3.0.0
	 *
	 * @return bool True if it was deleted, false otherwise.
	 */
	public function delete_key() {
		$this->delete_setting( 'licensekey' );

		return $this->save_settings();
	}

	/**
	 * Get License Status.
	 *
	 * @since 3.0.0
	 *
	 * @return stirng|bool The license status string if exists. False if empty.
	 */
	public function get_status() {
		return $this->get_setting( 'licensestatus' );
	}

	/**
	 * Update License Status.
	 *
	 * @since 3.0.0
	 *
	 * @param string $status The new status of the license.
	 *
	 * @return bool True if it is correctly updated, false otherwise.
	 */
	public function update_status( $status ) {
		$this->set_setting( 'licensestatus', $status );

		return $this->save_settings();
	}

	/**
	 * Get License Details
	 *
	 * @since 3.0.0
	 *
	 * @return array $license_details An array of all the details needed.
	 */
	protected function get_details() {
		return apply_filters( 's3mm_license_details', array(
			'version'   => S3MM_VERSION,
			'license'   => $this->get_key(),
			'item_id'   => $this->get_id(),
			'item_name' => $this->get_name(),
			'author'    => $this->get_author(),
			'beta'      => $this->get_beta(),
		) );
	}

	/**
	 * Init License.
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	public function init_license() {
		if ( ! $this->check_admin() ) {
			return;
		}

		$settings = $this->get_settings();

		if ( empty( $settings ) ) {
			$this->load_settings();
		}

		new Updater( $this->get_url(), S3MM_FILE, $this->get_details() );
	}

	/**
	 * Activate License
	 *
	 * @since 3.0.0
	 *
	 * @return bool|WP_Error True upon activation of WP_Error instance on error.
	 */
	public function activate() {
		$activate = $this->api_request( 'activate_license' );

		if ( is_wp_error( $activate ) ) {
			$this->delete_key();
			$this->clear_cache();
			$this->cache_status( 'invalid' );

			return $activate;
		}

		$this->clear_cache();
		$this->cache_status( $activate->license );

		return $this->update_status( $activate->license );
	}

	/**
	 * Deactivate License
	 *
	 * @since 3.0.0
	 *
	 * @return bool True upon license deactivation.
	 */
	public function deactivate() {
		$deactivate = $this->api_request( 'deactivate_license' );

		if ( is_wp_error( $deactivate ) ) {
			$message = esc_html__( 'License successfully deactivated!', 'wp-courseware' );
		} else {
			$message = $deactivate->license;
		}

		$this->delete_key();
		$this->clear_cache();
		$this->cache_status( 'invalid' );

		return $this->update_status( $message );
	}

	/**
	 * Check License Status.
	 *
	 * @since 3.0.0
	 *
	 * @return string $status The status of the license.
	 */
	public function check_status() {
		global $pagenow;

		$status = get_transient( $this->cache['status'] );

		if ( false === $status ) {
			$license_status = $this->api_request( 'check_license' );

			if ( is_wp_error( $license_status ) ) {
				$status = 'invalid';
			} else {
				$status = $license_status->license;
			}

			$this->cache_status( $status );
		}

		$settings = $this->get_settings();

		if ( empty( $settings ) ) {
			$this->load_settings();
		}

		if ( 'invalid' !== $status && ! $this->get_key() ) {
			$this->clear_cache();
		}

		if ( ! $this->check_admin() ) {
			return;
		}

		if ( 'valid' === $status ) {
			/* translators: %s - License url. */
			$error = sprintf( __( 'Your <strong>S3 Media Maestro</strong> license key is missing or invalid. <a href="%s">Please enter your license key.</a>', 's3mm' ), $this->get_license_page() );
			Utils::admin_notice( $error, 'error' );
		}
	}

	/**
	 * Cache Status.
	 *
	 * @since 3.0.0
	 *
	 * @param string $status The status of the plugin.
	 */
	public function cache_status( $status ) {
		set_transient( $this->cache['status'], $status, DAY_IN_SECONDS );
	}

	/**
	 * Clear Cache.
	 *
	 * @since 3.0.0
	 */
	protected function clear_cache() {
		foreach ( $this->cache as $cache_item ) {
			delete_transient( $cache_item );
		}
	}

	/**
	 * License Api Request.
	 *
	 * @since 3.0.0
	 *
	 * @param string $action The request action. Default is 'check_license'.
	 *
	 * @return object|WP_Error Object of values or a WP_Error.
	 */
	protected function api_request( $action = 'check_license' ) {
		if ( empty( $action ) ) {
			return new WP_Error( 's3mm_request_action_error', esc_html__( 'License API request action invalid', 's3mm' ) );
		}

		$settings = $this->get_settings();

		if ( empty( $settings ) ) {
			$this->load_settings();
		}

		$api_params = array(
			'edd_action' => $action,
			'license'    => $this->get_key(),
			'item_name'  => $this->get_name(),
			'item_id'    => $this->get_id(),
			'url'        => home_url(),
		);

		$request = wp_remote_post( $this->get_url(), array(
			'timeout'   => 15,
			'sslverify' => false,
			'body'      => $api_params,
		) );

		if ( is_wp_error( $request ) ) {
			return $request;
		}

		if ( 200 !== wp_remote_retrieve_response_code( $request ) ) {
			return new WP_Error( 's3mm_license_error', esc_html__( 'An error occurred, please try again', 's3mm' ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $request ) );

		if ( false === $data->success ) {
			$error = isset( $data->error ) ? $data->error : $data->license;

			return new WP_Error( 's3mm_license_error', $this->api_get_error( $error, $data ) );
		}

		return $data;
	}

	/**
	 * Get License API Error.
	 *
	 * @since 3.0.0
	 *
	 * @param string $error The error to look up.
	 * @param object $data The license data.
	 *
	 * @return string $error_message The license error message.
	 */
	protected function api_get_error( $error, $data ) {
		$error_message = '';

		switch ( $error ) {
			case 'expired':
				/* translators: %s license expired date. */
				$error_message = sprintf( __( 'Your license key expired on %s.', 's3mm' ), date_i18n( get_option( 'date_format' ), strtotime( $data->expires, current_time( 'timestamp' ) ) ) );
				break;
			case 'revoked':
				$error_message = esc_html__( 'Your license key has been disabled.', 's3mm' );
				break;
			case 'invalid':
			case 'missing':
				$error_message = esc_html__( 'Invalid license key. Please enter a valid license key.', 's3mm' );
				break;
			case 'site_inactive':
				$error_message = esc_html__( 'Your license is not active for this URL.', 's3mm' );
				break;
			case 'item_name_mismatch':
				/* translators: %s product name. */
				$error_message = sprintf( __( 'This appears to be an invalid license key for %s.', 's3mm' ), $this->get_name() );
				break;
			case 'no_activations_left':
				$error_message = esc_html__( 'Your license key has reached its activation limit.', 's3mm' );
				break;
			default:
				$error_message = esc_html__( 'An error occurred, please try again.', 's3mm' );
				break;
		}

		if ( $error_message ) {
			$error_message = sprintf( '<strong>%s:</strong> %s', esc_html__( 'Error', 's3mm' ), $error_message );
		}

		return apply_filters( 's3mm_license_error', $error_message, $error );
	}

	/**
	 * Get License Page.
	 *
	 * @since 3.0.0
	 *
	 * @return string $license_page_url The license page url.
	 */
	public function get_license_page() {
		return esc_url_raw( add_query_arg(
			array(
				'page' => 's3mm',
				'tab'  => 'settings',
			),
			admin_url( 'options-general.php' )
		) );
	}

	/**
	 * License Api Endpoints
	 *
	 * @since 3.0.0
	 *
	 * @param array $endpoints The api endpoints.
	 */
	public function api_endpoints( $endpoints ) {
		$license_api_endpoint = array(
			'endpoint' => 'license',
			'method'   => 'POST',
			'callback' => array( $this, 'api_license' ),
		);

		$clear_license_cache = array(
			'endpoint' => 'license-clear-cache',
			'method'   => 'POST',
			'callback' => array( $this, 'api_license_clear_cache' ),
		);

		array_push( $endpoints, $license_api_endpoint );
		array_push( $endpoints, $clear_license_cache );

		return $endpoints;
	}

	/**
	 * Api License Callback
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The api request.
	 *
	 * @return WP_REST_Response|WP_Error The api response.
	 */
	public function api_license( WP_REST_Request $request ) {
		$notice = '';

		$license = $request->get_param( 'license' );
		$action  = $request->get_param( 'action' );

		if ( empty( $license ) || empty( $action ) ) {
			return new WP_Error(
				's3mm-api-license-error',
				esc_html__( 'There was an error updating your license. Please try again.', 's3mm' )
			);
		}

		$this->load_settings();

		if ( 'activate' === $action ) {
			$this->update_key( $license );

			$activate = $this->activate();

			if ( is_wp_error( $activate ) ) {
				return $activate;
			}

			$notice = esc_html__( 'License successfully activated!', 's3mm' );
		}

		if ( 'deactivate' === $action ) {
			$deactivate = $this->deactivate();

			if ( is_wp_error( $deactivate ) ) {
				return $deactivate;
			}

			$notice = esc_html__( 'License successfully deactivated!', 's3mm' );
		}

		$response_data = array(
			'license' => $this->get_key(),
			'status'  => $this->get_status(),
			'notice'  => $notice,
		);

		return rest_ensure_response( $response_data );
	}

	/**
	 * Api License Clear Cache Callback.
	 *
	 * @since 3.0.6
	 *
	 * @param WP_REST_Request $request The api request.
	 *
	 * @return WP_REST_Response|WP_Error The api response.
	 */
	public function api_license_clear_cache( WP_REST_Request $request ) {
		global $wpdb;

		$wpdb->query( $wpdb->prepare( "DELETE FROM $wpdb->options WHERE option_name LIKE %s", '%' . $wpdb->esc_like( 's3mm_sl' ) . '%' ) );

		$transients_to_delete = array(
			'update_plugins',
			'plugin_slugs',
			'update_core',
			'update_themes',
			'theme_roots',
			's3mm_license_status',
		);

		foreach ( $transients_to_delete as $transient ) {
			delete_site_transient( $transient );
			delete_transient( $transient );
		}

		$message = esc_html__( 'Plugin update cache cleared successfully!', 'wp-courseware' );

		return rest_ensure_response( array( 'message' => $message ) );
	}
}
