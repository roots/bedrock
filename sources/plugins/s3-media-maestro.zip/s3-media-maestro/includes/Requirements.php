<?php
/**
 * Plugin Requirements.
 *
 * @package S3MM\Includes
 * @since 3.0.0
 */

/**
 * Class S3MM_Requirements
 *
 * @since 3.0.0
 */
class S3MM_Requirements {

	/**
	 * @var string WP Version.
	 * @since 3.0.0
	 */
	protected $wp_version = '4.4.0';

	/**
	 * @var string PHP Version.
	 * @since 3.0.0
	 */
	protected $php_version = '5.5.0';

	/**
	 * @var string Curl Version
	 * @since 3.0.0
	 */
	protected $curl_version = '7.16.2';

	/**
	 * @var array Errors.
	 * @since 3.0.0
	 */
	protected $errors;

	/**
	 * Are requirements met.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public static function are_met() {
		$requirements = new self();

		return $requirements->check();
	}

	/**
	 * Check Requirements.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function check() {
		$php_fail = false;
		$wp_fail  = false;

		if ( version_compare( phpversion(), $this->php_version, '<' ) ) {
			$php_fail = true;
		}

		if ( version_compare( get_bloginfo( 'version' ), $this->wp_version, '<' ) ) {
			$wp_fail = true;
		}

		if ( $wp_fail && $php_fail ) {
			$this->errors[] = sprintf(
				__( '<strong>S3 Media Maestro</strong> - requires PHP version %1$s or later and WordPress version %2$s or later to run.', 's3mm' ),
				$this->php_version,
				$this->wp_version
			);
		} elseif ( $php_fail ) {
			$this->errors[] = sprintf(
				__( '<strong>S3 Media Maestro</strong> - requires PHP version %1$s or later to run. You are running %2$s .', 's3mm' ),
				$this->php_version,
				phpversion()
			);
		} elseif ( $wp_fail ) {
			$this->errors[] = sprintf(
				__( '<strong>S3 Media Maestro</strong> - requires WordPress version %1$s or later to run. You are running %2$s.', 's3mm' ),
				$this->wp_version,
				get_bloginfo( 'version' )
			);
		}

		if ( $wp_fail || $php_fail || $this->errors ) {
			$this->errors[] = __( '<strong>S3 Media Maestro</strong> has been deactivated.', 's3mm' );
			add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
			add_action( 'admin_init', array( $this, 'deactivate' ) );
			add_action( 'all_admin_notices', array( $this, 'display_errors' ) );

			return false;
		}

		return true;
	}

	/**
	 * Load Textdomain.
	 *
	 * @since 3.0.0
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 's3mm', false, dirname( S3MM_FILE ) . '/languages/' );
	}

	/**
	 * Display Errors.
	 *
	 * @since 3.0.0
	 */
	public function display_errors() {
		if ( ! empty ( $this->errors ) ) {
			foreach ( $this->errors as $error ) {
				$class = 'notice notice-error is-dismissable';
				printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $error ) );
			}
		}
	}

	/**
	 * Deactivate Plugin.
	 *
	 * @since 3.0.0
	 */
	public function deactivate() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		if ( ! function_exists( 'deactivate_plugins' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		deactivate_plugins( S3MM_PATH . 's3-media-maestro.php' );

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}
	}
}