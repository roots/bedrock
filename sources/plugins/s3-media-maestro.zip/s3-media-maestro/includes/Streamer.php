<?php
/**
 * Streamer.
 *
 * @since 3.2.3
 * @package S3MM
 */

namespace S3MM;

/**
 * Class Streamer.
 *
 * @package S3MM
 * @since 3.2.3
 */
class Streamer {

	/**
	 * @var string File Path.
	 * @since 3.2.3
	 */
	protected $path = '';

	/**
	 * @var string Stream Object.
	 * @since 3.2.3
	 */
	protected $stream = '';

	/**
	 * @var int Buffer Size.
	 * @since 3.2.3
	 */
	protected $buffer = 102400;

	/**
	 * @var int Start Buffer.
	 * @since 3.2.3
	 */
	protected $start = - 1;

	/**
	 * @var int End Buffer.
	 * @since 3.2.3
	 */
	protected $end = - 1;

	/**
	 * @var int Size.
	 * @since 3.2.3
	 */
	protected $size = 0;

	/**
	 * File constructor.
	 *
	 * @since 3.2.3
	 *
	 * @param string $file_path The file path.
	 */
	public function __construct( $file_path ) {
		$this->path = $file_path;
	}

	/**
	 * Open Stream.
	 *
	 * @since 3.2.3
	 */
	protected function open() {
		if ( ! ( $this->stream = fopen( $this->path, 'rb' ) ) ) {
			die( 'Could not open stream for reading' );
		}
	}

	/**
	 * Set Headers.
	 *
	 * @since 3.2.3
	 */
	public function headers() {
		ob_get_clean();
		header( 'Content-Type: ' . mime_content_type( $this->path ) );
		header( 'Content-Disposition: inline; filename="' . basename( $this->path ) . '"' );
		header( "Cache-Control: max-age=2592000, public" );
		header( "Expires: " . gmdate( 'D, d M Y H:i:s', time() + 2592000 ) . ' GMT' );
		header( "Last-Modified: " . gmdate( 'D, d M Y H:i:s', @filemtime( $this->path ) ) . ' GMT' );

		$this->start = 0;
		$this->size  = filesize( $this->path );
		$this->end   = $this->size - 1;

		header( "Accept-Ranges: bytes 0-{$this->end}" );

		if ( isset( $_SERVER['HTTP_RANGE'] ) ) {
			$c_start = $this->start;
			$c_end   = $this->end;

			list( , $range ) = explode( '=', $_SERVER['HTTP_RANGE'], 2 );
			if ( strpos( $range, ',' ) !== false ) {
				header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
				header( "Content-Range: bytes {$this->start}-{$this->end}/{$this->size}" );
				exit;
			}

			if ( $range == '-' ) {
				$c_start = $this->size - substr( $range, 1 );
			} else {
				$range   = explode( '-', $range );
				$c_start = $range[0];
				$c_end   = ( isset( $range[1] ) && is_numeric( $range[1] ) ) ? $range[1] : $c_end;
			}

			$c_end = ( $c_end > $this->end ) ? $this->end : $c_end;

			if ( $c_start > $c_end || $c_start > $this->size - 1 || $c_end >= $this->size ) {
				header( 'HTTP/1.1 416 Requested Range Not Satisfiable' );
				header( "Content-Range: bytes {$this->start}-{$this->end}/{$this->size}" );
				exit;
			}

			$this->start = $c_start;
			$this->end   = $c_end;
			$length      = $this->end - $this->start + 1;

			fseek( $this->stream, $this->start );
			header( 'HTTP/1.1 206 Partial Content' );
		}

		// Header Range.
		header( "Content-Range: bytes {$this->start}-{$this->end}/{$this->size}" );
		header( 'Content-Length: ' . $length );
	}

	/**
	 * Close Stream.
	 *
	 * @since 3.2.3
	 */
	public function end() {
		fclose( $this->stream );
		exit;
	}

	/**
	 * Stream Calculated Range.
	 *
	 * @since 3.2.3
	 */
	public function stream() {
		$i = $this->start;
		while ( ! feof( $this->stream ) && $i <= $this->end ) {
			$bytesToRead = $this->buffer;
			if ( ( $i + $bytesToRead ) > $this->end ) {
				$bytesToRead = $this->end - $i + 1;
			}

			set_time_limit( 0 );
			echo fread( $this->stream, $bytesToRead );
			flush();
			$i += $bytesToRead;
		}
	}

	/**
	 * Start the Stream.
	 *
	 * @since 3.2.3
	 */
	public function start() {
		$this->open();
		$this->headers();
		$this->stream();
		$this->end();
	}
}
