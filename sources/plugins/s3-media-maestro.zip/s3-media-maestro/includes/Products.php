<?php
/**
 * S3 Media Maestro Products Class.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\Base;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || die;

/**
 * Products Class.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Products extends Base {

	/**
	 * System Instance.
	 *
	 * @param null $class
	 *
	 * @return System The system object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		add_filter( 's3mm_api_endoints', array( $this, 'api_endpoints' ) );
	}

	/**
	 * Register Api Endpoints
	 *
	 * @since 3.0.0
	 *
	 * @param Api $api The api object.
	 */
	public function api_endpoints( $endpoints ) {
		$products_api_endpoint = array(
			'endpoint' => 'otherproducts',
			'method'   => 'GET',
			'callback' => array( $this, 'api_get_products' ),
		);

		array_push( $endpoints, $products_api_endpoint );

		return $endpoints;
	}

	/**
	 * Get Products.
	 *
	 * @since 3.0.0
	 * @access public
	 *
	 * @return array $products An array of other products.
	 */
	public function get_products() {
		return apply_filters( 's3mm_other_products', array(
			'wp-courseware' => array(
				'title'            => esc_html__( 'WP Courseware', 's3mm' ),
				'url'              => 'https://flyplugins.com/wp-courseware/?discount=15OFF4CC',
				'image'            => $this->image( 'wp-courseware.svg' ),
				'desc'             => esc_html__( 'The first and most widely-used learning management system plugin for WordPress. Create your first course within minutes using our powerful drag and drop course editor. You can even begin earning money from your courses the same day!', 's3mm' ),
				'discount'         => esc_html__( 'Save 15%', 's3mm' ),
				'discount_enabled' => true,
			),
			'churnly'       => array(
				'title'            => esc_html__( 'Churnly', 's3mm' ),
				'url'              => 'https://flyplugins.com/churnly-for-wordpress/?discount=15OFF4CC',
				'image'            => $this->image( 'churnly.svg' ),
				'desc'             => esc_html__( 'Churnly is the only solution for WordPress that allows you to easily recapture failed recurring credit card payments through a completely automated process. On average, Churnly increases its users\' annual revenues by 7%!', 's3mm' ),
				'discount'         => esc_html__( 'Save 15%', 's3mm' ),
				'discount_enabled' => true,
			),
		) );
	}

	/**
	 * Api Get Products Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The api request.
	 *
	 * @return WP_REST_Response|WP_Error The api response.
	 */
	public function api_get_products( WP_REST_Request $request ) {
		$products = $this->get_products();

		if ( empty( $products ) ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'There are currently no products available. Please try again later.', 's3mm' ) );
		}

		return rest_ensure_response( array( 'products' => $products ) );
	}
}