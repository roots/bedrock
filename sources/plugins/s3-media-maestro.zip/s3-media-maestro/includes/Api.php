<?php
/**
 * S3 Media Maestor Api.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\Base;
use S3MM\Utils;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

defined( 'ABSPATH' ) || die;

/**
 * Class Api.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Api extends Base {

	/**
	 * @var string The api namespace.
	 * @since 3.0.0
	 */
	protected $namespace = 's3mm/v1';

	/**
	 * @var string The api route base.
	 * @since 3.0.0
	 */
	protected $base = '/api/';

	/**
	 * @var string The action api prefix.
	 * @since 3.0.0
	 */
	protected $action_api_prefix = 's3mm_api';

	/**
	 * Api Instance.
	 *
	 * @since 3.0.0
	 *
	 * @param null $class
	 *
	 * @return Api The api object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Api Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		add_action( 'init', array( $this, 'register_actions' ), 5 );
		add_action( 'init', array( $this, 'process_actions' ), 10 );
		add_action( 'rest_api_init', array( $this, 'register' ) );
	}

	/**
	 * Register Api Actions.
	 *
	 * @since 3.0.0
	 */
	public function register_actions() {
		/**
		 * Register Api Actions Hook.
		 *
		 * @since 3.0.0
		 *
		 * @param string $action_api_prefix
		 * @param object Api The api object.
		 */
		do_action( 's3mm_api_action_register', $this->action_api_prefix, $this );
	}

	/**
	 * Process Api Actions.
	 *
	 * @since 3.0.0
	 */
	public function process_actions() {
		if ( $post_action = Utils::post_var( "{$this->action_api_prefix}_action" ) ) {
			do_action( "{$this->action_api_prefix}_{$post_action}", $_POST );
		}

		if ( $get_action = Utils::get_var( "{$this->action_api_prefix}_action" ) ) {
			do_action( "{$this->action_api_prefix}_{$get_action}", $_GET );
		}
	}

	/**
	 * Get Namespace.
	 *
	 * @since 3.0.0
	 *
	 * @return string The namespace.
	 */
	public function get_namespace() {
		return $this->namespace;
	}

	/**
	 * Get API Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string The api url.
	 */
	public function get_url() {
		return esc_url_raw( rest_url( $this->namespace . '/api/' ) );
	}

	/**
	 * Get API Nonce.
	 *
	 * @since 3.0.0
	 *
	 * @return string The api nonce.
	 */
	public function get_nonce() {
		return wp_create_nonce( 'wp_rest' );
	}

	/**
	 * Get API Endpoints.
	 *
	 * @since 3.0.0
	 *
	 * @return array The api endpoints.
	 */
	public function get_endpoints() {
		return apply_filters( 's3mm_api_endoints', array(
			array( 'endpoint' => 'settings', 'method' => 'GET', 'callback' => array( $this, 'api_get_settings' ) ),
			array( 'endpoint' => 'settings', 'method' => 'POST', 'callback' => array( $this, 'api_save_settings' ) ),
		) );
	}

	/**
	 * Register Api.
	 *
	 * @since 3.0.0
	 */
	public function register() {
		foreach ( $this->get_endpoints() as $endpoint ) {
			$this->register_endpoint( $endpoint['endpoint'], $endpoint['callback'], $endpoint['method'] );
		}
	}

	/**
	 * Register Api Endpoint.
	 *
	 * @since 3.0.0
	 *
	 * @param string $endpoint
	 * @param string $callback
	 * @param string $method
	 */
	public function register_endpoint( $endpoint, $callback, $method = 'GET' ) {
		register_rest_route( $this->namespace, '/api/' . $endpoint, array(
			'methods'             => $method,
			'callback'            => $callback,
			'permission_callback' => array( $this, 'auth' ),
		) );
	}

	/**
	 * Api Permissions Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The api request.
	 *
	 * @return WP_REST_Response|WP_Error The api response.
	 */
	public function auth( WP_REST_Request $request ) {
		if ( ! current_user_can( 'manage_options' ) && apply_filters( 's3mm_api_auth_permissions', true ) ) {
			return new WP_Error(
				'api_access_forbidden',
				esc_html__( 'You are not able to access this api endpoint without proper permission.', 's3mmm' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Get Settings Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
	public function api_get_settings( WP_REST_Request $request ) {
		$this->load_settings();

		$settings = $this->get_settings();
		$regions  = $this->get_regions();

		return rest_ensure_response( array( 'settings' => $settings, 'regions' => $regions ) );
	}

	/**
	 * Save Settings Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The api request.
	 *
	 * @return WP_REST_Response|WP_Error The api response.
	 */
	public function api_save_settings( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );

		if ( empty( $settings ) ) {
			return new WP_Error(
				'api-request-settings-empty',
				esc_html__( 'Sorry, the request that was made contained not settings to save. Please try again.', 's3mm' )
			);
		}

		$this->set_settings( $settings );
		$this->save_settings();

		return rest_ensure_response( $this->get_settings() );
	}
}
