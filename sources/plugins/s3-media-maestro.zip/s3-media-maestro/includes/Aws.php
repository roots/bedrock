<?php
/**
 * S3 Media Maestro Aws Integration.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\Base;
use Aws\S3\S3Client;
use Aws\S3\S3MultiRegionClient;
use Aws\S3\MultipartUploader;
use Aws\Exception\MultipartUploadException;
use Aws\CloudFront\CloudFrontClient;
use Aws\Exception\AwsException;
use WP_Error;
use WP_REST_Request;

defined( 'ABSPATH' ) || die;

/**
 * Class Aws.
 *
 * @since 3.0.0
 * @package S3MM
 */
class Aws extends Base {

	/**
	 * @var S3Client The AWS S3 Client Instance.
	 * @since 3.0.0
	 */
	private $s3client;

	/**
	 * @var CloudFrontClient The AWS Cloudfront Client Instance.
	 * @since 3.0.0
	 */
	private $cfclient;

	/**
	 * @var string Default ACL for any file uploaded.
	 * @since 3.0.0
	 */
	private $acl = 'private';

	/**
	 * @var MultipartUploader The multipart uploader object.
	 * @since 3.0.0
	 */
	private $uploader;

	/**
	 * Aws Instance.
	 *
	 * @param null $class The class object.
	 *
	 * @return Aws The Aws object.
	 */
	public static function get_object( $class = null ) {
		return parent::get_object( __CLASS__ );
	}

	/**
	 * Load Hooks.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() {
		add_filter( 's3mm_api_endoints', array( $this, 'api_endpoints' ) );
	}

	/**
	 * Register Api Endpoints
	 *
	 * @since 3.0.0
	 *
	 * @param array $endpoints The api endpoints.
	 */
	public function api_endpoints( $endpoints ) {
		$get_s3_buckets    = array(
			'endpoint' => 's3buckets',
			'method'   => 'POST',
			'callback' => array( $this, 'api_get_s3buckets' ),
		);
		$add_s3_bucket     = array(
			'endpoint' => 'adds3bucket',
			'method'   => 'POST',
			'callback' => array( $this, 'api_add_s3bucket' ),
		);
		$get_s3_region     = array(
			'endpoint' => 'gets3region',
			'method'   => 'POST',
			'callback' => array( $this, 'api_get_s3region' ),
		);
		$get_s3_files      = array(
			'endpoint' => 's3files',
			'method'   => 'POST',
			'callback' => array( $this, 'api_get_s3files' ),
		);
		$add_s3_files      = array(
			'endpoint' => 'adds3files',
			'method'   => 'POST',
			'callback' => array( $this, 'api_add_s3files' ),
		);
		$delete_s3_files   = array(
			'endpoint' => 'deletes3files',
			'method'   => 'POST',
			'callback' => array( $this, 'api_delete_s3files' ),
		);
		$add_s3_folder     = array(
			'endpoint' => 'adds3folder',
			'method'   => 'POST',
			'callback' => array( $this, 'api_add_s3folder' ),
		);
		$get_s3_signed_url = array(
			'endpoint' => 'gets3signedurl',
			'method'   => 'POST',
			'callback' => array( $this, 'api_get_s3_signed_url' ),
		);

		array_push( $endpoints, $get_s3_buckets );
		array_push( $endpoints, $add_s3_bucket );
		array_push( $endpoints, $get_s3_region );
		array_push( $endpoints, $get_s3_files );
		array_push( $endpoints, $add_s3_files );
		array_push( $endpoints, $delete_s3_files );
		array_push( $endpoints, $add_s3_folder );
		array_push( $endpoints, $get_s3_signed_url );

		return $endpoints;
	}

	/**
	 * Get AWS Access Key.
	 *
	 * @since 3.0.0
	 *
	 * @return string|false
	 */
	public function get_access_key() {
		return $this->get_setting( 's3accesskey' );
	}

	/**
	 * Get AWS Secret Key.
	 *
	 * @since 3.0.0
	 *
	 * @return string|false
	 */
	public function get_secret_key() {
		return $this->get_setting( 's3secretkey' );
	}

	/**
	 * Get Bucket.
	 *
	 * @since 3.0.0
	 *
	 * @return string|false
	 */
	public function get_bucket() {
		return $this->get_setting( 's3bucket' );
	}

	/**
	 * Get AWS S3 Region.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function get_region() {
		$region = $this->get_setting( 's3region' );

		return ( $region ) ? $region : apply_filters( 's3mm_aws_default_region', 'us-east-1' );
	}

	/**
	 * Get AWS S3 Expiry.
	 *
	 * @since 3.0.0
	 *
	 * @return string The expiry time.
	 */
	public function get_expiry() {
		return $this->get_setting( 's3expiry' );
	}

	/**
	 * Get ACL.
	 *
	 * @since 3.1.0
	 *
	 * @return string
	 */
	public function get_acl() {
		return $this->acl;
	}

	/**
	 * Get AWS S3 Client.
	 *
	 * @since 3.0.0
	 *
	 * @param bool $multiregion Determine if it should be multi-region or not.
	 *
	 * @return S3Client|WP_Error
	 */
	public function get_s3_client( $multiregion = false ) {
		$settings = $this->get_settings();

		// Get Settings.
		if ( empty( $settings ) ) {
			$this->load_settings();
		}

		// Access.
		$access_key = $this->get_access_key();
		$secret_key = $this->get_secret_key();

		// Check.
		if ( ! $access_key || ! $secret_key ) {
			return new WP_Error(
				'aws_s3_keys_missing',
				esc_html__( 'You are missing your Aws S3 Access Key ID and S3 Secret Key. Please correct and try again', 's3mm' )
			);
		}

		// Require AWS.
		require $this->vendor_dir . 'autoload.php';

		// Region.
		$region = $this->get_region();

		// Get Client.
		if ( $multiregion ) {
			$this->s3client = new S3MultiRegionClient(
				array(
					'version'     => 'latest',
					'credentials' => array(
						'key'    => $access_key,
						'secret' => $secret_key,
					),
				)
			);
		} else {
			$this->s3client = new S3Client(
				array(
					'version'     => 'latest',
					'region'      => $region,
					'credentials' => array(
						'key'    => $access_key,
						'secret' => $secret_key,
					),
				)
			);
		}

		return $this->s3client;
	}

	/**
	 * Get AWS Cloudfront Key.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_cf_key() {
		return trim( $this->get_setting( 'cfkey' ) );
	}

	/**
	 * Get AWS Cloudfront Private Key.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_cf_private_key() {
		return trim( $this->get_setting( 'cfprivatekey' ) );
	}

	/**
	 * Get AWS Cloudfront Distribution Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_cf_dist_url() {
		return $this->get_setting( 'cfdisturl' );
	}

	/**
	 * Get AWS Cloudfront Expiry.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	protected function get_cf_expiry() {
		return $this->get_setting( 'cfexpiry' );
	}

	/**
	 * Get AWS Cloudfront Client.
	 *
	 * @since 3.0.0
	 *
	 * @return CloudFrontClient|WP_Error
	 */
	public function get_cloudfront_client() {
		$settings = $this->get_settings();

		if ( empty( $settings ) ) {
			$this->load_settings();
		}

		// Require AWS.
		require $this->vendor_dir . 'autoload.php';

		// Region.
		$region = $this->get_region();

		// Create Cloudfront client.
		$this->cfclient = new CloudFrontClient(
			array(
				'version' => 'latest',
				'region'  => $region,
			)
		);

		return $this->cfclient;
	}

	/**
	 * Get S3 Buckets Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest api request.
	 *
	 * @return mixed|WP_REST_Response
	 */
	public function api_get_s3buckets( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		$buckets = $this->get_s3_buckets( $settings );

		return rest_ensure_response( $buckets );
	}

	/**
	 * Get AWS S3 Buckets.
	 *
	 * @since 3.0.0
	 *
	 * @param array $settings The s3 bucket settings.
	 *
	 * @return array|WP_Error
	 */
	public function get_s3_buckets( $settings ) {
		$this->set_settings( $settings );

		$buckets = array();
		$client  = $this->get_s3_client( true );

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		try {
			$result = $client->listBuckets();

			$buckets_data = $result->get( 'Buckets' );

			if ( $buckets_data ) {
				foreach ( $buckets_data as $bucket ) {
					$buckets[] = array( 'name' => $bucket['Name'] );
				}
			}

			return $buckets;
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getAwsErrorMessage() );
		}
	}

	/**
	 * Add S3 Bucket Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest request.
	 *
	 * @return WP_REST_Response
	 */
	public function api_add_s3bucket( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		$bucket = $request->get_param( 'bucket' );
		$region = $request->get_param( 'region' );

		if ( empty( $bucket ) ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'You must specify a bucket name.', 's3mm' ) );
		}

		$new_bucket = $this->add_s3_bucket( $settings, $bucket, $region );

		if ( is_wp_error( $new_bucket ) ) {
			return $new_bucket;
		}

		if ( false === $new_bucket ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'Something went wrong. Please try again', 's3mm' ) );
		}

		$success_message = sprintf( '<strong>"%s"</strong> - %s', $new_bucket, esc_html__( 'Added Sucessfully', 's3mm' ) );

		return rest_ensure_response(
			array(
				'bucket'  => $new_bucket,
				'message' => $success_message,
			)
		);
	}

	/**
	 * Add S3 Bucket.
	 *
	 * @since 3.0.0
	 *
	 * @param array  $settings The bucket settings.
	 * @param string $name The bucket name.
	 * @param string $region The region.
	 */
	public function add_s3_bucket( $settings, $name, $region = '' ) {
		$this->set_settings( $settings );

		if ( ! empty( $region ) ) {
			$this->set_setting( 's3region', $region );
		}

		$client      = $this->get_s3_client();
		$bucket_name = sanitize_title( $name );

		$bucket_args = array(
			'ACL'    => $this->acl,
			'Bucket' => $bucket_name,
		);

		try {
			$result   = $client->createBucket( $bucket_args );
			$metadata = $result->get( '@metadata' );

			return ( isset( $metadata['statusCode'] ) && ( 200 === $metadata['statusCode'] ) ) ? $bucket_name : false;
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getAwsErrorMessage() );
		}
	}

	/**
	 * Get S3 Bucket Region
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest request.
	 *
	 * @return mixed|WP_REST_Response
	 */
	public function api_get_s3region( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );
		$bucket   = $request->get_param( 'bucket' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		$region = $this->get_s3_bucket_region( $settings, $bucket );

		if ( is_wp_error( $region ) ) {
			return $region;
		}

		return rest_ensure_response(
			array(
				'bucket' => $bucket,
				'region' => $region,
			)
		);
	}

	/**
	 * Get S3 Bucket Region.
	 *
	 * @since 3.0.0
	 *
	 * @param array  $settings The settings array.
	 * @param string $bucket The bucket.
	 *
	 * @return array|WP_Error
	 */
	public function get_s3_bucket_region( $settings, $bucket ) {
		$this->set_settings( $settings );

		$region = '';
		$client = $this->get_s3_client( true );

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		try {
			$result = $client->getBucketLocation( array( 'Bucket' => $bucket ) );
			$region = $result->get( 'LocationConstraint' );

			return $region;
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getAwsErrorMessage() );
		}
	}

	/**
	 * Get S3 Files Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest api request.
	 *
	 * @return mixed|WP_REST_Response
	 */
	public function api_get_s3files( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );
		$marker   = $request->get_param( 'marker' );
		$prefix   = $request->get_param( 'prefix' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		if ( empty( $settings ) ) {
			return new WP_Error( 's3mm-api-s3-error', esc_html__( 'There was an error with your request. Please try again.', 's3mm' ) );
		}

		$files = $this->get_s3_files( $settings, $prefix, $marker );

		return rest_ensure_response( $files );
	}

	/**
	 * Get S3 Files.
	 *
	 * @since 3.0.0
	 *
	 * @param array  $settings The settings to connect.
	 * @param array  $prefix The prefix folder name.
	 * @param string $marker The next token for the next set.
	 *
	 * @return array|WP_Error
	 */
	public function get_s3_files( $settings, $prefix = '', $marker = '' ) {
		$this->set_settings( $settings );

		$files  = array();
		$client = $this->get_s3_client();

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		try {
			$args = array(
				'Bucket'    => $this->get_bucket(),
				'Delimiter' => '/',
			);

			if ( ! empty( $prefix ) ) {
				$prefix         = trailingslashit( $prefix );
				$args['Prefix'] = $prefix;
			}

			if ( $marker ) {
				$args['Marker'] = $marker;
			}

			$result = $client->listObjects( $args );

			$folders = $result->get( 'CommonPrefixes' );
			$objects = $result->get( 'Contents' );

			$master_key = 0;

			if ( ! $folders && ! $objects ) {
				return new WP_Error( 's3mm-bucket-empty', __( '<strong>Error:</strong> There are no files available. Is the selected bucket empty?', 's3mm' ) );
			}

			if ( $folders ) {
				foreach ( $folders as $key => $folder ) {
					$found_prefix = ! empty( $prefix ) ? strpos( $folder['Prefix'], $prefix ) : false;
					$name         = ( $found_prefix !== false ) ? substr_replace( $folder['Prefix'], '', $found_prefix, strlen( $prefix ) ) : $folder['Prefix'];

					$files[] = array(
						'key'    => $master_key,
						'name'   => $name,
						'folder' => true,
					);
					$master_key ++;
				}
			}

			if ( $objects ) {
				foreach ( $objects as $key => $object ) {
					if ( $object['Size'] > 0 ) {
						$found_prefix = ! empty( $prefix ) ? strpos( $object['Key'], $prefix ) : false;
						$name         = ( $found_prefix !== false ) ? substr_replace( $object['Key'], '', $found_prefix, strlen( $prefix ) ) : $object['Key'];

						$files[] = array(
							'key'    => $master_key,
							'name'   => $name,
							'folder' => false,
						);
						$master_key ++;
					}
				}
			}

			if ( $result->get( 'IsTruncated' ) ) {
				$last_file = end( $files );
				if ( ! empty( $last_file['name'] ) ) {
					$marker = $last_file['name'];
				}
			}
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getMessage() );
		}

		return array(
			'files'  => $files,
			'marker' => $marker,
		);
	}

	/**
	 * Add S3 Files.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest api request.
	 *
	 * @return mixed
	 */
	public function api_add_s3files( WP_REST_Request $request ) {
		$file_params = $request->get_file_params();

		$settings = $request->get_param( 'settings' );
		$files    = isset( $file_params['s3files'] ) ? $file_params['s3files'] : false;

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		if ( empty( $files ) ) {
			return new WP_Error( 's3mm-api-file-upload-error', esc_html__( 'There were no files uploaded. Please try again.', 's3mm' ) );
		}

		$files = $this->add_s3_files( $files, $settings );

		return rest_ensure_response( array( 'files' => $files ) );
	}

	/**
	 * Add S3 Files.
	 *
	 * @since 3.0.0
	 *
	 * @param array $files The files to be added.
	 * @param array $settings The settings to connect.
	 *
	 * @return bool|WP_Error
	 */
	public function add_s3_files( $files, $settings ) {
		$this->set_settings( $settings );

		$client = $this->get_s3_client();
		$bucket = $this->get_bucket();

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$s3_files = $this->normalize_file_array( $files );

		$files_uploaded = array();

		foreach ( $s3_files as $file ) {
			$acl = $this->acl;

			$name = $file['name'];
			$type = $file['type'];
			$path = $file['tmp_name'];
			$size = $file['size'];
			$key  = $name;

			if ( $this->get_setting( 'objectversioning' ) ) {
				$prefix = $this->get_object_version_prefix();
				$key    = $prefix . $name;
			}

			$uploader = new MultipartUploader(
				$client, $path, array(
					'bucket' => $bucket,
					'key'    => $key,
					'acl'    => $acl,
				)
			);

			do {
				try {
					$result           = $uploader->upload();
					$files_uploaded[] = $result->get( 'ObjectURL' );
				} catch ( MultipartUploadException $e ) {
					rewind( $source );
					$uploader = new MultipartUploader(
						$this->s3client, $source, [
							'state' => $e->getState(),
						]
					);
				}
			} while ( ! isset( $result ) );
		}

		return $files_uploaded;
	}

	/**
	 * Delete S3 Files.
	 *
	 * @since 3.2.0
	 *
	 * @param WP_REST_Request $request The rest api request.
	 *
	 * @return mixed
	 */
	public function api_delete_s3files( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		$files = $request->get_param( 'files' );

		if ( empty( $files ) ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'You must specify some files to delete.', 's3mm' ) );
		}

		$deleted_files = $this->delete_s3_files( $settings, $files );

		if ( is_wp_error( $deleted_files ) ) {
			return $deleted_files;
		}

		$message = sprintf( '<strong>%s</strong><br />%s', implode( '<br />', $deleted_files ), esc_html__( 'Deleted Sucessfully', 's3mm' ) );

		return rest_ensure_response( array(
			'files'   => $files,
			'message' => $message
		) );
	}

	/**
	 * Delete S3 Files.
	 *
	 * @since 3.2.0
	 *
	 * @param array $settings The settings.
	 * @param array $files The files to be added.
	 *
	 * @return bool|WP_Error
	 */
	public function delete_s3_files( $settings, $files ) {
		$this->set_settings( $settings );

		$client = $this->get_s3_client();
		$bucket = $this->get_bucket();

		$files_to_delete = array();

		foreach ( $files as $file ) {
			$files_to_delete[]['Key'] = $file;
		}

		$delete_args = array(
			'Bucket' => $bucket,
			'Delete' => array(
				'Objects' => $files_to_delete
			)
		);

		try {
			$result   = $client->deleteObjects( $delete_args );
			$metadata = $result->get( '@metadata' );
			$deleted  = $result->get( 'Deleted' );

			return ( isset( $metadata['statusCode'] ) && ( 200 === $metadata['statusCode'] ) && ! empty( $deleted ) ) ? wp_list_pluck( $deleted, 'Key' ) : false;
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getAwsErrorMessage() );
		}
	}

	/**
	 * Add S3 Folder Api Callback.
	 *
	 * @since 3.0.0
	 *
	 * @param WP_REST_Request $request The rest request.
	 *
	 * @return WP_REST_Response
	 */
	public function api_add_s3folder( WP_REST_Request $request ) {
		$settings = $request->get_param( 'settings' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		$folder = $request->get_param( 'folder' );
		$prefix = $request->get_param( 'prefix' );

		if ( empty( $folder ) ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'You must specify a folder name.', 's3mm' ) );
		}

		$new_folder = $this->add_s3_folder( $settings, $folder, $prefix );

		if ( is_wp_error( $new_folder ) ) {
			return $new_folder;
		}

		if ( false === $new_folder ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'Something went wrong. Please try again', 's3mm' ) );
		}

		$success_message = sprintf( '<strong>"%s"</strong> - %s', $new_folder, esc_html__( 'Added Sucessfully', 's3mm' ) );

		return rest_ensure_response(
			array(
				'folder'  => $new_folder,
				'message' => $success_message,
			)
		);
	}

	/**
	 * Add S3 Folder.
	 *
	 * @since 3.0.0
	 *
	 * @param array  $settings The settings.
	 * @param string $folder_name The folder name.
	 * @param string $prefix The folder prefix.
	 */
	public function add_s3_folder( $settings, $folder, $prefix = '' ) {
		$this->set_settings( $settings );

		$client = $this->get_s3_client();
		$bucket = $this->get_bucket();

		$folder_name   = sanitize_title( $folder );
		$folder_prefix = ! empty( $prefix ) ? trailingslashit( $prefix ) : '';

		$folder_args = array(
			'ACL'    => $this->acl,
			'Bucket' => $bucket,
			'Key'    => trailingslashit( $folder_prefix . $folder_name ),
		);

		$folder_exists = $client->doesObjectExist( $bucket, trailingslashit( $folder_prefix . $folder_name ) );

		if ( $folder_exists ) {
			return new WP_Error( 's3mm-api-error', esc_html__( 'The folder already exists in this bucket.', 's3mm' ) );
		}

		try {
			$result   = $client->putObject( $folder_args );
			$metadata = $result->get( '@metadata' );

			return ( isset( $metadata['statusCode'] ) && ( 200 === $metadata['statusCode'] ) ) ? $folder_name : false;
		} catch ( AwsException $e ) {
			return new WP_Error( 's3mm-aws-exception', $e->getAwsErrorMessage() );
		}
	}

	/**
	 * Api: Get S3 Signed Upload Request.
	 *
	 * @since 3.1.0
	 *
	 * @param WP_REST_Request $request The rest api request.
	 *
	 * @return mixed
	 */
	public function api_get_s3_signed_url( WP_REST_Request $request ) {
		$file     = $request->get_param( 'file' );
		$settings = $request->get_param( 'settings' );

		if ( ! is_array( $settings ) ) {
			$settings = json_decode( $settings, true );
		}

		if ( is_array( $file ) ) {
			return new WP_Error( 's3mm-api-upload-filename-error', esc_html__( 'There was no filename provided. Please try again.', 's3mm' ) );
		}

		$signed_url = $this->get_s3_signed_upload_url( esc_attr( $file ), $settings );

		if ( empty( $signed_url ) ) {
			return new WP_Error( 's3mm-api-upload-signature-error', esc_html__( 'The upload request could not be signed by Amazon. Please try again.', 's3mm' ) );
		}

		if ( is_wp_error( $signed_url ) ) {
			return $signed_url;
		}

		return rest_ensure_response( array( 'url' => $signed_url ) );
	}

	/**
	 * Normalize File Array.
	 *
	 * @since 3.0.0
	 *
	 * @param array $files The files to be normalized.
	 *
	 * @return array $files The files that have been normalized.
	 */
	protected function normalize_file_array( $files ) {
		$normalized_files = array();

		foreach ( $files['name'] as $index => $file ) {
			$normalized_files[ $index ]['name'] = $file;

			if ( ! empty( $files['type'][ $index ] ) ) {
				$normalized_files[ $index ]['type'] = $files['type'][ $index ];
			}

			if ( ! empty( $files['tmp_name'][ $index ] ) ) {
				$normalized_files[ $index ]['tmp_name'] = $files['tmp_name'][ $index ];
			}

			if ( ! empty( $files['error'][ $index ] ) ) {
				$normalized_files[ $index ]['error'] = $files['error'][ $index ];
			}

			if ( ! empty( $files['size'][ $index ] ) ) {
				$normalized_files[ $index ]['size'] = $files['size'][ $index ];
			}
		}

		return $normalized_files;
	}

	/**
	 * Get Object Version Prefix.
	 *
	 * @since 3.0.0
	 *
	 * @param string $time The current timestamp.
	 *
	 * @return string $object_version The unique object version.
	 */
	protected function get_object_version_prefix( $time = null ) {
		if ( is_null( $time ) ) {
			$time = current_time( 'timestamp' );
		}

		$object_version = date( 'YmdHis', $time );
		$object_version = uniqid( $object_version );

		return trailingslashit( $object_version );
	}

	/**
	 * Get S3 Signed Url.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file The file for which to get the url.
	 * @param array  $settings The settings to be used.
	 * @param string $cmd The command to be used to get the signed url.
	 *
	 * @return string The signed url for the file.
	 */
	public function get_s3_signed_url( $file, $settings, $cmd = 'GetObject' ) {
		$this->set_settings( $settings );

		$client = $this->get_s3_client();
		$expiry = $this->get_expiry();

		$bucket = $this->get_bucket();

		$file = apply_filters( 's3mm_s3_file_name', $file );
		$file = ltrim( $file, '/' );
		$file = trim( $file );

		$command = $client->getCommand( $cmd, array(
				'Bucket' => $bucket,
				'Key'    => $file,
			)
		);

		$request = $client->createPresignedRequest( $command, "+{$expiry} minutes" );

		return (string) $request->getUri();
	}

	/**
	 * Get S3 Signed Upload Url.
	 *
	 * @since 3.1.0
	 *
	 * @param string $file The file for which to get the url.
	 * @param array  $settings The settings to be used.
	 *
	 * @return string The signed url for the file.
	 */
	public function get_s3_signed_upload_url( $file, $settings ) {
		$this->set_settings( $settings );

		$client = $this->get_s3_client();

		if ( is_wp_error( $client ) ) {
			return $client;
		}

		$this->check_s3_bucket_cors( $client );

		$command = $client->getCommand(
			'PutObject', array(
				'ACL'    => $this->get_acl(),
				'Bucket' => $this->get_bucket(),
				'Key'    => trim( $file ),
			)
		);

		$request = $client->createPresignedRequest( $command, '+20 minutes' );

		return (string) $request->getUri();
	}

	/**
	 * Get Bucket Cors.
	 *
	 * @since 3.1.0
	 *
	 * @param S3Client $client The s3 client.
	 *
	 * @return string
	 */
	public function check_s3_bucket_cors( S3Client $client ) {
		$cors = $this->get_s3_bucket_cors( $client );

		if ( ! is_array( $cors ) ) {
			$cors = array();
		}

		// Check if exists.
		foreach ( $cors as $cor ) {
			if ( ! empty( $cor['AllowedMethods'] ) && is_array( $cor['AllowedMethods'] ) && in_array( 'PUT', $cor['AllowedMethods'] ) ) {
				if ( ! empty( $cor['AllowedOrigins'] ) && is_array( $cor['AllowedOrigins'] ) && in_array( site_url(), $cor['AllowedOrigins'] ) ) {
					return true;
				}
			}
		}

		$cors[] = array(
			'AllowedHeaders' => array( '*' ),
			'AllowedMethods' => array( 'PUT' ),
			'AllowedOrigins' => array( esc_url( site_url() ) ),
			'MaxAgeSeconds'  => 3000,
		);

		try {
			$client->putBucketCors(
				array(
					'Bucket'            => $this->get_bucket(),
					'CORSConfiguration' => array(
						'CORSRules' => $cors,
					),
				)
			);

			return true;
		} catch ( AwsException $e ) {
			return false;
		}
	}

	/**
	 * Get Bucket Cors.
	 *
	 * @since 3.1.0
	 *
	 * @param S3Client $client The s3 client.
	 *
	 * @return string
	 */
	public function get_s3_bucket_cors( S3Client $client ) {
		try {
			$request = $client->getBucketCors( array( 'Bucket' => $this->get_bucket() ) );

			$cors = $request->get( 'CORSRules' );

			return ! empty( $cors ) ? $cors : array();
		} catch ( AwsException $e ) {
			return array();
		}
	}

	/**
	 * Get Cloudfront Signed Url.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file The file for which to get the url.
	 * @param array  $settings The settings to be used.
	 *
	 * @return string The signed url for the file.
	 */
	public function get_cloudfront_signed_url( $file, $settings ) {
		$this->set_settings( $settings );

		$client = $this->get_cloudfront_client();

		$key        = $this->get_cf_key();
		$privatekey = $this->get_cf_private_key();
		$expiry     = $this->get_cf_expiry();
		$dist_url   = $this->get_cf_dist_url();

		if ( empty( $key ) || empty( $privatekey ) ) {
			return new WP_Error( 'aws-cloudfront-missing-creds', esc_html__( 'Missing Cloudfront Keys', 's3mm' ) );
		}

		$file = apply_filters( 's3mm_cloudfront_file_name', $file );
		$file = urlencode( ltrim( $file, '/' ) );

		$expiry = time() + ( $expiry * 60 );
		$url    = $this->url_force_https( trailingslashit( $dist_url ) . $file );

		$policy = sprintf(
			'{
			"Statement" : [{
				"Resource": "%s",
				"Condition": {
					"DateLessThan": {
						"AWS:EpochTime":%d
					}
				}
			}]
		}', $url, $expiry
		);

		$policy = preg_replace( '/\s+/', '', $policy );

		$privatekey = openssl_pkey_get_private( $privatekey );

		if ( $privatekey ) {
			openssl_sign( $policy, $signed_policy, $privatekey );

			openssl_free_key( $privatekey );

			$base64_signed_policy = base64_encode( $signed_policy );

			$signature = str_replace( array( '+', '=', '/' ), array( '-', '_', '~' ), $base64_signed_policy );
			$policy    = strtr( base64_encode( $policy ), '+=/', '-_~' );

			$url = add_query_arg(
				array(
					'Policy'      => $policy,
					'Signature'   => $signature,
					'Key-Pair-Id' => $key,
				), $url
			);
		}

		return $url;
	}
}
