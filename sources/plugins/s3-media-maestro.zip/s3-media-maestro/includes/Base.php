<?php
/**
 * S3 Media Maestro Base Object.
 *
 * All classes should extend.
 *
 * @since 3.0.0
 * @package S3MM
 */

namespace S3MM;

use S3MM\License;
use S3MM\Utils;

defined( 'ABSPATH' ) || die;

/**
 * Class Base.
 *
 * @since 3.0.0
 * @package S3MM
 */
abstract class Base {

	/**
	 * @var bool Development mode.
	 * @since 3.0.0
	 */
	protected $development = true;

	/**
	 * @var array Plugin Objects.
	 * @since 3.0.0
	 */
	private static $objects;

	/**
	 * @var string Plugin Settings Key.
	 * @since 3.0.0
	 */
	protected $settings_key = 's3mm';

	/**
	 * @var array Plugin Settings.
	 * @since 3.0.0
	 */
	protected $settings;

	/**
	 * @var string Text domain.
	 * @since 3.0.0
	 */
	protected $domain = 's3mm';

	/**
	 * @var string Assets directory.
	 * @since 3.0.0
	 */
	public $assets_dir;

	/**
	 * @var stirng Includes directory.
	 * @since 3.0.0
	 */
	public $inc_dir;

	/**
	 * @var string Languages directory.
	 * @since 3.0.0
	 */
	public $lang_dir;

	/**
	 * @var string Classes directory.
	 * @since 3.0.0
	 */
	public $class_dir;

	/**
	 * @var string Functions directory.
	 * @since 3.0.0
	 */
	public $func_dir;

	/**
	 * @var string Libraries directory.
	 * @since 3.0.0
	 */
	public $lib_dir;

	/**
	 * @var string Templates directory.
	 * @since 3.0.0
	 */
	public $templates_dir;

	/**
	 * @var string Vendor Directory.
	 * @since 3.0.0
	 */
	public $vendor_dir;

	/**
	 * @var string Assets url.
	 * @since 3.0.0
	 */
	public $asset_url;

	/**
	 * @var string CSS url.
	 * @since 3.0.0
	 */
	public $css_url;

	/**
	 * @var string Javascript url.
	 * @since 3.0.0
	 */
	public $js_url;

	/**
	 * @var stirng Images url.
	 * @since 3.0.0
	 */
	public $images_url;

	/**
	 * @var bool Should protection be enabled?
	 * @since 3.2.3
	 */
	protected $enable_protection = false;

	/**
	 * Get Plugin Instance.
	 *
	 * @since 3.0.0
	 *
	 * @param null $class
	 *
	 * @return Base The base object.
	 */
	public static function get_object( $class = null ) {
		if ( ! class_exists( $class ) ) {
			return null;
		}

		if ( ! isset( self::$objects[ $class ] ) ) {
			self::$objects[ $class ] = new $class;
		}

		return self::$objects[ $class ];
	}

	/**
	 * Base constructor.
	 *
	 * @since 3.0.0
	 * @access private
	 */
	private function __construct() {
		$this->load_globals();
		$this->load();
		$this->load_hooks();
	}

	/**
	 * Load Plugin Class Globals.
	 *
	 * @since 3.0.0
	 */
	protected function load_globals() {
		$this->assets_dir    = trailingslashit( S3MM_PATH . 'assets' );
		$this->inc_dir       = trailingslashit( S3MM_PATH . 'includes' );
		$this->templates_dir = trailingslashit( S3MM_PATH . 'templates' );
		$this->vendor_dir    = trailingslashit( S3MM_PATH . 'vendor' );

		$this->lang_dir  = trailingslashit( $this->inc_dir . 'languages' );
		$this->class_dir = trailingslashit( $this->inc_dir . 'classes' );
		$this->func_dir  = trailingslashit( $this->inc_dir . 'functions' );
		$this->lib_dir   = trailingslashit( $this->inc_dir . 'lib' );

		$this->asset_url  = trailingslashit( S3MM_URL . 'assets' );
		$this->css_url    = trailingslashit( $this->asset_url . 'css' );
		$this->js_url     = trailingslashit( $this->asset_url . 'js' );
		$this->images_url = trailingslashit( $this->asset_url . 'images' );
	}

	/**
	 * Load Plugin Object.
	 *
	 * Child classes can implement this method.
	 *
	 * @since 3.0.0
	 */
	public function load() { /* Override in child */ }

	/**
	 * Load Plugin Object Hooks.
	 *
	 * All child classes can implement this method.
	 *
	 * @since 3.0.0
	 */
	public function load_hooks() { /* Override in child */ }

	/**
	 * Load Plugin Settings.
	 *
	 * @sicne 3.0.0
	 */
	public function load_settings() {
		if ( ! $this->settings_key ) {
			return;
		}

		$this->plugin_settings_upgrade();
		$this->plugin_upgrade();

		$default_settings = $this->get_default_settings();

		$settings = get_option( $this->settings_key, array() );

		if ( empty( $settings ) ) {
			$this->set_settings( $this->get_default_settings() );
			$this->save_settings();
		}

		// Merge with Default Settings.
		$settings = wp_parse_args( $settings, $default_settings );

		if ( method_exists( $this, 'default_settings' ) ) {
			$this->settings = (array) $this->default_settings();
		}

		$settings = wp_parse_args( $settings, $this->settings );

		$this->settings = $settings;
	}

	/**
	 * Plugin Settings Upgrade.
	 *
	 * @since 3.0.0
	 */
	protected function plugin_settings_upgrade() {
		if ( get_option( 's3mm_upgrade_to_3_0' ) ) {
			return;
		}

		if ( ! $s3mm_old_settings = get_option( 'S3MM_Settings' ) ) {
			update_option( 's3mm_upgrade_to_3_0', true );

			return;
		}

		$this->set_settings( $this->get_default_settings() );
		$s3mm_old_settings = maybe_unserialize( $s3mm_old_settings );

		$settings_map = array(
			'licence_key'     => 'licensekey',
			'use_default_css' => 'playercss',
			'show_powered_by' => 'poweredbylink',
			's3_accesskey'    => 's3accesskey',
			's3_secretkey'    => 's3secretkey',
			's3_bucket'       => 's3bucket',
			's3_bucketregion' => 's3region',
			's3_expiry'       => 's3expiry',
			'cf_keyPairID'    => 'cfkey',
			'cf_privateKey'   => 'cfprivatekey',
			'cf_distribution' => 'cfdisturl',
			'player_width'    => 'playerwidth',
			'player_height'   => 'playerheight',
			'affiliate_id'    => 'affiliateid',
		);

		foreach ( $settings_map as $old_setting_key => $new_setting_key ) {
			$old_setting = isset( $s3mm_old_settings[ $old_setting_key ] ) ? $s3mm_old_settings[ $old_setting_key ] : false;

			if ( ! $old_setting ) {
				continue;
			}

			switch ( $old_setting_key ) {
				case 'use_default_css' :
					if ( $old_setting === 'show_css' ) {
						$this->set_setting( $new_setting_key, true );
					}
					break;
				case 'show_powered_by' :
					if ( $old_setting === 'show_link' ) {
						$this->set_setting( $new_setting_key, 'yes' );
					}
					break;
				case 'cf_distribution' :
					if ( $old_setting ) {
						$old_setting = esc_url( $old_setting );
						$old_setting = $this->remove_http( $old_setting );
						$this->set_setting( $new_setting_key, $old_setting );
					}
					break;
				case 's3_expiry' :
					if ( $old_setting ) {
						$this->set_setting( $new_setting_key, $old_setting );
						$this->set_setting( 'cfexpiry', absint( $old_setting ) );
					}
					break;
				default:
					$this->set_setting( $new_setting_key, $old_setting );
					break;
			}
		}

		// Set Player Size to fixed to maintain backwards compatability.
		$this->set_setting( 'playersize', 'fixed' );

		$this->save_settings();

		// Activate license.
		$license = License::get_object();
		$license->activate();

		update_option( 's3mm_version', S3MM_VERSION );
		update_option( 's3mm_db_version', S3MM_DB_VERSION );
		update_option( 's3mm_upgrade_to_3_0', true );
	}

	/**
	 * Plugin Upgrade.
	 *
	 * @since 3.0.0
	 */
	protected function plugin_upgrade() {
		$version    = get_option( 's3mm_version' );
		$db_version = get_option( 's3mm_db_version' );

		if ( ! $version || version_compare( S3MM_VERSION, $version, '>' ) ) {
			$new_version = S3MM_VERSION;
			update_option( 's3mm_version', $new_version );

			/**
			 * Hook: Update to Version 'X'
			 *
			 * @since 3.0.0
			 *
			 * @param string $new_version The new version.
			 * @param string $version The current version.
			 */
			do_action( "s3mm_update_to_version_{$new_version}", $new_version, $version );
		}

		if ( ! $db_version || version_compare( S3MM_DB_VERSION, $db_version, '>' ) ) {
			$new_db_version = S3MM_DB_VERSION;
			update_option( 's3mm_db_version', $new_db_version );

			/**
			 * Hook: Update to DB Version 'X'
			 *
			 * @since 3.0.0
			 *
			 * @param string $new_db_version The new db version.
			 * @param string $db_version The current db version.
			 */
			do_action( "s3mm_update_db_to_version_{$new_db_version}", $new_db_version, $db_version );
		}
	}

	/**
	 * Get Plugin Default Settings.
	 *
	 * @since 3.0.0
	 *
	 * @return array The default settings.
	 */
	public function get_default_settings() {
		return array(
			'keysset'             => false,
			'type'                => 'video',
			'source'              => 's3',
			's3accesskey'         => '',
			's3secretkey'         => '',
			's3bucket'            => '',
			's3region'            => 'us-east-1',
			's3expiry'            => '30',
			's3files'             => '',
			's3titles'            => '',
			'nons3files'          => '',
			'nons3titles'         => '',
			'cfkey'               => '',
			'cfprivatekey'        => '',
			'cfdisturl'           => '',
			'cfexpiry'            => '30',
			'cffiles'             => '',
			'cftitles'            => '',
			'licensekey'          => '',
			'licensestatus'       => 'invalid',
			'poweredbylink'       => 'no',
			'affiliateid'         => '',
			'player'              => 'mediaelementjs',
			'playerwidth'         => '480',
			'playerheight'        => '270',
			'playeraudiowidth'    => '400',
			'playeraudioheight'   => '40',
			'playersize'          => 'responsive',
			'playervolume'        => '0.8',
			'playerautoplay'      => '',
			'playerloop'          => '',
			'playerpreload'       => 'auto',
			'playercontrols'      => true,
			'playersplashimg'     => '',
			'playersplashimageid' => '',
			'playerskin'          => 'default',
			'playercss'           => true,
			'playerprotectsrc'    => 'no',
			'linkanchor'          => esc_html__( 'Download Now', 's3mm' ),
			'linkattributes'      => '',
			'linknewtab'          => 'no',
			'objectversioning'    => false,
			'wpcwrequiremedia'    => false,
			'wpcwcontroltype'     => 'button',
			'wpcwmediapercent'    => '100',
		);
	}

	/**
	 * Save plugin settings.
	 *
	 * @since 3.0.0
	 *
	 * @return bool
	 */
	public function save_settings() {
		if ( $this->settings ) {
			$this->verify_keys();

			$this->sanitize();

			return update_option( $this->settings_key, $this->settings );
		}

		return false;
	}

	/**
	 * Verify S3 Access Keys.
	 *
	 * @since 3.0.0
	 */
	public function verify_keys() {
		if ( ! empty( $this->settings['s3accesskey'] ) && ! empty( $this->settings['s3secretkey'] ) ) {
			$this->settings['keysset'] = true;
		} else {
			$this->settings['keysset'] = false;
		}
	}

	/**
	 * Sanitize Settings.
	 *
	 * @since 1.0.0
	 */
	public function sanitize() {
		// Sanitize Cloudfront Distribution url.
		if ( ! empty ( $this->settings['cfdisturl'] ) ) {
			$this->settings['cfdisturl'] = $this->remove_http( $this->settings['cfdisturl'] );
		}
	}

	/**
	 * Get plugin settings.
	 *
	 * @since 3.0.0
	 *
	 * @return array The settings array.
	 */
	public function get_settings() {
		if ( empty ( $this->settings ) ) {
			$this->load_settings();
		}

		return $this->settings;
	}

	/**
	 * Set plugin settings.
	 *
	 * @since 3.0.0
	 *
	 * @param array $settings The settings array.
	 */
	public function set_settings( $settings ) {
		$this->settings = (array) $settings;
	}

	/**
	 * Get a setting.
	 *
	 * @since 3.0.0
	 *
	 * @param string $setting The setting name.
	 * @param bool   $default The default value if returns empty.
	 *
	 * @return mixed
	 */
	public function get_setting( $setting, $default = false ) {
		if ( ! is_array( $setting ) ) {
			$setting = array( $setting );
		}

		return $this->_get_setting( $setting, $default, $this->settings );
	}

	/**
	 * Get a setting internal.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @param string $setting The setting name.
	 * @param mixed  $default The default value.
	 * @param array  $settings The settings array.
	 *
	 * @return mixed
	 */
	private function _get_setting( $setting, $default, &$settings ) {
		$key = array_shift( $setting );

		if ( ! isset( $settings[ $key ] ) ) {
			return $default;
		}

		if ( ! empty( $setting ) ) {
			return $this->_get_setting( $setting, $default, $settings[ $key ] );
		}

		return $settings[ $key ];
	}

	/**
	 * Set a setting.
	 *
	 * @since 3.0.0
	 *
	 * @param string $setting The setting name.
	 * @param string $value The setting value.
	 */
	public function set_setting( $setting, $value = '' ) {
		if ( ! is_array( $setting ) ) {
			$setting = array( $setting );
		}

		$this->_set_setting( $setting, $value, $this->settings );
	}

	/**
	 * Set a setting internal.
	 *
	 * @since 3.0.0
	 * @access private
	 *
	 * @param string $setting The setting name.
	 * @param mixed  $value The setting value.
	 * @param array  $settings The settings array.
	 *
	 * @return mixed
	 */
	private function _set_setting( $setting, $value, &$settings ) {
		$key = array_shift( $setting );

		if ( ! empty( $setting ) ) {
			if ( ! isset( $settings[ $key ] ) ) {
				$settings[ $key ] = array();
			}

			return $this->_set_setting( $setting, $value, $settings[ $key ] );
		}

		$settings[ $key ] = $value;
	}

	/**
	 * Delete a setting.
	 *
	 * @since 3.0.0
	 *
	 * @param stirng $setting The setting name.
	 */
	public function delete_setting( $setting ) {
		if ( ! is_array( $setting ) ) {
			$setting = array( $setting );
		}

		$this->_delete_setting( $setting, $this->settings );
	}

	/**
	 * Delete a setting internal.
	 *
	 * @since 3.0.0
	 *
	 * @param string $setting The setting name.
	 * @param array  $settings The settings array.
	 *
	 * @return mixed
	 */
	private function _delete_setting( $setting, &$settings ) {
		$key = array_shift( $setting );

		if ( ! empty( $setting ) ) {
			return $this->_delete_setting( $setting, $settings[ $key ] );
		}

		unset( $settings[ $key ] );
	}

	/**
	 * Assets File Helper.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file The file.
	 * @param string $path The file path.
	 *
	 * @return string
	 */
	public function asset_file( $file, $path ) {
		$asset_url = trailingslashit( $this->asset_url . $path ) . $file;

		if ( $this->development ) {
			$mix_file     = "/{$path}/{$file}";
			$mix_manifest = $this->assets_dir . 'mix-manifest.json';

			if ( file_exists( $mix_manifest ) ) {
				$mix_assets = json_decode( file_get_contents( $mix_manifest ), true );

				if ( isset( $mix_assets[ $mix_file ] ) ) {
					$asset_url = untrailingslashit( $this->asset_url ) . $mix_assets[ $mix_file ];
				}
			}
		}

		return esc_url( $asset_url );
	}

	/**
	 * Image File Helper.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file
	 *
	 * @return string
	 */
	public function image( $file = '' ) {
		return ( $file ) ? $this->asset_file( $file, 'images' ) : trailingslashit( $this->asset_url . 'images' );
	}

	/**
	 * Javascript File Helper.
	 *
	 * @since 3.0.0
	 *
	 * @param string $file
	 *
	 * @return string
	 */
	public function js( $file = '' ) {
		return ( $file ) ? $this->asset_file( $file, 'js' ) : trailingslashit( $this->asset_url . 'js' );
	}

	/**
	 * CSS File Helper.
	 *
	 * @param string $file
	 *
	 * @return string
	 */
	public function css( $file = '' ) {
		return ( $file ) ? $this->asset_file( $file, 'css' ) : trailingslashit( $this->asset_url . 'css' );
	}

	/**
	 * Plugin Name.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function plugin_name() {
		return esc_html__( 'S3 Media Maestro', 's3mm' );
	}

	/**
	 * Company Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function company_url() {
		return esc_url( apply_filters( 's3mm_company_url', 'https://flyplugins.com/' ) );
	}

	/**
	 * Member Portal Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function member_portal_url() {
		return esc_url( apply_filters( 's3mm_member_portal_url', 'https://flyplugins.com/member-portal/' ) );
	}

	/**
	 * Member Portal Support Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function member_portal_support_url() {
		return esc_url( apply_filters( 's3mm_member_portal_support_url', 'https://flyplugins.com/member-portal/support/' ) );
	}

	/**
	 * Member Portal License Url.
	 *
	 * @since 3.0.0
	 *
	 * @return string
	 */
	public function member_portal_license_url() {
		return esc_url( apply_filters( 's3mm_member_portal_license_url', 'https://flyplugins.com/member-portal/license-keys/' ) );
	}

	/**
	 * Get Template.
	 *
	 * @since 3.0.0
	 *
	 * @param string $template The template name.
	 *
	 * @return string The template contents.
	 */
	public function get_template( $template ) {
		if ( ! file_exists( $template ) ) {
			$template = $this->templates_dir . $template . '.php';
			if ( ! file_exists( $template ) ) {
				return '';
			}
		}

		ob_start();

		include $template;

		return ob_get_clean();
	}

	/**
	 * Get Media Players.
	 *
	 * @since 3.0.0
	 *
	 * @return array The media players defined.
	 */
	public function get_media_players() {
		return apply_filters( 's3mm_media_players', array(
			'mediaelementjs' => array(
				'name'  => esc_html__( 'MediaElement.js', 's3mm' ),
				'url'   => esc_url_raw( 'http://www.mediaelementjs.com/' ),
				'skins' => array(
					'default' => array( 'label' => esc_html__( 'Default', 's3mm' ), 'default' => true ),
					'ted'     => array( 'label' => esc_html__( 'TED Talks', 's3mm' ), 'default' => false ),
					'wmp'     => array( 'label' => esc_html__( 'Windows Media Player', 's3mm' ), 'default' => false ),
				),
			),
		) );
	}

	/**
	 * Get Aws Regions.
	 *
	 * @since 3.0.0
	 *
	 * @return array The AWS S3 regions.
	 */
	public function get_regions() {
		$regions = array(
			'us-east-2'      => 'US East (Ohio)',
			'us-east-1'      => 'US East (N. Virginia)',
			'us-west-1'      => 'US West (N. California)',
			'us-west-2'      => 'US West (Oregon)',
			'ca-central-1'   => 'Canada (Central)',
			'ap-south-1'     => 'Asia Pacific (Mumbai)',
			'ap-northeast-2' => 'Asia Pacific (Seoul)',
			'ap-southeast-1' => 'Asia Pacific (Singapore)',
			'ap-southeast-2' => 'Asia Pacific (Sydney)',
			'ap-northeast-1' => 'Asia Pacific (Tokyo)',
			'eu-central-1'   => 'EU (Frankfurt)',
			'eu-west-1'      => 'EU (Ireland)',
			'eu-west-2'      => 'EU (London)',
			'sa-east-1'      => 'South America (São Paulo)',
		);

		return apply_filters( 's3mm_aws_regions', $regions );
	}

	/**
	 * Url Force Https.
	 *
	 * @since 3.0.0
	 *
	 * @param string $url The url string.
	 *
	 * @return string The modified url string.
	 */
	public function url_force_https( $url ) {
		$parsed_url = parse_url( $url );

		if ( empty( $parsed_url['scheme'] ) ) {
			$url = sprintf( 'https://%s', $url );
		}

		return set_url_scheme( $url, 'https' );
	}

	/**
	 * Remove HTTP(s) string from urls.
	 *
	 * @param string $url The string of the url.
	 *
	 * @return mixed
	 */
	public function remove_http( $url ) {
		$disallowed = array( 'http://', 'https://' );
		foreach ( $disallowed as $d ) {
			if ( strpos( $url, $d ) === 0 ) {
				return str_replace( $d, '', $url );
			}
		}

		return $url;
	}

	/**
	 * Strip all Whitespace and lince breaks from string.
	 *
	 * @param $string
	 *
	 * @return mixed
	 */
	public function strip( $string ) {
		return preg_replace( '/\s+/S', '', $string );
	}

	/**
	 * Check Selected Admin Pages.
	 *
	 * @since 3.0.2
	 */
	public function check_admin() {
		global $pagenow;

		$allowed_pages = array(
			'options-general.php',
			'plugins.php',
			'plugin-install.php',
			'update-core.php',
			'update.php',
		);

		if ( ! in_array( $pagenow, $allowed_pages ) ) {
			return false;
		}

		if ( $pagenow === 'options-general.php' && Utils::get_var( 'page' ) !== 's3mm' ) {
			return false;
		}

		return true;
	}

	/**
	 * Is WP Courseware Enabled?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if enabled, false otherwise.
	 */
	public function is_wpcw_enabled() {
		return (bool) ( $this->is_wpcw_active() && ( $this->is_wpcw_unit() || $this->is_wpcw_course() ) );
	}

	/**
	 * Is WP Courseware Unit Enabled?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if successful, false otherwise.
	 */
	public function is_wpcw_unit_enabled() {
		return (bool) ( $this->is_wpcw_active() && $this->is_wpcw_unit() );
	}

	/**
	 * Is WP Courseware Course Enabled?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if successful, false otherwise.
	 */
	public function is_wpcw_course_enabled() {
		return (bool) ( $this->is_wpcw_active() && $this->is_wpcw_course() );
	}

	/**
	 * Is WP Courseware Unit?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if is a unit, false otherwise.
	 */
	public function is_wpcw_unit() {
		$is_unit = false;

		if ( is_admin() && 'course_unit' === get_post_type() ) {
			$is_unit = true;
		}

		if ( ! is_admin() && ( is_singular( 'course_unit' ) || is_single( 'course_unit' ) ) ) {
			$is_unit = true;
		}

		return apply_filters( 's3mm_is_wpcw_unit', (bool) $is_unit );
	}

	/**
	 * Is WP Courseware Course?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if is a unit, false otherwise.
	 */
	public function is_wpcw_course() {
		$is_course = false;

		if ( is_admin() && 'wpcw_course' === get_post_type() ) {
			$is_course = true;
		}

		return apply_filters( 's3mm_is_wpcw_course', (bool) $is_course );
	}

	/**
	 * Is WP Courseware Active?
	 *
	 * @since 3.2.0
	 *
	 * @return bool True if enabled, false otherwise.
	 */
	public function is_wpcw_active() {
		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		$is_wpcw_active = ( is_plugin_active( 'wp-courseware/wp-courseware.php' ) && function_exists( 'wpcw' ) );

		return apply_filters( 's3mm_is_wpcw_active', (bool) $is_wpcw_active );
	}

	/**
	 * Is Protection Enabled?
	 *
	 * @since 3.2.3
	 *
	 * @return bool
	 */
	public function is_protection_enabled() {
		return $this->enable_protection;
	}

	/**
	 * Disable cloning.
	 *
	 * @since 3.0.0
	 */
	public function __clone() { _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 's3mm' ), '3.0.0' ); }

	/**
	 * Disable unserializing.
	 *
	 * @since 3.0.0
	 */
	public function __wakeup() { _doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 's3mm' ), '3.0.0' ); }
}
