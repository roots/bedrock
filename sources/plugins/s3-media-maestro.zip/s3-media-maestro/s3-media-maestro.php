<?php
/**
 * Plugin Name: S3 Media Maestro
 * Plugin URI:  https://flyplugins.com/s3-media-maestro/
 * Description: Protect your audio, video, and any file that you store up on Amazon S3.
 * Author:      Fly Plugins
 * Author URI:  https://flyplugins.com
 * Version:     3.2.3
 * License:     GPLv3
 * Text Domain: s3mm
 * Domain Path: languages
 *
 * Copyright (c) 2017 Fly Plugins (email : info@flyplugins.com)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package S3MM
 * @author Fly Plugins <info@flyplugins.com>
 * @version 3.2.3
 */

defined( 'ABSPATH' ) || die;

/** Paths. */
define( 'S3MM_FILE', __FILE__ );
define( 'S3MM_PATH', plugin_dir_path( S3MM_FILE ) );
define( 'S3MM_URL', plugin_dir_url( S3MM_FILE ) );

/** Versions. */
define( 'S3MM_VERSION', '3.2.3' );
define( 'S3MM_DB_VERSION', '3.2.3' );
define( 'S3MM_TWP_VERSION', '5.0.3' );

/** Requirements File. */
require_once S3MM_PATH . 'includes/Requirements.php';

/** Check Requirements. */
if ( S3MM_Requirements::are_met() ) {

	/** Plugin Files. */
	require_once S3MM_PATH . 'includes/Base.php';
	require_once S3MM_PATH . 'includes/Plugin.php';

	/**
	 * Create Main S3MM Instance.
	 *
	 * @since 3.0.0
	 *
	 * @return \S3MM\Plugin The one true instance of S3 Media Maestro.
	 */
	function s3mm() {
		return \S3MM\Plugin::get_object();
	}

	/**
	 * Load S3 Media Maestor.
	 *
	 * @since 3.0.0
	 * @see s3mm()
	 */
	add_action( 'plugins_loaded', 's3mm' );
}
