 ! function($){$( function(){} )}(jQuery);
