=== BSK PDF Manager Pro===
Contributors: bannersky
Plugin URI: http://www.bannersky.com/bsk-pdf-manager-pro/
Tags: PDF,manager,category,widget
Requires at least: 3.2.1
Tested up to: 4.9.8
Stable tag: 2.1

== Description ==

The plugin help you manage your PDF documents in WordPress. You may upload by categories and display by caregories or show one special PDF document.

It is easy to use. You just need copy the shortcodes into the page/post where you want to show. Then it will show the link in your page/post.

Widget is supported now! You may show PDFs list in a widget area.


== Installation ==

Activate the plugin then you can use either a shortcode [bsk-pdfm-pdfs-ul id="1"] to show the link of a special PDF document of id 1 or [bsk-pdf-manager-pdf id="1,2, 3"] to show several PDF documents.

You may use [bsk-pdfm-category-ul id="1"] to show all PDF documents under the category of id 1 or [bsk-pdf-manager-list-category id="1,2,3"] to show all PDFs under categories of id 1, 2, 3.

The plugin has a very easy admin page that allows you to manage categories and PDF documents.

== Frequently Asked Questions ==

Please visit <a href="http://www.bannersky.com/bsk-pdf-manager/">http://www.bannersky.com/bsk-pdf-manager/</a> for documents or support.

== Screenshots ==

1. Admin interface of categories manager
2. Admin interface of PDF documents
3. Admin interface of add PDF document.


== Changelog ==

1.0 First version.

