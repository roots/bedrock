<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class BSKPDFMPro_Common_Data_Source {
    
    
    public static function bsk_pdfm_get_pdfs( $args ){
        global $wpdb;
        
        $where_case_array = array();
        $prepare_values_array = array();
        
        //date of
        $year_of = $args['year_of'];
        $month_of = $args['month_of'];
        $day_of = $args['day_of'];
        $weekday_of = $args['weekday_of'];
        
        //process id
        if( $args['show_all_pdfs'] ) {
            $where_case_array[] = 'WHERE 1 ';
        }else{
            $ids_array = $args['ids_array'];
            $where_case_array[] = 'WHERE `id` IN('.implode(',', $ids_array).')';
            
            //process only support show_all_pdfs
            $year_of = false;
            $month_of = false;
            $day_of = false;
            $weekday_of = false;
        }
        
        if( isset($args['exclude_ids_array']) && is_array( $args['exclude_ids_array'] ) && count( $args['exclude_ids_array'] ) > 0 ){
            $where_case_array[] = 'AND `id` NOT IN('.implode(',', $args['exclude_ids_array']).')';
        }

        //publish & exired
        $where_case_array[] = 'AND (`publish_date` IS NULL OR `publish_date` <= "'.date('Y-m-d 00:00:00', current_time( 'timestamp' ) ).'") ';
        $where_case_array[] = 'AND (`expiry_date` IS NULL OR `expiry_date` > "'.date('Y-m-d 23:59:59', current_time( 'timestamp' ) ).'") ';
        
        if( $year_of !== false || $month_of != false || $day_of !== false ){
            if( $year_of == '9999' || $month_of == '99' || $day_of == '99' ){
                $sql = 'SELECT `last_date` FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` '.
                         'WHERE 1 '.
                         'AND (`publish_date` IS NULL OR `publish_date` <= "'.date('Y-m-d 00:00:00', current_time( 'timestamp' ) ).'") '.
                         'AND (`expiry_date` IS NULL OR `expiry_date` > "'.date('Y-m-d 23:59:59', current_time( 'timestamp' ) ).'") '.
                         'ORDER BY `last_date` DESC '.
                         'LIMIT 0, 1';
                $most_recent_date = $wpdb->get_var( $sql );
                $year_of = $year_of == '9999' ? substr( $most_recent_date, 0, 4 ) : $year_of;
                $month_of = $month_of == '99' ? substr( $most_recent_date, 5, 2 ) : $month_of;
                $day_of = $day_of == '99' ? substr( $most_recent_date, 8, 2 ) : $day_of;
            }
            
            if( is_array( $year_of ) && count( $year_of ) == 2 ){
                $year_from = $year_of['from'];
                $date_like_from_value = $year_from.'-';
                $date_like_from_value .= $month_of == false ? '01-' : $month_of.'-';
                $date_like_from_value .= $day_of == false ? '01 00:00:00' : $day_of.' 00:00:00';
                
                $year_to = $year_of['to'];
                $date_like_to_value = $year_to.'-';
                $date_like_to_value .= $month_of == false ? '12-' : $month_of.'-';
                $date_like_to_value .= $day_of == false ? '31 23:59:59' : $day_of.' 00:00:00';

                $where_case_array[] = 'AND `last_date` >= %s ';
                $where_case_array[] = 'AND `last_date` <= %s ';
                $prepare_values_array[] = $date_like_from_value;
                $prepare_values_array[] = $date_like_to_value;
            }else{
                $date_like_value = $year_of == false ? '%-' : $year_of.'-';
                $date_like_value .= $month_of == false ? '%-' : $month_of.'-';
                $date_like_value .= $day_of == false ? '%' : $day_of.'%';

                $where_case_array[] = 'AND `last_date` LIKE %s ';
                $prepare_values_array[] = $date_like_value;
            }
        }
        
        if( $weekday_of !== false ){
            $where_case_array[] = 'AND WEEKDAY(`last_date`) = %d ';
            $prepare_values_array[] = $weekday_of;
        }
        
        $keywords = isset( $args['keywords'] ) && trim( $args['keywords'] ) ? trim( $args['keywords'] ) : false;
        if( $keywords ){
            $where_case_array[] = 'AND ( `title` LIKE %s OR `file_name` LIKE %s OR `description` LIKE %s )';
            $prepare_values_array[] = '%'.$keywords.'%';
            $prepare_values_array[] = '%'.$keywords.'%';
            $prepare_values_array[] = '%'.$keywords.'%';
        }
        
        $most_top = isset( $args['most_top'] ) ? absint($args['most_top']) : false;
        $limit_case = '';
        $total_results_count = 0;
        $total_pages = 0;
        if( $most_top > 0 ){
            $limit_case = ' LIMIT 0, '.$most_top;
        }else if( isset($args['pagination']) && $args['pagination'] ){
            $pdfs_per_page = $args['pdfs_per_page'];
            $paged = $args['paged'];
            $page_sql = 'SELECT COUNT(*) FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` '.
                              implode( ' ', $where_case_array );
            $page_sql = $wpdb->prepare( $page_sql, $prepare_values_array );
            $total_results_count = $wpdb->get_var( $page_sql );
            if( $paged ){
                $total_pages = ceil( $total_results_count / $pdfs_per_page );
                $paged = $paged > $total_pages ? $total_pages : $paged;
                $paged_start = ( $paged - 1 ) * $pdfs_per_page;
                $limit_case = ' LIMIT '.$paged_start.', '.$pdfs_per_page;
            }else if( $total_results_count > $pdfs_per_page ){
                $limit_case = ' LIMIT 0, '.$pdfs_per_page;
            }
        }
        
        //process order by case
		$order_by_str = ' ORDER BY `title`'; //default set to title
		$order_str = ' ASC';
		if( $args['order_by'] == 'title' ){
			//default
		}else if( $args['order_by'] == 'date' ){
			$order_by_str = ' ORDER BY `last_date`';
		}else if( $args['order_by'] == 'custom' ){
			$order_by_str = ' ORDER BY `order_num`';
		}else if( $args['order_by'] == 'id' ){
			$order_by_str = ' ORDER BY `id`';
		}
        
		if( strtoupper(trim($args['order'])) == 'DESC' ){
			$order_str = ' DESC';
		}
        $order_case = $order_by_str.$order_str;
        
        if( $args['order_by'] == "" && $args['ids_array'] && is_array( $args['ids_array'] ) && count( $args['ids_array'] ) > 0 ){
            $order_case = ' ORDER BY FIELD(`id`, '.implode(',', $args['ids_array']).')';
        }
        
        
        $sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` '.
                 implode( ' ', $where_case_array ).
                 $order_case.
                 $limit_case;
        $sql = $wpdb->prepare( $sql, $prepare_values_array );
        $results = $wpdb->get_results( $sql );
        if( !$results || !is_array( $results ) || count( $results ) < 1 ){
            return false;
        }

        $pdf_id_as_key_array = array();
        foreach( $results as $obj ){
            $pdf_id_as_key_array[$obj->id] = $obj;
        }
        
        //sort pdfs by id sequence order
        if( $args['ids_array'] && is_array( $args['ids_array'] ) && $args['order_by'] == "" ){
            $pdfs_results_array = array();
            foreach( $args['ids_array'] as $pdf_id ){
                if( !isset($pdf_id_as_key_array[$pdf_id]) ){
                    continue;
                }
                $pdfs_results_array[$pdf_id] = $pdf_id_as_key_array[$pdf_id];
            }
            return array( 'pdfs' => $pdfs_results_array, 'pages' => 0, 'total' => 0 );
        }
        
        return array( 'pdfs' => $pdf_id_as_key_array, 'pages' => $total_pages, 'total' => $total_results_count );
    }
    
    public static function bsk_pdfm_get_pdfs_by_cat( $args ){
        global $wpdb;
        
        $pdfs_tbl = $wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name;
        $cats_tbl = $wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name;
        $rels_tbl = $wpdb->prefix.BSKPDFManagerPro::$_rels_tbl_name;
        
        $where_case_array = array();
        $prepare_values_array = array();
        
        //date of
        $year_of = $args['year_of'];
        $month_of = $args['month_of'];
        $day_of = $args['day_of'];
        $weekday_of = $args['weekday_of'];

        //process category id
        $ids_array = $args['ids_array'];
        if( !$ids_array || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            return false;
        }
        
        $where_case_array[] = 'WHERE C.`id` IN('.trim(str_repeat( '%d,', count( $ids_array ) ), ',').')';
        foreach( $ids_array as $cat_id_to_query ){
            $prepare_values_array[] = $cat_id_to_query;
        } 

        //process PDF exclude id
        $exclude_ids_array = $args['exclude_ids_array'];
        if( $exclude_ids_array && is_array( $exclude_ids_array ) && count( $exclude_ids_array ) > 0 ){
            $where_case_array[] = 'AND P.`id` NOT IN('.trim(str_repeat( '%d,', count( $exclude_ids_array ) ), ',').')';
            foreach( $exclude_ids_array as $pdf_id_to_exclude ){
                $prepare_values_array[] = $pdf_id_to_exclude;
            }
        }
        
        //publish & exired
        $where_case_array[] = 'AND (P.`publish_date` IS NULL OR P.`publish_date` <= "'.date('Y-m-d 00:00:00', current_time( 'timestamp' ) ).'") ';
        $where_case_array[] = 'AND (P.`expiry_date` IS NULL OR P.`expiry_date` > "'.date('Y-m-d 23:59:59', current_time( 'timestamp' ) ).'") ';
        
        if( $year_of !== false || $month_of != false || $day_of !== false ){
            if( $year_of == '9999' || $month_of == '99' || $day_of == '99' ){
                $sql = 'SELECT P.`last_date` FROM `'.
                         $rels_tbl.'` AS R LEFT JOIN `'.$pdfs_tbl.'` AS P ON R.`pdf_id` = P.`id` LEFT JOIN `'.$cats_tbl.'` AS C ON R.`cat_id` = C.`id`'.
                         implode( ' ', $where_case_array ). //here where case only have ( where 1 or categories id ) and ( publish , expiry )
                         'ORDER BY P.`last_date` DESC '.
                         'LIMIT 0, 1';
                $most_recent_date = $wpdb->get_var( $sql );
                $year_of = $year_of == '9999' ? substr( $most_recent_date, 0, 4 ) : $year_of;
                $month_of = $month_of == '99' ? substr( $most_recent_date, 5, 2 ) : $month_of;
                $day_of = $day_of == '99' ? substr( $most_recent_date, 8, 2 ) : $day_of;
            }
            if( is_array( $year_of ) && count( $year_of ) == 2 ){
                $year_from = $year_of['from'];
                $date_like_from_value = $year_from.'-';
                $date_like_from_value .= $month_of == false ? '01-' : $month_of.'-';
                $date_like_from_value .= $day_of == false ? '01 00:00:00' : $day_of.' 00:00:00';
                
                $year_to = $year_of['to'];
                $date_like_to_value = $year_to.'-';
                $date_like_to_value .= $month_of == false ? '12-' : $month_of.'-';
                $date_like_to_value .= $day_of == false ? '31 23:59:59' : $day_of.' 00:00:00';

                $where_case_array[] = 'AND P.`last_date` >= %s ';
                $where_case_array[] = 'AND P.`last_date` <= %s ';
                $prepare_values_array[] = $date_like_from_value;
                $prepare_values_array[] = $date_like_to_value;
            }else{
                $date_like_value = $year_of == false ? '%-' : $year_of.'-';
                $date_like_value .= $month_of == false ? '%-' : $month_of.'-';
                $date_like_value .= $day_of == false ? '%' : $day_of.'%';

                $where_case_array[] = 'AND P.`last_date` LIKE %s ';
                $prepare_values_array[] = $date_like_value;
            }
        }
        
        if( $weekday_of !== false ){
            $where_case_array[] = 'AND WEEKDAY(P.`last_date`) = %d ';
            $prepare_values_array[] = $weekday_of;
        }
        
        $keywords = isset( $args['keywords'] ) && trim( $args['keywords'] ) ? trim( $args['keywords'] ) : false;
        if( $keywords ){
            $where_case_array[] = 'AND ( P.`title` LIKE %s OR P.`file_name` LIKE %s OR P.`description` LIKE %s )';
            $prepare_values_array[] = '%'.$keywords.'%';
            $prepare_values_array[] = '%'.$keywords.'%';
            $prepare_values_array[] = '%'.$keywords.'%';
        }
        
        $most_top = isset( $args['most_top'] ) ? intval($args['most_top']) : false;
        $limit_case = '';
        $total_results_count = 0;
        $total_pages = 0;
        if( $most_top > 0 ){
            $limit_case = ' LIMIT 0, '.$most_top;
        }else if( isset($args['pagination']) && $args['pagination'] ){
            $pdfs_per_page = $args['pdfs_per_page'];
            $paged = $args['paged'];
            $page_sql = 'SELECT COUNT(*) FROM `'.
                              $rels_tbl.'` AS R LEFT JOIN `'.$pdfs_tbl.'` AS P ON R.`pdf_id` = P.`id` LEFT JOIN `'.$cats_tbl.'` AS C ON R.`cat_id` = C.`id`'.
                              implode( ' ', $where_case_array );
            $page_sql = $wpdb->prepare( $page_sql, $prepare_values_array );
            $total_results_count = $wpdb->get_var( $page_sql );
            if( $total_results_count > 0 ){
                if( $paged ){
                    $total_pages = ceil( $total_results_count / $pdfs_per_page );
                    $paged = $paged > $total_pages ? $total_pages : $paged;
                    $paged_start = ( $paged - 1 ) * $pdfs_per_page;
                    $limit_case = ' LIMIT '.$paged_start.', '.$pdfs_per_page;
                }else if( $total_results_count > $pdfs_per_page ){
                    $limit_case = ' LIMIT 0, '.$pdfs_per_page;
                }
            }
        }
        
        //process order by case
        $cat_order_by_str = ' FIELD( C.`id`, '.implode(',', $ids_array).' )';
		$pdf_order_by_str = ' P.`title`'; //default set to title
        $pdf_order_str = ' ASC';
        if( $args['order_by'] == 'last_date' || $args['order_by'] == 'date' ){
			$pdf_order_by_str = ' P.`last_date`';
		}else if( $args['order_by'] == 'custom' ){
			$pdf_order_by_str = ' P.`order_num`';
		}else if( $args['order_by'] == 'id' ){
			$pdf_order_by_str = ' P.`id`';
		}
		if( strtoupper(trim($args['order'])) == 'DESC' ){
			$pdf_order_str = ' DESC';
		}
        $order_case = ' ORDER BY '.$cat_order_by_str.','.$pdf_order_by_str.$pdf_order_str;
        
        $sql = 'SELECT P.`id`, P.`title`, P.`file_name`, P.`description`, P.`last_date`, P.`thumbnail_id`, P.`by_media_uploader`,  P.`download_count`, '.
                 'C.`id` AS `cat_id`, C.`title` AS `cat_title`, C.`parent` AS `cat_parent`, '.
                 'C.`description` AS `cat_desc`, C.`empty_message` as `cat_empty_msg` FROM `'.
                 $rels_tbl.'` AS R LEFT JOIN `'.$pdfs_tbl.'` AS P ON R.`pdf_id` = P.`id` LEFT JOIN `'.$cats_tbl.'` AS C ON R.`cat_id` = C.`id`'.
                 implode( ' ', $where_case_array ).
                 $order_case.
                 $limit_case;
        $sql = $wpdb->prepare( $sql, $prepare_values_array );
        $results = $wpdb->get_results( $sql );
        if( !$results || !is_array( $results ) || count( $results ) < 1 ){
            return false;
        }
        
        $pdf_by_category_array = array();
        $categories_for_pdfs = array();
        foreach( $results as $obj ){
            if( !isset( $pdf_by_category_array[$obj->cat_id] ) ){
                $pdf_by_category_array[$obj->cat_id] = array();
            }
            $pdf_by_category_array[$obj->cat_id][$obj->id] = $obj;
            $categories_for_pdfs[$obj->cat_id] = $obj->cat_id;
         }

        return array( 
                            'pdfs' => $pdf_by_category_array, 
                            'pages' => $total_pages, 
                            'total' => $total_results_count, 
                            'categories_for_pdfs' => $categories_for_pdfs 
                         );
    }
    
    public static function bsk_pdfm_get_sub_cat( $parent_id, $cat_order_by, $cat_order ){
        global $wpdb;
        
        $cats_tbl = $wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name;
        $rels_tbl = $wpdb->prefix.BSKPDFManagerPro::$_rels_tbl_name;
        
        //process order by case
        $cat_order_by_str = ' C.`title`';
		$cat_order_str = ' ASC';
		if( $cat_order_by == 'date' ){
			$cat_order_by_str = ' C.`last_date`';
		}
		if( trim($cat_order) == 'DESC' ){
			$cat_order_str = ' DESC';
		}
        
        $sql = 'SELECT * FROM `'.$cats_tbl.'` AS C '.
                 'WHERE C.`parent` = %d '.
                 'ORDER BY '.$cat_order_by_str.$cat_order_str;
        $sql = $wpdb->prepare( $sql, $parent_id );
        $results = $wpdb->get_results( $sql );
        if( !$results || !is_array( $results ) || count( $results ) < 1 ){
            return false;
        }
        $array_to_return = array();
        foreach( $results as $cat_obj ){
            $array_to_return[$cat_obj->id] = $cat_obj;
        }
        
        return $array_to_return;
    }
    
    public static function bsk_pdfm_get_cat_obj( $cat_id ){
        global $wpdb;
        
        $cats_tbl = $wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name;
        $sql = 'SELECT * FROM `'.$cats_tbl.'` AS C '.
                 'WHERE C.`id` = %d ';
        $sql = $wpdb->prepare( $sql, $cat_id );
        $results = $wpdb->get_results( $sql );
        if( !$results || !is_array( $results ) || count( $results ) < 1 ){
            return false;
        }
        
        return $results[0];
    }
    
    public static function bsk_pdfm_organise_categories_id_sequence(  
                                                                                                    $id_string, 
                                                                                                    $hierarchical, 
                                                                                                    $exclude_cat_ids, 
                                                                                                    $cat_order_by_str, 
                                                                                                    $cat_order_str 
                                                                                                  ){
        global $wpdb;
        
        if( trim($id_string) == "" ){
            return false;
        }
        
        $exclude_cat_ids_array = false;
        if( trim($exclude_cat_ids) ){
            $temp_array = explode(',', $exclude_cat_ids);
            if( is_array($temp_array) && count($temp_array) > 0 ){
                foreach( $temp_array as $key => $val ){
                    if( $val < 1 ){
                        continue;
                    }
                    $exclude_cat_ids_array[] = absint( $val );  
                }
            }
        }
        
        $ids_array = array();
        $categories_loop_array = array();
        
        $temp_valid_array = array();
        $sql_base = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name.'` AS C '.
                         'WHERE 1 ';
        if( is_array($exclude_cat_ids_array) && count($exclude_cat_ids_array) > 0 ){
            $sql_base .= ' AND C.`id` NOT IN('.implode(',', $exclude_cat_ids_array).')';
        }
        $sql = '';
		if( strtoupper($id_string) == 'ALL' ){
            $sql = $sql_base.
                      ' ORDER BY '.$cat_order_by_str.$cat_order_str;
		}else{
			$temp_array = explode(',', $id_string);
            $temp_valid_array = array();
            foreach($temp_array as $key => $cat_id){
                $cat_id = absint(trim($cat_id));
                if( $exclude_cat_ids_array && is_array( $exclude_cat_ids_array ) && count( $exclude_cat_ids_array ) > 0 ){
                    if( in_array( $cat_id, $exclude_cat_ids_array ) ){
                        continue;
                    }
                }
                $temp_valid_array[] = $cat_id;
            }
            
            if( !is_array($temp_valid_array) || count($temp_valid_array) < 1 ){
				return false;
			}
			$sql = $sql_base.
                     ' AND C.`id` IN('.implode(',', $temp_valid_array).') '.
                     ' ORDER BY '.$cat_order_by_str.$cat_order_str;
		}

        //query
        $categories_results = $wpdb->get_results( $sql );
        if( !$categories_results || !is_array( $categories_results) || count( $categories_results ) < 1 ){
            return false;
        }
        if( $hierarchical == false ){
            foreach( $categories_results as $cat_obj ){
                $ids_array[] = $cat_obj->id;
                $categories_loop_array[$cat_obj->id] = $cat_obj;
            }
            return array( 'ids_array' => $ids_array, 'categories_loop' => $categories_loop_array );
        }
        
        /*
          * with Hierarchial
          *
          * if a category's parent exist in all categories then skip temporarily as it would be queried out again from its parent
          *
          * if a category exist in the destination array then it must be child or grand
          */
        $all_categories_id = array();
        foreach( $categories_results as $cat_obj ){
            $all_categories_id[] = $cat_obj->id;
        }
        
        foreach( $categories_results as $cat_obj ){
            if( in_array( $cat_obj->id, $ids_array ) || 
                ( $cat_obj->parent && in_array( $cat_obj->parent, $all_categories_id ) ) ){
                continue;
            }
            $ids_array[] = $cat_obj->id;
            $categories_loop_array[$cat_obj->id] = $cat_obj;
            //child categories
            $sql = $sql_base.
                      ' AND C.`parent` = '.$cat_obj->id.
                      ' ORDER BY '.$cat_order_by_str.$cat_order_str;
            $child_results = $wpdb->get_results( $sql );
            if( $child_results && is_array( $child_results ) && count( $child_results ) > 0 ){
                foreach( $child_results as $child_cat_obj ){
                    $ids_array[] = $child_cat_obj->id;
                    //grand categories
                    $sql = $sql_base.
                              ' AND C.`parent` = '.$child_cat_obj->id.
                              ' ORDER BY '.$cat_order_by_str.$cat_order_str;
                    $grand_results = $wpdb->get_results( $sql );
                    if( $grand_results && is_array( $grand_results ) && count( $grand_results ) > 0 ){
                        foreach( $grand_results as $grand_cat_obj ){
                            $ids_array[] = $grand_cat_obj->id;
                        }
                    }
                }
            }
        }
        //print_r( $ids_array );exit;
        return array( 'ids_array' => $ids_array, 'categories_loop' => $categories_loop_array );
    }
}//end of class
