<?php 

class BSKPDFMPro_Dashboard_Updater {

    function __construct() {

        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'pre_set_site_transient_update_plugins_filter' ) );
		add_filter( 'plugins_api', array( $this, 'plugins_api_filter' ), 10, 3);
		add_filter( 'http_request_args', array( $this, 'http_request_args' ), 10, 2 );
	}
	
	function pre_set_site_transient_update_plugins_filter( $_transient_data ) {

		if( empty( $_transient_data ) ) return $_transient_data;
		
		$license = get_option( BSKPDFMPro_Dashboard::$_plugin_license, '' );
		if( !$license ){
			return;
		}
		
		$latest_info = $this->bsk_pdfm_remote_get_latest_info( $license );
		if( false !== $latest_info && is_object( $latest_info ) && isset( $latest_info->new_version ) ) {
			if( version_compare( BSKPDFManagerPro::$_PLUGIN_VERSION_, $latest_info->new_version, '<' ) ) {
				$_transient_data->response[BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_folder.'/'.BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_main_file] = $latest_info;
			}
		}

		return $_transient_data;
	}
	
	function plugins_api_filter( $_data, $_action = '', $_args = null ) {
		if( $_action != 'plugin_information' || 
			!isset( $_args->slug ) || 
			$_args->slug != BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_slug ){
			
			return $_data;
		}
		
		$license = get_option( BSKPDFMPro_Dashboard::$_plugin_license, '' );
		if( !$license ){
			return $_data;
		}

		$latest_info = $this->bsk_pdfm_remote_get_latest_info( $license );
		if( false !== $latest_info ){
			$_data = $latest_info;
		}

		return $_data;
	}

	function http_request_args( $args, $url ) {
		// If it is an https request and we are performing a package download, disable ssl verification
		if( strpos( $url, 'https://' ) !== false && strpos( $url, 'bskddaction=package_download' ) ) {
			$args['sslverify'] = false;
		}
		return $args;
	}

	function bsk_pdfm_remote_get_latest_info( $license ) {
		if( trim($license) == "" ){
			return false;
		}
		
		$api_params = array( 
			'bskddaction' 	=> 'get_latest_info',
			'license' 		=> $license,
			'slug'			=> BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_slug,
			'author'		=> BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_author,
			'product_id' 	=> BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_product_id
		);

		$request = wp_remote_get( 
                                                add_query_arg( $api_params, BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_home_url ), 
                                                array( 'timeout' => 15, 'ssverify' => false ) 
                                              );
		if ( is_wp_error( $request ) ){
			return false;
		}
		
		$data = json_decode( wp_remote_retrieve_body( $request ) );
		if( $data ){
			$data->sections = maybe_unserialize( $data->sections );
		}

		return $data;
	}
}