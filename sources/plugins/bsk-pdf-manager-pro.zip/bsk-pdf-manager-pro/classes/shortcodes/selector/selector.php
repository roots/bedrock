<?php

class BSKPDFMPro_Shortcodes_Selector {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    public $_selector_OBJ_dropdown = NULL;
    public $_selector_OBJ_ul_ol = NULL;
    public $_selector_OBJ_columns = NULL;
    
	public function __construct() {
        require_once( 'selector-dropdown.php' );
        require_once( 'selector-ul-ol.php' );
        require_once( 'selector-columns.php' );
        
        $this->_selector_OBJ_dropdown = new BSKPDFMPro_Shortcodes_Selector_Dropdown();
        $this->_selector_OBJ_ul_ol = new BSKPDFMPro_Shortcodes_Selector_UL_OL();
        $this->_selector_OBJ_columns = new BSKPDFMPro_Shortcodes_Selector_Columns();
	}
}