<?php

class BSKPDFMPro_Shortcodes_Selector_Columns {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    private static $_current_category_depth = 1;
    
	public function __construct() {
        add_shortcode('bsk-pdfm-selector-columns', array($this, 'bsk_pdf_manager_list_pdfs_by_cat_as_columns') );
        
        add_action( 'wp_ajax_pdfs_get_selector_columns', array( $this, 'bsk_pdfm_ajax_selector_get_pdfs_columns' ) );
		add_action( 'wp_ajax_nopriv_pdfs_get_selector_columns', array( $this, 'bsk_pdfm_ajax_selector_get_pdfs_columns' ) );
	}
	
    function bsk_pdf_manager_list_pdfs_by_cat_as_columns( $atts, $content ){
		global $wpdb;
		
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
		
		//read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
        $enable_multi_column_layout = false;
        $default_column_number = 2;
		$default_column_layout_title_positon = 'below';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}

            if( isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
            
            if( isset($plugin_settings['multi_column_layout']) ){
				$enable_multi_column_layout = $plugin_settings['multi_column_layout'];
			}
			
			if( isset($plugin_settings['default_column_number']) ){
				$default_column_number = $plugin_settings['default_column_number'];
			}
			
			if( isset($plugin_settings['column_layout_title_positon']) ){
				$default_column_layout_title_positon = $plugin_settings['column_layout_title_positon'];
			}
		}
		
		$shortcode_atts = shortcode_atts( 
                                            array(  
                                                       'cat_id' => '',
                                                       'default_cat_id' => '',
                                                       'exclude_cat_id' => '',
                                                       'password_required' => 'no',
                                                       'hierarchical' => 'no',
                                                       'cat_order_by' => '',
                                                       'cat_order' => '',
                                                       'show_cat_title' => '',
                                                       'show_cat_description' => 'no',
                                                       'hide_empty_cat' => 'no',
                                                       'show_cat_empty_message' => 'no',
                                                       'selector_option_none' => 'Select category to browse...',
                                                       'exclude_pdf_id' => '',
                                                       'order_by' => '',
                                                       'order' => '', 
                                                       'target' => '',
                                                       'most_top' => 0,
                                                       'year_of' => '0000', //work when 'id'="all", 9999 means most recent, length = 4
                                                       'month_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                       'day_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                       'weekday_of' => 'no', //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                                       'search_bar' => 'no',  //work when 'id'="all" and 'most_recent_date' = 'no'
                                                       'search_bar_year_range' => '',
                                                       'search_bar_year_order' => '',
                                                       'show_description' => '',
                                                       'featured_image' => '',
                                                       'featured_image_size' => '',
                                                       'show_pdf_title' => '',
                                                       'title_position' => 'below',
                                                       'nofollow_tag' => 'no',
                                                       'show_date' => 'no',
                                                       'date_format' => ' d/m/Y',
                                                       'date_before_title' => 'no',
                                                       'date_weekday_filter' => '',
                                                       'date_weekday_filter_order' => '',
                                                       'date_weekday_filter_right' => 'no',
                                                       'pdfs_per_page' => 0,
                                                       'columns' => 1,
                                                       'output_container_class' => '' 
                                                    ),
                                                $atts 
                                            );
		
        /**
          * process categories attributes
          */
        //proccess columns
        $columns = absint( $shortcode_atts['columns'] );
        //password protect
        $password_required = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('password_required', $shortcode_atts);
		//show category title or not
		$show_cat_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_title', $shortcode_atts);
        //show category description or not
		$show_cat_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_description', $shortcode_atts);
        //show category with hierarchical
		$show_cat_hierarchical = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hierarchical', $shortcode_atts);
        //hide empty
        $hide_empty_cat = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hide_empty_cat', $shortcode_atts);
		//show empty message
		$show_cat_empty_message = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_empty_message', $shortcode_atts);
        //selector option none
        $selector_option_none = trim( $shortcode_atts['selector_option_none'] );
        $selector_option_none = $selector_option_none ? $selector_option_none : 'Select category to browse...';
        
        //process order by case
        $cat_order_by_str = ' C.`title`';
		$cat_order_str = ' ASC';
		if( $shortcode_atts['cat_order_by'] == 'date' ){
			$cat_order_by_str = ' C.`last_date`';
		}
		if( trim($shortcode_atts['cat_order']) == 'DESC' ){
			$cat_order_str = ' DESC';
        }
        
        //exclude category ids
        $exclude_cat_ids_array = null;
        if( trim($shortcode_atts['exclude_cat_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_cat_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $cat_id ){
                    $exclude_cat_ids_array[] = absint( trim($cat_id) );
                }
            }
        }
        
        global $wpdb;
        
        $ids_array = false;
		$categories_loop_array = false;
        $exclude_cat_ids_array_str = $exclude_cat_ids_array && is_array( $exclude_cat_ids_array ) ? implode(',', $exclude_cat_ids_array) : '';
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts['cat_id'], 
                                                                                                $show_cat_hierarchical, 
                                                                                                $exclude_cat_ids_array_str, 
                                                                                                $cat_order_by_str, 
                                                                                                $cat_order_str );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }
        if( $ids_array == false || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $str = '<div class="bsk-pdfm-output-container'.' '.$shortcode_atts['output_container_class'].'">'.
                            '<p>No valid category id found</p>'.
                     '</div>';
            return $str;
        }
        
        /**
          * Process PDFs attributes
        */
		//show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//process open target
		$open_target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$open_target_str = ' target="_blank"';
		}
        
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );

        //featured image
		$featured_image = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('featured_image', $shortcode_atts);
		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$featured_image = false;
		}
		//show pdf title with featured imaged
		$show_pdf_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_pdf_title', $shortcode_atts);
        //pdf title postion
        $pdf_title_position = 'above';
        if( strtoupper($shortcode_atts['title_position']) == 'BELOW' ){
            $pdf_title_position = 'below';
        }
        //featurec image size
		$featured_image_size = $default_thumbnail_size;
        if( trim($shortcode_atts['featured_image_size']) ){
            $featured_image_size = trim($shortcode_atts['featured_image_size']);
        }
        $image_position = 'left';

        //anchor nofollow tag
		$nofollow_tag = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('nofollow_tag', $shortcode_atts);
        if( $nofollow_tag ){
            $nofollow_tag = ' rel="nofollow"';
        }
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}
        
        //process pagination
        $pdfs_per_page = intval( $shortcode_atts['pdfs_per_page'] );
        $pagination = $pdfs_per_page > 0 ? true : false;
        if( $most_top > 0 ){
            //disble pagination for some special situations
            $pagination = false;
        }
        
        $search_bar = strtoupper( $shortcode_atts['search_bar'] );
        if( $search_bar != 'YES' && 
            $search_bar != 'KEYWORDS' && 
            $search_bar != 'YEAR_KEYWORDS' &&
            $search_bar != 'CATEGORY_YEAR_KEYWORDS' ){
            
            $search_bar = false;
        }
        $search_bar = $search_bar == 'YES' ? 'KEYWORDS' : $search_bar;
        $search_bar = $search_bar == 'CATEGORY_YEAR_KEYWORDS' ? 'YEAR_KEYWORDS' : $search_bar;
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        //exclude pdf ids
        $exclude_pdf_ids_array = null;
        if( trim($shortcode_atts['exclude_pdf_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_pdf_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_pdf_ids_array[] = absint( trim($pdf_id) );
                }
            }
        }
        
        //columns
		$columns = absint($shortcode_atts['columns']);
		if( $columns < 1 || $columns > 6 ){
			$columns = $default_column_number;
		}

        $shortcode_atts['columns'] = $columns;
        
        $default_cat_id = absint( $shortcode_atts['default_cat_id'] );
        $default_cat_obj = null;
        $cat_pdfs_query_results = null;
        if( $default_cat_id ){
            $default_cat_obj = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_cat_obj( $default_cat_id );
            if( $default_cat_obj ){
                //query pdfs
                /**
                  * Query PDFs for category
                */
                $query_args = array();
                $query_args['year_of'] = $year_of;
                $query_args['month_of'] = $month_of;
                $query_args['day_of'] = $day_of;
                $query_args['weekday_of'] = $weekday_of;
                $query_args['pagination'] = $pagination;
                $query_args['pdfs_per_page'] = $pdfs_per_page;
                $query_args['paged'] = 1;
                $query_args['cat_order_by'] = $shortcode_atts['cat_order_by'];
                $query_args['cat_order'] = $shortcode_atts['cat_order'];
                $query_args['order_by'] = $shortcode_atts['order_by'];
                $query_args['order'] = $shortcode_atts['order'];
                $query_args['most_top'] = $most_top;
                $query_args['ids_array'] = array( $default_cat_id );
                $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;
                
                $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );
            }else{
                $default_cat_id = 0;
            }
        }
        
        $output_container_class = $shortcode_atts['output_container_class'] ? ' '.$shortcode_atts['output_container_class'] : '';
        $output_container_start = '<div class="bsk-pdfm-output-container shortcode-selector layout-columns'.$output_container_class.'">';
        $category_selector = BSKPDFMPro_Common_Display::get_category_selector( 
                                                                                                       $categories_loop_array,
                                                                                                       $ids_array, 
                                                                                                       $default_cat_id,
                                                                                                       $show_cat_hierarchical,
                                                                                                       $cat_order_by_str, 
                                                                                                       $cat_order_str,
                                                                                                       $selector_option_none,
                                                                                                       $hide_empty_cat
                                                                                                      );

        $category_output_str = '';
        $date_weekday_filter_str = '';
        $pagination_str = '';
        $search_bar_str = '';
        $cat_description_str = '';
        
        $categories_ask_for_password = array();
        $categories_output_done = array();
        if( $default_cat_obj && $cat_pdfs_query_results ){
            $pdfs_results_array_by_category = $cat_pdfs_query_results['pdfs'];
            $total_pages = $cat_pdfs_query_results['pages'];
            $total_pdfs = $cat_pdfs_query_results['total'];
            $categories_for_pdfs_results = $cat_pdfs_query_results['categories_for_pdfs'];
            
            if( $show_cat_description ){
                $cat_description_str = '<div class="bsk-pdfm-category-description">'.$default_cat_obj->description.'</div>';
            }
            
            if( $pdfs_results_array_by_category == false || 
                !is_array( $pdfs_results_array_by_category ) || 
                count( $pdfs_results_array_by_category ) < 1 ){
                
                //no pdfs, only show empty message
                $category_output_array = $this->show_category_pdfs_in_columns(
                                                                                                        $columns,
                                                                                                        $current_category_depth,
                                                                                                        $hide_empty_cat,
                                                                                                        $show_cat_empty_message,
                                                                                                        $password_required,
                                                                                                        null,
                                                                                                        $default_cat_obj, 
                                                                                                        null,
                                                                                                        $show_description,
                                                                                                        $featured_image, $featured_image_size, 
                                                                                                        $show_pdf_title, $pdf_title_position,
                                                                                                        $default_thumbnail_html, $image_position,
                                                                                                        $open_target_str, $nofollow_tag, 
                                                                                                        $show_date, $date_format_str, $date_before_title
                                                                                                       );
                $category_output_str = $category_output_array['category_output_str'];
                if( $category_output_array['ask_password'] ){
                    $categories_ask_for_password[] = $category_output_array['ask_password'];
                }
                if( $category_output_array['done'] ){
                    $categories_output_done[] = $category_output_array['done'];
                }
            }else{
                if( in_array( $default_cat_obj->id, $categories_for_pdfs_results) &&
                    isset( $pdfs_results_array_by_category[$default_cat_obj->id] ) ){
                    
                    $current_category_depth = 1;
                    $category_output_array = $this->show_category_pdfs_in_columns(
                                                                                                        $columns,
                                                                                                        $current_category_depth,
                                                                                                        $hide_empty_cat,
                                                                                                        $show_cat_empty_message,
                                                                                                        $password_required,
                                                                                                        null,
                                                                                                        $default_cat_obj, 
                                                                                                        $pdfs_results_array_by_category[$default_cat_obj->id],
                                                                                                        $show_description,
                                                                                                        $featured_image, $featured_image_size, 
                                                                                                        $show_pdf_title, $pdf_title_position,
                                                                                                        $default_thumbnail_html, $image_position,
                                                                                                        $open_target_str, $nofollow_tag, 
                                                                                                        $show_date, $date_format_str, $date_before_title
                                                                                                       );
                    $category_output_str .= $category_output_array['category_output_str'];
                    if( $category_output_array['ask_password'] ){
                        $categories_ask_for_password[] = $category_output_array['ask_password'];
                    }
                    if( $category_output_array['done'] ){
                        $categories_output_done[] = $category_output_array['done'];
                    }
                }
            }
        }
        
        if( $pdfs_results_array_by_category && is_array( $pdfs_results_array_by_category ) && count($pdfs_results_array_by_category) > 0 ){
            //show date filter
            $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
            $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
            $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
            if( $date_weekday_filter ){
                $all_pdfs_results_array = array();
                foreach( $pdfs_results_array_by_category as $key => $pdfs_by_category ){
                    if( count($categories_ask_for_password) > 0 && in_array($key, $categories_ask_for_password ) ){
                        continue;
                    }
                    $all_pdfs_results_array = array_merge( $all_pdfs_results_array, $pdfs_by_category );
                }
                $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                    $all_pdfs_results_array, 
                                                                                                    $date_weekday_filter, 
                                                                                                    $date_weekday_filter_order, 
                                                                                                    $date_weekday_filter_right 
                                                                                                 );
            }
            
            //show search bar
            if( $search_bar && count($categories_ask_for_password) < 1 ){ 
                //only a single category queried so donot show pagination if it asks password
                $search_bar_str = BSKPDFMPro_Common_Search::show_search_bar( 
                                                                                                                 $search_bar, 
                                                                                                                false, //$categories_loop_array,
                                                                                                                false, //$ids_array,
                                                                                                                false, //$show_cat_hierarchical, 
                                                                                                                '', //$cat_order_by_str,
                                                                                                                '', //$cat_order_str,
                                                                                                                $shortcode_atts['search_bar_year_range'],
                                                                                                                $shortcode_atts['search_bar_year_order']
                                                                                                             );
            }
            
            if( $total_pages > 1 && count($categories_ask_for_password) < 1 ){ 
                //only a single category queried so donot show pagination if it asks password
                $pagination_str = BSKPDFMPro_Common_Pagination::bsk_pdf_show_pagination( 
                                                                                                                                    $total_pdfs, 
                                                                                                                                    $pdfs_per_page, 
                                                                                                                                    1
                                                                                                                                  );
            }
        }

        //credit
        $credit_str = '';
        if( isset( $plugin_settings['enable_credit'] ) && $plugin_settings['enable_credit'] == 'Yes' ){
            $credit_text = 'PDFs powered by PDF Manager Pro';
            if( $plugin_settings['credit_text'] ){
                $credit_text = $plugin_settings['credit_text'];
            }
            $pdf_manager_pro_link = 'https://www.bannersky.com/bsk-pdf-manager/';
            $credit_str .= '<p class="bsk-pdfm-credit-link-container"><a href="'.$pdf_manager_pro_link.'" target="_blank">'.$credit_text.'</a></p>';
        }
        
        //output all shortcode parameters
        $shortcode_parameters_str = '<div class="bsk-pdfm-selector-shortcode-attr">';
        foreach( $shortcode_atts as $attr_name => $attr_val ){
            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="'.$attr_val.'" />';
        }
        if( $password_required ){
            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr category-password-hidden-feild" data-attr_name="category_password" value="" />';
        }
        $ajax_nonce = wp_create_nonce( "selector-ajax-get" );
        $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-selector-ajax-nonce" value="'.$ajax_nonce.'">';
        $shortcode_parameters_str .= BSKPDFMPro_Statistics_Download_Count::bsk_pdfm_statistics_get_ajax_nonce();
        $shortcode_parameters_str .= '<!-- //bsk-pdfm-selector-shortcode-attr -->';
        $shortcode_parameters_str .= '</div>';

        $output_container_end = '</div><!-- //bsk-pdfm-output-container -->';
        
        $output_str =  ''.
                            $output_container_start.
                            $category_selector.
                            $cat_description_str.
                            $search_bar_str.
                            $date_weekday_filter_str.
                            $category_output_str.
                            $pagination_str.
                            $credit_str.
                            $shortcode_parameters_str.
                            $output_container_end;
        
		return $output_str;
	} //end of function
    
    function show_category_pdfs_in_columns( 
                                                                $columns,
                                                                $category_depth,
                                                                $hide_empty_cat,
                                                                $show_cat_empty_message,
                                                                $password_required,
                                                                $category_password_array,
                                                                $cat_obj, 
                                                                $pdfs_results_array,
                                                                $show_description,
                                                                $featured_image, $featured_image_size, 
                                                                $show_pdf_title, $pdf_title_position,
                                                                $default_thumbnail_html, $image_position,
                                                                $open_target_str, $nofollow_tag, 
                                                                $show_date, $date_format_str, $date_before_title
                                                                ){
        $depth_class = ' category-hierarchical-depth-'.$category_depth;
        $caegory_title_tag = 'h'.($category_depth + 1);
        $pdf_title_tag = 'h'.($category_depth + 2);
            
        $categor_output_container_begin = '<div class="bsk-pdfm-category-output cat-'.$cat_obj->id.$depth_class.' pdfs-in-columns" data-cat-id="'.$cat_obj->id.'" data-columns="'.$columns.'">';
        $categor_output_container_end = '<!--//bsk-pdfm-category-output cat-'.$cat_obj->id.'-->';
        $categor_output_container_end .= '</div>';

        //check if password protection set for the category
        if( $password_required && $cat_obj->password != "" ){
            $show_password_form = true;
            $password_error = false;
            if( $category_password_array && is_array( $category_password_array ) && array_key_exists( $cat_obj->id, $category_password_array ) ){
                if( $category_password_array[$cat_obj->id] != $cat_obj->password ){
                    $password_error = true;
                }else{
                    $show_password_form = false;
                }
            }
            
            if( $show_password_form ){
                //no enter password or password is wrong 
                $password_form = BSKPDFMPro_Common_Display::show_category_password_require_form( $cat_obj, $password_error );
                $category_output_str = 
                                                 $categor_output_container_begin.
                                                 $password_form.
                                                 $categor_output_container_end;
                return array( 'ask_password' => $cat_obj->id,
                                   'category_output_str' => $category_output_str,
                                   'done' =>  0 );
            }
        }
        
        //get pdfs list str
        $columns_str = BSKPDFMPro_Common_Display::show_pdfs_in_column(
                                                                                                         false,
                                                                                                         $pdfs_results_array, 
                                                                                                         $show_description,
                                                                                                         $featured_image, $featured_image_size, 
                                                                                                         $default_thumbnail_html, 
                                                                                                         $open_target_str, $nofollow_tag, $columns, 
                                                                                                         $show_pdf_title, $pdf_title_position,
                                                                                                         $show_date, $date_format_str, $date_before_title
                                                                                                        );

        if( $columns_str == "" ){
            if( $hide_empty_cat == true ){
                return '';
            }else if( $show_cat_empty_message ){
                $columns_str = '<p class="bsk-pdfm-category-empty-message cat-'.$cat_obj->id.'">'.$cat_obj->empty_message.'</p>';
            }
        }

        $category_output_str  = $categor_output_container_begin.
                                          $columns_str.
                                          $categor_output_container_end;
        
        return array( 'ask_password' => 0,
                           'category_output_str' => $category_output_str,
                           'done' =>  $cat_obj->id );
    }
    
    function bsk_pdfm_ajax_selector_get_pdfs_columns(){
        if( !check_ajax_referer( 'selector-ajax-get', 'nonce', false ) ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Security check!</p>' );
            wp_die( json_encode( $return_array ) );
        }
        $license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Invalid license!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        //read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
        $enable_multi_column_layout = false;
        $default_column_number = 2;
		$default_column_layout_title_positon = 'below';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
            if( $default_enable_featured_image && isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
            
            if( isset($plugin_settings['multi_column_layout']) ){
				$enable_multi_column_layout = $plugin_settings['multi_column_layout'];
			}
			
			if( isset($plugin_settings['default_column_number']) ){
				$default_column_number = $plugin_settings['default_column_number'];
			}
			
			if( isset($plugin_settings['column_layout_title_positon']) ){
				$default_column_layout_title_positon = $plugin_settings['column_layout_title_positon'];
			}
		}

        $shortcode_atts = array(  
                                           'paged' => $_POST['paged'],
                                           'cat_id' => $_POST['cat_id'],
                                           'password_required' => $_POST['password_required'],
                                           'hierarchical' => $_POST['hierarchical'],
                                           'show_cat_title' => $_POST['show_cat_title'],
                                           'show_cat_description' => $_POST['show_cat_description'],
                                           'hide_empty_cat' => $_POST['hide_empty_cat'],
                                           'show_cat_empty_message' => $_POST['show_cat_empty_message'],
                                           'exclude_pdf_id' => $_POST['exclude_pdf_id'],
                                           'year_of' => $_POST['year_of'], //work when 'id'="all", 9999 means most recent, length = 4
                                           'month_of' => $_POST['month_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'day_of' => $_POST['day_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'weekday_of' => $_POST['weekday_of'], //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                           'search_bar' => $_POST['search_bar'], 
                                           'keywords' => isset($_POST['keywords']) ? $_POST['keywords'] : '',
                                           'search_bar_year_range' => $_POST['search_bar_year_range'],
                                           'search_bar_year_order' => $_POST['search_bar_year_order'],
                                           'order_by' => $_POST['order_by'],
                                           'order' => $_POST['order'],
                                           'target' => $_POST['target'],
                                           'show_description' => $_POST['show_description'],
                                           'featured_image' => $_POST['featured_image'],
                                           'featured_image_size' => $_POST['featured_image_size'],
                                           'image_position' => $_POST['image_position'],
                                           'show_pdf_title' => $_POST['show_pdf_title'],
                                           'title_position' => $_POST['title_position'],
                                           'nofollow_tag' => $_POST['nofollow_tag'],
                                           'show_date' => $_POST['show_date'],
                                           'date_format' => $_POST['date_format'],
                                           'date_before_title' => $_POST['date_before_title'],
                                           'date_weekday_filter' => $_POST['date_weekday_filter'],
                                           'date_weekday_filter_order' => $_POST['date_weekday_filter_order'],
                                           'date_weekday_filter_right' => $_POST['date_weekday_filter_right'],
                                           'pdfs_per_page' => $_POST['pdfs_per_page'],
                                           'most_top' => $_POST['most_top'],
                                           'columns' => $_POST['columns']
                                          );
        
        $categories_password_array = array();
        if( isset( $_POST['category_password']  ) ){
            $shortcode_atts['category_password'] = $_POST['category_password'];
            $temp_array = explode( ',', $shortcode_atts['category_password'] );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $cat_n_password ){
                    $cat_n_password_array = explode( ':', $cat_n_password );
                    if( !$cat_n_password_array || !is_array( $cat_n_password_array ) || count( $cat_n_password_array ) != 2 ){
                        continue;
                    }
                    $cat_id = absint( $cat_n_password_array[0] );
                    $password = preg_replace( '%[^0-9a-zA-Z]%', '', $cat_n_password_array[1] );
                    $categories_password_array[$cat_id] = $password;
                }
            }
        }

        /**
          * process categories attributes
          */
        //proccess columns
        $columns = absint( $shortcode_atts['columns'] );
        //password protect
        $password_required = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('password_required', $shortcode_atts);
		//show category title or not
		$show_cat_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_title', $shortcode_atts);
        //show category description or not
		$show_cat_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_description', $shortcode_atts);
        //show category with hierarchical
		$show_cat_hierarchical = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hierarchical', $shortcode_atts);
        //hide empty
        $hide_empty_cat = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hide_empty_cat', $shortcode_atts);
		//show empty message
		$show_cat_empty_message = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_empty_message', $shortcode_atts);
        //sub cat ident
        $sub_cat_indent = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('sub_cat_indent', $shortcode_atts);
        
        //process order by case
        $cat_order_by_str = ' C.`title`';
		$cat_order_str = ' ASC';
        
        global $wpdb;
        
        $ids_array = false;
		$categories_loop_array = false;
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts['cat_id'], 
                                                                                                false, 
                                                                                                array(), 
                                                                                                $cat_order_by_str, 
                                                                                                $cat_order_str );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }
        if( !$ids_array || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Category ID( '.$shortcode_atts['cat_id'].' )doesn\'t exist</p>' );
            wp_die( json_encode( $return_array ) );
        }
        
        /**
          * Process PDFs attributes
        */
		//show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//process open target
		$open_target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$open_target_str = ' target="_blank"';
		}
        
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );

        //featured image
		$featured_image = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('featured_image', $shortcode_atts);
		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$featured_image = false;
		}
		//show pdf title with featured imaged
		$show_pdf_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_pdf_title', $shortcode_atts);
        //pdf title postion
        $pdf_title_position = 'above';
        if( strtoupper($shortcode_atts['title_position']) == 'BELOW' ){
            $pdf_title_position = 'below';
        }
        //featurec image size
		$featured_image_size = $default_thumbnail_size;
        if( trim($shortcode_atts['featured_image_size']) ){
            $featured_image_size = trim($shortcode_atts['featured_image_size']);
        }
        $image_position = 'left';
        if( trim($shortcode_atts['image_position']) && trim($shortcode_atts['image_position']) == 'right' ){
            $image_position = trim($shortcode_atts['image_position']);
        }

		//anchor nofollow tag
		$nofollow_tag = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('nofollow_tag', $shortcode_atts);
        if( $nofollow_tag ){
            $nofollow_tag = ' rel="nofollow"';
        }
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}
        
        //process pagination
        $pdfs_per_page = intval( $shortcode_atts['pdfs_per_page'] );
        $pagination = $pdfs_per_page > 0 ? true : false;
        if( $most_top > 0 ){
            //disble pagination for some special situations
            $pagination = false;
        }
        
        $search_bar = strtoupper( $shortcode_atts['search_bar'] );
        if( $search_bar != 'YES' && 
            $search_bar != 'KEYWORDS' && 
            $search_bar != 'YEAR_KEYWORDS' &&
            $search_bar != 'CATEGORY_YEAR_KEYWORDS' ){
            
            $search_bar = false;
        }
        $search_bar = $search_bar == 'YES' ? 'KEYWORDS' : $search_bar;
        $search_bar = $search_bar == 'CATEGORY_YEAR_KEYWORDS' ? 'YEAR_KEYWORDS' : $search_bar;
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        //exclude pdf ids
        $exclude_pdf_ids_array = null;
        if( trim($shortcode_atts['exclude_pdf_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_pdf_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_pdf_ids_array[] = absint( trim($pdf_id) );
                }
            }
        }
        
        //columns
		$columns = absint($shortcode_atts['columns']);
		if( $columns < 1 || $columns > 6 ){
			$columns = $default_column_number;
		}
        
        /**
          * Query PDFs for category
        */
        $query_args = array();
        $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;
        $query_args['year_of'] = $year_of;
        $query_args['month_of'] = $month_of;
        $query_args['day_of'] = $day_of;
        $query_args['weekday_of'] = $weekday_of;
        $query_args['pagination'] = $pagination;
        $query_args['pdfs_per_page'] = $pdfs_per_page;
        $query_args['paged'] = absint($shortcode_atts['paged']);
        $query_args['order_by'] = $shortcode_atts['order_by'];
        $query_args['order'] = $shortcode_atts['order'];
        $query_args['most_top'] = absint($most_top);
        $query_args['ids_array'] = $ids_array; /* ids_array sequence determine the order by of category */
        $query_args['keywords'] = $shortcode_atts['keywords'];
        
        $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );

        $pdfs_results_array_by_category = $cat_pdfs_query_results['pdfs'];
        $total_pages = $cat_pdfs_query_results['pages'];
        $total_pdfs = $cat_pdfs_query_results['total'];
        $categories_for_pdfs_results = $cat_pdfs_query_results['categories_for_pdfs'];

        $category_output_str = '';
        $date_weekday_filter_str = '';
        $pagination_str = '';
        $search_bar_str = '';
        $cat_description_str = '';
        
        $categories_ask_for_password = array();
        $categories_output_done = array();
        foreach( $categories_loop_array as $cat_obj ){
            $current_category_depth = 1;
            
            if( $pdfs_results_array_by_category == false || 
                !is_array( $pdfs_results_array_by_category ) || 
                count( $pdfs_results_array_by_category ) < 1 ){
                //no pdfs, only show empty message
                $category_output_array = $this->show_category_pdfs_in_columns(
                                                                                                        $columns,
                                                                                                        $current_category_depth,
                                                                                                        $hide_empty_cat,
                                                                                                        $show_cat_empty_message,
                                                                                                        $password_required,
                                                                                                        $categories_password_array,
                                                                                                        $cat_obj, 
                                                                                                        null,
                                                                                                        $show_description,
                                                                                                        $featured_image, $featured_image_size, 
                                                                                                        $show_pdf_title, $pdf_title_position,
                                                                                                        $default_thumbnail_html, $image_position,
                                                                                                        $open_target_str, $nofollow_tag, 
                                                                                                        $show_date, $date_format_str, $date_before_title
                                                                                                       );
                $category_output_str .= $category_output_array['category_output_str'];
                if( $category_output_array['ask_password'] ){
                    $categories_ask_for_password[] = $category_output_array['ask_password'];
                }
                if( $category_output_array['done'] ){
                    $categories_output_done[] = $category_output_array['done'];
                }
                
                continue;
            }
            
            /*
              * Loop category maybe not exist in results but still need to check its child & grand
              */
            if( in_array( $cat_obj->id, $categories_for_pdfs_results) &&
                isset( $pdfs_results_array_by_category[$cat_obj->id] ) ){
                $current_category_depth = 1;
                $category_output_array = $this->show_category_pdfs_in_columns(
                                                                                                    $columns,
                                                                                                    $current_category_depth,
                                                                                                    $hide_empty_cat,
                                                                                                    $show_cat_empty_message,
                                                                                                    $password_required,
                                                                                                    $categories_password_array,
                                                                                                    $cat_obj, 
                                                                                                    $pdfs_results_array_by_category[$cat_obj->id],
                                                                                                    $show_description,
                                                                                                    $featured_image, $featured_image_size, 
                                                                                                    $show_pdf_title, $pdf_title_position,
                                                                                                    $default_thumbnail_html, $image_position,
                                                                                                    $open_target_str, $nofollow_tag, 
                                                                                                    $show_date, $date_format_str, $date_before_title
                                                                                                   );
                $category_output_str .= $category_output_array['category_output_str'];
                if( $category_output_array['ask_password'] ){
                    $categories_ask_for_password[] = $category_output_array['ask_password'];
                }
                if( $category_output_array['done'] ){
                    $categories_output_done[] = $category_output_array['done'];
                }
            }
            
            if( $show_cat_description ){
                $cat_description_str = '<div class="bsk-pdfm-category-description">'.$cat_obj->description.'</div>';
            }

        } //end of foreach
        
        $all_pdfs_results_count = 0;
        $all_pdfs_results_array_for_date_filter = array();
        if( $pdfs_results_array_by_category && is_array( $pdfs_results_array_by_category ) && count($pdfs_results_array_by_category) > 0 ){
            
            foreach( $pdfs_results_array_by_category as $key => $pdfs_by_category ){
                $all_pdfs_results_count += count( $pdfs_by_category );
                if( count($categories_ask_for_password) > 0 && in_array($key, $categories_ask_for_password ) ){
                    continue;
                }
                $all_pdfs_results_array_for_date_filter = array_merge( $all_pdfs_results_array_for_date_filter, $pdfs_by_category );
            }
            //show date filter
            $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
            $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
            $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
            if( $date_weekday_filter ){
                $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                    $all_pdfs_results_array_for_date_filter, 
                                                                                                    $date_weekday_filter, 
                                                                                                    $date_weekday_filter_order, 
                                                                                                    $date_weekday_filter_right 
                                                                                                 );
            }
            
            //show search bar
            if( $search_bar && count($categories_ask_for_password) < 1 ){ 
                //only a single category queried so donot show pagination if it asks password
                $search_bar_str = BSKPDFMPro_Common_Search::show_search_bar( 
                                                                                                                 $search_bar, 
                                                                                                                false, //$categories_loop_array,
                                                                                                                false, //$ids_array,
                                                                                                                false, //$show_cat_hierarchical, 
                                                                                                                '', //$cat_order_by_str,
                                                                                                                '', //$cat_order_str,
                                                                                                                $shortcode_atts['search_bar_year_range'],
                                                                                                                $shortcode_atts['search_bar_year_order']
                                                                                                             );
            }
            
            //show pagination only for when show all PDFs
            if( $total_pages > 1 && count($categories_ask_for_password) < 1 ){ 
                //only a single category queried so donot show pagination if it asks password
                $pagination_str = BSKPDFMPro_Common_Pagination::bsk_pdf_show_pagination( 
                                                                                                                                    $total_pdfs, 
                                                                                                                                    $pdfs_per_page, 
                                                                                                                                    absint($shortcode_atts['paged'])
                                                                                                                                  );
            }
        }

        //total_pdfs only have valid value when pagination enabled so
        $pdfs_count = $total_pages > 1 ? $total_pdfs : $all_pdfs_results_count;
        $results_desc_str = $pdfs_count > 1 ? $pdfs_count.' records found' : $pdfs_count.' record found';
        $data_to_return = array( 
                                            'pdfs' => $category_output_str, 
                                            'date_filter' => $date_weekday_filter_str, 
                                            'pagination' => $pagination_str,
                                            'pdfs_count' => $pdfs_count,
                                            'results_desc' => $results_desc_str,
                                            'search_bar_str' => $search_bar_str,
                                            'cat_desc_str' => $cat_description_str
                                         );
        wp_die( json_encode( $data_to_return ) );
        
    } //end of function
}