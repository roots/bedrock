<?php

class BSKPDFMPro_Shortcodes_PDFs_Dropdown {
    
    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
	public function __construct() {
		add_shortcode('bsk-pdfm-pdfs-dropdown', array($this, 'bsk_pdf_manager_show_pdfs_in_dropdown') );
	}
	
	function bsk_pdf_manager_show_pdfs_in_dropdown( $atts, $content ){
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
        
        //read plugin settings

		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
        
		$shortcode_atts = shortcode_atts( 
                                          array(
                                                   'id' => '', 
                                                   'exclude_id' => '',
                                                   'option_none' => 'Select to open...',
                                                   'order_by' => '',
                                                   'order' => '', 
                                                   'target' => '_blank',
                                                   'most_top' => 0,
                                                   'year_of' => '0000', //work when 'id'="all", 9999 means most recent, length = 4
                                                   'month_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                   'day_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                   'weekday_of' => 'no', //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                                   'show_date' => 'no',
                                                   'date_format' => ' d/m/Y',
                                                   'date_before_title' => 'no',
                                                   'date_weekday_filter' => '',
                                                   'date_weekday_filter_order' => '',
                                                   'date_weekday_filter_right' => 'no',
                                                   'output_container_class' => ''
                                                 ), 
                                           $atts
                                        );
		//organise ids array
		$ids_array = array();
        $show_all_pdfs = false;
		if( trim($shortcode_atts['id']) == "" ){
			return '';
		}
        if( strtoupper(trim($shortcode_atts['id'])) == 'ALL' ){
            $show_all_pdfs = true;  
        }else if( is_string($shortcode_atts['id']) ){
			$ids_array = explode(',', $shortcode_atts['id']);
			foreach($ids_array as $key => $pdf_id){
				$pdf_id = intval(trim($pdf_id));
				if( $pdf_id < 1 ){
					unset($ids_array[$key]);
                    continue;
				}
				$ids_array[$key] = $pdf_id;
			}
		}
        
		if( ( !is_array($ids_array) || count($ids_array) < 1 ) && $show_all_pdfs == false ){
			return '';
		}
        
        //exclude ids
        $exclude_ids_array = null;
        if( trim($shortcode_atts['exclude_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_ids_array[] = intval( $pdf_id );
                }
            }
        }
        
        $option_none_text = trim( $shortcode_atts['option_none'] );
            
		//process open target
		$open_target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$open_target_str = ' data-target="_blank"';
		}
        
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );

        $query_args = array();
        $query_args['show_all_pdfs'] = $show_all_pdfs;
        $query_args['ids_array'] = $ids_array;
        $query_args['exclude_ids_array'] = $exclude_ids_array;
        $query_args['year_of'] = $year_of;
        $query_args['month_of'] = $month_of;
        $query_args['day_of'] = $day_of;
        $query_args['weekday_of'] = $weekday_of;
        $query_args['order_by'] = $shortcode_atts['order_by'];
        $query_args['order'] = $shortcode_atts['order'];
        $query_args['most_top'] = $most_top;
        
        $pdfs_query_return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs( $query_args );
        
        $output_container_class = trim($shortcode_atts['output_container_class']) ? ' '.trim($shortcode_atts['output_container_class']) : '';
        $str_body = '<div class="bsk-pdfm-output-container shortcode-pdfs layout-dropdown'.$output_container_class.'">';
        if( !$pdfs_query_return || !is_array($pdfs_query_return) || count($pdfs_query_return) < 1 ){
            $str_body .= '</div><!-- //bsk-pdfm-output-containe -->';
            return $str_body;
        }
        
        $str_body .= '<div class="bsk-pdfm-pdfs-output pdfs-in-dropdown">';
        
        $pdfs_results_array = $pdfs_query_return['pdfs'];

        //show date filter
        $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
        $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
        $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
        $str_body .= BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                $pdfs_results_array, 
                                                                                                $date_weekday_filter, 
                                                                                                $date_weekday_filter_order, 
                                                                                                $date_weekday_filter_right 
                                                                                             );
        
        $str_body .= BSKPDFMPro_Common_Display::show_pdfs_in_dropdown( 
                                                                                                             $pdfs_results_array, 
                                                                                                             'bsk-pdfm-pdfs-dropdown', 
                                                                                                             $option_none_text,
                                                                                                             $open_target_str,
                                                                                                             $show_date, 
                                                                                                             $date_format_str,
                                                                                                             $date_before_title
                                                                                                            );
        
        $str_body .= '</div><!--// bsk-pdfm-pdfs-output-->';
        
        //credit
        if( isset( $plugin_settings['enable_credit'] ) && $plugin_settings['enable_credit'] == 'Yes' ){
            $credit_text = 'PDFs powered by PDF Manager Pro';
            if( $plugin_settings['credit_text'] ){
                $credit_text = $plugin_settings['credit_text'];
            }
            $pdf_manager_pro_link = 'https://www.bannersky.com/bsk-pdf-manager/';
            $str_body .= '<p class="bsk-pdfm-credit-link-container"><a href="'.$pdf_manager_pro_link.'" target="_blank">'.$credit_text.'</a></p>';
        }
        
        //output all shortcode parameters
        $str_body .= '<div class="bsk-pdfm-pdfs-shortcode-attr">';
        foreach( $shortcode_atts as $attr_name => $attr_val ){
            $str_body .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="'.$attr_val.'" />';
        }
        $ajax_nonce = wp_create_nonce( "pdfs-ajax-get" );
        $str_body .= '<input type="hidden" class="bsk-pdfm-pdfs-ajax-nonce" value="'.$ajax_nonce.'">';
        $str_body .= '<!-- //bsk-pdfm-pdfs-shortcode-attr -->';
        $str_body .= BSKPDFMPro_Statistics_Download_Count::bsk_pdfm_statistics_get_ajax_nonce();
        $str_body .= '</div>';
        
        $str_body .= '</div><!--// bsk-pdfm-output-container-->';

        return $str_body;
	}
}