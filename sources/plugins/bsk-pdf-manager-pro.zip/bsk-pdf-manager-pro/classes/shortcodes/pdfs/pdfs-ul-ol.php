<?php

class BSKPDFMPro_Shortcodes_PDFs_UL_OL {
    
    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
	public function __construct() {
        add_shortcode('bsk-pdfm-pdfs-ul', array($this, 'bsk_pdf_manager_show_pdfs_in_ul') );
        add_shortcode('bsk-pdfm-pdfs-ol', array($this, 'bsk_pdf_manager_show_pdfs_in_ol') );
        
        //ajax action for pagination & search
        add_action( 'wp_ajax_pdfs_get_pdfs_ul', array( $this, 'bsk_pdfm_ajax_get_pdfs_ul_ol' ) );
		add_action( 'wp_ajax_nopriv_pdfs_get_pdfs_ul', array( $this, 'bsk_pdfm_ajax_get_pdfs_ul_ol' ) );
        add_action( 'wp_ajax_pdfs_get_pdfs_ol', array( $this, 'bsk_pdfm_ajax_get_pdfs_ul_ol' ) );
		add_action( 'wp_ajax_nopriv_pdfs_get_pdfs_ol', array( $this, 'bsk_pdfm_ajax_get_pdfs_ul_ol' ) );
	}
    
	function bsk_pdf_manager_show_pdfs_in_ul( $atts, $content ){
        if( !is_array( $atts ) ){
            $atts = array();
        }
        $atts['ul_or_ol'] = 'ul';
        
        return $this->bsk_pdf_manager_show_pdfs_in_ul_ol( $atts );
    }
    
    function bsk_pdf_manager_show_pdfs_in_ol( $atts, $content ){
        if( !is_array( $atts ) ){
            $atts = array();
        }
        $atts['ul_or_ol'] = 'ol';
        
        return $this->bsk_pdf_manager_show_pdfs_in_ul_ol( $atts );
    }
    
	function bsk_pdf_manager_show_pdfs_in_ul_ol( $atts ){
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
		
		//read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
            if( $default_enable_featured_image && isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
		}
		
		$shortcode_atts = shortcode_atts( 
                                          array(
                                                   'ul_or_ol' => 'ul',
                                                   'id' => '', 
                                                   'exclude_id' => '',
                                                   'link_only' => 'no',
                                                   'url_only' => 'no',
                                                   'order_by' => '',
                                                   'order' => '', 
                                                   'target' => '',
                                                   'most_top' => 0,
                                                   'year_of' => '0000', //work when 'id'="all", 9999 means most recent, length = 4
                                                   'month_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                   'day_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                   'weekday_of' => 'no', //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                                   'search_bar' => 'no',  //work when 'id'="all" and 'most_recent_date' = 'no', YES = KEYWORDS, YEAR_KEYWORDS, CATEGORY_YEAR_KEYWORDS
                                                   'search_bar_year_range' => '',
                                                   'search_bar_year_order' => 'DESC',
                                                   'show_description' => '',
                                                   'featured_image' => '',
                                                   'featured_image_size' => '',
                                                   'image_position' => 'left',
                                                   'show_pdf_title' => '',
                                                   'nofollow_tag' => 'no',
                                                   'show_date' => 'no',
                                                   'date_format' => ' d/m/Y',
                                                   'date_before_title' => 'no',
                                                   'date_weekday_filter' => '',
                                                   'date_weekday_filter_order' => '',
                                                   'date_weekday_filter_right' => 'no',
                                                   'pdfs_per_page' => 0,
                                                   'output_container_class' => ''
                                                 ), 
                                           $atts
                                        );
        
        $ul_or_ol = strtoupper($shortcode_atts['ul_or_ol']) == 'OL' ? 'ol' : 'ul';
            
        //show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//organise ids array
		$ids_array = array();
        $show_all_pdfs = false;
		if( trim($shortcode_atts['id']) == "" ){
			return '';
		}
        if( strtoupper(trim($shortcode_atts['id'])) == 'ALL' ){
            $show_all_pdfs = true;  
        }else if( is_string($shortcode_atts['id']) ){
			$ids_array = explode(',', $shortcode_atts['id']);
			foreach($ids_array as $key => $pdf_id){
				$pdf_id = intval(trim($pdf_id));
				if( $pdf_id < 1 ){
					unset($ids_array[$key]);
                    continue;
				}
				$ids_array[$key] = $pdf_id;
			}
		}
        
		if( ( !is_array($ids_array) || count($ids_array) < 1 ) && $show_all_pdfs == false ){
			return '';
		}
        
        //exclude ids
        $exclude_ids_array = null;
        if( trim($shortcode_atts['exclude_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_ids_array[] = intval( $pdf_id );
                }
            }
        }

		//process open target
		$open_target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$open_target_str = ' target="_blank"';
		}
        
		//link only
		$show_link_only = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('link_only', $shortcode_atts);
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );

        //featured image
		$featured_image = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('featured_image', $shortcode_atts);
		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$featured_image = false;
		}
		//show pdf title with featured imaged
		$show_pdf_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_pdf_title', $shortcode_atts);
        //featurec image size
		$featured_image_size = $default_thumbnail_size;
        if( trim($shortcode_atts['featured_image_size']) ){
            $featured_image_size = trim($shortcode_atts['featured_image_size']);
        }
        $image_position = 'left';
        if( trim($shortcode_atts['image_position']) && trim($shortcode_atts['image_position']) == 'right' ){
            $image_position = trim($shortcode_atts['image_position']);
        }

		//anchor nofollow tag
		$nofollow_tag = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('nofollow_tag', $shortcode_atts);
        if( $nofollow_tag ){
            $nofollow_tag = ' rel="nofollow"';
        }
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}

        //show pdf ulr only
        $show_PDF_url_only = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('url_only', $shortcode_atts);
        
        //process pagination
        $pdfs_per_page = intval( $shortcode_atts['pdfs_per_page'] );
        $pagination = $pdfs_per_page > 0 ? true : false;
        
        //show search bar only when id="all" and most_recent_date = "no"
        $search_bar = strtoupper( $shortcode_atts['search_bar'] );
        if( $search_bar != 'YES' && 
            $search_bar != 'KEYWORDS' && 
            $search_bar != 'YEAR_KEYWORDS' &&
            $search_bar != 'CATEGORY_YEAR_KEYWORDS' ){
            
            $search_bar = false;
        }
        $search_bar = $search_bar == 'YES' ? 'KEYWORDS' : $search_bar;
        $search_bar = $search_bar == 'CATEGORY_YEAR_KEYWORDS' ? 'YEAR_KEYWORDS' : $search_bar;
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        //disble pagination, search_bar for some special situations
        if( $most_top > 0 || 
            $show_PDF_url_only || 
            $show_link_only ||
            $show_all_pdfs == false ){

            $pagination = false;
            $search_bar = false;
        }

        $query_args = array();
        $query_args['show_all_pdfs'] = $show_all_pdfs;
        $query_args['ids_array'] = $ids_array;
        $query_args['exclude_ids_array'] = $exclude_ids_array;
        $query_args['year_of'] = $year_of;
        $query_args['month_of'] = $month_of;
        $query_args['day_of'] = $day_of;
        $query_args['weekday_of'] = $weekday_of;
        $query_args['pagination'] = $pagination;
        $query_args['pdfs_per_page'] = $pdfs_per_page;
        $query_args['paged'] = 1;
        $query_args['order_by'] = $shortcode_atts['order_by'];
        $query_args['order'] = $shortcode_atts['order'];
        $query_args['most_top'] = $most_top;
        
        $pdfs_query_return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs( $query_args );
        
        if( $show_link_only ){
            if( !$pdfs_query_return || !is_array($pdfs_query_return) || count($pdfs_query_return) < 1 ){
                return '';
            }
            $pdfs_results_array = $pdfs_query_return['pdfs'];
            $str_body = BSKPDFMPro_Common_Display::show_pdfs_link_only(
                                                                                                     $pdfs_results_array, 
                                                                                                     $open_target_str, $nofollow_tag, 
                                                                                                     $show_date, $date_format_str, $date_before_title
                                                                                                    );
            return $str_body;
        }
        
        if( $show_PDF_url_only ){
            if( !$pdfs_query_return || !is_array($pdfs_query_return) || count($pdfs_query_return) < 1 ){
                return '';
            }
            $pdfs_results_array = $pdfs_query_return['pdfs'];
            $str_body = BSKPDFMPro_Common_Display::show_pdfs_url_only( $pdfs_results_array );
            return $str_body;
        }
        
        $output_container_class = trim($shortcode_atts['output_container_class']) ? ' '.trim($shortcode_atts['output_container_class']) : '';
        $str_body = '<div class="bsk-pdfm-output-container shortcode-pdfs layout-'.$ul_or_ol.$output_container_class.'">';
        if( !$pdfs_query_return || !is_array($pdfs_query_return) || count($pdfs_query_return) < 1 ){
            $str_body .= '</div><!-- //bsk-pdfm-pdfs-output -->';
            return $str_body;
        }
        
        $str_body .= '<div class="bsk-pdfm-pdfs-output pdfs-in-'.$ul_or_ol.'">';
        
        $pdfs_results_array = $pdfs_query_return['pdfs'];
        $total_pages = $pdfs_query_return['pages'];
        $total_pdfs = $pdfs_query_return['total'];
        
        //show search bar
        if( $search_bar ){
            $str_body .= BSKPDFMPro_Common_Search::show_search_bar( 
                                                                                                        $search_bar, 
                                                                                                        false, //categories loop array
                                                                                                        false, //available categories
                                                                                                        false, //show hierarchical
                                                                                                        '', //cat order by
                                                                                                        '', //cat order
                                                                                                        $shortcode_atts['search_bar_year_range'],
                                                                                                        $shortcode_atts['search_bar_year_order']
                                                                                                     );
        }
        
        //show date filter
        $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
        $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
        $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
        $str_body .= BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                $pdfs_results_array, 
                                                                                                $date_weekday_filter, 
                                                                                                $date_weekday_filter_order, 
                                                                                                $date_weekday_filter_right 
                                                                                             );
        
        $str_body .= BSKPDFMPro_Common_Display::display_pdfs_in_ul_or_ol(
                                                                                                     $ul_or_ol,
                                                                                                     false,
                                                                                                     'bsk-pdfm-pdfs-'.$ul_or_ol.'-list',
                                                                                                     $pdfs_results_array, 
                                                                                                     $show_description,
                                                                                                     $featured_image, $featured_image_size, $show_pdf_title,
                                                                                                     $default_thumbnail_html, $image_position,
                                                                                                     $open_target_str, $nofollow_tag, 
                                                                                                     $show_date, $date_format_str, $date_before_title,
                                                                                                     'h3'
                                                                                                    );
        
        //show pagination only for when show all PDFs
        if( $total_pages > 1 ){
            $str_body .= BSKPDFMPro_Common_Pagination::bsk_pdf_show_pagination( 
                                                                                                                        $total_pdfs, 
                                                                                                                        $pdfs_per_page, 
                                                                                                                        1
                                                                                                                       );
        }
        $str_body .= '</div><!-- //end for bsk-pdfm-pdfs-output -->';
        
        //credit
        if( isset( $plugin_settings['enable_credit'] ) && $plugin_settings['enable_credit'] == 'Yes' ){
            $credit_text = 'PDFs powered by PDF Manager Pro';
            if( $plugin_settings['credit_text'] ){
                $credit_text = $plugin_settings['credit_text'];
            }
            $pdf_manager_pro_link = 'https://www.bannersky.com/bsk-pdf-manager/';
            $str_body .= '<p class="bsk-pdfm-credit-link-container"><a href="'.$pdf_manager_pro_link.'" target="_blank">'.$credit_text.'</a></p>';
        }
        
        
        //output all shortcode parameters
        $str_body .= '<div class="bsk-pdfm-pdfs-shortcode-attr">';
        foreach( $shortcode_atts as $attr_name => $attr_val ){
            $str_body .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="'.$attr_val.'" />';
        }
        $ajax_nonce = wp_create_nonce( "pdfs-ajax-get" );
        $str_body .= '<input type="hidden" class="bsk-pdfm-pdfs-ajax-nonce" value="'.$ajax_nonce.'">';
        $str_body .= BSKPDFMPro_Statistics_Download_Count::bsk_pdfm_statistics_get_ajax_nonce();
        $str_body .= '<!-- //bsk-pdfm-pdfs-shortcode-attr -->';
        $str_body .= '</div>';
        
        $str_body .= '</div><!-- //end for bsk-pdfm-output-container-->';

        return $str_body;
	} //end of function
    
    function bsk_pdfm_ajax_get_pdfs_ul_ol(){
        if( !check_ajax_referer( 'pdfs-ajax-get', 'nonce', false ) ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Security check!</p>' );
            wp_die( json_encode( $return_array ) );
        }
        $license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Invalid license!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        //read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
            if( $default_enable_featured_image && isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
		}
        
        $shortcode_atts = array(  
                                           'ul_or_ol' => $_POST['layout'],
                                           'paged' => $_POST['paged'],
                                           'id' => $_POST['id'],
                                           'exclude_id' => $_POST['exclude_id'],
                                           'year_of' => $_POST['year_of'], //work when 'id'="all", 9999 means most recent, length = 4
                                           'month_of' => $_POST['month_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'day_of' => $_POST['day_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'weekday_of' => $_POST['weekday_of'], //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                           'search_bar' => $_POST['search_bar'],  //work when id="all"
                                           'keywords' => $_POST['keywords'],
                                           'order_by' => $_POST['order_by'],
                                           'order' => $_POST['order'],
                                           'target' => $_POST['target'],
                                           'show_description' => $_POST['show_description'],
                                           'featured_image' => $_POST['featured_image'],
                                           'featured_image_size' => $_POST['featured_image_size'],
                                           'image_position' => $_POST['image_position'],
                                           'show_pdf_title' => $_POST['show_pdf_title'],
                                           'nofollow_tag' => $_POST['nofollow_tag'],
                                           'show_date' => $_POST['show_date'],
                                           'date_format' => $_POST['date_format'],
                                           'date_before_title' => $_POST['date_before_title'],
                                           'date_weekday_filter' => $_POST['date_weekday_filter'],
                                           'date_weekday_filter_order' => $_POST['date_weekday_filter_order'],
                                           'date_weekday_filter_right' => $_POST['date_weekday_filter_right'],
                                           'pdfs_per_page' => $_POST['pdfs_per_page'],
                                           'most_top' => $_POST['most_top']
                                          );
        $ul_or_ol = strtoupper($shortcode_atts['ul_or_ol']) == 'OL' ? 'ol' : 'ul';
        //show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//organise ids array
		$ids_array = array();
        $show_all_pdfs = false;
		if( trim($shortcode_atts['id']) == "" ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">No PDFs id!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        if( strtoupper(trim($shortcode_atts['id'])) == 'ALL' ){
            $show_all_pdfs = true;  
        }else if( is_string($shortcode_atts['id']) ){
			$ids_array = explode(',', $shortcode_atts['id']);
			foreach($ids_array as $key => $pdf_id){
				$pdf_id = intval(trim($pdf_id));
				if( $pdf_id < 1 ){
					unset($ids_array[$key]);
                    continue;
				}
				$ids_array[$key] = $pdf_id;
			}
		}
        
		if( ( !is_array($ids_array) || count($ids_array) < 1 ) && $show_all_pdfs == false ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Invalid PDFs id!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        
        //exclude ids
        $exclude_ids_array = null;
        if( trim($shortcode_atts['exclude_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_ids_array[] = intval( $pdf_id );
                }
            }
        }

		//process open target
		$open_target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$open_target_str = ' target="_blank"';
		}
        
        //featured image
		$featured_image = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('featured_image', $shortcode_atts);
		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$featured_image = false;
		}
		//show pdf title with featured imaged
		$show_pdf_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_pdf_title', $shortcode_atts);
        //featurec image size
		$featured_image_size = $default_thumbnail_size;
        if( trim($shortcode_atts['featured_image_size']) ){
            $featured_image_size = trim($shortcode_atts['featured_image_size']);
        }
        $image_position = 'left';
        if( trim($shortcode_atts['image_position']) && trim($shortcode_atts['image_position']) == 'right' ){
            $image_position = trim($shortcode_atts['image_position']);
        }

		//anchor nofollow tag
		$nofollow_tag = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('nofollow_tag', $shortcode_atts);
        if( $nofollow_tag ){
            $nofollow_tag = ' rel="nofollow"';
        }
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}

        //process pagination
        $pdfs_per_page = intval( $shortcode_atts['pdfs_per_page'] );
        $paged = intval( $shortcode_atts['paged'] );
        $pagination = $pdfs_per_page > 0 ? true : false;
        if( $show_all_pdfs == false ){
            //disble pagination for some special situations
            $pagination = false;
        }

        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        $query_args = array();
        $query_args['show_all_pdfs'] = $show_all_pdfs;
        $query_args['ids_array'] = $ids_array;
        $query_args['exclude_ids_array'] = $exclude_ids_array;
        $query_args['year_of'] = $year_of;
        $query_args['month_of'] = $month_of;
        $query_args['day_of'] = $day_of;
        $query_args['weekday_of'] = $weekday_of;
        $query_args['pagination'] = $pagination;
        $query_args['pdfs_per_page'] = $pdfs_per_page;
        $query_args['paged'] = $paged;
        $query_args['keywords'] = $shortcode_atts['keywords'];
        $query_args['order_by'] = $shortcode_atts['order_by'];
        $query_args['order'] = $shortcode_atts['order'];
        $query_args['most_top'] = $shortcode_atts['most_top'];

        $pdfs_query_return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs( $query_args );
        if( !$pdfs_query_return || !is_array($pdfs_query_return) || count($pdfs_query_return) < 1 ){
            
            $data_to_return = array( 'pdfs' => '', 'date_filter' => '', 'pagination' => '', 'pdfs_count' => 0, 'results_desc' => 'No results found' );
            wp_die( json_encode( $data_to_return ) );
        }
        
        $pdfs_results_array = $pdfs_query_return['pdfs'];
        $total_pages = $pdfs_query_return['pages'];
        $total_pdfs = $pdfs_query_return['total'];

        //show date filter
        $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
        $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
        $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
        $date_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                        $pdfs_results_array, 
                                                                                                        $date_weekday_filter, 
                                                                                                        $date_weekday_filter_order, 
                                                                                                        $date_weekday_filter_right 
                                                                                                    );
        
        $pdfs_str = BSKPDFMPro_Common_Display::display_pdfs_in_ul_or_ol(
                                                                                                     $ul_or_ol,
                                                                                                     true,
                                                                                                     'bsk-pdfm-pdfs-'.$ul_or_ol.'-list',
                                                                                                     $pdfs_results_array, 
                                                                                                     $show_description,
                                                                                                     $featured_image, $featured_image_size, $show_pdf_title,
                                                                                                     $default_thumbnail_html, $image_position,
                                                                                                     $open_target_str, $nofollow_tag, 
                                                                                                     $show_date, $date_format_str, $date_before_title,
                                                                                                     'h3'
                                                                                                    );
        
        //show pagination only for when show all PDFs
        $pagination_str = '';
        if( $total_pages > 1 ){
            $pagination_str .= BSKPDFMPro_Common_Pagination::bsk_pdf_show_pagination( 
                                                                                                                        $total_pdfs, 
                                                                                                                        $pdfs_per_page, 
                                                                                                                        $paged
                                                                                                                       );
        }
        
        //total_pdfs only have valid value when pagination enabled so
        $pdfs_count = $total_pages > 1 ? $total_pdfs : count( $pdfs_results_array );
        $results_desc_str = $pdfs_count > 1 ? $pdfs_count.' records found' : $pdfs_count.' record found';
        $data_to_return = array( 
                                            'pdfs' => $pdfs_str, 
                                            'date_filter' => $date_filter_str, 
                                            'pagination' => $pagination_str, 
                                            'pdfs_count' => $pdfs_count,
                                            'results_desc' => $results_desc_str
                                          );
        wp_die( json_encode( $data_to_return ) );
        
    } //end of function
    
}//end of class