<?php

class BSKPDFMPro_Shortcodes_Category {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    public $_category_OBJ_dropdown = NULL;
    public $_category_OBJ_ul_ol = NULL;
    public $_category_OBJ_columns = NULL;
    
	public function __construct() {
        require_once( 'category-functions.php' );
        
        require_once( 'category-dropdown.php' );
        require_once( 'category-ul-ol.php' );
        require_once( 'category-columns.php' );
        
        $this->_category_OBJ_dropdown = new BSKPDFMPro_Shortcodes_Category_Dropdown();
        $this->_category_OBJ_ul_ol = new BSKPDFMPro_Shortcodes_Category_UL_OL();
        $this->_category_OBJ_columns = new BSKPDFMPro_Shortcodes_Category_Columns();
	}
}