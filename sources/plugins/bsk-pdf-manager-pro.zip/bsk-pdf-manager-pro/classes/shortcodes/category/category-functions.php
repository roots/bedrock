<?php

class BSKPDFMPro_Shortcodes_Category_Functions {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    public static $_shortcode_category_atts = array(
                                                                        'id' => '',
                                                                        'exclude_id' => '',
                                                                        'password_required' => 'no',
                                                                        'hierarchical' => 'no',
                                                                        'cat_order_by' => '',
                                                                        'cat_order' => '',
                                                                        'show_cat_title' => '',
                                                                        'show_cat_description' => 'no',
                                                                        /* >>>>>only for a single Category */
                                                                        'hide_empty_cat' => 'no',
                                                                        'show_cat_empty_message' => 'no',
                                                                        /* only for a single Category<<<<<< */
                                                                        'sub_cat_indent' => 'yes',
                                                                       );
    public static $_shortcode_pdfs_atts = array(
                                                                'exclude_pdf_id' => '',
                                                                'order_by' => '',
                                                                'order' => '',
                                                                'target' => '',
                                                                'most_top' => 0,
                                                                'year_of' => '0000', //work when 'id'="all", 9999 means most recent, length = 4
                                                                'month_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                                'day_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                                'weekday_of' => 'no', //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                                                'show_description' => '',
                                                                'featured_image' => '',
                                                                'featured_image_size' => '',
                                                                'image_position' => 'left',
                                                                'show_pdf_title' => 'no',
                                                                'nofollow_tag' => 'no',
                                                                'show_date' => 'no',
                                                                'date_before_title' => 'no',
                                                                'date_format' => ' d/m/Y'
                                                                );
    public static $_shortcode_searchbar_atts = array(
                                                                        'search_bar' => 'no',
                                                                        'search_bar_year_range' => '',
                                                                        'search_bar_year_order' => '',
                                                                        'keywords' => '',
                                                                        );
    public static $_shortcode_date_weekday_filter_atts = array(
                                                                                        'date_weekday_filter' => '',
                                                                                        'date_weekday_filter_order' => '',
                                                                                        'date_weekday_filter_right' => 'no',
                                                                                       );
    public static $_shortcode_pagination_atts = array(
                                                                            'pdfs_per_page' => 0,
                                                                            'paged' => 1,
                                                                         );
    public static $_shortcode_output_container_atts = array(
                                                                                    'output_container_class' => '',
                                                                                  );
    
	public function __construct() {
        
	}
    
    public static function process_bool_attr_val( $attr_val) {
        $return_bool = false;
        if( is_string( $attr_val ) ){
			$return_bool = strtoupper($attr_val) == "YES" ? true : false;
			if( $return_bool == false ){
				$return_bool = strtoupper($attr_val) == 'TRUE' ? true : false;
			}
		}else if( is_bool($attr_val) ){
			$return_bool = $attr_val;
		}

        return $return_bool;
    }
    
    public static function process_shortcode_parameters( $shortcode_atts ){
        
        //read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
        $default_column_number = 2;
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}

            if( isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
            
            if( isset($plugin_settings['default_column_number']) && $plugin_settings['default_column_number'] > 0 ){
				$default_column_number = $plugin_settings['default_column_number'];
			}
		}
        
        $processed = array();
        foreach( $shortcode_atts as $key => $val ){
            $attr_val = trim( $val );
            switch( $key ){
                case 'id':
                    if( strtoupper( $attr_val ) == 'ALL' ){
                        $processed['id'] = 'ALL';
                    }else{
                        $temp_array = explode(',', $attr_val);
                        $temp_valid_array = array();
                        if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                            foreach( $temp_array as $temp_cat_id ){
                                $temp_valid_array[] = absint( $temp_cat_id );
                            }
                        }
                        $processed['id'] = implode( ',', $temp_valid_array );
                    }
                break;
                case 'shortcode_only_single':
                    $processed['shortcode_only_single'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'exclude_id':
                    $temp_valid_array = array();
                    if( $attr_val ){
                        $temp_array = explode(',', $attr_val);
                        if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                            foreach( $temp_array as $temp_cat_id ){
                                $temp_valid_array[] = absint( $temp_cat_id );
                            }
                        }
                    }
                    $processed['exclude_id'] = implode( ',', $temp_valid_array );
                break;
                case 'password_required':
                    $processed['password_required'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'hierarchical':
                    $processed['hierarchical'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'cat_order_by':
                    $cat_order_by_str = ' C.`title`';
                    if( $attr_val == 'date' || $shortcode_atts['cat_order_by'] == 'last_date' ){
                        $cat_order_by_str = ' C.`last_date`';
                    }
                    $processed['cat_order_by'] = $cat_order_by_str;
                break;
                case 'cat_order':
                    $cat_order_str = ' ASC';
                    if( strtoupper(trim($attr_val)) == 'DESC' ){
                        $cat_order_str = ' DESC';
                    }
                    $processed['cat_order'] = $cat_order_str;
                break;
                case 'show_cat_title':
                    $processed['show_cat_title'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'show_cat_description':
                    $processed['show_cat_description'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'hide_empty_cat':
                    $processed['hide_empty_cat'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'show_cat_empty_message':
                    $processed['show_cat_empty_message'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'sub_cat_indent':
                    $processed['sub_cat_indent'] = self::process_bool_attr_val( $attr_val );
                break;
                /*
                  * for PDFs
                  */
                case 'exclude_pdf_id':
                    $exclude_pdf_ids_array = array();
                    $temp_array = explode( ',', $attr_val );
                    if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                        foreach( $temp_array as $pdf_id ){
                            $exclude_pdf_ids_array[] = absint( trim($pdf_id) );
                        }
                    }
                    $processed['exclude_pdf_id'] = implode( ',', $exclude_pdf_ids_array );
                break;
                case 'order_by':
                    $processed['order_by'] = $attr_val;
                break;
                case 'order':
                    $processed['order'] = strtoupper($attr_val) == 'DESC' ? 'DESC' : 'ASC';
                break;
                case 'target':
                    $processed['target'] = $attr_val == '_blank' ? ' _blank' : '';
                break;
                case 'most_top':
                    $processed['most_top'] = absint( $attr_val );
                break;
                case 'year_of':
                    $processed['year_of'] = BSKPDFMPro_Common_Display::validate_year( $attr_val );
                break;
                case 'month_of':
                    $processed['month_of'] = BSKPDFMPro_Common_Display::validate_month( $attr_val );
                break;
                case 'day_of':
                    $processed['day_of'] = BSKPDFMPro_Common_Display::validate_day( $attr_val );
                break;
                case 'weekday_of':
                    $processed['weekday_of'] = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $attr_val );
                break;
                case 'show_description':
                    $processed['show_description'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'featured_image':
                    $processed['featured_image'] = self::process_bool_attr_val( $attr_val );
                    if( $default_enable_featured_image == false ){
                       $processed['featured_image'] = false;
                    }
                break;
                case 'featured_image_size':
                    $processed['featured_image_size'] = $attr_val;
                break;
                case 'image_position':
                    $processed['image_position'] = $attr_val == 'right' ? 'right' : 'left';
                break;
                case 'show_pdf_title':
                    $processed['show_pdf_title'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'nofollow_tag':
                    $processed['nofollow_tag'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'show_date':
                    $processed['show_date'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'date_before_title':
                    $processed['date_before_title'] = self::process_bool_attr_val( $attr_val );
                break;
                case 'date_format':
                    $date_format_str = $processed['date_before_title'] ? 'd/m/Y ' : ' d/m/Y';
                    if( $val != ' d/m/Y' ){
                        $date_format_str = $val;
                    }
                    $processed['date_format'] = $date_format_str;
                break;
                /*
                  * for Searchbar
                  */
                case 'search_bar':
                    $search_bar = strtoupper( $attr_val );
                    if( $search_bar != 'YES' && 
                        $search_bar != 'KEYWORDS' && 
                        $search_bar != 'YEAR_KEYWORDS' &&
                        $search_bar != 'CATEGORY_YEAR_KEYWORDS' ){

                        $search_bar = false;
                    }
                    $search_bar = $search_bar == 'YES' ? 'KEYWORDS' : $search_bar;
                    $processed['search_bar'] = $search_bar;
                break;
                case 'search_bar_year_range':
                    $processed['search_bar_year_range'] = $attr_val;
                break;
                case 'search_bar_year_order':
                    $processed['search_bar_year_order'] = $attr_val;
                break;
                case 'keywords':
                    $processed['keywords'] = trim( $attr_val );
                break;
                /*
                  * for date_weekday_filter
                  */
                case 'date_weekday_filter':
                    $processed['date_weekday_filter'] = $attr_val ? $attr_val : false;
                break;
                case 'date_weekday_filter_order':
                    $processed['date_weekday_filter_order'] = $attr_val ? $attr_val : false;
                break;
                case 'date_weekday_filter_right':
                    $processed['date_weekday_filter_right'] = self::process_bool_attr_val( $attr_val );
                break;
                /*
                  * for pagination
                  */
                case 'pdfs_per_page':
                    $processed['pdfs_per_page'] = absint( $attr_val );
                    $processed['pagination'] = $processed['pdfs_per_page'] ? true : false;
                break;
                case 'paged':
                    $processed['paged'] = absint( $attr_val );
                break;
                /*
                  * for output_container
                  */
                case 'output_container_class':
                    $processed['output_container_class'] = $attr_val;
                break;
                /*
                  * for columns
                  */
                case 'columns':
                    $attr_val = absint( $attr_val );
                    if( $attr_val > 6 || $attr_val < 1 ){
                        $attr_val = $default_column_number;
                    }
                    $processed['columns'] = absint( $attr_val );
                break;
                case 'pdf_title_position':
                    $attr_val = $attr_val == 'above' ? 'above' : 'below';
                    $processed['pdf_title_position'] = $attr_val;
                break;
                default:
                    $processed[$key] = $attr_val;
                break;
            }
        }

        if( $processed['most_top'] > 0 ){
            //disble pagination for some special situations
            $processed['pagination'] = false;
        }

        /*
          * additional parameters
          */
        if( isset( $processed['ul_or_ol'] ) ){
            $processed['ul_or_ol'] = trim($shortcode_atts['ul_or_ol']) == 'ol' ? 'ol' : 'ul';
        }
        $processed['default_thumbnail_html'] = $default_thumbnail_html;
        
        
        /*
          category password array only exist when in Ajax call
        */
        $categories_password_array = array();
        if( isset($shortcode_atts['category_password']) && $shortcode_atts['category_password'] ){
            $temp_array = explode( ',', $shortcode_atts['category_password'] );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $cat_n_password ){
                    $cat_n_password_array = explode( ':', $cat_n_password );
                    if( !$cat_n_password_array || !is_array( $cat_n_password_array ) || count( $cat_n_password_array ) != 2 ){
                        continue;
                    }
                    $cat_id = absint( $cat_n_password_array[0] );
                    $password = preg_replace( '%[^0-9a-zA-Z]%', '', $cat_n_password_array[1] );
                    $categories_password_array[$cat_id] = $password;
                }
            }
        }
        $processed['category_password_array'] = $categories_password_array;
        
        return $processed;
    }
    
    public static function get_shortcode_parameters_output( $processed_shortcode_parameters ){
        $shortcode_parameters_str = '';
        //output all shortcode parameters
        foreach( $processed_shortcode_parameters as $attr_name => $attr_val ){
            if( $attr_name == 'default_thumbnail_html' ){
                $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="" />';
                continue;
            }
            $attr_val_str = $attr_val;
            if( is_array( $attr_val ) ){
                $attr_val_str = count( $attr_val ) > 0 ? implode(',', $attr_val_str) : '';
            }else if( is_bool( $attr_val ) ){
                $attr_val_str = $attr_val ? 'YES' : 'NO';
            }

            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="'.$attr_val_str.'" />';
        }
        
        if( $processed_shortcode_parameters['password_required'] ){
            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr category-password-hidden-feild" data-attr_name="category_password" value="" />';
        }
        
        return $shortcode_parameters_str;
    }
}