<?php

class BSKPDFMPro_Dashboard_FTP {

    private $_file_upload_message = array();

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
	public function __construct() {
		global $wpdb;
		
		$this->bsk_pdf_manager_init_message();

		add_action( 'admin_notices', array($this, 'bsk_pdf_manager_admin_notice') );

		add_action( 'bsk_pdf_manager_pdf_upload_by_ftp', array($this, 'bsk_pdf_manager_padf_upload_by_ftp_save_fun') );
	}
	
	function bsk_pdf_manager_init_message(){

        $this->_file_upload_message[41] = array( 'message' => 'Upload file by FTP results:', 
												 'type' => 'WARNING');				
	}
	
	function bsk_pdf_manager_admin_notice(){
		$current_page = isset($_REQUEST['page']) ? $_REQUEST['page'] : '';
		if( !$current_page || !in_array($current_page, BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages) ){
			return;
		}
		
		$message_id = isset($_REQUEST['message']) ? $_REQUEST['message'] : 0;
		if( !$message_id ){
			return;
		}
		if( !isset($this->_file_upload_message[ $message_id ]) ){
			return;
		}
		
		$type = $this->_file_upload_message[ $message_id ]['type'];
		$msg_to_show = $this->_file_upload_message[ $message_id ]['message'];
		if( !$msg_to_show ){
			return;
		}
		$msg_to_show = '<p>'.$msg_to_show.'</p>';
		if( in_array( $message_id, array(41) ) ){
			$msg_to_show .= '<p>'.get_option( BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_'.$message_id ).'</p>';
		}else{
            return;
        }
		
		//admin message
		if( $type == 'WARNING' ){
			echo '<div class="updated">';
			echo $msg_to_show;
			echo '</div>';
		}else if( $type == 'ERROR' ){
			echo '<div class="error">';
			echo $msg_to_show;
			echo '</div>';
		}
	}

	function bsk_pdf_manager_current_user_can(){
		global $current_user;
		
		if ( current_user_can('level_3') ){
			return true;
		}else{
			/*
			//get role;
			$user_roles = $current_user->roles;
			$user_role = array_shift($user_roles);
			
			if ($user_role == 'spcial role'){
				return true;
			}
			*/
		}
		return false;
	}
	
	function bsk_pdf_manager_pdfs_add_by_ftp(){
		global $current_user, $wpdb;
		
		if (!$this->bsk_pdf_manager_current_user_can()){
			wp_die( __('You do not have sufficient permissions to access this page.') );
		}
		
		//get all categories
		$sql = 'SELECT COUNT(*) FROM '.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name;
		if( $wpdb->get_var( $sql ) < 1 ){
			$create_category_url = add_query_arg( 'page', BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['category'], admin_url() );
			$create_category_url = add_query_arg( 'view', 'addnew', $create_category_url );
			echo 'Please <a href="'.$create_category_url.'">create category</a> first';
			
			return;
		}
						
		$maximum_of_list = 50;
		$pdf_files_under_ftp_folder = array();
		$ftp_folder  = opendir( BSKPDFManagerPro::$_upload_path.BSKPDFManagerPro::$_upload_folder_4_ftp );
		$item_filename = 0;
		while (false !== ($filename = readdir($ftp_folder))) {
			if( $filename == '.' ||
			    $filename == '..' ||
				$filename == 'index.php' ){
				continue;
			}
			
            $ext_n_type = wp_check_filetype( $filename );
            $supported_extension_and_mime_type = BSKPDFMPro_Common_Backend::get_supported_extension_with_mime_type();
            if( !array_key_exists( strtolower($ext_n_type['ext']), $supported_extension_and_mime_type) ){
                continue;
            }
            if( !in_array( $ext_n_type['type'], $supported_extension_and_mime_type[strtolower($ext_n_type['ext'])] ) ){
                continue;
            }
            
			$item_filename++;
            $timestamp_of_last_modify = filemtime( BSKPDFManagerPro::$_upload_path.BSKPDFManagerPro::$_upload_folder_4_ftp.$filename );
			$pdf_files_under_ftp_folder[] = array( 'name' => $filename, 'date' => date( 'Y-m-d', $timestamp_of_last_modify ) );
			if( $maximum_of_list <= $item_filename ){
				break;
			}
		}
        
        $plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
        $supported_extension = false;
        if( isset($plugin_settings['supported_extension']) ){
            $supported_extension = $plugin_settings['supported_extension'];
        }
        if( !$supported_extension || !is_array($supported_extension) || !in_array( 'pdf', $supported_extension ) ){
            $supported_extension = array( 'pdf' );
        }
        
		$upload_folder_4_ftp_display = str_replace( ABSPATH, '', BSKPDFManagerPro::$_upload_path.BSKPDFManagerPro::$_upload_folder_4_ftp );
        
		echo '  <p style="margin-top:30px;">Please uplaod all you documents( '.implode(', ', $supported_extension ).' ) to the folder <b>'.$upload_folder_4_ftp_display.'</b> first.</p>';
		echo '  <p>After upload, your documents will be moved out from this folder.<p>';
		echo '  <p>To avoid time out error on your server the maximum of documents that can be listed here is '.$maximum_of_list.'. It means you may import max 50 documents every time but you may come to here any time.</p>';
		?>
        <table class="widefat" style="width:60%;">
		<thead>
			<tr>
				<td class="check-column" style="width:15%; padding-left:10px;"><input type='checkbox' /></td>
				<td style="width:55%;">File</td>
                <td style="width:30%;">Last Modify</td>
			</tr>
		</thead>
		<tbody>
        	<?php
			if( count($pdf_files_under_ftp_folder) < 1 ){
			?>
            <tr class="alternate">
				<td colspan="3">No valid PDF files found</td>
			</tr>
			<?php
            }else{
				$i = 1;
				foreach( $pdf_files_under_ftp_folder as $file_obj ){
					$class_str = '';
					if( $i % 2 == 1 ){
						$class_str = ' class="alternate"';
					}
			?>
                <tr<?php echo $class_str; ?>>
                    <th class='check-column' style="padding-left:10px;"><input type='checkbox' name='bsk_pdf_manager_ftp_files[]' value='<?php echo esc_attr($file_obj['name']) ?>' style="padding:0; margin:0;" /></th>
                    <td><label><?php echo esc_html($file_obj['name']) ?></label></td>
                    <td><label><?php echo esc_html($file_obj['date']) ?></label></td>
                </tr>
        	<?php
					$i++;
				}
			}
			?>
		</tbody>
		<tfoot>
			<tr>
				<td class="check-column" style="padding-left:10px;"><input type='checkbox' /></td>
				<td>File</td>
                <td>Last Modify</td>
			</tr>
		</tfoot>
		</table>
		<?php
		if( count($pdf_files_under_ftp_folder) > 0 ){
		?>
        <h3>Category</h3>
		<?php
        echo BSKPDFMPro_Common_Backend::get_category_hierarchy_checkbox( 'bsk_pdf_manager_ftp_categories[]', 'bsk-pdfm-ftp-category-checkbox', NULL );
		$nonce = wp_create_nonce( 'bsk_pdf_manager_pdf_upload_by_ftp_nonce' );
        ?>
        <hr />
        <h3>Settings</h3>
        <p>
        	<label>
            	<input type="checkbox" name="bsk_pdf_manager_ftp_use_file_name_as_title" id="bsk_pdf_manager_ftp_use_file_name_as_title_ID" />Use file name as title
            </label>
        </p>
        <p id="bsk_pdf_manager_ftp_pdf_title_exclude_extension_container_ID" style="display:none;">
            	<span class="bsk-pdfm-field-label">Exclude extension(.pdf) from title:</span>
                <span class="bsk-pdf-field">
                    <label><input type="radio" name="bsk_pdf_manager_ftp_pdf_exclude_extension_from_title" value="YES" /> Yes</label>
                    <label style="margin-left:20px;"><input type="radio" name="bsk_pdf_manager_ftp_pdf_exclude_extension_from_title" value="NO" checked="checked" /> No</label>
                </span>
        </p>
        <p>
        	<label>
            	<input type="checkbox" name="bsk_pdf_manager_ftp_use_last_modify_as_date" />Use file last modify as date
            </label>
        </p>
		<p style="margin-top:20px;">
        	<input type="hidden" name="nonce" value="<?php echo $nonce; ?>" />
        	<input type="hidden" name="bsk_pdf_manager_action" value="pdf_upload_by_ftp" />
        	<input type="button" id="bsk_pdf_manager_add_by_ftp_save_button_ID" class="button-primary" value="Upload..." />
        </p>
        <?php
		}
	}
	
	function bsk_pdf_manager_padf_upload_by_ftp_save_fun( $data ){
		global $wpdb;
		//check nonce field
		if( !wp_verify_nonce( $data['nonce'], 'bsk_pdf_manager_pdf_upload_by_ftp_nonce' ) ){
			return;
		}
		if( !isset($data['bsk_pdf_manager_ftp_files']) ||
			!is_array($data['bsk_pdf_manager_ftp_files']) || 
			count($data['bsk_pdf_manager_ftp_files']) < 1 ||
			!isset($data['bsk_pdf_manager_ftp_categories']) ||
			!is_array($data['bsk_pdf_manager_ftp_categories']) || 
			count($data['bsk_pdf_manager_ftp_categories']) < 1 ){
				
			return;
		}
		
        $_upload_folder_4_ftp_full_path = BSKPDFManagerPro::$_upload_path.BSKPDFManagerPro::$_upload_folder_4_ftp;
        $default_upload_path = BSKPDFManagerPro::$_upload_path.BSKPDFManagerPro::$_upload_folder;
        $custom_upload_path = BSKPDFManagerPro::$_custom_upload_folder_path;
        $current_upload_path = $custom_upload_path ? $custom_upload_path : $default_upload_path; 
        //save pdf by year/month
        $organise_directory_strucutre_with_year_month = true;
        $plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
        if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
            if( isset($plugin_settings['directory_with_year_month']) ){
                $organise_directory_strucutre_with_year_month = $plugin_settings['directory_with_year_month'];
			}
		}
		//save pdf by year/month
        $year = date( 'Y', current_time('timestamp') );
        $month = date( 'm', current_time('timestamp') );
        if( $organise_directory_strucutre_with_year_month ){
            if ( !is_dir($current_upload_path.$year) ) {
                if ( !wp_mkdir_p( $current_upload_path.$year ) ) {
                    $message_id = 31;
                    update_option( BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_31', 'Create folder: '.$current_upload_path.$year.'/ failed.');
                    return false;
                }
            }
            if ( !is_writeable( $current_upload_path.$year ) ) {
                update_option( BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_32', 
                                       'Directory: '.$current_upload_path.$year.'/ not writable.');
                $message_id = 32;
                return false;
            }
            if ( !is_dir($current_upload_path.$year.'/'.$month) ) {
                if ( !wp_mkdir_p( $current_upload_path.$year.'/'.$month ) ) {
                    $message_id = 33;
                    update_option( BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_33', 
                                           'Create folder: '.$current_upload_path.$year.'/'.$month.'/ failed.'
                                        );
                    return false;
                }
            }
            if ( !is_writeable( $current_upload_path.$year.'/'.$month ) ) {
                update_option( 
                                        BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_34', 
                                        'Directory: '.$current_upload_path.$year.'/'.$month.'/ not writable.'
                                    );
                $message_id = 34;
                return false;
            }
            if( !file_exists($current_upload_path.$year.'/'.$month.'/index.php') ){
                copy( 
                        BSK_PDFM_PRO_PLUGIN_DIR.'/assets/index.php',
                        $current_upload_path.$year.'/'.$month.'/index.php' );
            }
        }
        
		$move_file_success = array();
		$move_file_failed = array();
		
		//insert pdf into database & move file to destination
		foreach( $data['bsk_pdf_manager_ftp_files'] as $pdf_ftp_file ){
            $original_file_path = $_upload_folder_4_ftp_full_path.$pdf_ftp_file;
			//check if PDF name is unicode or not
			$destinate_file_name = wp_unique_filename( $current_upload_path, $pdf_ftp_file);
            $destinate_file_path = $current_upload_path.$destinate_file_name;
            $return_destinate_name = str_replace( ABSPATH, '', $destinate_file_path );
            if( $organise_directory_strucutre_with_year_month ){
                $destinate_file_name = wp_unique_filename( $current_upload_path.$year.'/'.$month.'/', $pdf_ftp_file);
                $destinate_file_path = $current_upload_path.$year.'/'.$month.'/'.$destinate_file_name;
                $return_destinate_name = str_replace( ABSPATH, '', $destinate_file_path );
            }
			//move file
			$ret = rename($original_file_path, $destinate_file_path);
			if( !$ret ){
				$move_file_failed[] = $pdf_ftp_file;
				continue;
			}
			
			$pdf_ftp_title_array = explode( '.', $pdf_ftp_file );
			unset( $pdf_ftp_title_array[count($pdf_ftp_title_array) - 1] );
			
			$pdf_data = array();
			$pdf_data['cat_id'] = '999999';
			$pdf_data['title'] = implode('.', $pdf_ftp_title_array);
			$data['pdf_date'] = '';
			if( isset($data['bsk_pdf_manager_ftp_use_file_name_as_title']) ){
				$pdf_data['title'] = $pdf_ftp_file;
				if( $data['bsk_pdf_manager_ftp_pdf_exclude_extension_from_title'] == 'YES' ){
					$pdf_data['title'] = implode('.', $pdf_ftp_title_array);
				}
			}
            if( isset($data['bsk_pdf_manager_ftp_use_last_modify_as_date']) ){
				$pdf_data['last_date'] = date( 'Y-m-d H:i:s', filemtime($destinate_file_path) );
			}else{
                $pdf_data['last_date'] = trim($data['pdf_date']) ? trim($data['pdf_date']).' 00:00:00' : date('Y-m-d 00:00:00', current_time('timestamp'));
            }
            
			$pdf_data['file_name'] = $return_destinate_name;
			
			//insert
			$return = $wpdb->insert( $wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name, $pdf_data, array('%s', '%s', '%s', '%s') );
			if ( !$return ){
				$move_file_failed[] = $pdf_ftp_file;
				continue;
			}
            $pdf_id = $wpdb->insert_id;
            
            //update pdf categories
            if( isset($data['bsk_pdf_manager_ftp_categories']) && 
                is_array($data['bsk_pdf_manager_ftp_categories']) && 
                count($data['bsk_pdf_manager_ftp_categories']) > 0 ){
                
                foreach( $data['bsk_pdf_manager_ftp_categories'] as $cat_id ){
                    $wpdb->insert( 
                                           $wpdb->prefix.BSKPDFManagerPro::$_rels_tbl_name, 
                                           array( 'cat_id' => $cat_id, 'pdf_id' => $pdf_id ), 
                                           array('%d', '%d') 
                                         );
                }
            }
			$move_file_success[] = $pdf_ftp_file; 
		}
		
		$message = count($move_file_success).' file(s) have been uploaded succesfully';
		if( count($move_file_failed) > 0 ){
			$message .= ', '.count($move_file_failed).' failed.';
		}
		
		update_option( BSKPDFManagerPro::$_plugin_temp_option_prefix.'message_id_41', $message);
		$message_id = 41;
		$redirect_to = admin_url( 'admin.php?page='.BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['add_by_ftp'].'&message='.$message_id  );
		wp_redirect( $redirect_to );
		exit;
	}
}