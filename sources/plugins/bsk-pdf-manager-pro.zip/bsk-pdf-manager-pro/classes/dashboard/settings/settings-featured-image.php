<?php

class BSKPDFMPro_Dashboard_Settings_Featured_Image {
	
	private static $_bsk_pdf_settings_page_url = '';
	   
	public function __construct() {
		
		self::$_bsk_pdf_settings_page_url = admin_url( 'admin.php?page='.BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['setting'] );
		
		add_action( 'bsk_pdf_manager_featured_image_settings_save', array($this, 'bsk_pdf_manager_settings_featured_image_tab_save_fun') );
        add_action( 'wp_ajax_bsk_pdf_manager_settings_get_default_featured_image', array($this, 'bsk_pdf_manager_get_post_thumbnail_fun') );
	}

	function show_settings( $plugin_settings ){
		$default_enable_featured_image = true;
		$default_thumbnail_id = 0;
		$register_image_size_1 = array();
		$register_image_size_2 = array();
		$default_thumbnail_size = 'thumbnail';

		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_id']) ){
				$default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
			}
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
			if( isset($plugin_settings['register_image_size']) && 
				isset($plugin_settings['register_image_size']['size_1']) && 
				count($plugin_settings['register_image_size']['size_1']) > 0 ){
				$register_image_size_1 = $plugin_settings['register_image_size']['size_1'];
			}
			if( isset($plugin_settings['register_image_size']) && 
				isset($plugin_settings['register_image_size']['size_2']) && 
				count($plugin_settings['register_image_size']['size_2']) > 0 ){
				$register_image_size_2 = $plugin_settings['register_image_size']['size_2'];
			}
		}
        
        $default_feated_image_size_dimission = BSKPDFMPro_Common_Backend::get_image_size_dimission( $default_thumbnail_size );
	?>
    <form action="<?php echo self::$_bsk_pdf_settings_page_url ?>" method="POST" id="bsk_pdfm_featured_image_settings_form_ID">
    <div class="bsk_pdf_manager_settings_featured_image_tab" style="width:80%;">
        <p>
        	<label><input type="checkbox" name="bsk_pdf_manager_enable_featured_image" id="bsk_pdf_manager_enable_featured_image_ID" value="1" <?php echo $default_enable_featured_image ? 'checked="checked"' : '' ?> /> Enable featured image</label>
        </p>
        <div id="bsk_pdf_manager_featured_image_settings_containder_ID" style="display:<?php echo $default_enable_featured_image ? 'block' : 'none'; ?>">
            <h4>PDF Default Featured Image</h4>
            <p>
                <div id="postimagediv" class="postbox" style="width:95%;" >
                    <div class="inside" style="width: <?php echo $default_feated_image_size_dimission['width']; ?>px;">
                    <?php
                    $remove_container_display = "none";
                    $default_container_display = "block";
                    $thumbnail_html = '';
                    if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                    $remove_container_display = "inline-block";
                    $default_container_display = "none";
                    }
        
                    $ajax_loader_img_url = BSKPDFManagerPro::$_ajax_loader_img_url;
                    $default_pdf_icon_url = BSKPDFManagerPro::$_default_pdf_icon_url;
                    ?>
                    <p class="hide-if-no-js">
                        <span id="bsk_pdf_manger_default_image_icon_container_ID" style="display:<?php echo $default_container_display ?>"><img src="<?php echo $default_pdf_icon_url; ?>" /></span>
                        <a title="Set default featured image" href="javascript:void(0);" id="bsk_pdf_manager_set_default_featured_image_anchor_ID" >
                        <?php echo $thumbnail_html ? $thumbnail_html : 'Change default featured image'; ?>
                        </a>
                        <span id="bsk_pdf_manager_set_default_featured_image_ajax_loader_ID" style="display:none;"><img src="<?php echo $ajax_loader_img_url; ?>" /></span>
                    </p>
                    
                    <p class="hide-if-no-js">
                        <a href="javascript:void(0);" id="bsk_pdf_manager_remove_default_featured_image_anchor_ID" style="display:<?php echo $remove_container_display ?>">Remove default featured image</a>
                        <span id="bsk_pdf_manager_remove_default_featured_image_ajax_loader_ID" style="display:none;"><img src="<?php echo $ajax_loader_img_url; ?>" /></span>
                        </p>
                    </div>
                    <input type="hidden" name="bsk_pdf_manager_default_thumbnail_id" id="bsk_pdf_manager_default_thumbnail_id_ID" value="<?php echo $default_thumbnail_id; ?>" />
                </div>
            </p>
            <h4>Register Featured Image Size</h4>
            <?php
            $size_name = '';
            $size_width = '';
            $size_height = '';
            $size_crop_str = '';
            if( is_array($register_image_size_1) && count($register_image_size_1) > 0 ){
            $size_name = $register_image_size_1['name'];
            $size_width = $register_image_size_1['width'];
            $size_height = $register_image_size_1['height'];
            $size_crop_str = $register_image_size_1['crop'] ? ' checked="checked"' : '';
            }
            ?>
            <p>
                <span style="display:inline-bloc;">Name: <input type="text" name="bsk_pdf_manager_register_image_size_name_1" id="bsk_pdf_manager_register_image_size_name_1_ID" value="<?php echo $size_name; ?>" style="width:150px;" /> Width: <input type="number" name="bsk_pdf_manager_register_image_size_width_1" id="bsk_pdf_manager_register_image_size_width_1_ID" value="<?php echo $size_width; ?>" style="width:80px;" />px Height: <input type="number" name="bsk_pdf_manager_register_image_size_height_1"  id="bsk_pdf_manager_register_image_size_height_1_ID" value="<?php echo $size_height; ?>" style="width:80px;" />px
                </span>
                <span style="display:inline-block; margin-left:15px;"><label><input type="checkbox" name="bsk_pdf_manager_register_image_size_crop_1" id="bsk_pdf_manager_register_image_size_crop_1_ID" value="Yes"<?php echo $size_crop_str; ?> />Crop thumbnail to exact dimensions ?</label></span>
            </p>
            <?php
            $size_name = '';
            $size_width = '';
            $size_height = '';
            $size_crop_str = '';
            if( is_array($register_image_size_2) && count($register_image_size_2) > 0 ){
            $size_name = $register_image_size_2['name'];
            $size_width = $register_image_size_2['width'];
            $size_height = $register_image_size_2['height'];
            $size_crop_str = $register_image_size_2['crop'] ? ' checked="checked"' : '';
            }
            ?>
            <p>
                <span style="display:inline-bloc;">Name: <input type="text" name="bsk_pdf_manager_register_image_size_name_2" id="bsk_pdf_manager_register_image_size_name_2_ID" value="<?php echo $size_name; ?>" style="width:150px;" /> Width: <input type="number" name="bsk_pdf_manager_register_image_size_width_2" id="bsk_pdf_manager_register_image_size_width_2_ID" value="<?php echo $size_width; ?>" style="width:80px;" />px Height: <input type="number" name="bsk_pdf_manager_register_image_size_height_2" id="bsk_pdf_manager_register_image_size_height_2_ID" value="<?php echo $size_height; ?>" style="width:80px;" />px</span>
                <span style="display:inline-block; margin-left:15px;"><label><input type="checkbox" name="bsk_pdf_manager_register_image_size_crop_2" value="Yes"<?php echo $size_crop_str; ?> />Crop thumbnail to exact dimensions ?</label></span>
            </p>
            <h4>Default Featured Image Size</h4>
            <p>
                <select name="bsk_pdf_manager_default_thumbnail_size" id="bsk_pdf_manager_default_thumbnail_size_ID">
                <?php
                    $image_sizes = BSKPDFMPro_Common_Backend::get_image_sizes();
                    $hidden_dimission_str = '';
                    $hidden_registers_size_names_array = array();
                    $selected_width_str = '';
                    $selected_height_str = '';
                    $selected_crop_ste = 'Crop: No';
                    foreach ( $image_sizes as $size_name => $size_name_dimission )  {
                        if ( $size_name_dimission['width'] < 1 || 
                            $size_name_dimission['height'] < 1 || 
                            $size_name == 'bsk-pdf-dashboard-list-thumbnail' ){
                            continue;
                        }
                        $selected_str = '';
						$selected_crop_str = '';
                        if ( $default_thumbnail_size == $size_name ) {
                            $selected_str = 'selected="selected"';
                            $selected_width_str = 'Width: '.$size_name_dimission['width'].'px';
                            $selected_height_str = 'Height: '.$size_name_dimission['height'].'px';
                            $selected_crop_str = $size_name_dimission['crop'] ? 'Crop: Yes' : 'Crop: No';
                        }
                        echo '<option value="'.$size_name.'" '.$selected_str.'>'.$size_name.'</option>';
                        $crop = $size_name_dimission['crop'] ? 'Yes' : 'No';
                        $hidden_value = $size_name_dimission['width'].'_'.$size_name_dimission['height'].'_'.$crop;
                        $hidden_dimission_str .= '<input type="hidden" id="bsk_pdfm_size_dimission_'.$size_name.'_ID" value="'.$hidden_value.'" />';
                
                        //organise register sizes array, excude regsiter size by me
                        if( is_array($register_image_size_2) && count($register_image_size_2) > 0 ){
                            if( $size_name == $register_image_size_2['name'] ){
                                continue;
                            }
                        }
                        if( is_array($register_image_size_1) && count($register_image_size_1) > 0 ){
                            if( $size_name == $register_image_size_1['name'] ){
                                continue;
                            }
                        }
                        $hidden_registers_size_names_array[] = $size_name;
                    }
                
                    if( $default_thumbnail_size == 'full' ){
                        echo '<option value="full" selected="selected">full</option>';
                    }else{
                        echo '<option value="full">full</option>';
                    }
                ?>
                </select>
                <span style="display:inline-block; margin-left:20px;" id="bsk_pdf_manager_dft_size_width_span_ID"><?php echo $selected_width_str; ?></span>
                <span style="display:inline-block; margin-left:20px;" id="bsk_pdf_manager_dft_size_height_span_ID"><?php echo $selected_height_str; ?></span>
                <span style="display:inline-block; margin-left:20px;" id="bsk_pdf_manager_dft_size_crop_span_ID"><?php echo $selected_crop_str; ?></span>
                <?php echo $hidden_dimission_str; ?>
                <input type="hidden" id="bsk_pdf_manager_registered_size_names_id" value="<?php echo implode(',', $hidden_registers_size_names_array); ?>" />
            </p>
        </div>
        <p style="margin-top:20px;">
        	<input type="button" id="bsk_pdf_manager_settings_featured_image_tab_save_form_ID" class="button-primary" value="Save Featured Image Settings" />
            <input type="hidden" name="bsk_pdf_manager_action" value="featured_image_settings_save" />
        </p>
        <?php echo wp_nonce_field( plugin_basename( __FILE__ ), 'bsk_pdf_manager_settings_featured_image_tab_save_oper_nonce', true, false ); ?>
    </div>
    </form>
    <?php
	}
	
	function bsk_pdf_manager_settings_featured_image_tab_save_fun( $data ){
		global $wpdb, $current_user;
		//check nonce field
		if( !wp_verify_nonce( $data['bsk_pdf_manager_settings_featured_image_tab_save_oper_nonce'], plugin_basename( __FILE__ ) ) ){
			return;
		}
		
		if( !current_user_can( 'moderate_comments' ) ){
			return;
		}
		
		$enable_featured_image = isset($data['bsk_pdf_manager_enable_featured_image']) ? true : false;
		$thumbnail_id = $data['bsk_pdf_manager_default_thumbnail_id'];
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( !$plugin_settings || !is_array($plugin_settings) || count($plugin_settings) < 1 ){
			$plugin_settings = array();
		}
		$plugin_settings['enable_featured_image'] = $enable_featured_image;
		$plugin_settings['default_thumbnail_id'] = $thumbnail_id;
		$plugin_settings['default_thumbnail_size'] = $data['bsk_pdf_manager_default_thumbnail_size'];
		$plugin_settings['register_image_size'] = array( 'size_1' => array(), 'size_2' => array() );
		
		$register_size_name_1 = trim($data['bsk_pdf_manager_register_image_size_name_1']);
		$register_size_width_1 = $data['bsk_pdf_manager_register_image_size_width_1'];
		$register_size_height_1 = $data['bsk_pdf_manager_register_image_size_height_1'];
		$register_size_crop_1 = isset($data['bsk_pdf_manager_register_image_size_crop_1']) ? true : false;

		if( $register_size_name_1 && $register_size_width_1 && $register_size_height_1 ){
			$plugin_settings['register_image_size']['size_1'] = array( 
																	   'name' => $register_size_name_1,
																	   'width' => $register_size_width_1,
																	   'height' => $register_size_height_1,
																	   'crop' => $register_size_crop_1
																	 );
		}
		
		$register_size_name_2 = trim($data['bsk_pdf_manager_register_image_size_name_2']);
		$register_size_width_2 = $data['bsk_pdf_manager_register_image_size_width_2'];
		$register_size_height_2 = $data['bsk_pdf_manager_register_image_size_height_2'];
		$register_size_crop_2 = isset($data['bsk_pdf_manager_register_image_size_crop_2']) ? true : false;
		
		if( $register_size_name_2 && $register_size_width_2 && $register_size_height_2 ){
			$plugin_settings['register_image_size']['size_2'] = array( 
																	   'name' => $register_size_name_2,
																	   'width' => $register_size_width_2,
																	   'height' => $register_size_height_2,
																	   'crop' => $register_size_crop_2
																	 );
		}

		update_option( BSKPDFManagerPro::$_plugin_settings_option, $plugin_settings );
		
		$redirect_url = add_query_arg( 'target', 'featured-image', self::$_bsk_pdf_settings_page_url );
		wp_redirect( $redirect_url );
	}
	
	function bsk_pdf_manager_get_post_thumbnail_fun(){
		global $wpdb, $current_user;
		//check nonce field
		if( !check_ajax_referer( 'bsk_pdf_manager_settings_page_ajax-oper-nonce', 'nonce', false ) ){
			wp_die( 'ERROR - Invalid nonce, please refresh-'.$_POST['nonce'] );
		}
		
		if( !current_user_can( 'moderate_comments' ) ){
			return;
		}
		
		$thumbnail_id = intval( $_POST['thumbnail_id'] );
		if( $thumbnail_id && get_post( $thumbnail_id ) ){
			$thumbnail_html = wp_get_attachment_image( $thumbnail_id, $_POST['size'] );
			wp_die( $thumbnail_html );
		}
		
		wp_die( 'ERROR - Invalid thumbnail ID: '.$thumbnail_id );
	}
	
	function get_image_sizes() {
		global $_wp_additional_image_sizes;
	
		$sizes = array();
	
		foreach ( get_intermediate_image_sizes() as $_size ) {
			if ( $_size == 'bsk-pdf-dashboard-list-thumbnail' ){
				continue;
			}
			if ( in_array( $_size, array('thumbnail', 'medium', 'medium_large', 'large') ) ) {
				$sizes[ $_size ]['width']  = get_option( "{$_size}_size_w" );
				$sizes[ $_size ]['height'] = get_option( "{$_size}_size_h" );
				$sizes[ $_size ]['crop']   = (bool) get_option( "{$_size}_crop" );
			} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
				$sizes[ $_size ] = array(
					'width'  => $_wp_additional_image_sizes[ $_size ]['width'],
					'height' => $_wp_additional_image_sizes[ $_size ]['height'],
					'crop'   => $_wp_additional_image_sizes[ $_size ]['crop'],
				);
			}
		}
	
		return $sizes;
	}

}