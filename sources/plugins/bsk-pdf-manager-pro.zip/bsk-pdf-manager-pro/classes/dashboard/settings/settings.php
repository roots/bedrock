<?php

class BSKPDFMPro_Dashboard_Settings {
	
	private static $_bsk_pdf_settings_page_url = '';
    
    private static $_bsk_pdfm_OBJ_settings_general = NULL;
	private static $_bsk_pdfm_OBJ_settings_featured_image = NULL;
	private static $_bsk_pdfm_OBJ_settings_styles = NULL;
	   
	public function __construct() {
		require_once( 'settings-general.php' );
		require_once( 'settings-featured-image.php' );
		require_once( 'settings-styles.php' );	
		
		self::$_bsk_pdf_settings_page_url = admin_url( 'admin.php?page='.BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['setting'] );
        
        self::$_bsk_pdfm_OBJ_settings_general = new BSKPDFMPro_Dashboard_Settings_General();
        self::$_bsk_pdfm_OBJ_settings_featured_image = new BSKPDFMPro_Dashboard_Settings_Featured_Image();
        self::$_bsk_pdfm_OBJ_settings_styles = new BSKPDFMPro_Dashboard_Settings_Styles();
	}
	
	function show_settings(){
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		?>
        
        <div class="wrap" id="bsk_pdfm_setings_wrap_ID">
        	<div id="icon-edit" class="icon32"><br/></div>
			<h2>BSK PDF Settings & Support</h2>
            <h2 class="nav-tab-wrapper">
                <a class="nav-tab nav-tab-active" href="javascript:void(0);" id="bsk_pdfm_setings_tab-general-settings">General settings</a>
                <a class="nav-tab" href="javascript:void(0);" id="bsk_pdfm_setings_tab-featured-image">Featured Image</a>
                <a class="nav-tab" href="javascript:void(0);" id="bsk_pdfm_setings_tab-styles">Styles</a>
            </h2>
            <div id="bsk_pdfm_setings_tab_content_wrap_ID">
				<section><?php self::$_bsk_pdfm_OBJ_settings_general->show_settings( $plugin_settings ); ?></section>
                <section><?php self::$_bsk_pdfm_OBJ_settings_featured_image->show_settings( $plugin_settings ); ?></section>
                <section><?php self::$_bsk_pdfm_OBJ_settings_styles->show_settings( $plugin_settings ); ?></section>
            </div>
        </div>
		<?php
		$target_tab = isset($_REQUEST['target']) ? $_REQUEST['target'] : '';
		echo '<input type="hidden" id="bsk_pdfm_settings_target_tab_ID" value="'.$target_tab.'" />';
		$ajax_nonce = wp_create_nonce( 'bsk_pdf_manager_settings_page_ajax-oper-nonce' );
        echo '<input type="hidden" id="bsk_pdf_manager_settings_page_ajax_nonce_ID" value="'.$ajax_nonce.'" />';
	}
    
}