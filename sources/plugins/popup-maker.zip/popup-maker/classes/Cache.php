<?php
/*******************************************************************************
 * Copyright (c) 2019, Code Atlantic LLC
 ******************************************************************************/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class PUM_Cache
 *
 * @deprecated 1.8.0
 */
class PUM_Cache extends PUM_Utils_Cache {}
