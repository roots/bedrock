<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Manage Players' , 'lbg-vp1-html5' );?></h2>
 	</div>
    <div>
      <p><?php esc_html_e( 'From this section you can add multiple players.' , 'lbg-vp1-html5' );?> </p>
    </div>

    <div id="previewDialog"><iframe id="previewDialogIframe" src="" width="100%" height="600" style="border:0;"></iframe></div>

<div style="text-align:center; padding:0px 0px 20px 0px;"><img src="<?php echo plugins_url('images/icons/add_icon.gif', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="?page=LBG_VP1_HTML5_Add_New"><?php esc_html_e( 'Add new (player)' , 'lbg-vp1-html5' );?></a></div>

<table width="100%" class="widefat">

			<thead>
				<tr>
					<th scope="col" width="8%"><?php esc_html_e( 'ID' , 'lbg-vp1-html5' );?></th>
					<th scope="col" width="40%"><?php esc_html_e( 'Name' , 'lbg-vp1-html5' );?></th>
                    <th scope="col" width="22%"><?php esc_html_e( 'Shorcode' , 'lbg-vp1-html5' );?></th>
					<th scope="col" width="24%"><?php esc_html_e( 'Action' , 'lbg-vp1-html5' );?></th>
                    <th scope="col" width="6%"><?php esc_html_e( 'Preview' , 'lbg-vp1-html5' );?></th>
				</tr>
			</thead>

<tbody>
<?php foreach ( $result as $row )
	{
		$row=lbg_vp1_html5_unstrip_array($row); ?>
							<tr class="alternate author-self status-publish" valign="top">
					<td><?php echo esc_html($row['id'])?></td>
					<td><?php echo esc_html($row['name'])?></td>
					<td>[lbg_vp1_html5 settings_id='<?php echo esc_html($row['id'])?>']</td>
					<td><a href="?page=LBG_VP1_HTML5_Settings&amp;id=<?php echo esc_attr($row['id'])?>&amp;name=<?php echo esc_attr($row['name'])?>"><?php esc_html_e( 'Player Settings' , 'lbg-vp1-html5' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="?page=LBG_VP1_HTML5_Manage_Players&amp;id=<?php echo esc_attr($row['id'])?>" onclick="return confirm('Are you sure?')" style="color:#F00;"><?php esc_html_e( 'Delete' , 'lbg-vp1-html5' );?></a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="?page=LBG_VP1_HTML5_Manage_Players&amp;duplicate_id=<?php echo esc_attr($row['id'])?>"><?php esc_html_e( 'Duplicate' , 'lbg-vp1-html5' );?></a></td>
                    <td><a href="javascript: void(0);" onclick="showDialogPreview(<?php echo esc_js($row['id'])?>)"><img src="<?php echo plugins_url('images/icons/magnifier.png', dirname(__FILE__))?>" alt="preview" border="0" align="absmiddle" /></a></td>
				</tr>
<?php } ?>
<!-- pagination start -->
<tr><td colspan="5" align="center" style="padding:20px; font-size:14px; font-weight:bold;">
	<?php
echo '<div class="lbg_pagination">';
echo paginate_links( array(
'base' => add_query_arg( 'cpage', '%#%' ),
'format' => '',
'prev_text' => __('&laquo;'),
'next_text' => __('&raquo;'),
'total' => ceil($total_players / $post_per_page),
'current' => $page_no,
'type' => 'plain'
));
echo '</div>';
?></td>
</tr>
						</tbody>
		</table>



</div>
