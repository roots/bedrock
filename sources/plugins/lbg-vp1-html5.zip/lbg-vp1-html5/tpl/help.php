<style type="text/css">
.lbg_subtitle {	color:#21759b;
	font-weight:bold;
	font-size:14px;
}
</style>
<div class="wrap">
<div id="lbg_logo">
			<h2>Help</h2>
  </div>
<p>This plugin requires at least WordPress 3.0</p>
<ul class="lbg_list-1">
  <li><a href="#videotutorials">Video Tutorials</a></li>
  <li><a href="#manage">Manage Players</a></li>
  <li><a href="#settings">Player Settings</a></li>
  <li>.<a href="#htaccess">htaccess</a></li>
  <li><a href="#shortcode">ShortCode</a></li>
</ul>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="videotutorials" id="videotutorials"></a>1. Video Tutorials</span></p>
<p>Step 1: Installation – <a href="https://www.youtube.com/watch?v=scpeZjw1F64" target="_blank">https://www.youtube.com/watch?v=scpeZjw1F64</a><br />
Step 2: How To Create a Video Player and How To Change the Player Settings  – <a href="https://www.youtube.com/watch?v=HvsiOPyFwZA" target="_blank">https://www.youtube.com/watch?v=HvsiOPyFwZA</a><br />
Step 3: How To Create Multiple Players And Use The Shortcode Optional Parameters - <a href="https://www.youtube.com/watch?v=REgltNEdWtE" target="_blank">https://www.youtube.com/watch?v=REgltNEdWtE</a></p>
<p>&nbsp;</p>
<p class="lbg_subtitle"><a name="manage" id="manage"></a>2. Manage Players</p>
<p class="">From this section you can:<br />
- add a new player <br />
-
select the player you want to edit by clicking &quot;Player Settings&quot;<br />
- delete an existing player by clicking &quot;Delete&quot;
<br />
- duplicate an existing player by clicking &quot;Duplicate&quot; </p>
<p class="">&nbsp;</p>
<p class="lbg_subtitle"><a name="settings" id="settings"></a>3. Player Settings</p>
<p>From this section you can define the video player  settings.</p>
<table class="wp-list-table widefat fixed pages" cellspacing="0">
  <tr>
    <td width="30%" align="left" valign="top" class="row-title"></td>
    <td width="70%" align="left" valign="top"></td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray">Video Sources</td>
    </tr>
  <tr>
    <td width="30%" align="left" valign="top" class="row-title">Movie Title</td>
    <td width="70%" align="left" valign="top">movie title</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Movie Description</td>
    <td align="left" valign="top">movie description</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Preview</td>
    <td align="left" valign="top">optional you can upload a preview image is you set autoplay=false </td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">MP4 file </td>
    <td align="left" valign="top">.mp4 file link</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">WebM</td>
    <td align="left" valign="top">.webm file link</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="left" valign="top" class="lbg_regGray">General Settings</td>
    </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Player Width</td>
    <td align="left" valign="top">player width</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Player Height</td>
    <td align="left" valign="top">player height</td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title">Center Plugin</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the player will be centered on the page<br />
      <strong>false</strong> - the player will be centered on the page</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title"><span class="regb">Responsive</span></td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the banner will responsive<br />
      <strong>false</strong> - the banner will not be responsive</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Responsive Relative To Browser</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the banner will be responisve relatively to browser dimensions<br />
      <strong>false</strong> - the banner will be responisve relatively to parent div</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Width 100%</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the player width will be 100%<br />
      <strong>false</strong> - the player width will be what you've set for <span class="row-title">Player Width</span></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Height 100%</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the video height will be 100%<br />
      <strong>false</strong> - the video height will be what you've set for <span class="row-title">Player Height</span></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Skin Name</td>
    <td align="left" valign="top"> available skins:<br />
      - universalBlack<br />
      - universalWhite<br />
      - giant<br />
      - futuristicElectricBlue<br />
      - futuristicChrome
  <br />
      - elegantMinimal</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Seek Bar Adjust</td>
    <td align="left" valign="top"><p>This value will reduce the length of seek bar</p>
      <p>Recommended values: </p>
      <p> - universalBlack: 220<br />
        - universalWhite: 220<br />
        - giant: 390<br />
        - futuristicElectricBlue: 255<br />
        - futuristicChrome: 255<br />
      - elegantMinimal: 0</p></td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Show Information Button</td>
    <td align="left" valign="top">You can show or hide the info button.<br />
      Possible values: <br />
  <strong>true</strong> - show info button<br />
  <strong>false</strong> - hide info button</td>
    </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Preload</td>
    <td align="left" valign="top">Specifies if and how the author thinks the video should be loaded when the page   loads</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Loop Video</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - starts next movie after current movie has finished<br />
      <strong>false</strong> - doesn't start next movie after current movie has finished</td>
    </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Auto Play</td>
    <td align="left" valign="top">true if you want your video to autoplay, and false otherwise</td>
  </tr>
	<tr>
    <td align="left" valign="top" class="row-title">Auto-Play On Mobile</td>
		<td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - the video will autoplay on mobile devices<br />
      <strong>false</strong> - the video will not autoplayon mobile devices<br />
			NOTES: <br />
			- for the moment only IOS allows autoplay and only if the video is muted. When you set autoPlayOnMobile:true, the video will mute automatically for mobile devices.<br />
			- this option is only available for self-hosted videos. YouTube & Vimeo doesn't have this option for mobile devices, yet.
		</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Initial Volume Value</td>
    <td align="left" valign="top">the initial volume value. It takes values between 0-1</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Link To Go When Video Ends</td>
    <td align="left" valign="top">The link to open when the video ends</td>
    </tr>
  <tr>
    <td align="left" valign="top" class="row-title">Target Window For Link</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>'_blank'</strong> - the link will open in a new window<br />
      <strong>'_slef'</strong>- the link  will open in the same window</td>
    </tr>
  <tr>
    <td align="left" valign="top" class="row-title">AutoHide Controllers</td>
    <td align="left" valign="top">Possible values: <br />
      <strong>true</strong> - hide the controllers on mouse out and show them on mouse over<br />
      <strong>false</strong> - the controllers are always visible no matter the mouse position</td>
  </tr>
  <tr>
    <td align="left" valign="top" class="row-title">&nbsp;</td>
    <td align="left" valign="top">&nbsp;</td>
  </tr>
</table>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="htaccess" id="htaccess"></a>4.htaccess</span></p>
<p>For Mozzila and IE9 please use the .htaccess present in the .zip file if the videos are not played. This video is not played because your server is not transmitting the correct MIME TYPE and the .htaccess tries to correct the server problem.</p>
<p>Also, if you need to increase the wordpress media library upload file size limit add the following definitions in the .htaccess file</p>
<p>&lt;IfModule mod_php5.c&gt;<br />
  php_value post_max_size           50M<br />
  php_value upload_max_filesize     50M<br />
  php_value memory_limit            500M<br />
  &lt;/IfModule&gt;</p>
<p>&nbsp;</p>
<p><span class="lbg_subtitle"><a name="shortcode" id="shortcode"></a>5. ShortCode</span></p>
<p>The shortcode is: <br />
[lbg_vp1_html5 settings_id='1']<br />
where <br />
 'settings_id'  is the player ID defined in &quot;Manage Players&quot; section - mandatory parameter<br />

 <p>OPTIONAL PARAMETERS:</p>

 'mp4_file' is the link to the .mp4 file, in case you don't want to use 'Playlist' section - optional parameter<br />
 'webm_file' is the link to the .webm file, in case you don't want to use 'Playlist' section  - optional parameter<br />
 'preview_file' is the link to the preview image file, in case you don't want to use 'Playlist' section - optional parameter<br />
 'movie_title' is the movie title, in case you don't want to use 'Playlist' section - optional parameter<br />
 'movie_desc' is the movie description, in case you don't want to use 'Playlist' section - optional parameter<br /><br />

 'mp4_custom_field' is the custom field name which will hold the link to the .mp4 file, in case you don't want to use 'Playlist' section - optional parameter<br />
 'webm_custom_field' is the custom field name which will hold the link to the .webm file, in case you don't want to use 'Playlist' section - optional parameter<br />
 'preview_custom_field' is the custom field name which will hold the link to the preview image file, in case you don't want to use 'Playlist' section - optional parameter<br />
 'movie_title_custom_field' is the custom field name which will hold the movie title, in case you don't want to use 'Playlist' section - optional parameter<br />
 'movie_desc_custom_field' is the custom field name which will hold the movie description, in case you don't want to use 'Playlist' section - optional parameter<br />  </p>
<p><br />
</p>
</div>
