<div class="wrap">
		<div id="lbg_logo">
			<h2><?php esc_html_e( 'Overview' , 'lbg-vp1-html5' );?></h2>
		</div>
		<div class="postbox-container" style="width:100%">
			<div class="postbox">
				<h3 style="padding:7px 10px;"><?php esc_html_e( 'LambertGroup - HTML5 Video Player with Multiple Skins' , 'lbg-vp1-html5' );?></h3>
				<div class="inside">
				<p>
					<?php esc_html_e( 'This plugin will allow you to insert an HTML5 Video Player with Multiple Skins.' , 'lbg-vp1-html5' );?>
				</p>
				<p><?php esc_html_e( 'You have available the following sections:' , 'lbg-vp1-html5' );?></p>
				<ul class="lbg_list-1">
					<li><a href="?page=LBG_VP1_HTML5_Manage_Players"><?php esc_html_e( 'Manage Players' , 'lbg-vp1-html5' );?></a></li>
					<li><a href="?page=LBG_VP1_HTML5_Add_New"><?php esc_html_e( 'Add New (player)' , 'lbg-vp1-html5' );?></a></li>
          <li><a href="?page=LBG_VP1_HTML5_Help"><?php esc_html_e( 'Help' , 'lbg-vp1-html5' );?></a></li>
				</ul>
			  </div>
			</div>
		</div>
	</div>
