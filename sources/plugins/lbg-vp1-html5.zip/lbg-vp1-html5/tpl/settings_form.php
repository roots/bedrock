<script>
jQuery(document).ready(function() {

	// Uploading files

	jQuery('#upload_img_button_vp1_html5').click(function(event) {
		var file_frame;
		event.preventDefault();
		// If the media frame already exists, reopen it.
		if ( file_frame ) {
			file_frame.open();
			return;
		}
		// Create the media frame.
		file_frame = wp.media.frames.file_frame = wp.media({
			title: jQuery( this ).data( 'uploader_title' ),
			button: {
			text: jQuery( this ).data( 'uploader_button_text' ),
			},
			multiple: false // Set to true to allow multiple files to be selected
		});
		// When an image is selected, run a callback.
		file_frame.on( 'select', function() {
			// We set multiple to false so only get one image from the uploader
			attachment = file_frame.state().get('selection').first().toJSON();
			// Do something with attachment.id and/or attachment.url here
			jQuery('#preview_show').attr('src',attachment.url);
			jQuery('#preview').val(attachment.url);
		});
		// Finally, open the modal
		file_frame.open();
	});




jQuery('#upload_mp4_button').live('click', function( event ){
		var file_frame;
		event.preventDefault();
		// If the media frame already exists, reopen it.
		if ( file_frame ) {
			file_frame.open();
			return;
		}
		// Create the media frame.
		file_frame = wp.media.frames.file_frame = wp.media({
			title: jQuery( this ).data( 'uploader_title' ),
			button: {
			text: jQuery( this ).data( 'uploader_button_text' ),
			},
			multiple: false // Set to true to allow multiple files to be selected
		});
		// When an image is selected, run a callback.
		file_frame.on( 'select', function() {
			// We set multiple to false so only get one image from the uploader
			attachment = file_frame.state().get('selection').first().toJSON();
			// Do something with attachment.id and/or attachment.url here
			jQuery('#mp4').val(attachment.url);
		});
		// Finally, open the modal
		file_frame.open();
	});

jQuery('#upload_webm_button').live('click', function( event ){
		var file_frame;
		event.preventDefault();
		// If the media frame already exists, reopen it.
		if ( file_frame ) {
			file_frame.open();
			return;
		}
		// Create the media frame.
		file_frame = wp.media.frames.file_frame = wp.media({
			title: jQuery( this ).data( 'uploader_title' ),
			button: {
			text: jQuery( this ).data( 'uploader_button_text' ),
			},
			multiple: false // Set to true to allow multiple files to be selected
		});
		// When an image is selected, run a callback.
		file_frame.on( 'select', function() {
			// We set multiple to false so only get one image from the uploader
			attachment = file_frame.state().get('selection').first().toJSON();
			// Do something with attachment.id and/or attachment.url here
			jQuery('#webm').val(attachment.url);
		});
		// Finally, open the modal
		file_frame.open();
	});

});
</script>



<div class="wrap">
	<div id="lbg_logo">
			<h2><?php esc_html_e( 'Player Settings for player:' , 'lbg-vp1-html5' );?> <span style="color:#FF0000; font-weight:bold;"><?php echo esc_html($_SESSION['xname'])?> - ID #<?php echo esc_html($_SESSION['xid'])?></span></h2>
 	</div>

        <div style="text-align:center; padding:0px 0px 20px 0px;"><img src="<?php echo plugins_url('images/icons/magnifier.png', dirname(__FILE__))?>" alt="add" align="absmiddle" /> <a href="javascript: void(0);" onclick="showDialogPreview(<?php echo strip_tags($_SESSION['xid'])?>)"><?php esc_html_e( 'Preview Player' , 'lbg-vp1-html5' );?></a></div>

        <div id="previewDialog"><iframe id="previewDialogIframe" src="" width="100%" height="600" style="border:0;"></iframe></div>

  <form id="form-playlist-vp1html5" method="POST" enctype="multipart/form-data" action="?page=LBG_VP1_HTML5_Settings">
	<script>
	jQuery(function() {
		var icons = {
			header: "ui-icon-circle-arrow-e",
			headerSelected: "ui-icon-circle-arrow-s"
		};
		jQuery( "#accordion" ).accordion({
			icons: icons,
			autoHeight: false
		});
	});
	</script>


<div id="accordion">
  <h3><a href="#">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php esc_html_e( 'Video Sources' , 'lbg-vp1-html5' );?></a></h3>
  <div style="padding:30px;">
    <table width="70%" cellspacing="0" class="wp-list-table widefat fixed pages">

      <tr>
        <td align="right" valign="top" class="row-title" width="30%"><?php esc_html_e( 'Movie Title' , 'lbg-vp1-html5' );?></td>
        <td align="left" valign="middle" width="76%"><input name="movieTitle" type="text" size="55" id="movieTitle" value="<?php echo stripslashes($_POST['movieTitle']);?>"/></td>
      </tr>
      <tr>
        <td width="30%" align="right" valign="top" class="row-title"><?php esc_html_e( 'Movie Description' , 'lbg-vp1-html5' );?></td>
        <td width="76%" align="left" valign="middle"><textarea name="movieDesc" id="movieDesc" cols="55" rows="5"><?php echo stripslashes($_POST['movieDesc']);?></textarea></td>
      </tr>
		  <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Preview' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="top"><input name="preview" type="text" id="preview" size="50" value="<?php echo stripslashes($row['preview']);?>" />
              <input name="upload_img_button_vp1_html5" type="button" id="upload_img_button_vp1_html5" value="<?php esc_attr_e( 'Change Image' , 'lbg-vp1-html5' );?>" />
              <br />
              <?php esc_html_e( 'Enter an URL or upload an image' , 'lbg-vp1-html5' );?><br />
            <?php if ($_POST['preview']) { ?>
            	<p><img src="<?php echo esc_attr($_POST['preview'])?>" border="0" align="top" name="preview_show" id="preview_show" /></p>
            <?php } ?>
            </td>
	    </tr>
          <tr>
        <td align="right" valign="top" class="row-title"><?php esc_html_e( 'MP4 file' , 'lbg-vp1-html5' );?> </td>
        <td align="left" valign="middle"><input name="mp4" type="text" size="80" id="mp4" value="<?php echo stripslashes($_POST['mp4'])?>"/> <input name="upload_mp4_button" type="button" id="upload_mp4_button" value="<?php esc_attr_e( 'Upload File' , 'lbg-vp1-html5' );?>" /></td>
      </tr>
          <tr>
            <td align="right" valign="top" class="row-title">&nbsp;</td>
            <td align="left" valign="middle"> <?php esc_html_e( 'Enter an URL (from your server or third-party server) or upload the file' , 'lbg-vp1-html5' );?></td>
          </tr>
          <tr>
            <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Optional WebM (Opera & Firefox)' , 'lbg-vp1-html5' );?></td>
            <td align="left" valign="middle"><input name="webm" type="text" size="80" id="webm" value="<?php echo stripslashes($_POST['webm']);?>"/> <input name="upload_webm_button" type="button" id="upload_webm_button" value="<?php esc_attr_e( 'Upload File' , 'lbg-vp1-html5' );?>" /></td>
          </tr>
          <tr>
            <td align="right" valign="top" class="row-title">&nbsp;</td>
            <td align="left" valign="middle"> <?php esc_html_e( 'Enter an URL (from your server or third-party server) or upload the file' , 'lbg-vp1-html5' );?></td>
          </tr>
    </table>
  </div>


  <h3><a href="#">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php esc_html_e( 'General Settings' , 'lbg-vp1-html5' );?></a></h3>
  <div style="padding:30px;">
	  <table class="wp-list-table widefat fixed pages" cellspacing="0">

		  <tr>
		    <td align="right" valign="top" class="row-title" width="30%"><?php esc_html_e( 'Player Name' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="top" width="70%"><input name="name" type="text" size="40" id="name" value="<?php echo esc_attr($_SESSION['xname']);?>"/></td>
	      </tr>
		  <tr>
            <td width="25%" align="right" valign="top" class="row-title"><?php esc_html_e( 'Player Width' , 'lbg-vp1-html5' );?></td>
		    <td width="75%" align="left" valign="top"><input name="playerWidth" type="text" size="25" id="playerWidth" value="<?php echo esc_attr($_POST['playerWidth']);?>"/></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Player Height' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="top"><input name="playerHeight" type="text" size="25" id="playerHeight" value="<?php echo esc_attr($_POST['playerHeight']);?>"/></td>
	    </tr>
		 <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Width 100%' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="width100Proc" id="width100Proc">
              <option value="true" <?php echo (($_POST['width100Proc']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['width100Proc']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		<tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Height 100%' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="height100Proc" id="height100Proc">
              <option value="true" <?php echo (($_POST['height100Proc']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['height100Proc']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
			<tr>
			<td align="right" valign="top" class="row-title"><?php esc_html_e( 'Center Plugin' , 'lbg-vp1-html5' );?></td>
			<td align="left" valign="middle"><select name="centerPlugin" id="centerPlugin">
						<option value="true" <?php echo (($_POST['centerPlugin']=='true')?'selected="selected"':'')?>>true</option>
						<option value="false" <?php echo (($_POST['centerPlugin']=='false')?'selected="selected"':'')?>>false</option>
					</select></td>
		</tr>
		<tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Responsive' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="responsive" id="responsive">
              <option value="true" <?php echo (($_POST['responsive']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['responsive']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
        <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Responsive Relative To Browser' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="responsiveRelativeToBrowser" id="responsiveRelativeToBrowser">
              <option value="true" <?php echo (($_POST['responsiveRelativeToBrowser']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['responsiveRelativeToBrowser']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Skin Name' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="skin" id="skin">
		      <option value="universalBlack" <?php echo (($_POST['skin']=='universalBlack')?'selected="selected"':'')?>>universalBlack</option>
		      <option value="universalWhite" <?php echo (($_POST['skin']=='universalWhite')?'selected="selected"':'')?>>universalWhite</option>
		      <option value="giant" <?php echo (($_POST['skin']=='giant')?'selected="selected"':'')?>>giant</option>
		      <option value="futuristicElectricBlue" <?php echo (($_POST['skin']=='futuristicElectricBlue')?'selected="selected"':'')?>>futuristicElectricBlue</option>
		      <option value="futuristicChrome" <?php echo (($_POST['skin']=='futuristicChrome')?'selected="selected"':'')?>>futuristicChrome</option>
		      <option value="elegantMinimal" <?php echo (($_POST['skin']=='elegantMinimal')?'selected="selected"':'')?>>elegantMinimal</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Seek Bar Adjust' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><input name="seekBarAdjust" type="text" size="25" id="seekBarAdjust" value="<?php echo esc_attr($_POST['seekBarAdjust']);?>"/>
            <p><?php esc_html_e( 'Seek Bar AdjustRecommended values:' , 'lbg-vp1-html5' );?> </p>
            <p>
	- universalBlack: 220<br />
- universalWhite: 220<br />
- giant: 390<br />
- futuristicElectricBlue: 255<br />
- futuristicChrome: 255<br />
- elegantMinimal: 0</p>
            </td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Show Information Button' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="showInfo" id="showInfo">
              <option value="true" <?php echo (($_POST['showInfo']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['showInfo']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Preload' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="preload" id="preload">
		      <option value="auto" <?php echo (($_POST['preload']=='auto')?'selected="selected"':'')?>>auto</option>
		      <option value="metadata" <?php echo (($_POST['preload']=='metadata')?'selected="selected"':'')?>>metadata</option>
		      <option value="none" <?php echo (($_POST['preload']=='none')?'selected="selected"':'')?>>none</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Loop Video' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="loop" id="loop">
              <option value="loop" <?php echo (($_POST['loop']=='loop')?'selected="selected"':'')?>>true</option>
              <option value="" <?php echo (($_POST['loop']=='')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Auto Play' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="autoPlay" id="autoPlay">
              <option value="autoplay" <?php echo (($_POST['autoPlay']=='autoplay')?'selected="selected"':'')?>>true</option>
              <option value="" <?php echo (($_POST['autoPlay']=='')?'selected="selected"':'')?>>false</option>
            </select></td>
	    </tr>
      <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Auto-Play On Mobile' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="autoPlayOnMobile" id="autoPlayOnMobile">
              <option value="true" <?php echo (($_POST['autoPlayOnMobile']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['autoPlayOnMobile']=='false')?'selected="selected"':'')?>>false</option>
              </select>
							<p><i><?php esc_html_e( '- for the moment only IOS allows autoplay and only if the video is muted. When you set autoPlayOnMobile:true, the video will mute automatically for mobile devices.' , 'lbg-vp1-html5' );?></i></p>
					</td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Link To Go When Video Ends' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><input name="linkToGo" type="text" size="40" id="linkToGo" value="<?php echo esc_attr($_POST['linkToGo']);?>"/></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Target Window For Link' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="target" id="target">
		      <option value="_blank" <?php echo (($_POST['target']=='_blank')?'selected="selected"':'')?>>_blank</option>
		      <option value="_self" <?php echo (($_POST['target']=='_self')?'selected="selected"':'')?>>_self</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'Initial Volume Value' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><script>
	jQuery(function() {
		jQuery( "#initialVolume-slider-range-min" ).slider({
			range: "min",
			value: <?php echo esc_js($_POST['initialVolume']);?>,
			min: 0,
			max: 1,
			step: 0.1,
			slide: function( event, ui ) {
				jQuery( "#initialVolume" ).val(ui.value );
			}
		});
		jQuery( "#initialVolume" ).val( jQuery( "#initialVolume-slider-range-min" ).slider( "value" ) );
	});
	        </script>
                <div id="initialVolume-slider-range-min" class="inlinefloatleft" style="width:200px;"></div>
		      <div class="inlinefloatleft" style="padding-left:20px;">
		        <input name="initialVolume" type="text" size="10" id="initialVolume" style="border:0; color:#000000; font-weight:bold;"/>
	          </div></td>
	    </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title"><?php esc_html_e( 'AutoHide Controllers' , 'lbg-vp1-html5' );?></td>
		    <td align="left" valign="middle"><select name="autoHideControllers" id="autoHideControllers">
              <option value="true" <?php echo (($_POST['autoHideControllers']=='true')?'selected="selected"':'')?>>true</option>
              <option value="false" <?php echo (($_POST['autoHideControllers']=='false')?'selected="selected"':'')?>>false</option>
            </select></td>
	      </tr>
		  <tr>
		    <td align="right" valign="top" class="row-title">&nbsp;</td>
		    <td align="left" valign="middle">&nbsp;</td>
	      </tr>
      </table>
  </div>




</div>

<div style="text-align:center; padding:20px 0px 20px 0px;"><input name="Submit" type="submit" id="Submit" class="button-primary" value="Update Player Settings"></div>

</form>
</div>
