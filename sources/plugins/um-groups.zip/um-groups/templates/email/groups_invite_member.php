<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Hi {group_invitation_guest_name},

{group_invitation_host_name} has invited you to join to group: {group_name}.
To confirm/reject this invitation please click the following link: <a href="{group_url}" style="color: #3ba1da;text-decoration: none;">{group_url}</a>