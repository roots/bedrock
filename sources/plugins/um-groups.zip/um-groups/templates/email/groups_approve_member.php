<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Your request to join to group "{group_name}" has been approved. <a href="{group_url}" style="color: #3ba1da;text-decoration: none;">{group_url}</a>