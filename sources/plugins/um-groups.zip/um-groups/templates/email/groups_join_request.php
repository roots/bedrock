<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

Hi {moderator_name},

{member_name} has requested to join to group: {group_name}. You can view their profile here: <a href="{profile_link}" style="color: #3ba1da;text-decoration: none;">{profile_link}</a>.
To approve/reject this request please click the following link: <a href="{groups_request_tab_url}" style="color: #3ba1da;text-decoration: none;">{groups_request_tab_url}</a>