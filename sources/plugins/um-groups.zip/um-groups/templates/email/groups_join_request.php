Hi {moderator_name},

{member_name} has requested to join {group_name}. You can view their profile here: {profile_link}.
To approve/reject this request please click the following link: {groups_request_tab_url}