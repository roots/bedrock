=== Photo Album - Video Gallery ===
Contributors: Image Gallery Photo Gallery
Requires at least: 3.3
Tested up to: 4.4.2
Tags: photo album,best photo album,responsive photo album,lightbox,lightbox,video gallery, image gallery responsive,responsive photo gallery, best image gallery, best photo gallery
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


You don't need to take any extra step, just create a gallery using the wordpress default galley system and you will get an awesome photo album ready at the frontend.


== Description ==

### PLUGIN ADMIN PANEL: After active our plugin Go to Page > Add New Click on "Add Media" then you can see media uploader. Now click on "Create Gallery" then upload some photos there then publish. Click "view page" then you can see an awesome photo gallery :)

Admin Panel: The plugin have another admin panel go to Settings > Photo Gallery Options

Responsive "Photo Gallery" WordPress has been created to display photo gallery on your WordPress site. It is responsive, beautiful and very easy to use. The photo gallery have lot's of style. As navigation you can use thumbnails also support youtube video,vimeo video,mp3,mp4.

There are no limitations! Countless gallery can be created and displayed individually on different posts or pages by shortcode. You can also modify each gallery and their packages at any time. The packages are sortable and each package can be designed by different colors by the Shortcode. You can also set thumbnail overlay color, shadow color, margin, 4 types image view on each package. You can use slide & fade effect. Package features are also sortable, means you can change the position of each feature at any time.



<strong>Watch the Video How to Work</strong> <br>
https://www.youtube.com/watch?v=mEcgXniSwaY



* [See the premium live demo!&raquo;](http://code.realwebcare.com/awesome-responsive-photo-gallery/)
* [Online Documentation!&raquo;](https://17ac464d0fa8c9e6a0cf1ab268f17f0676137a59.googledrive.com/host/0B7rkQpNDg1H9MWhNSk13WlFIUzg/#!/configuration)
* [Upgrade to Premium!&raquo;](http://code.realwebcare.com/item/awesome-image-gallery/?preview=true)


### Plugin Features:-
1.  Super Easy Installation
2.  Include Both Videos and Images Within a Single Gallery
3.  Responsive For All Devices
4.  Unlimited Gallery
5.  Touch Support 
6.  Support Keyboard navigation
7.  LightBox
8.  Drag and Drop Order
9.  Slide & Fade 2 Types Gallery 
10. User Friendly Admin Panel
11. Youtube,Vimeo,MP4,FLV and support manymore
12. Support ID
13. All Major Browser Supported
14. Works With Every Version of Wordpress
15. Very Lightweight Only 35kb
16. SEO Friendly
17. WordPress Gallery System
18. Random Order
19. Reserved
20. Easy Documentation
21. Use a Random Gallery to Your Sidebar
22. Use a Random gallery to Your Page

### Premium Features
23. Image, Video title & caption support
24. After view thumbnail Navigation supported
25. External admin panel
26. Use unlimited site
27. Thumbnail overlay color
28. Shadow color
29. Thumbnail margin
30. Thumbnail radius
31. 7 Days refund
32. 6 months support
33. Life time free update. 

### ADMIN PANEL: After active our plugin Go to Page > Add New. Click on "Add Media" then you can see media uploader. Now click on "Create Gallery" then upload some photos there then publish. Click "view page" then you can see an awesome image gallery :)

<strong>You can use by shortcode</strong> <br>

<strong> 1. Default Image Gallery </strong>
[easygallery id="1" ids="15,16,14,13,12,9,10,11"]


<strong> 2. Video Gallery, Fade effect,size, shadow, shadow color, thumbnail overlay color </strong>

[easygallery id="2" effect="fade" size="small" shadow="3px" shadow_color="pink" theme="#000" ids="176,177,178,179,180,181,182,183,184,185,186,187"]


<strong> 3. Image & Video Gallery, Slide effect,margin,shadow,shadow_color, thumbnail overlay color </strong>
[easygallery id="3" effect="slide" ids="15,16,14,13,130,129,128" margin="15px" shadow="3px" shadow_color="yellow" theme="blue" ]


== Installation ==

Installing Wordpress Photo Gallery Plugin is as simple as installing any other WordPress Plugin

1. Log In as an Admin on your WordPress blog.
2. In the menu displayed on the left, there is a "Plugins" tab. Click it.
3. Now click "Add New".
4. There, you have the buttons: "Upload Plugin". Click it.
5. Upload the photo-gallery.zip file and click Install Now button.
6. After the installation is finished, click Activate Plugin.
7. After active our plugin Go to Page > Add New. Click on "Add Media" then you can see media uploader. Now click on "Create Gallery" then upload some photos there then publish. Click "view page" then you can see an awesome image gallery :)
8. ADMIN PANEL: After active our plugin Go to Page > Add New. Click on "Add Media" then you can see media uploader. Now click on "Create Gallery" then upload some photos there then publish. Click "view page" then you can see an awesome image gallery :)


== License ==

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA




== Screenshots ==

1. Photo Gallery
2. Video Gallery
3. Navigation Without Thumbnail
4. Put Image or Video Title,Caption & Video Link
5. Drag & Drop Order with Reverse Order
6. Basic Settings (External Admin Panel)
7. Advance Settings (External Admin Panel)


== Changelog ==

= 1.0 (18 February, 2016) = 
* 1st release.


== CREDIT ==
1.This plugin was developed by [Justin Allison]

