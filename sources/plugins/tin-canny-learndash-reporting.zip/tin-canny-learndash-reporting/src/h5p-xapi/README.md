wp-h5p-xapi
===========

This wordpress plugin stores all xAPI statements generaded by H5P in a remote LRS.

How to use
----------

Install this plugin and go to Settings >> H5P xAPI. Enter the credentials for the connection to the LRS and you are good to go!

For more information, see the plugin page at:

https://wordpress.org/plugins/wp-h5p-xapi/