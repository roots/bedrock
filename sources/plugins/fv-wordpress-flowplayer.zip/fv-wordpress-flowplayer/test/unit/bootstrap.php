<?php
include_once('../../vendor/autoload.php');
include_once "../wp-global-empty-mocks.php";