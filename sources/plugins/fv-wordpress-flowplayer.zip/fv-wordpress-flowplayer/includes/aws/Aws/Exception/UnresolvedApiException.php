<?php
namespace Aws\Exception;

class UnresolvedApiException extends \RuntimeException {}
