<?php
// This file was auto-generated from sdk-root/src/data/cloudfront/2015-09-17/examples-1.json
return [ 'version' => '1.0', 'examples' => [],];
