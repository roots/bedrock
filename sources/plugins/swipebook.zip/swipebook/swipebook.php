<?php

	/*
	Plugin Name: SwipeBook
	Plugin URI: http://codecanyon.net/user/creativeinteractivemedia/portfolio?ref=creativeinteractivemedia
	Description: Premium Responsive PDF viewer 
	Version: 1.2.1
	Author: creativeinteractivemedia
	Author URI: http://codecanyon.net/user/creativeinteractivemedia?ref=creativeinteractivemedia
	*/

	define('SWIPEBOOK_DIR', plugin_dir_url( __FILE__ ));
	define('SWIPEBOOK_VERSION', '1.2.1');
	
	// function trace($var){
	// 	echo("<pre style='background:#fcc;color:#000;font-size:12px;font-weight:bold'>");
	// 	print_r($var);
	// 	echo("</pre>");
	// }

	if(!is_admin()) {
		include("includes/plugin-frontend.php");
	}
	else {
		include("includes/plugin-admin.php");
		add_filter("plugin_action_links_" . plugin_basename(__FILE__), "swipebook_admin_link");
	}
	
	function swipebook_admin_link($links) {
		array_unshift($links, '<a href="' . get_admin_url() . 'options-general.php?page=swipebook_admin">Admin</a>');
		return $links;
	}
	
	function deactivate_swipebook() {
	}

