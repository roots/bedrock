<?php

	function swipebook_admin_menu(){
		add_options_page("Swipebook Admin", "Swipebook", "publish_posts", "swipebook_admin", "swipebook_admin"); 

		add_menu_page("Swipebook Admin", "Swipebook", "publish_posts", "swipebook_menu", "swipebook_admin",'dashicons-book'); 
		// Add a new top-level menu (ill-advised):
	    // add_menu_page(__('Real3D swipebook','menu-test'), __('Real3D swipebook','menu-test'), 'publish_posts', 'mt-top-level-handle', 'real3d_swipebook_admin','dashicons-book' );

	    // Add a submenu to the custom top-level menu:
	    //add_submenu_page('mt-top-level-handle', __('Categories','menu-test'), __('Categories','menu-test'), 'publish_posts', 'swipebook_admin', 'mt_sublevel_page');
	}
	add_action("admin_menu", "swipebook_admin_menu");

	add_action( 'wp_ajax_swipebook_save', 'swipebook_save_callback' );
	add_action( 'wp_ajax_nopriv_swipebook_save', 'swipebook_save_callback' );
	function swipebook_save_callback() {
		
		$current_id = $page_id = '';
		// handle action from url

		if (isset($_GET['bookId']) ) {
			$current_id = $_GET['bookId'];
		}

		$swipebooks_converted = get_option("swipebooks_converted");

		if(!$swipebooks_converted){

			$swipebooks = get_option("swipebooks");
			if(!$swipebooks){
				$swipebooks = array();
			}

			add_option('swipebooks_converted', true);
			$swipebooks_ids = array();
			//trace('converting swipebooks...');
			foreach ($swipebooks as $b) {
				$id = $b['id'];
				//trace($id);
				delete_option('swipebook_'.(string)$id);
				add_option('swipebook_'.(string)$id, $b);
				array_push($swipebooks_ids,(string)$id);
			}
			// trace($swipebooks_ids);
		}else{
			// trace($swipebooks_ids);
			$swipebooks_ids = get_option('swipebooks_ids');
			if(!$swipebooks_ids){
				$swipebooks_ids = array();
			}
			$swipebooks = array();
			foreach ($swipebooks_ids as $id) {
				// trace($id);
				$book = get_option('swipebook_'.$id);
				if($book){
					$swipebooks[$id] = $book;
					// array_push($swipebooks,$book);
				}else{
					//remove id from array
					$swipebooks_ids = array_diff($swipebooks_ids, array($id));
				}
			}
		}
		
		update_option('swipebooks_ids', $swipebooks_ids);

		if (!isset($_POST['pages']) ) {
			$_POST['pages'] = array();
		}
		if($swipebooks && $current_id != ''){
			$swipebook = $swipebooks[$current_id];
			if($swipebook){
				$pages = $swipebook["pages"];
			}else{
				$swipebook = array();
			}
		}

		$new = array_merge($swipebook, $_POST);
		$swipebooks[$current_id] = $new;
		//reset indexes because of sortable pages can be rearranged
		$oldPages = $swipebooks[$current_id]["pages"];
		$newPages = array();
		$index = 0;
		foreach($oldPages as $p){
			$newPages[$index] = $p;
			$index++;
		}
		$swipebooks[$current_id]["pages"] = $newPages;
						
		update_option('swipebook_'.$current_id, $swipebooks[$current_id]);

	    echo json_encode($swipebooks[$current_id]);

		wp_die(); // this is required to terminate immediately and return a proper response
	}



	//options page
	function swipebook_admin()
    {

		$current_action = $current_id = $page_id = '';
		// handle action from url
		if (isset($_GET['action']) ) {
			$current_action = $_GET['action'];
		}

		if (isset($_GET['bookId']) ) {
			$current_id = $_GET['bookId'];
		}
		
		if (isset($_GET['pageId']) ) {
			$page_id = $_GET['pageId'];
		}

		$url=admin_url( "admin.php?page=swipebook_admin" );

		$swipebooks_converted = get_option("swipebooks_converted");

		if(!$swipebooks_converted){

			$swipebooks = get_option("swipebooks");
			if(!$swipebooks){
				$swipebooks = array();
			}

			add_option('swipebooks_converted', true);
			$swipebooks_ids = array();
			//trace('converting swipebooks...');
			foreach ($swipebooks as $b) {
				$id = $b['id'];
				//trace($id);
				delete_option('swipebook_'.(string)$id);
				add_option('swipebook_'.(string)$id, $b);
				array_push($swipebooks_ids,(string)$id);
			}
			// trace($swipebooks_ids);
		}else{
			// trace($swipebooks_ids);
			$swipebooks_ids = get_option('swipebooks_ids');
			if(!$swipebooks_ids){
				$swipebooks_ids = array();
			}
			$swipebooks = array();
			foreach ($swipebooks_ids as $id) {
				// trace($id);
				$book = get_option('swipebook_'.$id);
				if($book){
					$swipebooks[$id] = $book;
					// array_push($swipebooks,$book);
				}else{
					//remove id from array
					$swipebooks_ids = array_diff($swipebooks_ids, array($id));
				}
			}
		}
		
		update_option('swipebooks_ids', $swipebooks_ids);

		switch( $current_action ) {
		
			case 'edit':
				include("edit-swipebook.php");
				break;
				
			case 'delete':
				//backup
				delete_option('swipebooks_ids_back');
				add_option('swipebooks_ids_back',$swipebooks_ids);
				foreach ($swipebooks_ids as $id) {
					update_option("swipebooks_ids",array());
				}
				
				
				$ids = explode(',', $current_id);
				
				foreach ($ids as $id) {
					unset($swipebooks[$id]);
				}
				$swipebooks_ids = array_diff($swipebooks_ids, $ids);
				update_option('swipebooks_ids', $swipebooks_ids);
				
				//delete swipebook with id from url
				
				include("swipebooks.php");
				// trace($swipebooks[$current_id]['name']);
				// trace(REAL3D_swipebook_DIR);
				////delete folder books/$swipebooks[$current_id]['name']
				// $bookFolder = $swipebooks[$current_id]['name'];
				// trace(REAL3D_swipebook_DIR.'books/'.$bookFolder);
				// rrmdir(REAL3D_swipebook_DIR.'books/'.$bookFolder);
				break;
				
			case 'delete_all':
				//backup
				delete_option('swipebooks_ids_back');
				add_option('swipebooks_ids_back',$swipebooks_ids);
				foreach ($swipebooks_ids as $id) {
					delete_option('swipebook_'.(string)$id);
				}
				$swipebooks = array();
				include("swipebooks.php");
				break;
				
			case 'duplicate':
				$new_id = 0;
				$highest_id = 0;

				foreach ($swipebooks_ids as $id) {
					if((int)$id > $highest_id) {
						$highest_id = (int)$id;
					}
				}
				$new_id = $highest_id + 1;
				$swipebooks[$new_id] = $swipebooks[$current_id];
				$swipebooks[$new_id]["id"] = $new_id;
				$swipebooks[$new_id]["name"] = $swipebooks[$current_id]["name"]." (copy)";
				
				$swipebooks[$new_id]["date"] = current_time( 'mysql' );

				delete_option('swipebook_'.(string)$new_id);
				add_option('swipebook_'.(string)$new_id,$swipebooks[$new_id]);

				array_push($swipebooks_ids,$new_id);
				update_option('swipebooks_ids',$swipebooks_ids);


				include("swipebooks.php");
				break;
				
			case 'add_new':
				//generate ID 
				$new_id = 0;
				$highest_id = 0;

				foreach ($swipebooks_ids as $id) {
					if((int)$id > $highest_id) {
						$highest_id = (int)$id;
					}
				}

				$current_id = $highest_id + 1;
				//create new book 
				$book = array(	"id" => $current_id, 
								"name" => "swipebook " . $current_id,
								"pages" => array(),
								"date" => current_time( 'mysql' ),
								"viewMode" => "swipe"
							);
				//save new book to database
				delete_option('swipebook_'.(string)$current_id);
				add_option('swipebook_'.(string)$current_id,$book);
				//add new book to books
				array_push($swipebooks,$book);
				//save new id to array of id-s
				array_push($swipebooks_ids,$current_id);
				update_option('swipebooks_ids',$swipebooks_ids);

				include("edit-swipebook.php");
				break;
				
			case 'add_new_cat':
				
				break;
				
			case 'save_settings':

				if(count($_POST) == 0){
					include("edit-swipebook.php");
					break;
				}
				
				//clear pages array if delete all pages
				if (!isset($_POST['pages']) ) {
					$_POST['pages'] = array();
				}
				if($swipebooks && $current_id != ''){
					$swipebook = $swipebooks[$current_id];
					if($swipebook){
						$pages = $swipebook["pages"];
					}else{
						$swipebook = array();
					}
				}

				$new = array_merge($swipebook, $_POST);
				$swipebooks[$current_id] = $new;
				//reset indexes because of sortable pages can be rearranged
				$oldPages = $swipebooks[$current_id]["pages"];
				$newPages = array();
				$index = 0;
				foreach($oldPages as $p){
					$newPages[$index] = $p;
					$index++;
				}
				$swipebooks[$current_id]["pages"] = $newPages;
								
				//for each page
				/*for($i = 0; $i < count($swipebooks[$current_id]["pages"]); $i++){
					$p = $swipebooks[$current_id]["pages"][$i];

					if(isset($p["links"])){
						//reset links 
						$oldLinks = $p["links"];
						if($oldLinks){
							$newLinks = array();
							$index = 0;
							foreach($oldLinks as $lnk){
								$newLinks[$index] = $lnk;
								$index++;
							}
							$swipebooks[$current_id]["pages"][$i]["links"] = $newLinks;
							$p = $swipebooks[$current_id]["pages"][$i];
							//for each link in links
							$formattedLinks = array();
							for($j = 0; $j < count($p["links"]); $j++){
								$l = $p["links"][$j];
								$formattedLink = array_map("cast", $l);
								$formattedLinks[$j] = $formattedLink;
							}
							$swipebooks[$current_id]["pages"][$i]["links"] = $formattedLinks;
						}
					}	
				}*/
				update_option('swipebook_'.$current_id, $swipebooks[$current_id]);

				include("edit-swipebook.php");


				// $response = array(
				//    'what'=>'foobar',
				//    'action'=>'update_something',
				//    'id'=>'1',
				//    'data'=>'<p><strong>Hello world!</strong></p>'
				// );
				// $xmlResponse = new WP_Ajax_Response($response);
				// $xmlResponse->send();



				break;


			case 'preview':

				if(count($_POST) == 0){
					include("edit-swipebook.php");
					break;
				}
				
				//clear pages array if delete all pages
				if (!isset($_POST['pages']) ) {
					$_POST['pages'] = array();
				}
				if($swipebooks && $current_id != ''){
					$swipebook = $swipebooks[$current_id];
					if($swipebook){
						$pages = $swipebook["pages"];
					}else{
						$swipebook = array();
					}
				}

				$new = array_merge($swipebook, $_POST);
				$swipebooks[$current_id] = $new;
				//reset indexes because of sortable pages can be rearranged
				$oldPages = $swipebooks[$current_id]["pages"];
				$newPages = array();
				$index = 0;
				foreach($oldPages as $p){
					$newPages[$index] = $p;
					$index++;
				}
				$swipebooks[$current_id]["pages"] = $newPages;
	
				update_option('swipebook_'.$current_id, $swipebooks[$current_id]);

		
				echo 'swipebookstart'.json_encode($swipebooks[$current_id]).'swipebookend';

				exit;
				
				break;
				
			case 'generate_json':
				// trace("generate_json");
				// trace($_POST);
				include("swipebooks.php");
				break;
			
			case 'import_from_json':
				// trace("import_from_json");
				// trace($_POST);
				include("swipebooks.php");
				break;
			
			case 'import_from_json_confirm':

				//backup
				delete_option('swipebooks_ids_back');
				add_option('swipebooks_ids_back',$swipebooks_ids);

				//delete all swipebooks
				foreach ($swipebooks_ids as $id) {
					delete_option('swipebook_'.(string)$id);
				}

				// trace($_POST);
				// trace("import_from_json_confirm");
				// trace($_POST['swipebooks']);
				$json = stripslashes($_POST['swipebooks']);
				// trace(($json));
				// trace(json_decode($json));
				// trace(json_decode($_POST['swipebooks']));

				//trace($_POST['swipebooks']);
				$newswipebooks = swipebook_objectToArray(json_decode($json));
				// trace($newswipebooks);
				if((string)$json != "" && is_array($newswipebooks)){
					$swipebooks_ids = array();
					//trace('converting swipebooks...');
					foreach ($newswipebooks as $b) {
						$id = $b['id'];
						//trace($id);
						// delete_option('swipebook_'.(string)$id);
						add_option('swipebook_'.(string)$id, $b);
						array_push($swipebooks_ids,(string)$id);
					}
					// trace($swipebooks_ids);
					update_option('swipebooks_ids', $swipebooks_ids);
					$swipebooks = $newswipebooks;
				}
				
				// trace($_POST['swipebooks'] !== "");
				// trace($_POST['swipebooks']);
				// trace(json_decode(stripslashes($_POST['swipebooks'])));
				include("swipebooks.php");
				break;
				
			case 'undo':

				$swipebooks_ids = get_option('swipebooks_ids_back');

				$swipebooks = array();
				foreach ($swipebooks_ids as $id) {
					// trace($id);
					$book = get_option('swipebook_'.$id);
					if($book){
						$swipebooks[$id] = $book;
						// array_push($swipebooks,$book);
					}else{
						//remove id from array
						$swipebooks_ids = array_diff($swipebooks_ids, array($id));
					}
				}
				update_option('swipebooks_ids', $swipebooks_ids);


				include("swipebooks.php");
				break;
			
			default:
				include("swipebooks.php");
				break;
				
		}
    }
	
	
	function swipebook_objectToArray($d) {
		if (is_object($d)) {
			// Gets the properties of the given object
			// with get_object_vars function
			$d = get_object_vars($d);
		}

		if (is_array($d)) {
			/*
			* Return array converted to object
			* Using __FUNCTION__ (Magic constant)
			* for recursive call
			*/
			return array_map(__FUNCTION__, $d);
		}
		else {
			// Return array
			return $d;
		}
	}				
	
	function swipebook_cast($n)
	{
		if($n === "true") {
			return true;
		}else if ($n === "false"){
			return false;
		}else if(is_numeric($n)){
			// return (int)$n;
			return floatval($n);
		}else{
			return $n;
		}
	}