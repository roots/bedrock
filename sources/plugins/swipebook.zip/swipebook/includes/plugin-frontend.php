<?php
	function swipebook_shortcode($atts){
		// trace($atts);
		$args = shortcode_atts( 
			array(
				'id'   => '-1',
				'name' => '-1',
				'pdf' => '-1',
				'mode' => '-1',
				'viewmode' => '-1',
				'lightboxopened' => '-1',
				'lightboxfullscreen' => '-1',
				'lightboxtext' => '-1',
				'lightboxcssclass' => '-1',
				'lightboxthumbnailurl' => '-1',
				'hidemenu' => '-1',
				'autoplayonstart' => '-1',
				'autoplayinterval' => '-1',
				'zoom' => '-1',
				'zoomdisabled' => '-1',
				'btndownloadpdfurl' => '-1',


			), 
			$atts
		);
		$id = (int) $args['id'];
		$bookId = $id .'_'.uniqid();
		$name = $args['name'];
		if($name != -1){
			$swipebooks_ids = get_option('swipebooks_ids');
			foreach ($swipebooks_ids as $id) {
				$book = get_option('swipebook_'.$id);
				if($book && $book['name'] == $name){
					$swipebook = $book;
					break;
				}
			}
		}else if($id != -1){
			$swipebook = get_option('swipebook_'.$id);
		}

		foreach ($args as $key => $val) {
			if($val != -1){

				if($key == 'mode') $key = 'mode';
				if($key == 'viewmode') $key = 'viewMode';
				if($key == 'lightboxtext') $key = 'lightboxText';
				if($key == 'lightboxopened') $key = 'lightBoxOpened';
				if($key == 'lightboxfullscreen') $key = 'lightBoxFullscreen';
				if($key == 'lightboxcssclass') $key = 'lightboxCssClass';
				if($key == 'lightboxthumbnailurl') $key = 'lightboxThumbnailUrl';
				if($key == 'pdf') $key = 'pdfUrl';
				if($key == 'hidemenu') $key = 'hideMenu';
				if($key == 'autoplayonstart') $key = 'autoplayOnStart';
				if($key == 'autoplayinterval') $key = 'autoplayInterval';
				if($key == 'zoom') $key = 'zoomLevels';
				if($key == 'zoomisabled') $key = 'zoomDisabled';
				if($key == 'btndownloadpdfurl') $key = 'btnDownloadPdfUrl';

		    	$swipebook[$key] = $val;
			}
		}

		$swipebook['rootFolder'] = plugins_url()."/swipebook/";
		$output = '<div class="swipebook" id="'.$bookId.'" ></div>';

	     if (!wp_script_is( 'real3d_flipbook', 'enqueued' )) {
	     	wp_enqueue_script("real3d_flipbook", plugins_url()."/swipebook/js/flipbook.min.js", array('jquery'),SWIPEBOOK_VERSION);
	     }

	     if (!wp_script_is( 'real3d_flipbook_bookswipe', 'enqueued' )) {
	     	wp_enqueue_script("real3d_flipbook_bookswipe", plugins_url()."/swipebook/js/flipbook.swipe.min.js", array('real3d_flipbook'),SWIPEBOOK_VERSION);
	     }

	     if (!wp_script_is( 'iscroll', 'enqueued' )) {
	     	wp_enqueue_script("iscroll", plugins_url()."/swipebook/js/iscroll.min.js", array('real3d_flipbook'),SWIPEBOOK_VERSION);
	     }

	     if($swipebook['pdfUrl'] != -1 || $swipebook['type'] == 'pdf'){

		     if (!wp_script_is( 'real3d_flipbook_pdfjs', 'enqueued' )) {
		     	wp_enqueue_script("real3d_flipbook_pdfjs", plugins_url()."/swipebook/js/pdf.min.js", array(),SWIPEBOOK_VERSION);
		     }

		     if (!wp_script_is( 'real3d_flipbook_pdfservice', 'enqueued' )) {
		     	wp_enqueue_script("real3d_flipbook_pdfservice", plugins_url()."/swipebook/js/flipbook.pdfservice.min.js", array(),SWIPEBOOK_VERSION);
		     }

	     }


	     if (!wp_script_is( 'swipebook_embed', 'enqueued' )) {
	     	wp_enqueue_script("swipebook_embed", plugins_url()."/swipebook/js/embed.js", array('real3d_flipbook'),SWIPEBOOK_VERSION);
	     }
	     wp_localize_script( 'swipebook_embed', 'swipebook_'.$bookId, json_encode($swipebook) );


	     if (!wp_style_is( 'flipbook_style', 'enqueued' )) {
	     	wp_enqueue_style( 'flipbook_style', plugins_url()."/swipebook/css/flipbook.style.css" , array(),SWIPEBOOK_VERSION);
	     }
	     if (!wp_style_is( 'font_awesome', 'enqueued' )) {
	     	wp_enqueue_style( 'font_awesome', plugins_url()."/swipebook/css/font-awesome.css" , array(),SWIPEBOOK_VERSION);
	     }
		return $output;
	}
	add_filter('widget_text', 'do_shortcode');
	add_shortcode('swipebook', 'swipebook_shortcode');