This file is part of the LightOpenID PHP Library

LightOpenID is an open source software available under the MIT License.

https://github.com/iignatov/LightOpenID

http://opensource.org/licenses/mit-license.php
