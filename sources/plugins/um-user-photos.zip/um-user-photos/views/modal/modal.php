<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="um-user-photos-modal" data-scope="um-user-photos-modal">
	<div class="um-user-photos-modal-body">
		<div class="um-user-photos-modal-head">
			<div class="um-user-photos-modal-title">
				<?php _e('Title','um-user-photos'); ?>
			</div>
		</div>
		<div class="um-user-photos-modal-content"></div>
	</div>
</div>