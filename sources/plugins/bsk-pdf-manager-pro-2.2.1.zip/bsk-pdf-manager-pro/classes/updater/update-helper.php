<?php

class BSKPDFMPro_Dashboard_Update_Helper {

    public static $_bsk_pdfm_plugin_name = 'BSK PDF Manager Pro';
	public static $_bsk_pdfm_plugin_product_id = 212;
	public static $_bsk_pdfm_plugin_folder = 'bsk-pdf-manager-pro';
	public static $_bsk_pdfm_plugin_main_file = 'bsk-pdf-manager-pro.php';
	public static $_bsk_pdfm_plugin_home_url = 'http://www.bannersky.com/';
	public static $_bsk_pdfm_plugin_product_details_page_url = 'http://www.bannersky.com/bsk-pdf-manager/';
    //public static $_bsk_pdfm_plugin_home_url = 'http://localhost/bannersky-180626/';
	//public static $_bsk_pdfm_plugin_product_details_page_url = 'http://localhost/bannersky-180626/bsk-pdf-manager/';
	public static $_bsk_pdfm_plugin_author = 'BannerSky.com';

    public static $_bsk_pdfm_remote_license_policy_page = 'http://www.bannersky.com/plugin-licensing/';
	public static $_bsk_pdfm_remote_license_checkout_page = 'http://www.bannersky.com/refund-policy/';
	public static $_bsk_pdfm_remote_account_page = 'http://www.bannersky.com/your-account/';
    
    public static $_bsk_pdfm_plugin_base_url = '';
    public static $_bsk_pdfm_plugin_license_n_update_page_url = '';
	public static $_bsk_pdfm_plugin_slug = 'bsk-pdf-manager-pro';
	
	public function __construct() {
		
		self::$_bsk_pdfm_plugin_base_url = admin_url( 'admin.php?page='.BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['base'] );
        self::$_bsk_pdfm_plugin_license_n_update_page_url = admin_url( 'admin.php?page='.BSKPDFMPro_Dashboard::$_bsk_pdfm_pro_pages['license_update'] );
		
		if( is_admin() ){
			add_action( "wp_ajax_bsk_pdfm_dismiss_new_update_".self::$_bsk_pdfm_plugin_slug, array($this, 'bsk_pdfm_notice_dismiss_new_update') );
			add_action( "wp_ajax_bsk_pdfm_dismiss_expired_".self::$_bsk_pdfm_plugin_slug, array($this, 'bsk_pdfm_notice_dismiss_expired') );	
			add_action( "wp_ajax_bsk_pdfm_dismiss_invalid_".self::$_bsk_pdfm_plugin_slug, array($this, 'bsk_pdfm_notice_dismiss_invalid') );		
			
			add_action( 'admin_notices', array($this, 'bsk_pdfm_admin_notice_fun') );
		}
        
        add_action( 'bsk_pdfm_schedule_check_license_daily', array( $this, 'bsk_pdfm_schedule_check_license_daily_fun') );
        if ( function_exists('wp_next_scheduled') && function_exists('wp_schedule_event') ){
			if ( !wp_next_scheduled( 'bsk_pdfm_schedule_check_license_daily' ) ) {
				wp_schedule_event( time(), 'daily', 'bsk_pdfm_schedule_check_license_daily' );
			}
		}
	}
	
	function bsk_pdfm_admin_notice_fun(){
		global $pagenow;
		
		if( 'index.php' !== $pagenow ){
			return;
		}
		$license = get_option( BSKPDFMPro_Dashboard::$_plugin_license, '' );
        $license_status = '';
		if( $license ){
			$license_status = $this->bsk_pdfm_remote_check_license( $license );
            if( $license_status == 'VALID' ){
                update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'VALID' );
            }else if( $license_status == 'EXPIRED' ){
                $this->bsk_pdfm_notice_expired( $license );
                update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'EXPIRED' );
            }else if( $license_status == 'DISABLED' ){
                update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'DISABLED' );
                $this->bsk_pdfm_notice_disabled();
            }else if( $license_status == 'NET_ERROR' ){
                //do nothing
            }else{
                update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, $license_status );
                $this->bsk_pdfm_notice_disabled();
            }
		}

		update_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_expired_dismissed", 0);
		update_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_disabled_dismissed", 0);
		
		$latest_info = $this->bsk_pdfm_remote_get_latest_info();
		if( !$latest_info || !is_object( $latest_info ) ){
			return;
		}
		if( version_compare( BSKPDFManagerPro::$_PLUGIN_VERSION_, $latest_info->new_version, '>=' ) ) {
			return;
		}
		$this->bsk_pdfm_notice_new_update( $latest_info->new_version, $license_status );
	}
	
	function bsk_pdfm_notice_new_update( $new_version, $license_status ){
		$dismissed_new_versions = get_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_update_dismissed", '');
		if( $dismissed_new_versions && in_array($new_version, $dismissed_new_versions) ){
			//don't show if the new version message has been dismissed
			return;
		}
		
        $message = '';
        if( $license_status == 'VALID' || $license_status == 'EXPIRED' ){
            $message = "New update available for <b>".self::$_bsk_pdfm_plugin_name."</b> <a href='".self::$_bsk_pdfm_plugin_license_n_update_page_url."'>View Details</a>";
        }else{
            $message = "New update available for <b>".self::$_bsk_pdfm_plugin_name."</b> <a href='".self::$_bsk_pdfm_plugin_base_url."'>View Details</a>";
        }
		?>
		<div class='updated' style='padding:15px; position:relative;' id='bsk_pdfm_dashboard_message_<?php echo $this->_bsk_pdfm_plugin_slug; ?>'>
			<?php echo $message ?>
			<a href="javascript:void(0);" onclick="bsk_pdfm_dismiss_message_<?php echo str_replace('-', '_', self::$_bsk_pdfm_plugin_slug); ?>();" style='float:right;'>Dismiss</a>
		</div>
		<script type="text/javascript">
		function bsk_pdfm_dismiss_message_<?php echo str_replace('-', '_', self::$_bsk_pdfm_plugin_slug); ?>(){
			jQuery("#bsk_pdfm_dashboard_message_<?php echo self::$_bsk_pdfm_plugin_slug; ?>").slideUp();
			jQuery.post(ajaxurl, {action:"bsk_pdfm_dismiss_new_update_<?php echo self::$_bsk_pdfm_plugin_slug; ?>", version:"<?php echo $new_version; ?>"});
		}
		</script>
		<?php
	}
	
	function bsk_pdfm_notice_expired( $license ){
		$expired_dismissed = get_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_expired_dismissed", 0);
		if( $expired_dismissed ){
			return;
		}
		
		$message = 'Your '.$this->_bsk_pdfm_plugin_name.' license has expired. <a href="'.self::$_bsk_pdfm_remote_license_policy_page.'" target="_blank">Learn more here</a>';
		$update_license_url = add_query_arg( array('bskddaction' => 'renewlicense', 'bskddlicense' => $license), 
                                                               self::$_bsk_pdfm_plugin_home_url );
		?>
		<div class='updated' style='padding:15px; position:relative;' id='bsk_pdfm_dashboard_expired_message_<?php echo self::$_bsk_pdfm_plugin_slug; ?>'>
			<?php echo $message ?>
            &nbsp;&nbsp;
            <a class='button-primary' href='<?php echo $update_license_url; ?>' target="_blank">Update license</a>
            <a href="javascript:void(0);" onclick="bsk_pdfm_dismiss_expired_message_<?php echo str_replace('-', '_', $this->_bsk_pdfm_plugin_slug); ?>();" style='float:right;'>Dismiss</a>
		</div>
		<script type="text/javascript">
		function bsk_pdfm_dismiss_expired_message_<?php echo str_replace('-', '_', self::$_bsk_pdfm_plugin_slug); ?>(){
			jQuery("#bsk_pdfm_dashboard_expired_message_<?php echo self::$_bsk_pdfm_plugin_slug; ?>").slideUp();
			jQuery.post(ajaxurl, {action:"bsk_pdfm_dismiss_expired_<?php echo self::$_bsk_pdfm_plugin_slug; ?>"});
		}
		</script>
		<?php
	}
	
	function bsk_pdfm_notice_disabled(){
		$is_dismissed = get_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_disabled_dismissed", 0);
		if( $is_dismissed ){
			return;
		}
		$message = 'Your '.self::$_bsk_pdfm_plugin_name.' license is disabled. <a href="'.self::$_bsk_pdfm_remote_license_policy_page.'" target="_blank">Learn more here</a>';
		?>
		<div class='updated' style='padding:15px; position:relative;' id='bsk_pdfm_dashboard_invalid_message_<?php echo self::$_bsk_pdfm_plugin_slug; ?>'>
			<?php echo $message ?>
            &nbsp;&nbsp;
            <a class='button-primary' href='<?php echo self::$_bsk_pdfm_plugin_product_details_page_url; ?>' target="_blank">Buy a license</a>
			<a href="javascript:void(0);" onclick="bsk_pdfm_dismiss_invalid_message_<?php echo str_replace('-', '_', self::$_bsk_pdfm_plugin_slug); ?>();" style='float:right;'>Dismiss</a>
		</div>
		<script type="text/javascript">
		function bsk_pdfm_dismiss_invalid_message_<?php echo str_replace('-', '_', self::$_bsk_pdfm_plugin_slug); ?>(){
			jQuery("#bsk_pdfm_dashboard_invalid_message_<?php echo self::$_bsk_pdfm_plugin_slug; ?>").slideUp();
			jQuery.post(ajaxurl, {action:"bsk_pdfm_dismiss_invalid_<?php echo self::$_bsk_pdfm_plugin_slug; ?>"});
		}
		</script>
		<?php
	}
	
	function bsk_pdfm_notice_dismiss_new_update(){
       $dismissed_versions_array = get_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_update_dismissed");
        if( !is_array( $dismissed_versions_array ) ){
            $dismissed_versions_array = array();
		}

        $dismissed_versions_array[] = $_POST["version"];
        update_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_update_dismissed", $dismissed_versions_array);
    }
	
	function bsk_pdfm_notice_dismiss_expired(){
		update_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_expired_dismissed", 1);
	}
	
	function bsk_pdfm_notice_dismiss_invalid(){
		update_option("_bsk_pdfm_".self::$_bsk_pdfm_plugin_slug."_disabled_dismissed", 1);
	}
	
	function bsk_pdfm_plugin_update_center(){
        //check if the plugin activated manually
        if( get_option(BSKPDFMPro_Dashboard::$_plugin_license_activated_manually, NULL) ){
            echo '<p>As your server cannot connect to ours well so get the latest version and update manually.</p>';
            echo '<p>Please visit <a href="http://www.bannersky.com/purchase-history/" target="_blank">Purchase History</a> to check if new version available or not first. If you decided to install a new version, then please follow the instucutres here.</p>';
            echo '<h3>Manually Update Steps: </h3>';
            echo '<p>1. Download the latest version package from <a href="http://www.bannersky.com/purchase-history/" target="_blank">Purchase History</a></p>';
            echo '<p>2. Extract the package to your local</p>';
            echo '<p>3. Upload all files in the package to your server /wp-content/plugins/bsk-pdf-manager-pro/, overwrite all files.</p>';
                
            return;
        }
        
		//get latest plugin info from server, if there's new version, show new version info
        $license = get_option( BSKPDFMPro_Dashboard::$_plugin_license, NULL );
		$latest_info = $this->bsk_pdfm_remote_get_latest_info();
		if( !$latest_info || !is_object( $latest_info ) || version_compare( BSKPDFManagerPro::$_PLUGIN_VERSION_, $latest_info->new_version, '>=' ) ){
			echo '<p>The version '.BSKPDFManagerPro::$_PLUGIN_VERSION_.' you have is the latest.</p>';
		}else{
			$this->bsk_pdfm_update_center_show_update( $latest_info );
		}
	}
	
	function bsk_pdfm_update_center_show_expired( $license ){
		$message = 'Updates are not available for '.self::$_bsk_pdfm_plugin_name.' as your license has expired. <a href="'.self::$_bsk_pdfm_remote_license_policy_page.'" target="_blank">Learn more here';
		$update_license_url = add_query_arg( array('bskddaction' => 'renewlicense', 'bskddlicense' => $license), 
                                                               self::$_bsk_pdfm_plugin_home_url );
	?>
        <div style="width:95%; padding:20px; border: 1px solid #E6DB55; background-color: #FFFBCC; color: #424242;">
            <p><?php echo $message; ?></p>
            <a class='button-primary' href='<?php echo $update_license_url; ?>' target="_blank">Renew license here</a> &nbsp;
        </div>
    <?php
	}
	
	function bsk_pdfm_update_center_show_disabled(){
		$message = 'Updates are not available for '.self::$_bsk_pdfm_plugin_name.' as your license is disabled. <a href="'.self::$_bsk_pdfm_remote_license_policy_page.'" target="_blank">Learn more here';
	?>
        <div style="width:95%; padding:20px; border: 1px solid #E6DB55; background-color: #FFFBCC; color: #424242;">
            <p><?php echo $message; ?></p>
            <a class='button-primary' href='<?php echo self::$_bsk_pdfm_plugin_product_details_page_url; ?>' target="_blank">Buy a license</a> &nbsp;
        </div>
    <?php
	}
    
    function bsk_pdfm_update_center_show_purchase( $license_status ){
        $license_status = $license_status ? $license_status : 'NONE EXISTS';
		$message = 'Updates are not available for '.self::$_bsk_pdfm_plugin_name.' as your license is <span style="font-weight:bold;">'.$license_status.'</span>';
	?>
        <div style="width:95%; padding:20px; border: 1px solid #E6DB55; background-color: #FFFBCC; color: #424242;">
            <p><?php echo $message; ?></p>
            <a class='button-primary' href='<?php echo self::$_bsk_pdfm_plugin_product_details_page_url; ?>' target="_blank">Buy a license</a> &nbsp;
        </div>
    <?php
	}
    
    function bsk_pdfm_update_center_show_update( $latest_info ){
		//see if WordPress created its update array or not, if the array not exist then can not upgrade automatically
		$only_can_update_manually = false;
		$update_transient = get_site_transient( 'update_plugins' );
		if( empty( $update_transient ) ){
			$only_can_update_manually = true;
		}else{
			//To make the update works it must set the update transient data first, because WordPress will read it to download the package
			$update_transient->response[self::$_bsk_pdfm_plugin_folder.'/'.self::$_bsk_pdfm_plugin_main_file] = $latest_info;
			set_site_transient( 'update_plugins', $update_transient );
			
			//url to show update automatically
			$plugin_file_with_folder = self::$_bsk_pdfm_plugin_folder.'/'.self::$_bsk_pdfm_plugin_main_file;
			$upgrade_url = wp_nonce_url('update.php?action=upgrade-plugin&amp;plugin=' . urlencode($plugin_file_with_folder), 'upgrade-plugin_' . $plugin_file_with_folder);
		}
		?>
        <div style="width:95%; margin-top: 10px; padding: 20px; border:1px solid #ccc; background-color: #e5f3f9;">
        	<p>There is a new version of <span style="font-weight:bold;"><?php echo self::$_bsk_pdfm_plugin_name.' '.$latest_info->new_version; ?></span> available. </p>
            <h3>What's New</h3>
            <?php if( isset($latest_info->sections['changelog']) ) echo $latest_info->sections['changelog']; ?>
            <?php
			//if license is expired or disabled, then don't show update tab
			$license_status = get_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts );
			if( $license_status == 'VALID' ){ 
			?>
                <h3 style="margin-top:40px;">Update</h3>
                <?php
                if( is_multisite() && !is_super_admin() ){
                    echo '<p>Only Super Admin can do plugin upgrade</p>';
                }else{
                    if( $only_can_update_manually == false ){
                ?>
                        <p>You can update to the latest version automatically.</p>
                        <a class='button-primary' href='<?php echo $upgrade_url; ?>'>Update Automatically</a> &nbsp;
                    <?php 
                    }else{ //show download manually 
                    ?>
                        <p>The WordPress automatic update feature is disabled on your site. You may download the latest version and update manually. </p>
                         <h4>Manually Update Steps: </h4>
                        <p>1. Download the latest version package from <a href="http://www.bannersky.com/purchase-history/" target="_blank">Purchase History</a></p>
                        <p>2. Extract the package to your local</p>
                        <p>3. Upload all files in the package to your server /wp-content/plugins/bsk-pdf-manager-pro/ by <b>FTP</b>, overwrite all files.</p>
                    <?php
                        if( isset($latest_info->package) && $latest_info->package ){
                            $download_page_url = $latest_info->package;
                            $target = "_blank";
                            echo '<a class="button-primary" href="'.$download_page_url.'" target="'.$target.'">Download latest package</a>';
                        }
                    } //show download manually 
                }
			}
			?>
        </div>
    <?php
	}	
	
	
	function bsk_pdfm_remote_get_latest_info() {

        $api_params = array( 
			'bskddaction' 	=> 'get_latest_info',
			'slug'			=> self::$_bsk_pdfm_plugin_slug,
			'author'		=> self::$_bsk_pdfm_plugin_author,
			'product_id' 	=> self::$_bsk_pdfm_plugin_product_id
		);
		
		$request = wp_remote_get( add_query_arg( $api_params, self::$_bsk_pdfm_plugin_home_url ), 
                                                array( 'timeout' => 15, 'ssverify' => false ) );
		if ( is_wp_error( $request ) ){
			return false;
		}
		
		$data = json_decode( wp_remote_retrieve_body( $request ) );
		if( $data ){
			$data->sections = maybe_unserialize( $data->sections );
		}

		return $data;
	}
	
	function bsk_pdfm_remote_check_license( $license ) {
		if( trim($license) == "" ){
			return false;
		}
		
		$api_params = array( 
			'bskddaction' 	=> 'check_license',
			'license' 		=> $license, 
			'product_id' 	=> self::$_bsk_pdfm_plugin_product_id,
            'site'              => site_url(),
			
		);

        if( get_option( BSKPDFMPro_Dashboard::$_plugin_license_activated_manually, false ) ){
			return false;
		}

        $response = wp_remote_get( add_query_arg( $api_params, self::$_bsk_pdfm_plugin_home_url ), 
                                                   array( 'timeout' => 15, 'ssverify' => false ) );
		if ( is_wp_error( $response ) ){
			return 'NET_ERROR';
		}
        $response_body = wp_remote_retrieve_body( $response );
        if( trim($response_body) == "" ){
            return 'NET_ERROR';
        }
		// decode the license data
		$license_data = json_decode( $response_body );

		if( $license_data && isset($license_data->license_status) ){
			return $license_data->license_status;
		}
		return false;
	}
    
    function bsk_pdfm_schedule_check_license_daily_fun(){
        //check if license key expired or not
        $license = get_option( BSKPDFMPro_Dashboard::$_plugin_license );
        if( trim($license) == "" ){
            return;
        }
		$license_status = $this->bsk_pdfm_remote_check_license( $license );
        if( $license_status == 'VALID' ){
            update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'VALID' );
        }else if( $license_status == 'EXPIRED' ){
            update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'EXPIRED' );
        }else if( $license_status == 'DISABLED' ){
            update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'DISABLED' );
        }else if( $license_status == 'NONE EXISTS' ){
            update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, 'NONE EXISTS' );
        }else if( $license_status == 'NET_ERROR' ){
            //do nothing
        }else{
            update_option( BSKPDFMPro_Dashboard::$_plugin_license_stauts, $license_status );
        }
    }
}
