<?php

class BSKPDFMPro_Shortcodes_Selector_Deprecated {
    
    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
   
	public function __construct() {
		add_shortcode('bsk-pdf-manager-list-selector', array($this, 'bsk_pdf_manager_list_selector_fun') );
		
		add_action( 'wp_ajax_selector_get_assoicated_pdfs', array( $this, 'bsk_pdfm_get_assoicated_pdfs_fun' ) );
		add_action( 'wp_ajax_nopriv_selector_get_assoicated_pdfs', array( $this, 'bsk_pdfm_get_assoicated_pdfs_fun' ) );
	}
	
	function bsk_pdf_manager_list_selector_fun( $atts ){
		global $wpdb;
		
		$license = get_option( self::$_plugin_license, '' );
		$license_status = get_option( self::$_plugin_license_stauts, '' );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
		
		//read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_size = 'thumbnail';
		$enable_multi_column_layout = false;
		$default_column_number = 2;
		$default_column_layout_title_positon = 'below';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, null );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
			
			if( isset($plugin_settings['multi_column_layout']) ){
				$enable_multi_column_layout = $plugin_settings['multi_column_layout'];
			}
			
			if( isset($plugin_settings['default_column_number']) ){
				$default_column_number = $plugin_settings['default_column_number'];
			}
			
			if( isset($plugin_settings['column_layout_title_positon']) ){
				$default_column_layout_title_positon = $plugin_settings['column_layout_title_positon'];
			}
		}
		
		extract( shortcode_atts( array('defaultid' => '',
									   'selectoroptionnone' => '',
									   'includeid' => '',
									   'excludeid' => '',
									   'orderby' => '', 
									   'order' => '', 
                                       'additional_filter' => 'false',
									   'target' => '',
									   'dropdown' => '',
									   'showoptionnone' => '',
									   'mosttop' => 0,
									   'featuredimage' => '',
									   'featuredimagesize' => '',
									   'showpdftitle' => '',
									   'nofollowtag' => 'false',
									   'showdate' => 'false',
									   'dateformat' => ' d/m/Y',
									   'datebeforetitle' => false,
									   'orderedlist' => '',
									   'columns' => 2,
									   'multicolumns' => 'no',
									   'show_empty_message' => 'no' ),
								  $atts ) );
		$default_id = 0;
		$defaultid = trim($defaultid);
		if( strtoupper($defaultid) == 'ALL' ){
			$default_id = -1;
		}else{
			$default_id = intval( $defaultid );
		}
		
		$bsk_pm_cat_ids_included_array = array();
		if( trim($includeid) ){
			$bsk_pm_cat_ids_included_array = explode( ',', trim($includeid) );
			if( count($bsk_pm_cat_ids_included_array) > 0 ){
				foreach( $bsk_pm_cat_ids_included_array as $key => $cat_id ){
					$bsk_pm_cat_ids_included_array[$key] = intval( $cat_id );
				}
			}
		}
		
		$bsk_pm_cat_ids_to_exclude_array = array();
		if( trim($excludeid) ){
			$bsk_pm_cat_ids_to_exclude_array = explode( ',', trim($excludeid) );
			if( count($bsk_pm_cat_ids_to_exclude_array) > 0 ){
				foreach( $bsk_pm_cat_ids_to_exclude_array as $key => $cat_id ){
					$bsk_pm_cat_ids_to_exclude_array[$key] = intval( $cat_id );
				}
			}
		}
		
		//remove excluded id from included array
		if( count($bsk_pm_cat_ids_included_array) > 0 ){
			if( count($bsk_pm_cat_ids_to_exclude_array) > 0 ){
				foreach( $bsk_pm_cat_ids_included_array as $key => $included_id ){
					if( in_array( $included_id, $bsk_pm_cat_ids_to_exclude_array ) ){
						unset( $bsk_pm_cat_ids_included_array[$key] );
					}
				}
			}
		}
		
		$sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name.'` ORDER BY `title` ASC';
		if( $bsk_pm_cat_ids_included_array && is_array($bsk_pm_cat_ids_included_array) && count($bsk_pm_cat_ids_included_array) > 0 ){
			$sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name.'` WHERE `id` IN('.implode(',', $bsk_pm_cat_ids_included_array).') ORDER BY `title` ASC';
		}
		$categories_array = $wpdb->get_results($sql);
		if( !$categories_array || !is_array($categories_array) || count($categories_array) < 1 ){
			return '';
		}
		
		//process open target
		$open_target_str = trim($target);

		//process order
		$order_by_str = ' ORDER BY `title`'; //default set to title
		$order_str = ' ASC';
		if( $orderby == 'title' ){
			//default
		}else if( $orderby == 'filename' ){
			$order_by_str = ' ORDER BY `file_name`';
		}else if( $orderby == 'date' ){
			$order_by_str = ' ORDER BY `last_date`';
		}else if( $orderby == 'custom' ){
			$order_by_str = ' ORDER BY `order_num`';
		}
		if( trim($order) == 'DESC' ){
			$order_str = ' DESC';
		}
        
		//selected option of selector
		$selector_selected_option = trim($selectoroptionnone);

		//dropdown
		$output_as_dropdown = false;
		if( $dropdown && is_string($dropdown) ){
			$output_as_dropdown = strtoupper($dropdown) == 'YES' ? true : false;
			if( $output_as_dropdown == false ){
				$output_as_dropdown = strtoupper($dropdown) == 'TRUE' ? true : false;
			}
		}else if( is_bool($dropdown) ){
			$output_as_dropdown = $dropdown;
		}
		//showoptionnone
		$selected_option_text = '';
		if( $output_as_dropdown ){
			$selected_option_text = trim( $showoptionnone );
		}
		
		//most recent count
		$most_recent_count = intval($mosttop);
		if( $most_recent_count < 1 ){
			$most_recent_count = 99999;
		}
		
		//featured image
		$featured_image = false;
		$featured_image_size = '';
		if( $featuredimage && is_string($featuredimage) ){
			$featured_image = strtoupper($featuredimage) == 'TRUE' ? true : false;
			if( $featured_image == false ){
				$featured_image = strtoupper($featuredimage) == 'YES' ? true : false;
			}
		}else if( is_bool($featuredimage) ){
			$featured_image = $featuredimage;
		}
		
		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$featured_image = false;
		}
		
		//show pdf title with featured imaged
		$show_PDF_title_with_featured_image = false;
		if( $featured_image ){
			if( $showpdftitle && is_string($showpdftitle) ){
				$show_PDF_title_with_featured_image = strtoupper($showpdftitle) == 'TRUE' ? true : false;
				if( $show_PDF_title_with_featured_image == false ){
					$show_PDF_title_with_featured_image = strtoupper($showpdftitle) == 'YES' ? true : false;
				}
			}else if( is_bool($showpdftitle) ){
				$show_PDF_title_with_featured_image = $showpdftitle;
			}
			
			$featured_image_size = trim($featuredimagesize) ? trim($featuredimagesize) : $default_thumbnail_size;
		}
		
		//anchor nofollow tag
		$nofollow_tag = false;
		if( $nofollowtag && is_string($nofollowtag) ){
			$nofollow_tag = strtoupper($nofollowtag) == 'YES' ? true : false;
			if( strtoupper($nofollowtag) == 'TRUE' ){
				$nofollow_tag = true;
			}
		}else if( is_bool($nofollowtag) ){
			$nofollow_tag = $nofollowtag;
		}
		//show date in title
		$show_date_in_title = false;
		if( $showdate && is_string($showdate) ){
			$show_date_in_title = strtoupper($showdate) == 'YES' ? true : false;
			if( strtoupper($showdate) == 'TRUE' ){
				$show_date_in_title = true;
			}
		}else if( is_bool($showdate) ){
			$show_date_in_title = $showdate;
		}
		
		//date postion
		$date_before_title = false;
		if( $datebeforetitle && is_string($datebeforetitle) ){
			$date_before_title = strtoupper($datebeforetitle) == 'YES' ? true : false;
			if( strtoupper($datebeforetitle) == 'TRUE' ){
				$date_before_title = true;
			}
		}else if( is_bool($datebeforetitle) ){
			$date_before_title = $datebeforetitle;
		}
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $dateformat && is_string($dateformat) && $dateformat != ' d/m/Y' ){
			$date_format_str = $dateformat;
		}
		
		if( $output_as_dropdown ){
			$date_format_str = $date_before_title ? 'd/m/Y' : 'd/m/Y';
			if( $dateformat && is_string($dateformat) && $dateformat != ' d/m/Y' ){
				$date_format_str = $dateformat;
			}
		}
		
		//show as ordered list
		$show_as_ordered_list = false;
		if( $orderedlist && is_string($orderedlist) ){
			$show_as_ordered_list = strtoupper($orderedlist) == 'YES' ? true : false;
			if( strtoupper($orderedlist) == 'TRUE' ){
				$show_as_ordered_list = true;
			}
		}else if( is_bool($orderedlist) ){
			$show_as_ordered_list = $orderedlist;
		}
		//multi-column
		if( $enable_multi_column_layout ){
			$columns_number = intval($columns);
			if( $columns_number > 1 ){
				$default_column_number = $columns_number;
			}
			if( $multicolumns && is_string($multicolumns) ){
				$enable_multi_column_layout = strtoupper($multicolumns) == 'YES' ? true : false;
				if( strtoupper($multicolumns) == 'TRUE' ){
					$enable_multi_column_layout = true;
				}
			}else if( is_bool($multicolumns) ){
				$enable_multi_column_layout = $multicolumns;
			}
		}
		
		//show empty message
		$show_empty_message_bool = false;
		if( $show_empty_message && is_string($show_empty_message) ){
			$show_empty_message_bool = strtoupper($show_empty_message) == 'YES' ? true : false;
			if( strtoupper($show_empty_message) == 'TRUE' ){
				$show_empty_message_bool = true;
			}
		}else if( is_bool($show_empty_message) ){
			$show_empty_message_bool = $show_empty_message;
		}
		
		$home_url = site_url();
		$rand_id = rand(1, 100000);
		$forStr = '<div id="bsk_pdfm_list_selector_container_'.$rand_id.'" class="bsk-pdfm-list-selector-container">';
		//show category menu
		$forStr .= '<div id="bsk_pdfm_list_selector_menu_container_'.$rand_id.'" class="bsk-pdfm-list-selector-menu">';
		$forStr .= '<select id="bsk_pdfm_list_selector_menu_select_'.$rand_id.'" class="bsk-pdfm-list-selector-menu-select">';
		if( $default_id == -1 ){
			$forStr .= '<option value="-1">All</option>';
		}else if( $selector_selected_option ){
			$forStr .= '<option value="0">'.$selector_selected_option.'</option>';
		}
		
		$default_empty_message = '';
		foreach( $categories_array as $cat_obj ){
			if ( is_array( $bsk_pm_cat_ids_to_exclude_array ) && 
				 count( $bsk_pm_cat_ids_to_exclude_array ) > 0 && 
				 in_array( $cat_obj->id, $bsk_pm_cat_ids_to_exclude_array ) ) {
				
				continue;
			}
			
			if ($default_id == $cat_obj->id){
				$forStr .= '<option value="'.$cat_obj->id.'" selected>'.$cat_obj->title.'</option>';
				$default_empty_message = $cat_obj->empty_message;
			}else{
				$forStr .= '<option value="'.$cat_obj->id.'">'.$cat_obj->title.'</option>';
			}
		}
		$forStr .= '</select>';
        
		$forStr .= '<span style="display:none;" id="bsk_pdfm_list_selector_ajax_loader_span_'.$rand_id.'" class="bsk-pdfm-list-selector-ajax-loader-span"><img src="'.BSKPDFManagerPro::$_ajax_loader_img_url.'" /></span>';
		$forStr .= '</div>';
		
		$forStr .= '<div id="bsk_pdfm_list_selector_pdfs_container_'.$rand_id.'" class="bsk-pdfm-list-selector-pdfs-container">';
		
		$str = $this->get_all_pdfs_within_category( $default_id, $order_by_str, $order_str,
													$output_as_dropdown, $selected_option_text, $most_recent_count, $show_as_ordered_list, 
													$featured_image, $featured_image_size, $show_PDF_title_with_featured_image, $open_target_str, $nofollow_tag, 
													$show_date_in_title, $date_format_str, $date_before_title, 
													$default_column_number, $enable_multi_column_layout, $default_column_layout_title_positon, 
													$show_empty_message_bool, $default_empty_message );
		$forStr .= $str;
		$forStr .= '</div>';
		
		$as_dropdown_str = $output_as_dropdown ? 'YES' : '';
		$dropdown_selected_option_text = $selected_option_text;
		$show_as_ordered_list_hidden = $show_as_ordered_list ? 'YES' : '';
		$featured_image_hidden = $featured_image ? 'YES' : '';
		$show_PDF_title_with_featured_image_hidden = $show_PDF_title_with_featured_image ? 'YES' : '';
		$nofollow_tag_hidden = $nofollow_tag ? 'YES' : '';
		$show_date_in_title_hidden = $show_date_in_title ? 'YES' : '';
		$date_before_title_str = $date_before_title ? 'YES' : '';
		$multicolumns_str = $enable_multi_column_layout ? 'YES' : '';
		$show_empty_message_str = $show_empty_message_bool ? 'YES' : '';
		
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_order_by_'.$rand_id.'" value="'.$order_by_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_cat_order_'.$rand_id.'" value="'.$order_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_as_dropdown_'.$rand_id.'" value="'.$as_dropdown_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_dropdown_selected_option_'.$rand_id.'" value="'.$dropdown_selected_option_text.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_category_top_'.$rand_id.'" value="'.$most_recent_count.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_show_ordered_list_'.$rand_id.'" value="'.$show_as_ordered_list_hidden.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_show_thumbnail_'.$rand_id.'" value="'.$featured_image_hidden.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_thumbnail_size_'.$rand_id.'" value="'.$featured_image_size.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_thumbnail_with_title_'.$rand_id.'" value="'.$show_PDF_title_with_featured_image_hidden.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_open_target_'.$rand_id.'" value="'.$open_target_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_nofollow_tag_'.$rand_id.'" value="'.$nofollow_tag_hidden.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_show_date_in_title_'.$rand_id.'" value="'.$show_date_in_title_hidden.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_date_format_'.$rand_id.'" value="'.$date_format_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_date_before_title_'.$rand_id.'" value="'.$date_before_title_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_columns_'.$rand_id.'" value="'.$columns.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_multicolumn_'.$rand_id.'" value="'.$multicolumns_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_show_empty_message_'.$rand_id.'" value="'.$show_empty_message_str.'" />';
		$forStr .= '<input type="hidden" id="bsk_pdfm_selector_additional_filter_'.$rand_id.'" value="'.$additional_filter.'" />';
		if( $default_id == -1 ){
			$forStr .= '<input type="hidden" id="bsk_pdfm_selector_defaultid_'.$rand_id.'" value="-1" />';
		}
			
		$forStr .= '</div>';
		
		return $forStr;
	}
	
	function get_all_pdfs_within_category( $category_id, $order_by, $order,
                                           $dropdown, $dropdown_selected, $most_top, $ordered_list, 
										   $show_thumbnail, $thumbnail_size, $show_thumbnail_with_title, $open_target, $nofollow_tag, 
										   $show_date_in_title, $date_format_str, $date_before_title, $columns = 2, $multicolumns = false, $title_postion_4_mulitcolumn = 'below',
										   $show_category_empty_message = false, $default_empty_message = '' ){
		if( $category_id == 0 || $category_id == "" ){
			return '';
		}
		
		global $wpdb;
		
		//read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$featured_image_size = $thumbnail_size ? $thumbnail_size : 'thumbnail';
		$enable_multi_column_layout = false;
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, null );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$featured_image_size = $plugin_settings['default_thumbnail_size'];
			}
			if( isset($plugin_settings['default_thumbnail_id']) ){
				$default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
				if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
					$default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $thumbnail_size );
				}
			}
			
			if( isset($plugin_settings['multi_column_layout']) ){
				$enable_multi_column_layout = $plugin_settings['multi_column_layout'];
			}
		}

		//check if plugin setting -> enable featured image
		if( $default_enable_featured_image == false ){
			$show_thumbnail = false;
		}
		
		//multi-column
		if( $enable_multi_column_layout ){
			$columns_number = intval($columns);
			if( $columns_number > 1 ){
				$default_column_number = $columns_number;
			}
			if( $multicolumns && is_string($multicolumns) ){
				$enable_multi_column_layout = strtoupper($multicolumns) == 'YES' ? true : false;
				if( strtoupper($multicolumns) == 'TRUE' ){
					$enable_multi_column_layout = true;
				}
			}else if( is_bool($multicolumns) ){
				$enable_multi_column_layout = $multicolumns;
			}
		}
		
		$column_class = 'bsk-pdfm-one-half';
		if( $enable_multi_column_layout ){
			switch( $default_column_number ){
				case 2:
					$column_class = 'bsk-pdfm-one-half';
				break;
				case 3:
					$column_class = 'bsk-pdfm-one-third';
				break;
				case 4:
					$column_class = 'bsk-pdfm-one-fourth';
				break;
				case 5:
					$column_class = 'bsk-pdfm-one-fifth';
				break;
				case 6:
					$column_class = 'bsk-pdfm-one-sixth';
				break;
			}
		}
		
		$pdf_items_results = array();
		if( $category_id == -1 ){
			$sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` '.
				   'WHERE 1 '.
				   $order_by.$order.' ';
			$pdf_items_results = $wpdb->get_results( $sql );
			if( !$pdf_items_results || !is_array($pdf_items_results) || count($pdf_items_results) < 1 ){
				return '';
			}
		}else{
			//get pdf items in the category
			$sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` AS P '.
                     'LEFT JOIN `'.$wpdb->prefix.BSKPDFManagerPro::$_rels_tbl_name.'` AS R ON P.`id` = R.`pdf_id` '.
				     'WHERE R.`cat_id` = %d'.
				     $order_by.$order;
			$sql = $wpdb->prepare( $sql, $category_id );
			$pdf_items_results = $wpdb->get_results( $sql );
			if( !$pdf_items_results || !is_array($pdf_items_results) || count($pdf_items_results) < 1 ){
				$forStr = '';
				if( $show_category_empty_message && $default_empty_message ){
					$forStr .= '<p><span class="bsk-pdf-category-empty-message">'.$default_empty_message.'</span></p>';
				}
				return $forStr;
			}
		}
		
		//remove unpublished and expired ones
		foreach( $pdf_items_results as $key => $pdf_item_obj ){
			if( $pdf_item_obj->publish_date && $pdf_item_obj->publish_date != '0000-00-00 00:00:00' ){
				if( date('Y-m-d 23:59:59', current_time( 'timestamp' ) ) < $pdf_item_obj->publish_date  ){
					unset( $pdf_items_results[$key] );
					continue;
				}
			}
			
			if( $pdf_item_obj->expiry_date && $pdf_item_obj->expiry_date != '0000-00-00 00:00:00' ){
				if( $pdf_item_obj->expiry_date <= date('Y-m-d 00:00:00', current_time( 'timestamp' ) ) ){
					unset( $pdf_items_results[$key] );
					continue;
				}
			}
		}
		
		//process most top
		if( $most_top > 0 ){
			$pdf_items_results = array_slice( $pdf_items_results, 0, $most_top );
		}
		
		if( count($pdf_items_results) < 1 ){
			if( $show_category_empty_message && $default_empty_message ){
				$forStr .= '<p><span class="bsk-pdf-category-empty-message">'.$default_empty_message.'</span></p>';
				
				return $forStr;
			}
		}
		
		$forStr = '';
		$output_as_dropdown = $dropdown;
		if( $output_as_dropdown == true ){
			$forStr .= '<select name="bsk_pdfm_selector_pdfs_dropdown" class="bsk-pdfm-selector-pdfs-dropdown cat-'.$category_id.'" attr_target="'.$open_target.'">';
			$dropdown_selected = $dropdown_selected ? $dropdown_selected : 'Please selecte category...';
		}else if( $enable_multi_column_layout == true ){
			$forStr .= '<div class="bsk-specific-pdfs-multi-column-container">'."\n";
		}else{
			if( $dropdown_selected ){
				$forStr .= '<option value="">'.$dropdown_selected.'</option>';
			}
			
			if( $ordered_list ){
				$forStr .= '<ol class="bsk-pdfm-selector-pdfs-ordered-list cat-'.$category_id.'">'."\n";
			}else{
				$forStr .= '<ul class="bsk-pdfm-selector-pdfs-list cat-'.$category_id.'">'."\n";
			}
		}
		$nofollow_tag_str = $nofollow_tag ? ' rel="nofollow"' : '';
		$open_target_str = $open_target == '_blank' ? ' target="_blank"' : '';
		$item_count = 0;
		foreach($pdf_items_results as $pdf_item_obj ){
			if( $pdf_item_obj->file_name == "" &&  $pdf_item_obj->by_media_uploader < 1 ){
				continue;
			}
			$file_url = '';
			if( $pdf_item_obj->by_media_uploader ){
				$file_url = wp_get_attachment_url( $pdf_item_obj->by_media_uploader );
			}else if( file_exists(ABSPATH.$pdf_item_obj->file_name) ){
				$file_url = site_url().'/'.$pdf_item_obj->file_name;
			}
			if( $file_url == "" ){
				continue;
			}
				
			if( $output_as_dropdown == true ){
				$pdf_item_obj_title = $pdf_item_obj->title;
				if( $pdf_item_obj_title == "" ){
					$pdf_item_obj_title_array = explode( '/', $file_url );
					$pdf_item_obj_title = $pdf_item_obj_title_array[count($pdf_item_obj_title_array) - 1];
				}
				$option_text = $custom_link_text ? $custom_link_text : $pdf_item_obj_title;
				if( $show_date_in_title ){
					if( $date_before_title ){
						$option_text = date($date_format_str, strtotime($pdf_item_obj->last_date)).'--'.$option_text;
					}else{
						$option_text .= '--'.date($date_format_str, strtotime($pdf_item_obj->last_date));
					}
				}
                $filter_year_month = date('Y-m', strtotime($pdf_item_obj->last_date) );
                if( $use_additional_filter && is_array($use_additional_filter) && count($use_additional_filter) > 0 ){
                    $filter_year_month = date($use_additional_filter['filter-format'], strtotime($pdf_item_obj->last_date) );
                }
				$forStr .= '<option value="'.$file_url.'" id="'.$pdf_item_obj->id.'#'.$filter_year_month.'">'.$option_text.'</option>'."\n";
			}else if( $enable_multi_column_layout == true ){
				$column_class_item = ( $item_count % $default_column_number ) == 0 ? $column_class.' bsk-pdfm-first' : $column_class;
				$forStr .= $this->bsk_pdf_manager_show_pdf_item_single( $pdf_item_obj, $show_thumbnail, $thumbnail_size, $show_thumbnail_with_title, $default_thumbnail_html,
																			$open_target_str, $nofollow_tag_str, $show_date_in_title, $date_format_str, $date_before_title,
																			true, $column_class_item, $title_postion_4_mulitcolumn );
			}else{
				$forStr .= $this->bsk_pdf_manager_show_pdf_item_single( $pdf_item_obj, $show_thumbnail, $thumbnail_size,                            $show_thumbnail_with_title, $default_thumbnail_html,
																			$open_target_str, $nofollow_tag_str, $show_date_in_title, $date_format_str, $date_before_title );
			}
			$item_count++;
		}
		if( $output_as_dropdown == true ){
			$forStr .= '</select>';
		}else if( $enable_multi_column_layout == true ){
			$forStr .= '<div class="bsk-pdf-clear-both"></div>';
			$forStr .= '</div>';
		}else{
			if( $ordered_list ){
				$forStr .= '</ol>';
			}else{
				$forStr .= '</ul>';
			}
		}
		
		return $forStr;
	}
	
	function bsk_pdfm_get_assoicated_pdfs_fun(){
		$str = '';
		$title_postion_4_mulitcolumn = 'below';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, null );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['column_layout_title_positon']) ){
				$title_postion_4_mulitcolumn = $plugin_settings['column_layout_title_positon'];
			}
		}
		
		$bsk_pm_category_id = $_POST['category_id'];
		$bsk_pdf_manager_cat_order_by = $_POST['order_by'];
		$bsk_pdf_manager_cat_order = $_POST['cat_order'];
		$output_as_dropdown = $_POST['out_dropdown'];
		$selected_option_text = $_POST['dropdown_selected'];
		$bsk_pdf_manager_category_top = $_POST['category_top'];
		$bsk_pdf_manager_show_ordered_list = $_POST['show_ordered_list'];
		$bsk_pdf_manager_show_thumbnail = $_POST['show_thumbnail'];
		$bsk_pdf_manager_thumbnail_size = $_POST['thumbnail_size'];
		$bsk_pdf_manager_show_thumbnail_with_title = $_POST['thumbnail_with_title'];
		$open_target_str = $_POST['open_target'];
		$nofollow_tag = $_POST['nofollowtag'];
		$show_date_in_title = $_POST['show_date'];
		$date_format_str = $_POST['date_format'];
		$date_before_title_str = $_POST['datebeforetitle'];
		$columns = $_POST['columns'];
		$multicolumns = $_POST['multicolumns'];
		$show_empty_message = $_POST['show_empty_message'];
        $additional_filter = $_POST['additional_filter'];
        
		$bsk_pm_category_id = intval( $bsk_pm_category_id );
		$bsk_pdf_manager_category_top = intval( $bsk_pdf_manager_category_top );
		
		$date_before_title = strtoupper($date_before_title_str) == 'YES' ? true : false;
		if( strtoupper($date_before_title_str) == 'TRUE' ){
			$date_before_title = true;
		}else if( is_bool($date_before_title_str) ){
			$date_before_title = $date_before_title_str;
		}
		
		$multicolumns = $multicolumns == 'YES' ? true : false;
		$show_empty_message = $show_empty_message == 'YES' ? true: false;
		
		//get category obj
		$default_empty_message = '';
		global $wpdb;
		
		$sql = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name.'` WHERE `id` = %d';
		$sql = $wpdb->prepare( $sql, $bsk_pm_category_id );
		
		$categories_array = $wpdb->get_results($sql);
		if( !$categories_array || !is_array($categories_array) || count($categories_array) < 1 ){
			die( 'Error - Invalid category ID' );
		}
		$default_empty_message = $categories_array[0]->empty_message;
		
		$list_str = $this->get_all_pdfs_within_category( 
													$bsk_pm_category_id,
													$bsk_pdf_manager_cat_order_by, 
													$bsk_pdf_manager_cat_order,
													$output_as_dropdown,
													$selected_option_text,
													$bsk_pdf_manager_category_top, 
													$bsk_pdf_manager_show_ordered_list, 
													$bsk_pdf_manager_show_thumbnail,
													$bsk_pdf_manager_thumbnail_size,
													$bsk_pdf_manager_show_thumbnail_with_title, 
													$open_target_str, 
													$nofollow_tag, 
													$show_date_in_title, 
													$date_format_str,
													$date_before_title, 
													$columns, 
													$multicolumns,
													$title_postion_4_mulitcolumn,
													$show_empty_message,
													$default_empty_message
												  );
													
		die( json_encode( array( 'list' => $list_str, 'filter_option' => $filter_option_str) ) );
	}

	function bsk_pdf_manager_show_pdf_item_single( $pdf_item_obj, $featured_image, $featured_image_size, $show_PDF_title_with_featured_image, $default_thumbnail_html,
												   $open_target_str, $nofollow_tag_str, $show_date_in_title, $date_format_str, $date_before_title,
												   $enable_multi_column = false, $column_class = '', $column_layout_title_positon = 'below' ){
        
        $forStr = '';
		if( $enable_multi_column && $column_class ){
			$forStr .= '<div class="bsk-pdf-item '.$column_class.'"multicolumns="yes">';
		}else{
			$forStr .= '<li>';
		}
		
		$file_url = site_url().'/'.$pdf_item_obj->file_name;
		if( $pdf_item_obj->by_media_uploader ){
			$file_url = wp_get_attachment_url( $pdf_item_obj->by_media_uploader );
            if( $file_url == false ){
                return '';
            }
		}
		
		$pdf_item_obj_title = $pdf_item_obj->title;
		if( $pdf_item_obj_title == "" ){
			$pdf_item_obj_title_array = explode( '/', $file_url );
			$pdf_item_obj_title = $pdf_item_obj_title_array[count($pdf_item_obj_title_array) - 1];
		}

		if( $featured_image == true ){
			//get PDF featured image
			$thumbnail_html = '';
			if( $pdf_item_obj->thumbnail_id  && get_post( $pdf_item_obj->thumbnail_id ) ){
				$thumbnail_html = wp_get_attachment_image( $pdf_item_obj->thumbnail_id, $featured_image_size );
			}else if( $default_thumbnail_html){
				$thumbnail_html = $default_thumbnail_html;
			}else{
				$thumbnail_html = '<img src="'.BSKPDFManagerPro::$_default_pdf_icon_url.'" width="150" height="150" />';
			}
			$featured_image_str = '<a href="'.$file_url.'" '.$open_target_str.$nofollow_tag_str.' title="'.$pdf_item_obj->title.'">'.$thumbnail_html.'</a>';
			if( $show_PDF_title_with_featured_image ){
				$PDF_title = $pdf_item_obj_title;
				$anchor_title = $pdf_item_obj_title;
				if( $show_date_in_title ){
					if( $date_before_title ){
						$PDF_title = '<span class="bsk-pdf-manager-pdf-date">'.date($date_format_str, strtotime($pdf_item_obj->last_date)).'</span>'.$PDF_title;
					}else{
						$PDF_title = $PDF_title.'<span class="bsk-pdf-manager-pdf-date">'.date($date_format_str, strtotime($pdf_item_obj->last_date)).'</span>';
					}
				}
				$pdf_title_str  =  '<span class="bsk-pdf-manager-pdf-title">'.
								   '<a href="'.$file_url.'" '.$open_target_str.$nofollow_tag_str.' title="'.$anchor_title.'">'.$PDF_title.'</a>'.
								   '</span>';
				if( $column_layout_title_positon == 'below' ){
					$forStr .= $featured_image_str.$pdf_title_str;
				}else{
					$forStr .= $pdf_title_str.$featured_image_str;
				}
			}else{
				$forStr .= $featured_image_str;
			}
		}else{
			$link_text = $pdf_item_obj_title; //$custom_link_text ? $custom_link_text : $pdf_item_obj_title;
			if( $show_date_in_title ){
				if( $date_before_title ){
					$link_text = '<span class="bsk-pdf-manager-pdf-date">'.date($date_format_str, strtotime($pdf_item_obj->last_date)).'</span>'.$link_text;
				}else{
					$link_text .= '<span class="bsk-pdf-manager-pdf-date">'.date($date_format_str, strtotime($pdf_item_obj->last_date)).'</span>';
				}
			}
			$forStr .= '<a href="'.$file_url.'" '.$open_target_str.$nofollow_tag_str.'  title="'.$pdf_item_obj->title.'">'.$link_text.'</a>'."\n";
		}
		
		if( $enable_multi_column && $column_class ){
			$forStr .= '</div>'."\n";
		}else{
			$forStr .= '</li>'."\n";
		}
		
		return $forStr;
	}
	
}