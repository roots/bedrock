<?php

class BSKPDFMPro_Shortcodes_Selector_Dropdown {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
	public function __construct() {
        add_shortcode( 'bsk-pdfm-selector-dropdown', array($this, 'bsk_pdf_manager_list_pdfs_by_cat_as_dropdown') );
        
        add_action( 'wp_ajax_pdfs_get_selector_dropdown', array( $this, 'bsk_pdfm_ajax_selector_get_pdfs_dropdown' ) );
		add_action( 'wp_ajax_nopriv_pdfs_get_selector_dropdown', array( $this, 'bsk_pdfm_ajax_selector_get_pdfs_dropdown' ) );
	}
	
    function bsk_pdf_manager_list_pdfs_by_cat_as_dropdown( $atts, $content ){
		global $wpdb;
		
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
		
		$shortcode_atts = shortcode_atts( 
                                            array(  
                                                       'cat_id' => '',
                                                       'default_cat_id' => '',
                                                       'exclude_cat_id' => '',
                                                       'password_required' => 'no',
                                                       'hierarchical' => 'no',
                                                       'cat_order_by' => '',
                                                       'cat_order' => '',
                                                       'show_cat_description' => 'no',
                                                       'hide_empty_cat' => 'no',
                                                       'show_cat_empty_message' => 'no',
                                                       'selector_option_none' => 'Select category to browse...',
                                                       'exclude_pdf_id' => '',
                                                       'order_by' => '',
                                                       'order' => '', 
                                                       'target' => '_blank',
                                                       'most_top' => 0,
                                                       'year_of' => '0000', //work when 'id'="all", 9999 means most recent, length = 4
                                                       'month_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                       'day_of' => '00', //work when 'id'="all", 99 means most recent, length = 2
                                                       'weekday_of' => 'no', //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                                       'show_date' => 'no',
                                                       'date_format' => ' d/m/Y',
                                                       'date_before_title' => 'no',
                                                       'date_weekday_filter' => '',
                                                       'date_weekday_filter_order' => '',
                                                       'date_weekday_filter_right' => 'no',
                                                       'option_none' => 'Select to open...',
                                                       'output_container_class' => '' 
                                                    ),
                                                $atts 
                                            );
		
        /**
          * process categories attributes
          */
		//password protect
        $password_required = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('password_required', $shortcode_atts);
        //show category description or not
		$show_cat_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_description', $shortcode_atts);
        //show category with hierarchical
		$show_cat_hierarchical = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hierarchical', $shortcode_atts);
        //hide empty
        $hide_empty_cat = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hide_empty_cat', $shortcode_atts);
		//show empty message
		$show_cat_empty_message = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_empty_message', $shortcode_atts);
        
        //process order by case
        $cat_order_by_str = ' C.`title`';
		$cat_order_str = ' ASC';
		if( $shortcode_atts['cat_order_by'] == 'date' ){
			$cat_order_by_str = ' C.`last_date`';
		}
		if( trim($shortcode_atts['cat_order']) == 'DESC' ){
			$cat_order_str = ' DESC';
        }
        
        //exclude category ids
        $exclude_cat_ids_array = null;
        if( trim($shortcode_atts['exclude_cat_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_cat_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $cat_id ){
                    $exclude_cat_ids_array[] = absint( trim($cat_id) );
                }
            }
        }
        
        global $wpdb;
        
        $ids_array = false;
        $ids_array_no_hierarchical = false;
		$categories_loop_array = false;
        $exclude_cat_ids_array_str = $exclude_cat_ids_array && is_array( $exclude_cat_ids_array ) ? implode(',', $exclude_cat_ids_array) : '';
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts['cat_id'], 
                                                                                                $show_cat_hierarchical, 
                                                                                                $exclude_cat_ids_array_str, 
                                                                                                $cat_order_by_str, 
                                                                                                $cat_order_str );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }

        if( $ids_array == false || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $str = '<div class="bsk-pdfm-output-container'.' '.$shortcode_atts['output_container_class'].'">'.
                            '<p>No valid category id found</p>'.
                     '</div>';
            return $str;
        }
        
        /**
          * Process PDFs attributes
        */
		//show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//process open target
		$target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$target_str = ' data-target="_blank"';
		}
        
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );

		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}
        
        //process pagination
        $pdfs_per_page = 999999;
        $pagination = $pdfs_per_page > 0 ? true : false;
        if( $most_top > 0 ){
            //disble pagination for some special situations
            $pagination = false;
        }
        
        $search_bar = 'No';
        if( $search_bar != 'YES' && 
            $search_bar != 'KEYWORDS' && 
            $search_bar != 'YEAR_KEYWORDS' &&
            $search_bar != 'CATEGORY_YEAR_KEYWORDS' ){
            
            $search_bar = false;
        }
        $search_bar = $search_bar == 'YES' ? 'KEYWORDS' : $search_bar;
        $search_bar = $search_bar == 'CATEGORY_YEAR_KEYWORDS' ? 'YEAR_KEYWORDS' : $search_bar;
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        //exclude pdf ids
        $exclude_pdf_ids_array = null;
        if( trim($shortcode_atts['exclude_pdf_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_pdf_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_pdf_ids_array[] = absint( trim($pdf_id) );
                }
            }
        }
        
        $default_cat_id = absint( $shortcode_atts['default_cat_id'] );
        $default_cat_obj = null;
        $cat_pdfs_query_results = null;
        if( $default_cat_id ){
            $default_cat_obj = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_cat_obj( $default_cat_id );
            if( $default_cat_obj ){
                //query pdfs
                /**
                  * Query PDFs for category
                */
                $query_args = array();
                $query_args['year_of'] = $year_of;
                $query_args['month_of'] = $month_of;
                $query_args['day_of'] = $day_of;
                $query_args['weekday_of'] = $weekday_of;
                $query_args['pagination'] = $pagination;
                $query_args['pdfs_per_page'] = $pdfs_per_page;
                $query_args['paged'] = 1;
                $query_args['cat_order_by'] = $shortcode_atts['cat_order_by'];
                $query_args['cat_order'] = $shortcode_atts['cat_order'];
                $query_args['order_by'] = $shortcode_atts['order_by'];
                $query_args['order'] = $shortcode_atts['order'];
                $query_args['most_top'] = $most_top;
                $query_args['ids_array'] = array( $default_cat_id );
                $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;
                
                $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );
            }else{
                $default_cat_id = 0;
            }
        }
        
        $output_container_class = $shortcode_atts['output_container_class'] ? ' '.$shortcode_atts['output_container_class'] : '';
        $output_container_start = '<div class="bsk-pdfm-output-container shortcode-selector layout-dropdown'.$output_container_class.'">';
        $category_selector = BSKPDFMPro_Common_Display::get_category_selector( 
                                                                                                       $categories_loop_array,
                                                                                                       $ids_array, 
                                                                                                       $default_cat_id,
                                                                                                       $show_cat_hierarchical,
                                                                                                       $cat_order_by_str, 
                                                                                                       $cat_order_str,
                                                                                                       $shortcode_atts['selector_option_none'],
                                                                                                       $hide_empty_cat
                                                                                                      );
        
        $category_output_str = '';
        $date_weekday_filter_str = '';
        $cat_description = '';
        $dropdown_str = '';
        $password_forms_str = '';
        $pdfs_options_str = '';
        $cat_empty_message = '';
        
        $categories_ask_for_password = array();
        if( $default_cat_obj && $cat_pdfs_query_results ){
            $pdfs_results_array_by_category = $cat_pdfs_query_results['pdfs'];
            $total_pages = $cat_pdfs_query_results['pages'];
            $total_pdfs = $cat_pdfs_query_results['total'];
            $categories_for_pdfs_results = $cat_pdfs_query_results['categories_for_pdfs'];

            $password_form = $this->bsk_pdfm_show_category_password_form( $password_required, $default_cat_obj, false, 1 );
            if( $password_form != "" ){
                $password_forms_str .= $password_form;
                $categories_ask_for_password[] = $default_cat_obj->id;
            }else{
                if( is_array( $pdfs_results_array_by_category[$default_cat_obj->id] ) && 
                    count( $pdfs_results_array_by_category[$default_cat_obj->id] ) > 0 ){
                    
                    if( $show_cat_description ){
                        $cat_description = '<div class="bsk-pdfm-category-description">'.$default_cat_obj->description.'</div>';
                    }
            
                    $pdfs_options_str = BSKPDFMPro_Common_Display::show_pdfs_dropdown_option_for_category(
                                                                                                                 $pdfs_results_array_by_category[$default_cat_obj->id],
                                                                                                                 $default_cat_obj,
                                                                                                                 $hide_empty_cat,
                                                                                                                 $show_date, 
                                                                                                                 $date_format_str,
                                                                                                                 $date_before_title,
                                                                                                                 1,
                                                                                                                 false
                                                                                                                );
                }else if ( $show_cat_empty_message ){
                    $cat_empty_message = trim($default_cat_obj->empty_message);
                }
            }
            
            if( $pdfs_options_str ){
                $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';
                
                $option_none_str = trim($shortcode_atts['option_none']);
                if( $option_none_str ){
                    $dropdown_str .= '<option value="">'.$option_none_str.'</option>';
                }
                $dropdown_str .= $pdfs_options_str;
                $dropdown_str .= '</select>';
            }
            
            if( $pdfs_results_array_by_category && is_array( $pdfs_results_array_by_category ) && count($pdfs_results_array_by_category) > 0 ){
                //show date filter
                $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
                $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
                $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
                if( $date_weekday_filter ){
                    $all_pdfs_results_array = array();
                    foreach( $pdfs_results_array_by_category as $key => $pdfs_by_category ){
                        if( count($categories_ask_for_password) > 0 && in_array($key, $categories_ask_for_password ) ){
                            continue;
                        }
                        $all_pdfs_results_array = array_merge( $all_pdfs_results_array, $pdfs_by_category );
                    }
                    $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                        $all_pdfs_results_array, 
                                                                                                        $date_weekday_filter, 
                                                                                                        $date_weekday_filter_order, 
                                                                                                        $date_weekday_filter_right 
                                                                                                     );
                }
            }

            $categor_output_container_begin = '<div class="bsk-pdfm-category-output cat-'.$default_cat_obj->id.' pdfs-in-dropdown" data-cat-id="'.$default_cat_obj->id.'">';
            $categor_output_container_end = '<!--//bsk-pdfm-category-output cat-'.$default_cat_obj->id.'-->';
            $categor_output_container_end .= '</div>';
        }

        //credit
        $credit_str = '';
        if( isset( $plugin_settings['enable_credit'] ) && $plugin_settings['enable_credit'] == 'Yes' ){
            $credit_text = 'PDFs powered by PDF Manager Pro';
            if( $plugin_settings['credit_text'] ){
                $credit_text = $plugin_settings['credit_text'];
            }
            $pdf_manager_pro_link = 'https://www.bannersky.com/bsk-pdf-manager/';
            $credit_str .= '<p class="bsk-pdfm-credit-link-container"><a href="'.$pdf_manager_pro_link.'" target="_blank">'.$credit_text.'</a></p>';
        }
        
        //output all shortcode parameters
        $shortcode_parameters_str = '<div class="bsk-pdfm-selector-shortcode-attr">';
        foreach( $shortcode_atts as $attr_name => $attr_val ){
            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr" data-attr_name="'.$attr_name.'" value="'.$attr_val.'" />';
        }
        if( $password_required ){
            $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-shortcode-attr category-password-hidden-feild" data-attr_name="category_password" value="" />';
        }
        $ajax_nonce = wp_create_nonce( "selector-ajax-get" );
        $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-selector-ajax-nonce" value="'.$ajax_nonce.'">';
        $shortcode_parameters_str .= BSKPDFMPro_Statistics_Download_Count::bsk_pdfm_statistics_get_ajax_nonce();
        $shortcode_parameters_str .= '<!-- //bsk-pdfm-selector-shortcode-attr -->';
        $shortcode_parameters_str .= '</div>';

        $output_container_end = '</div><!-- //bsk-pdfm-output-container -->';
                
        $output_str =  ''.
                            $output_container_start.
                            $category_selector.
                            $password_forms_str.
                            $cat_description.
                            $date_weekday_filter_str.
                            $categor_output_container_begin.$cat_empty_message.$dropdown_str.$categor_output_container_end.
                            $credit_str.
                            $shortcode_parameters_str.
                            $output_container_end;
        
		return $output_str;
	} //end of function
    
    function bsk_pdfm_show_category_password_form( $password_required, $category, $category_password_array,
                                                                              $current_category_depth ){
        $depth_class = ' category-hierarchical-depth-'.$current_category_depth;
        $caegory_title_tag = 'h'.($current_category_depth + 1);
        
        //check if password protection set for the category
        if( $password_required && $category->password != "" ){
            $show_password_form = true;
            $password_error = false;
            if( $category_password_array && is_array( $category_password_array ) && array_key_exists( $category->id, $category_password_array ) ){
                if( $category_password_array[$category->id] != $category->password ){
                    $password_error = true;
                }else{
                    $show_password_form = false;
                }
            }
            

            if( $show_password_form ){
                //no enter password or password is wrong 
                $password_forms_str = BSKPDFMPro_Common_Display::show_category_password_require_form( $category, $password_error );
                
                $categor_output_container_begin = '<div class="bsk-pdfm-category-output cat-'.$category->id.$depth_class.' pdfs-in-dropdown password_required" data-cat-id="'.$category->id.'">';
                $categor_output_container_end = '<!--//bsk-pdfm-category-output cat-'.$category->id.'-->';
                $categor_output_container_end .= '</div>';
                
                $category_output = $categor_output_container_begin;
                $category_output .= $password_forms_str;
                $category_output .= $categor_output_container_end;
                
                return $category_output;
            }
        }
        
        return '';
    }
    
    function bsk_pdfm_ajax_selector_get_pdfs_dropdown(){
        if( !check_ajax_referer( 'selector-ajax-get', 'nonce', false ) ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Security check! nonce</p>' );
            wp_die( json_encode( $return_array ) );
        }
        $license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Invalid license!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        //read plugin settings
		$default_enable_featured_image = true;
		$default_thumbnail_html = '';
		$default_thumbnail_size = 'thumbnail';
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['enable_featured_image']) ){
				$default_enable_featured_image = $plugin_settings['enable_featured_image'];
			}
			
			if( isset($plugin_settings['default_thumbnail_size']) ){
				$default_thumbnail_size = $plugin_settings['default_thumbnail_size'];
			}
            if( $default_enable_featured_image && isset($plugin_settings['default_thumbnail_id']) ){
                $default_thumbnail_id = $plugin_settings['default_thumbnail_id'];
                if( $default_thumbnail_id && get_post( $default_thumbnail_id ) ){
                    $default_thumbnail_html = wp_get_attachment_image( $default_thumbnail_id, $default_thumbnail_size );
                }
            }
		}
        
        $shortcode_atts = array(  
                                           'cat_id' => $_POST['cat_id'],
                                           'password_required' => $_POST['password_required'],
                                           'show_cat_description' => $_POST['show_cat_description'],
                                           'show_cat_empty_message' => $_POST['show_cat_empty_message'],
                                           'year_of' => $_POST['year_of'], //work when 'id'="all", 9999 means most recent, length = 4
                                           'month_of' => $_POST['month_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'day_of' => $_POST['day_of'], //work when 'id'="all", 99 means most recent, length = 2
                                           'weekday_of' => $_POST['weekday_of'], //work when 'id'="all", MON, TUE, WED, THU, FRI, SAT, SUN
                                           'exclude_pdf_id' => $_POST['exclude_pdf_id'],
                                           'order_by' => $_POST['order_by'],
                                           'order' => $_POST['order'],
                                           'target' => $_POST['target'],
                                           'show_date' => $_POST['show_date'],
                                           'date_format' => $_POST['date_format'],
                                           'date_before_title' => $_POST['date_before_title'],
                                           'date_weekday_filter' => $_POST['date_weekday_filter'],
                                           'date_weekday_filter_order' => $_POST['date_weekday_filter_order'],
                                           'date_weekday_filter_right' => $_POST['date_weekday_filter_right'],
                                           'most_top' => $_POST['most_top'],
                                           'option_none' => $_POST['option_none'],
                                          );

        $categories_password_array = array();
        if( isset( $_POST['category_password']  ) ){
            $shortcode_atts['category_password'] = $_POST['category_password'];
            $temp_array = explode( ',', $shortcode_atts['category_password'] );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $cat_n_password ){
                    $cat_n_password_array = explode( ':', $cat_n_password );
                    if( !$cat_n_password_array || !is_array( $cat_n_password_array ) || count( $cat_n_password_array ) != 2 ){
                        continue;
                    }
                    $cat_id = absint( $cat_n_password_array[0] );
                    $password = preg_replace( '%[^0-9a-zA-Z]%', '', $cat_n_password_array[1] );
                    $categories_password_array[$cat_id] = $password;
                }
            }
        }

        /**
          * process categories attributes
          */
        //password protect
        $password_required = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('password_required', $shortcode_atts);
        //show category description or not
		$show_cat_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_description', $shortcode_atts);
        //show category with hierarchical
		$show_cat_hierarchical = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hierarchical', $shortcode_atts);
        //hide empty
        $hide_empty_cat = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('hide_empty_cat', $shortcode_atts);
		//show empty message
		$show_cat_empty_message = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_cat_empty_message', $shortcode_atts);
        
        //process order by case
        $cat_order_by_str = ' C.`title`';
		$cat_order_str = ' ASC';
        
        global $wpdb;
        
        $ids_array = false;
		$categories_loop_array = false;
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts['cat_id'], 
                                                                                                false, 
                                                                                                array(), 
                                                                                                $cat_order_by_str, 
                                                                                                $cat_order_str );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }
        if( !$ids_array || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Category ID( '.$shortcode_atts['cat_id'].' )doesn\'t exist</p>' );
            wp_die( json_encode( $return_array ) );
        }

        $default_cat_obj = null;
        foreach( $categories_loop_array as $cat_obj ){
            $default_cat_obj = $cat_obj;
            break;
        }
        /**
          * Process PDFs attributes
        */
		//show description
		$show_description = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_description', $shortcode_atts);
		//process open target
		$target_str = '';
		if( $shortcode_atts['target'] == '_blank' ){
			$target_str = ' data-target="_blank"';
		}
        
		//most top
		$most_top = intval( $shortcode_atts['most_top'] );

		//anchor nofollow tag
		$nofollow_tag = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('nofollow_tag', $shortcode_atts);
        if( $nofollow_tag ){
            $nofollow_tag = ' rel="nofollow"';
        }
		//show date in title
		$show_date = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('show_date', $shortcode_atts);
		//date postion
		$date_before_title = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs('date_before_title', $shortcode_atts);
		
		//date format
		$date_format_str = $date_before_title ? 'd/m/Y ' : ' d/m/Y';
		if( $shortcode_atts['date_format'] && is_string($shortcode_atts['date_format']) && $shortcode_atts['date_format'] != ' d/m/Y' ){
			$date_format_str = $shortcode_atts['date_format'];
		}
        
        $option_none_str = trim($shortcode_atts['option_none']);
        $option_none_str = $option_none_str ? $option_none_str : 'Select...';
        
        $year_of = BSKPDFMPro_Common_Display::validate_year( $shortcode_atts['year_of'] );
        $month_of = BSKPDFMPro_Common_Display::validate_month( $shortcode_atts['month_of'] );
        $day_of = BSKPDFMPro_Common_Display::validate_day( $shortcode_atts['day_of'] );
        $weekday_of = BSKPDFMPro_Common_Display::get_mysql_weekday_index( $shortcode_atts['weekday_of'] );
        
        //exclude pdf ids
        $exclude_pdf_ids_array = null;
        if( trim($shortcode_atts['exclude_pdf_id']) ){
            $temp_array = explode( ',', trim($shortcode_atts['exclude_pdf_id']) );
            if( $temp_array && is_array( $temp_array ) && count( $temp_array ) > 0 ){
                foreach( $temp_array as $pdf_id ){
                    $exclude_pdf_ids_array[] = intval( $pdf_id );
                }
            }
        }
        
        /**
          * Query PDFs for category
        */
        $query_args = array();
        $query_args['year_of'] = $year_of;
        $query_args['month_of'] = $month_of;
        $query_args['day_of'] = $day_of;
        $query_args['weekday_of'] = $weekday_of;
        $query_args['pagination'] = false;
        $query_args['pdfs_per_page'] = 9999;
        $query_args['paged'] = 1;
        $query_args['cat_order_by'] = $shortcode_atts['cat_order_by'];
        $query_args['cat_order'] = $shortcode_atts['cat_order'];
        $query_args['keywords'] = '';
        $query_args['order_by'] = $shortcode_atts['order_by'];
        $query_args['order'] = $shortcode_atts['order'];
        $query_args['most_top'] = absint($most_top);
        $query_args['ids_array'] = $ids_array; /* ids_array sequence determine the order by of category */
        $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;

        $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );

        $pdfs_results_array_by_category = $cat_pdfs_query_results['pdfs'];
        $total_pages = $cat_pdfs_query_results['pages'];
        $total_pdfs = $cat_pdfs_query_results['total'];
        $categories_for_pdfs_results = $cat_pdfs_query_results['categories_for_pdfs'];
        
        $password_forms_str = '';
        $category_output_str = '';
        $date_weekday_filter_str = '';
        $cat_description = '';
        $dropdown_str = '';
        
        if( $show_cat_description ){
            $cat_description = '<div class="bsk-pdfm-category-description">'.$default_cat_obj->description.'</div>';
        }
        
        $categories_ask_for_password = array();
        $password_form = $this->bsk_pdfm_show_category_password_form( $password_required, $default_cat_obj, $categories_password_array, 1 );
        if( $password_form != "" ){
            $password_forms_str .= $password_form;
            $categories_ask_for_password[] = $default_cat_obj->id;
        }else{
            if( is_array( $pdfs_results_array_by_category[$default_cat_obj->id] ) && 
                count( $pdfs_results_array_by_category[$default_cat_obj->id] ) > 0 ){

                

                $pdfs_options_str = BSKPDFMPro_Common_Display::show_pdfs_dropdown_option_for_category(
                                                                                                             $pdfs_results_array_by_category[$default_cat_obj->id],
                                                                                                             $default_cat_obj,
                                                                                                             $hide_empty_cat,
                                                                                                             $show_date, 
                                                                                                             $date_format_str,
                                                                                                             $date_before_title,
                                                                                                             1,
                                                                                                             false
                                                                                                            );
            }else if ( $show_cat_empty_message ){
                $cat_empty_message = trim($default_cat_obj->empty_message);
            }
        }

        if( $pdfs_options_str ){
            $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';

            $option_none_str = trim($shortcode_atts['option_none']);
            if( $option_none_str ){
                $dropdown_str .= '<option value="">'.$option_none_str.'</option>';
            }
            $dropdown_str .= $pdfs_options_str;
            $dropdown_str .= '</select>';
        }

        if( $pdfs_results_array_by_category && is_array( $pdfs_results_array_by_category ) && count($pdfs_results_array_by_category) > 0 ){
            //show date filter
            $date_weekday_filter = isset( $shortcode_atts['date_weekday_filter'] ) && $shortcode_atts['date_weekday_filter'] ? $shortcode_atts['date_weekday_filter'] : false;
            $date_weekday_filter_order = isset( $shortcode_atts['date_weekday_filter_order'] ) && $shortcode_atts['date_weekday_filter_order'] ? $shortcode_atts['date_weekday_filter_order'] : false;
            $date_weekday_filter_right = BSKPDFMPro_Common_Display::process_shortcodes_bool_attrs( 'date_weekday_filter_right', $shortcode_atts );
            if( $date_weekday_filter ){
                $all_pdfs_results_array = array();
                foreach( $pdfs_results_array_by_category as $key => $pdfs_by_category ){
                    if( count($categories_ask_for_password) > 0 && in_array($key, $categories_ask_for_password ) ){
                        continue;
                    }
                    $all_pdfs_results_array = array_merge( $all_pdfs_results_array, $pdfs_by_category );
                }
                $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                    $all_pdfs_results_array, 
                                                                                                    $date_weekday_filter, 
                                                                                                    $date_weekday_filter_order, 
                                                                                                    $date_weekday_filter_right 
                                                                                                 );
            }
        }

        $categor_output_container_begin = '<div class="bsk-pdfm-category-output cat-'.$default_cat_obj->id.$depth_class.' pdfs-in-dropdown" data-cat-id="'.$default_cat_obj->id.'">';
        $categor_output_container_end = '<!--//bsk-pdfm-category-output cat-'.$default_cat_obj->id.'-->';
        $categor_output_container_end .= '</div>';
        
        $category_output_str = $categor_output_container_begin.$cat_empty_message.$dropdown_str.$categor_output_container_end;
        
        //total_pdfs only have valid value when pagination enabled so
        $pdfs_count = $total_pages > 1 ? $total_pdfs : count( $all_pdfs_results_array );
        $results_desc_str = $pdfs_count > 1 ? $pdfs_count.' records found' : $pdfs_count.' record found';
        $data_to_return = array( 
                                            'pdfs' => $category_output_str, 
                                            'date_filter' => $password_forms_str.$date_weekday_filter_str, 
                                            'pagination' => '',
                                            'pdfs_count' => $pdfs_count,
                                            'results_desc' => $results_desc_str,
                                            'search_bar_str' => '',
                                            'cat_desc_str' => $cat_description
                                         );
        wp_die( json_encode( $data_to_return ) );
        
    } //end of function
}