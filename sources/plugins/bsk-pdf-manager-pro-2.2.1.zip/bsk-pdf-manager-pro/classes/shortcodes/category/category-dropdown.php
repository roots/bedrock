<?php

class BSKPDFMPro_Shortcodes_Category_Dropdown {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
	public function __construct() {
        add_shortcode( 'bsk-pdfm-category-dropdown', array($this, 'bsk_pdf_manager_list_pdfs_by_cat_as_dropdown') );
        
        //ajax action for verify password
        add_action( 'wp_ajax_pdfs_get_category_dropdown', array( $this, 'bsk_pdfm_ajax_get_category_dropdown' ) );
		add_action( 'wp_ajax_nopriv_pdfs_get_category_dropdown', array( $this, 'bsk_pdfm_ajax_get_category_dropdown' ) );
	}
    
    function bsk_pdf_manager_list_pdfs_by_cat_as_dropdown( $atts, $content ){
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			return '<p>Please activate your license first</p>';
		}
		
        $all_shortcode_atts = array( 
                                                'option_none' => 'Select to open...',
                                                'option_group_label' => 'CAT_TITLE', 
                                              );
        $all_shortcode_atts = array_merge( 
                                                           $all_shortcode_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_category_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_pdfs_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_date_weekday_filter_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_output_container_atts
                                                         );
        $all_shortcode_atts['target'] = '_blank';
		$shortcode_atts = shortcode_atts( $all_shortcode_atts, $atts );
        $shortcode_atts_processed = BSKPDFMPro_Shortcodes_Category_Functions::process_shortcode_parameters( $shortcode_atts );

        $ids_array = false;
		$categories_loop_array = false;
        $only_single_category = false;
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts_processed['id'], 
                                                                                                $shortcode_atts_processed['hierarchical'], 
                                                                                                $shortcode_atts_processed['exclude_id'], 
                                                                                                $shortcode_atts_processed['cat_order_by'], 
                                                                                                $shortcode_atts_processed['cat_order'] );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }
        if( $ids_array == false || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $str = '<div class="bsk-pdfm-output-container'.' '.$shortcode_atts_processed['output_container_class'].'">'.
                            '<p>No valid category id found</p>'.
                     '</div>';
            return $str;
        }
        
        $only_single_category = count( $ids_array ) == 1 ? true : false;
        $single_category_output = '';
        $multi_categories_output = '';
        
        if( $only_single_category ){
            /* 
                the difference between multiple categoryes & single cateogry: 
                1. searchbar is below category titile, category description
                2. weekday filter is below category titile, category description
                3. single category support show category empty messaage & hide empty category
                3. 
            */
            $category_obj = array_shift( $categories_loop_array );
            $category_output_return = $this->display_pdfs_in_dropdown_for_single_category( 
                                                                                        $shortcode_atts_processed,
                                                                                        $category_obj
                                                                                    );
            $single_category_output = $category_output_return['container_begin'];
            $single_category_output .= $category_output_return['cat_title'];
            $single_category_output .= $category_output_return['cat_description'];
            if( $category_output_return['cat_empty_message'] ){
                 $single_category_output .= $category_output_return['cat_empty_message'];
            }else{
                if( $category_output_return['password_form'] ){
                    $single_category_output .= $category_output_return['password_form'];
                }else{
                    $single_category_output .= $category_output_return['date_weekday_filter'];

                    $target_str = trim($shortcode_atts_processed['target']) == '_blank' ? ' data-target="_blank"' : '';
                    $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';
                    if( $shortcode_atts_processed['option_none'] ){
                        $dropdown_str .= '<option value="">'.$shortcode_atts_processed['option_none'].'</option>';
                    }
                    $dropdown_str .= $category_output_return['pdfs'];
                    $dropdown_str .= '</select>';

                    $single_category_output .= $dropdown_str;
                }
            }
            $single_category_output .= $category_output_return['container_end'];
        }else{
            $category_output_return = $this->display_pdfs_in_dropdown_multi_categories( 
                                                                                        $shortcode_atts_processed,
                                                                                        $ids_array,
                                                                                        $categories_loop_array
                                                                                    );
            $multi_categories_output .= $category_output_return['password_form'];
            $multi_categories_output .= $category_output_return['date_weekday_filter'];
            
            $target_str = trim($shortcode_atts_processed['target']) == '_blank' ? ' data-target="_blank"' : '';
            $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';
            if( $shortcode_atts_processed['option_none'] ){
                $dropdown_str .= '<option value="">'.$shortcode_atts_processed['option_none'].'</option>';
            }
            $dropdown_str .= $category_output_return['pdfs'];
            $dropdown_str .= '</select>';
            
            $multi_categories_output .= $dropdown_str;
        }
        
        $no_sub_cat_indent = $shortcode_atts_processed['sub_cat_indent'] ? '' : ' bsk-pdfm-sub-cat-no-indent';
        $only_single_category_class = $only_single_category ? ' bsk-pdfm-category-single' : '';
        $output_container_class = $shortcode_atts_processed['output_container_class'] ? ' '.$shortcode_atts_processed['output_container_class'] : '';
        $output_container_start = '<div class="bsk-pdfm-output-container shortcode-category layout-dropdown'.$no_sub_cat_indent.$only_single_category_class.$output_container_class.'">';
        $output_container_end = '</div><!-- //bsk-pdfm-output-container -->';
        
        //credit
        $credit_str = BSKPDFMPro_Common_Display::get_plugin_credit_text();
        
        //output all shortcode parameters
        $shortcode_parameters_str = '<div class="bsk-pdfm-category-shortcode-attr">';
        $shortcode_parameters_str .= BSKPDFMPro_Shortcodes_Category_Functions::get_shortcode_parameters_output( $shortcode_atts_processed );
        
        $ajax_nonce = wp_create_nonce( "category-ajax-get" );
        $shortcode_parameters_str .= '<input type="hidden" class="bsk-pdfm-category-ajax-nonce" value="'.$ajax_nonce.'">';
        $shortcode_parameters_str .= BSKPDFMPro_Statistics_Download_Count::bsk_pdfm_statistics_get_ajax_nonce();
        $shortcode_parameters_str .= '<!-- //bsk-pdfm-category-shortcode-attr -->';
        $shortcode_parameters_str .= '</div>';

        $output_str =  ''.
                            $output_container_start.
                            $single_category_output.
                            $multi_categories_output.
                            $credit_str.
                            $shortcode_parameters_str.
                            $output_container_end;
        
		return $output_str;
        
	} //end of function
    
    function display_pdfs_in_dropdown_for_single_category( 
                                                                                $processed_shortcodes_atts,
                                                                                $category_obj
                                                                           ){
        /**
          * Query PDFs for category
        */
        $exclude_pdf_ids_array = $processed_shortcodes_atts['exclude_pdf_id'] ? explode(',', $processed_shortcodes_atts['exclude_pdf_id'] ) : array();
        $query_args = array();
        $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;
        $query_args['year_of'] = $processed_shortcodes_atts['year_of'];
        $query_args['month_of'] = $processed_shortcodes_atts['month_of'];
        $query_args['day_of'] = $processed_shortcodes_atts['day_of'];
        $query_args['weekday_of'] = $processed_shortcodes_atts['weekday_of'];
        $query_args['pagination'] = false;
        $query_args['pdfs_per_page'] = 999999;
        $query_args['paged'] = 1;
        $query_args['order_by'] = $processed_shortcodes_atts['order_by'];
        $query_args['order'] = $processed_shortcodes_atts['order'];
        $query_args['most_top'] = $processed_shortcodes_atts['most_top'];
        $query_args['ids_array'] = array( $category_obj->id );
        $query_args['keywords'] = ''; // for dropdown no search bar $processed_shortcodes_atts['keywords'];
        
        $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );
        $category_depth = 1;
        $category_output_array = $this->get_category_output( 
                                                                                        $processed_shortcodes_atts,
                                                                                        $category_obj,
                                                                                        $cat_pdfs_query_results,
                                                                                        true, // for single category it need $date_weekday_filter,
                                                                                        false, //for single category it need not option group
                                                                                        $category_depth //category_depth
                                                                                    );

        $return_category = array();
        $return_category['container_begin'] = $category_output_array['container_begin'];
        $return_category['container_end'] = $category_output_array['container_end'];
        $return_category['cat_title'] = $category_output_array['cat_title'];
        $return_category['cat_description'] = $category_output_array['cat_description'];
        $return_category['cat_empty_message'] = $category_output_array['cat_empty_message'];
        $return_category['date_weekday_filter'] = $category_output_array['date_weekday_filter'];
        $return_category['pdfs'] = $category_output_array['pdfs'];
        $return_category['pagination'] = '';
        $return_category['results_desc'] = '';
        $return_category['search_bar_str'] = '';
        $return_category['password_form'] = $category_output_array['password_form'];
            
        return $return_category;
    }
    
    function display_pdfs_in_dropdown_multi_categories( 
                                                                 $processed_shortcodes_atts,
                                                                 $ids_array,
                                                                 $categories_to_loop
                                                              ){
        if( !$ids_array || !is_array( $ids_array ) || count( $ids_array ) < 1 || 
            !$categories_to_loop || !is_array( $categories_to_loop ) || count( $categories_to_loop ) < 1 ){
            return array( 'category_output' => '', 'results_desc' => 'No records found' );
        }
        
        /**
          * Query PDFs for category
        */
        $exclude_pdf_ids_array = $processed_shortcodes_atts['exclude_pdf_id'] ? explode(',', $processed_shortcodes_atts['exclude_pdf_id'] ) : array();
        $query_args = array();
        $query_args['exclude_ids_array'] = $exclude_pdf_ids_array;
        $query_args['year_of'] = $processed_shortcodes_atts['year_of'];
        $query_args['month_of'] = $processed_shortcodes_atts['month_of'];
        $query_args['day_of'] = $processed_shortcodes_atts['day_of'];
        $query_args['weekday_of'] = $processed_shortcodes_atts['weekday_of'];
        $query_args['pagination'] = false;
        $query_args['pdfs_per_page'] = 999999;
        $query_args['paged'] = 1;
        $query_args['order_by'] = $processed_shortcodes_atts['order_by'];
        $query_args['order'] = $processed_shortcodes_atts['order'];
        $query_args['most_top'] = $processed_shortcodes_atts['most_top'];
        $query_args['ids_array'] = $ids_array;
        $query_args['keywords'] = ''; // for dropdown no search bar $processed_shortcodes_atts['keywords'];
        
        $cat_pdfs_query_results = BSKPDFMPro_Common_Data_Source::bsk_pdfm_get_pdfs_by_cat( $query_args );
        if( !$cat_pdfs_query_results || !is_array( $cat_pdfs_query_results ) || count( $cat_pdfs_query_results ) < 1 ){
            return array( 'category_output' => '', 'results_desc' => 'No records found' );
        }
        $pdfs_results_array_by_category = $cat_pdfs_query_results['pdfs'];
        $total_pages = $cat_pdfs_query_results['pages'];
        $total_pdfs = $cat_pdfs_query_results['total'];
        $categories_for_pdfs_results = $cat_pdfs_query_results['categories_for_pdfs'];

        //display PDFs
        global $wpdb;
        $all_category_pdfs_output = '';
        $all_category_password_form_output = '';
        $categories_ask_for_password = array();
        foreach( $categories_to_loop as $category_obj ){
            $current_category_depth = 1;
            if(  isset( $pdfs_results_array_by_category[$category_obj->id] ) && 
                 is_array( $pdfs_results_array_by_category[$category_obj->id] ) &&
                 count( $pdfs_results_array_by_category[$category_obj->id] ) > 0 ){
                $category_output_array = $this->get_category_output( 
                                                                                            $processed_shortcodes_atts,
                                                                                            $category_obj,
                                                                                            $cat_pdfs_query_results,
                                                                                            false, // for multile category it need not $date_weekday_filter here
                                                                                            $processed_shortcodes_atts['option_group_label'],
                                                                                            $current_category_depth
                                                                                        );
                if( $category_output_array['password_form'] ){
                    $all_category_password_form_output .= ''.
                                            $category_output_array['container_begin'].
                                            $category_output_array['cat_title'].
                                            $category_output_array['cat_description'].
                                            $category_output_array['password_form'].
                                            $category_output_array['container_end'];
                    $categories_ask_for_password[] = $category_obj->id;
                }else{
                    $all_category_pdfs_output .= $category_output_array['pdfs'];
                }
            }
            
            if( $processed_shortcodes_atts['hierarchical'] ){
                //show child categories
                $sql_base = 'SELECT * FROM `'.$wpdb->prefix.BSKPDFManagerPro::$_cats_tbl_name.'` AS C '.
                                 'WHERE 1 ';
                $exclude_cat_ids_array = $processed_shortcodes_atts['exclude_id'] ? explode( ',', $processed_shortcodes_atts['exclude_id'] ) : false;
                if( $exclude_cat_ids_array && is_array( $exclude_cat_ids_array ) && count( $exclude_cat_ids_array ) > 0 ){
                    $sql_base .= ' AND C.`id` NOT IN('.implode(',', $exclude_cat_ids_array).')';
                }
                //child categories
                $sql = $sql_base.' AND C.`parent` = '.$category_obj->id.' ORDER BY '.
                         $processed_shortcodes_atts['cat_order_by'].$processed_shortcodes_atts['cat_order'];
                $child_results = $wpdb->get_results( $sql );
                if( $child_results && is_array( $child_results ) && count( $child_results ) > 0 ){
                    foreach( $child_results as $child_cat_obj ){
                        if(  isset( $pdfs_results_array_by_category[$child_cat_obj->id] ) && 
                             is_array( $pdfs_results_array_by_category[$child_cat_obj->id] ) &&
                             count( $pdfs_results_array_by_category[$child_cat_obj->id] ) > 0 ){
                            
                            $child_depth = $current_category_depth + 1;
                            $category_output_array = $this->get_category_output( 
                                                                                        $processed_shortcodes_atts,
                                                                                        $child_cat_obj,
                                                                                        $cat_pdfs_query_results,
                                                                                        false, // for multile category it need not $date_weekday_filter here
                                                                                        $processed_shortcodes_atts['option_group_label'],
                                                                                        $child_depth
                                                                                    );
                            if( $category_output_array['password_form'] ){
                                $all_category_password_form_output .= ''.
                                                        $category_output_array['container_begin'].
                                                        $category_output_array['cat_title'].
                                                        $category_output_array['cat_description'].
                                                        $category_output_array['password_form'].
                                                        $category_output_array['container_end'];
                                $categories_ask_for_password[] = $category_obj->id;
                            }else{
                                $all_category_pdfs_output .= $category_output_array['pdfs'];
                            }
                        }
                        //grand categories
                        $sql = $sql_base.' AND C.`parent` = '.$child_cat_obj->id.' ORDER BY '.
                                 $processed_shortcodes_atts['cat_order_by'].$processed_shortcodes_atts['cat_order'];
                        $grand_results = $wpdb->get_results( $sql );
                        if( $grand_results && is_array( $grand_results ) && count( $grand_results ) > 0 ){
                            foreach( $grand_results as $grand_cat_obj ){
                                if(  isset( $pdfs_results_array_by_category[$grand_cat_obj->id] ) && 
                                     is_array( $pdfs_results_array_by_category[$grand_cat_obj->id] ) &&
                                     count( $pdfs_results_array_by_category[$grand_cat_obj->id] ) > 0 ){

                                    $grand_depth = $current_category_depth + 2;
                                    $category_output_array = $this->get_category_output( 
                                                                                        $processed_shortcodes_atts,
                                                                                        $grand_cat_obj,
                                                                                        $cat_pdfs_query_results,
                                                                                        false, // for multile category it need not $date_weekday_filter here
                                                                                        $processed_shortcodes_atts['option_group_label'],
                                                                                        $grand_depth
                                                                                    );
                                    if( $category_output_array['password_form'] ){
                                        $all_category_password_form_output .= ''.
                                                                $category_output_array['container_begin'].
                                                                $category_output_array['cat_title'].
                                                                $category_output_array['cat_description'].
                                                                $category_output_array['password_form'].
                                                                $category_output_array['container_end'];
                                        $categories_ask_for_password[] = $category_obj->id;
                                    }else{
                                        $all_category_pdfs_output .= $category_output_array['pdfs'];
                                    }
                                }
                            }//end foreach
                        }//end for grand categories
                    } //end foreach child categories
                }
            } //end hierarchical
        }//end foreach
        
        $all_pdfs_results_count = 0;
        $all_pdfs_results_array_for_date_filter_and_pagination = array();
        $search_bar_str = '';
        $date_weekday_filter_str = '';
        $pagination_str = '';
        if( $pdfs_results_array_by_category && is_array( $pdfs_results_array_by_category ) && count($pdfs_results_array_by_category) > 0 ){
            foreach( $pdfs_results_array_by_category as $key => $pdfs_by_category ){
                $all_pdfs_results_count += count( $pdfs_by_category );
                if( count($categories_ask_for_password) > 0 && in_array($key, $categories_ask_for_password ) ){
                    continue;
                }
                $all_pdfs_results_array_for_date_filter_and_pagination = array_merge( $all_pdfs_results_array_for_date_filter_and_pagination, $pdfs_by_category );
            }

            //show date filter
            if( $processed_shortcodes_atts['date_weekday_filter'] ){
                $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                    $all_pdfs_results_array_for_date_filter_and_pagination, 
                                                                                                    $processed_shortcodes_atts['date_weekday_filter'], 
                                                                                                    $processed_shortcodes_atts['date_weekday_filter_order'], 
                                                                                                    $processed_shortcodes_atts['date_weekday_filter_right']
                                                                                                 );
            }
        }
        
        return array( 
                            'search_bar_str' => '', 
                            'date_weekday_filter' => $date_weekday_filter_str, 
                            'pdfs' => $all_category_pdfs_output,
                            'password_form' => $all_category_password_form_output,
                            'pagination' => '',
                            'results_desc' => '' 
                         );
    }
    
    function get_category_output( 
                                                    $processed_shortcodes_atts,
                                                    $category_obj,
                                                    $category_pdfs_query_result,
                                                    $date_weekday_filter,
                                                    $option_group,
                                                    $category_depth
                                             ){
        $return_array = array( 
                                        'container_begin' => '',
                                        'container_end' => '',
                                        'cat_title' => '', 
                                        'cat_description' => '',
                                        'password_form' => '',
                                        'cat_empty_message' => '', 
                                        'pdfs' => '', 
                                        'date_weekday_filter' => '',
                                        'pagination' => '',
                                        'results_desc' => '' 
                                      );
        
        if( !$category_obj ){
            return $return_array;
        }
        
        $depth_class = ' category-hierarchical-depth-'.$category_depth;
        $categor_output_container_begin = '<div class="bsk-pdfm-category-output cat-'.$category_obj->id.$depth_class.' pdfs-in-dropdown" data-cat-id="'.$category_obj->id.'">';
        $categor_output_container_end = '<!--//bsk-pdfm-category-output cat-'.$category_obj->id.'-->';
        $categor_output_container_end .= '</div>';
        
        $caegory_title_tag = 'h'.($category_depth + 1);
        $pdf_title_tag = 'h'.($category_depth + 2);
        
        $cat_title = '';
        if( $processed_shortcodes_atts['show_cat_title'] ){
            $cat_title = apply_filters( 'bsk_pdfm_filter_cat_title', 
                                                '<'.$caegory_title_tag.' class="bsk-pdfm-cat-titile">'.$category_obj->title.'</'.$caegory_title_tag.'>',
                                                $category_obj->id,
                                                $category_obj->title );
        }
        
        $cat_description = '';
        if( $processed_shortcodes_atts['show_cat_description'] ){
            $cat_description = '<div class="bsk-pdfm-category-description">'.$category_obj->description.'</div>';
        }
        
        //check if password protection set for the category
        $password_form_str = '';
        if( $processed_shortcodes_atts['password_required'] && $category_obj->password != "" ){
            if( array_key_exists( $category_obj->id, $processed_shortcodes_atts['category_password_array'] ) ){
                if( $processed_shortcodes_atts['category_password_array'][$category_obj->id] != $category_obj->password ){
                    $password_form_str = BSKPDFMPro_Common_Display::show_category_password_require_form( $category_obj, true );
                }
            }else{
                $password_form_str = BSKPDFMPro_Common_Display::show_category_password_require_form( $category_obj, false );
            }
        }
        
        
        $return_array['container_begin'] = $categor_output_container_begin;
        $return_array['container_end'] = $categor_output_container_end;
        $return_array['cat_title'] = $cat_title;
        $return_array['cat_description'] = $cat_description;
        $return_array['password_form'] = $password_form_str;
        
        if( $password_form_str ){
            return $return_array;
        }
        
        if( !$category_pdfs_query_result || !is_array( $category_pdfs_query_result ) || count( $category_pdfs_query_result ) < 1 ){
            $return_array['results_desc'] = 'No records found';
            $cat_empty_message = '';
            if( $processed_shortcodes_atts['show_cat_empty_message'] && $processed_shortcodes_atts['hide_empty_cat'] == false ){
                $cat_empty_message = '<p class="bsk-pdfm-category-empty-message cat-'.$category_obj->id.'">'.$category_obj->empty_message.'</p>';
            }
            $return_array['cat_empty_message'] = $cat_empty_message;
            
            return $return_array;
        }
        $pdfs_results_array_by_category = $category_pdfs_query_result['pdfs'];
        $total_pages = $category_pdfs_query_result['pages'];
        $total_pdfs = $category_pdfs_query_result['total'];
        $categories_for_pdfs_results = $category_pdfs_query_result['categories_for_pdfs'];

        //display PDFs
        $pdfs_options_str = BSKPDFMPro_Common_Display::show_pdfs_dropdown_option_for_category(
                                                                                                                 $pdfs_results_array_by_category[$category_obj->id],
                                                                                                                 $category_obj,
                                                                                                                 $processed_shortcodes_atts['show_date'], 
                                                                                                                 $processed_shortcodes_atts['date_format'],
                                                                                                                 $processed_shortcodes_atts['date_before_title'],
                                                                                                                 $category_depth,
                                                                                                                 $option_group
                                                                                                                );
        
        $all_pdfs_results_count = count( $pdfs_results_array_by_category[$category_obj->id] );
        
        //show date filter
        $date_weekday_filter_str = '';
        if( $date_weekday_filter && $processed_shortcodes_atts['date_weekday_filter'] ){
            $date_weekday_filter_str = BSKPDFMPro_Common_Filter::show_date_filter( 
                                                                                                $pdfs_results_array_by_category[$category_obj->id], 
                                                                                                $processed_shortcodes_atts['date_weekday_filter'], 
                                                                                                $processed_shortcodes_atts['date_weekday_filter_order'], 
                                                                                                $processed_shortcodes_atts['date_weekday_filter_right']
                                                                                             );
        }

        $return_array['pdfs'] = $pdfs_options_str;
        $return_array['date_weekday_filter'] = $date_weekday_filter_str;
        $return_array['pagination'] = '';
        $return_array['results_desc'] = '';
        
        return $return_array;
    }

    function bsk_pdfm_ajax_get_category_dropdown(){
        
        if( !check_ajax_referer( 'category-ajax-get', 'nonce', false ) ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Security check!</p>' );
            wp_die( json_encode( $return_array ) );
        }
        $license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		if( trim($license) == '' || 
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
			$return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Invalid license!</p>' );
            wp_die( json_encode( $return_array ) );
		}
        
        $all_shortcode_atts = array( 
                                                'option_none' => 'Select to open...',
                                                'option_group_label' => 'CAT_TITLE', 
                                              );
        $all_shortcode_atts['category_password'] = isset( $_POST['category_password'] ) ? $_POST['category_password'] : '';
        $all_shortcode_atts = array_merge( 
                                                           $all_shortcode_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_category_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_pdfs_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_date_weekday_filter_atts,
                                                           BSKPDFMPro_Shortcodes_Category_Functions::$_shortcode_output_container_atts
                                                         );
        foreach( $all_shortcode_atts as $key => $default_val ){
            $all_shortcode_atts[$key] = isset( $_POST[$key] ) ? $_POST[$key] : $default_val;
        }
        $shortcode_atts_processed = BSKPDFMPro_Shortcodes_Category_Functions::process_shortcode_parameters( $all_shortcode_atts );

        $ids_array = false;
		$categories_loop_array = false;
        $only_single_category = false;
        $return = BSKPDFMPro_Common_Data_Source::bsk_pdfm_organise_categories_id_sequence( 
                                                                                                $shortcode_atts_processed['id'], 
                                                                                                $shortcode_atts_processed['hierarchical'], 
                                                                                                $shortcode_atts_processed['exclude_id'], 
                                                                                                $shortcode_atts_processed['cat_order_by'], 
                                                                                                $shortcode_atts_processed['cat_order'] );
        if( $return ){
            $ids_array = $return['ids_array'];
            $categories_loop_array = $return['categories_loop'];
        }
        if( $ids_array == false || !is_array( $ids_array ) || count( $ids_array ) < 1 ){
            $return_array = array( 'error_message' => '<p class="bsk-pdfm-error-message">Category ID( '.$shortcode_atts_processed['id'].' )doesn\'t exist</p>' );
            wp_die( json_encode( $return_array ) );
        }

        $only_single_category = count( $ids_array ) == 1 ? true : false;
        $single_category_output = '';
        $multi_categories_output = '';
        $category_output_return = false;
        
        if( $only_single_category ){
            /* 
                the difference between multiple categoryes & single cateogry: 
                1. searchbar is below category titile, category description
                2. weekday filter is below category titile, category description
                3. single category support show category empty messaage & hide empty category
                3. 
            */
            $category_obj = array_shift( $categories_loop_array );
            $category_output_return = $this->display_pdfs_in_dropdown_for_single_category( 
                                                                                        $shortcode_atts_processed,
                                                                                        $category_obj
                                                                                    );
            $single_category_output = $category_output_return['container_begin'];
            $single_category_output .= $category_output_return['cat_title'];
            $single_category_output .= $category_output_return['cat_description'];
            if( $category_output_return['cat_empty_message'] ){
                 $single_category_output .= $category_output_return['cat_empty_message'];
            }else{
                if( $category_output_return['password_form'] ){
                    $single_category_output .= $category_output_return['password_form'];
                }else{
                    $single_category_output .= $category_output_return['date_weekday_filter'];

                    $target_str = trim($shortcode_atts_processed['target']) == '_blank' ? ' data-target="_blank"' : '';
                    $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';
                    if( $shortcode_atts_processed['option_none'] ){
                        $dropdown_str .= '<option value="">'.$shortcode_atts_processed['option_none'].'</option>';
                    }
                    $dropdown_str .= $category_output_return['pdfs'];
                    $dropdown_str .= '</select>';

                    $single_category_output .= $dropdown_str;
                }
            }
            $single_category_output .= $category_output_return['container_end'];
        }else{
            $category_output_return = $this->display_pdfs_in_dropdown_multi_categories( 
                                                                                        $shortcode_atts_processed,
                                                                                        $ids_array,
                                                                                        $categories_loop_array
                                                                                    );
            $multi_categories_output .= $category_output_return['password_form'];
            $multi_categories_output .= $category_output_return['date_weekday_filter'];
            
            $target_str = trim($shortcode_atts_processed['target']) == '_blank' ? ' data-target="_blank"' : '';
            $dropdown_str = '<select class="bsk-pdfm-pdfs-dropdown"'.$target_str.'>';
            if( $shortcode_atts_processed['option_none'] ){
                $dropdown_str .= '<option value="">'.$shortcode_atts_processed['option_none'].'</option>';
            }
            $dropdown_str .= $category_output_return['pdfs'];
            $dropdown_str .= '</select>';
            
            $multi_categories_output .= $dropdown_str;
        }
        
        $data_to_return = array( 
                                            'date_filter' => '', 
                                            'pdfs' => $single_category_output.$multi_categories_output, 
                                            'pagination' => '', 
                                            'results_desc' => ''
                                         );
        wp_die( json_encode( $data_to_return ) );
        
    } //end of function
}