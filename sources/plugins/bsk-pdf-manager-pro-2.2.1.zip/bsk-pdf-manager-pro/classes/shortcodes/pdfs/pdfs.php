<?php

class BSKPDFMPro_Shortcodes_PDFs {

    private static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    private static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    private static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    private static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    public $_pdfs_OBJ_dropdown = NULL;
    public $_pdfs_OBJ_ul_ol = NULL;
    public $_pdfs_OBJ_columns = NULL;
    
	public function __construct() {
        
        require_once( 'pdfs-dropdown.php' );
        require_once( 'pdfs-ul-ol.php' );
        require_once( 'pdfs-columns.php' );
        
        $this->_pdfs_OBJ_dropdown = new BSKPDFMPro_Shortcodes_PDFs_Dropdown();
        $this->_pdfs_OBJ_ul_ol = new BSKPDFMPro_Shortcodes_PDFs_UL_OL();
        $this->_pdfs_OBJ_columns = new BSKPDFMPro_Shortcodes_PDFs_Columns();
	}
}