<?php

class BSKPDFMPro_Statistics_Download_Count {

	public function __construct() {
        add_action( 'wp_ajax_pdfs_statistics_update_download_count', array( $this, 'bsk_pdfm_statistics_update_download_count_fun' ) );
		add_action( 'wp_ajax_nopriv_pdfs_statistics_update_download_count', array( $this, 'bsk_pdfm_statistics_update_download_count_fun' ) );
	}
    
    function bsk_pdfm_statistics_update_download_count_fun(){
        if( !check_ajax_referer( 'statistics-ajax-update', 'nonce', false ) ){
            wp_die( '' );
        }
        
        $pdf_id = 0;
        if( isset( $_POST['id'] ) && $_POST['id'] ){
            $pdf_id = absint( $_POST['id'] );
        }
        if( $pdf_id < 1 ){
            wp_die( '' );
        }
        
        global $wpdb;
        
        $sql = 'UPDATE `'.$wpdb->prefix.BSKPDFManagerPro::$_pdfs_tbl_name.'` SET `download_count` = `download_count` + 1 WHERE `id` = %d';
        $sql = $wpdb->prepare( $sql, $pdf_id );
        $wpdb->query( $sql );
        
        wp_die( '' );
    }
    
    public static function bsk_pdfm_statistics_get_ajax_nonce(){
        
        $statics_enabled = false;
        $plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 && 
            isset( $plugin_settings['statistics_enable'] ) && $plugin_settings['statistics_enable'] ){
            $statics_enabled = true;
		}
        
        if( $statics_enabled == false ){
            return '';
        }
        
        $ajax_nonce = wp_create_nonce( "statistics-ajax-update" );
        $nonce_hidden_input = '<input type="hidden" class="bsk-pdfm-statistics-ajax-nonce" value="'.$ajax_nonce.'">';
        
        return $nonce_hidden_input;
    }
    
    public static function bsk_pdfm_get_pdf_download_count( $download_count ){
        $statics_enabled = false;
        $download_count_front_enable = false;
        $download_count_label = ' ( Downloads: #COUNT# )';
        $plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
            if( isset( $plugin_settings['statistics_enable'] ) && $plugin_settings['statistics_enable'] ){
                $statics_enabled = true;
            }
            if( isset( $plugin_settings['download_count_front_enable'] ) && $plugin_settings['download_count_front_enable'] ){
                $download_count_front_enable = true;
            }
            if( isset( $plugin_settings['download_count_label'] ) && $plugin_settings['download_count_label'] ){
                $download_count_label = $plugin_settings['download_count_label'];
            }
		}
        
        if( $statics_enabled == false || $download_count_front_enable == false ){
            return '';
        }
        if( trim($download_count_label) == "" ){
            $download_count_label = ' ( Downloads: #COUNT# )';
        }
        
        $str = str_replace( '#COUNT#', $download_count, $download_count_label );
        $str = '<span class="bsk-pdfm-download-count">'.$str.'</span>';
            
        return $str;
    }
}