<?php
class BSKPDFMPro_Dashboard {
    
    public static $_bsk_pdfm_pro_pages = array(  
                                                                 'base'		=> 'bsk-pdf-manager-pro',
                                                                 'category' => 'bsk-pdf-manager-category', 
                                                                 'pdf' 		=> 'bsk-pdf-manager-pro-pdfs', 
                                                                 'add_by_ftp' 	=> 'bsk-pdf-manager-pro-add-by-ftp',
                                                                 'setting' 		=> 'bsk-pdf-manager-pro-settings-support', 
                                                                 'help' 		=> 'bsk-pdfm-help',
                                                                 'license_update' => 'bsk-pdf-manager-pro-license-update' );
    
    public static $_plugin_license = '_bsk_pdf_manager_pro_license_';
    public static $_plugin_license_stauts = '_bsk_pdf_manager_pro_license_stauts_';
    public static $_plugin_license_actived = '_bsk_pdf_manager_pro_license_actived_';
    public static $_plugin_license_activated_manually = '_bsk_pdf_manager_pro_license_activated_manually_';
    
    public static $_plugin_license_activation_return = '_bsk_pdf_manager_pro_activation_return_';
    
	private static $_bsk_pdfm_OBJ = NULL;
	private static $_bsk_pdfm_OBJ_category = NULL;
	private static $_bsk_pdfm_OBJ_pdf = NULL;
    private static $_bsk_pdfm_OBJ_ftp = NULL;
	private static $_bsk_pdfm_OBJ_settings = NULL;
    private static $_bsk_pdfm_OBJ_help = NULL;
	
	private static $_bsk_pdfm_OBJ_update_helper = NULL;
    private static $_bsk_pdfm_OBJ_updater = NULL;
			
	public function __construct() {
		
		require_once( 'categories.php' );
		require_once( 'category.php' );
		require_once( 'pdfs.php' );	
		require_once( 'pdf.php' );
        require_once( 'ftp.php' );
		require_once( 'settings/settings.php' );
        require_once( 'help.php' );
        require_once( BSK_PDFM_PRO_PLUGIN_DIR.'classes/updater/update-helper.php' );
        require_once( BSK_PDFM_PRO_PLUGIN_DIR.'classes/updater/updater.php' );

        self::$_bsk_pdfm_OBJ_category = new BSKPDFMPro_Dashboard_Category();		
		self::$_bsk_pdfm_OBJ_pdf = new BSKPDFMPro_Dashboard_PDF();
        self::$_bsk_pdfm_OBJ_ftp = new BSKPDFMPro_Dashboard_FTP();
		self::$_bsk_pdfm_OBJ_settings = new BSKPDFMPro_Dashboard_Settings();
        self::$_bsk_pdfm_OBJ_update_helper = new BSKPDFMPro_Dashboard_Update_Helper();
        self::$_bsk_pdfm_OBJ_updater = new BSKPDFMPro_Dashboard_Updater();
        self::$_bsk_pdfm_OBJ_help = new BSKPDFMPro_Dashboard_Help();
		
		add_action( 'admin_menu', array( $this, 'bsk_pdf_manager_dashboard_menu' ) );
		add_action( 'admin_init', array( $this, 'bsk_pdf_manager_activate_license' ) );
		add_action( 'admin_init', array( $this, 'bsk_pdf_manager_deactivate_license' ) );
        add_action( 'admin_notices', array( $this, 'bsk_pdf_manager_pro_upgrade_done_notice_fun' ) );
	}
	
	function bsk_pdf_manager_dashboard_menu() {
		
		//read plugin settings
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		$author_access_pdf_category = false;
        $editor_access_all = false;
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['author_access_pdf_category']) ){
				$author_access_pdf_category = $plugin_settings['author_access_pdf_category'];
			}
            if( isset($plugin_settings['editor_access_all']) ){
				$editor_access_all = $plugin_settings['editor_access_all'];
			}
		}
		
		$category_pdf_authorized_level = 'moderate_comments';
        $other_menus_authorized_level = 'manage_options';
		if( $author_access_pdf_category ){
			$category_pdf_authorized_level = 'publish_posts';
		}
        if( $editor_access_all ){
			$other_menus_authorized_level = 'moderate_comments';
		}
		
		add_menu_page( 
                                 'BSK PDF Pro', 
                                 'BSK PDF Pro', 
                                 $category_pdf_authorized_level, 
                                 self::$_bsk_pdfm_pro_pages['base'], 
                                 '', 
                                 'dashicons-media-document'
                                );
		
		$license = get_option( self::$_plugin_license );
		$license_status = get_option( self::$_plugin_license_stauts );
		$license_actived = get_option( self::$_plugin_license_actived );
		if( trim($license) == '' || 
			$license_actived != 'ACTIVED' ||
		    ( $license_status != 'VALID' && $license_status != 'EXPIRED' ) ){
				
			add_submenu_page( 
                                self::$_bsk_pdfm_pro_pages['base'],
                                'License & Update', 
                                'License & Update',
                                $other_menus_authorized_level, 
                                self::$_bsk_pdfm_pro_pages['base'],
                                array($this, 'bsk_pdf_manager_license_n_update') );
            
            add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'Help', 
							  'Help',
							  $other_menus_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['help'],
							  array($this, 'bsk_pdf_manager_help') );
		
		}else{
			add_submenu_page( 
                                self::$_bsk_pdfm_pro_pages['base'],
                                'Categories', 
                                'Categories',
                                $category_pdf_authorized_level, 
                                self::$_bsk_pdfm_pro_pages['base'],
                                array($this, 'bsk_pdf_manager_categories') );
	
			add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'PDF Documents', 
							  'PDF Documents', 
							  $category_pdf_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['pdf'],
							  array($this, 'bsk_pdf_manager_pdfs') );
											  
			add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'Add by FTP', 
							  'Add by FTP', 
							  $other_menus_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['add_by_ftp'],
							  array($this, 'bsk_pdf_manager_pdfs_add_by_ftp_interface') );	
							  
			add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'Settings', 
							  'Settings', 
							  $other_menus_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['setting'],
							  array($this, 'bsk_pdf_manager_settings_support') );
						
			add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'License & Update', 
							  'License & Update',
							  $other_menus_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['license_update'],
							  array($this, 'bsk_pdf_manager_license_n_update') );
            
            add_submenu_page( self::$_bsk_pdfm_pro_pages['base'],
							  'Help', 
							  'Help',
							  $category_pdf_authorized_level, 
							  self::$_bsk_pdfm_pro_pages['help'],
							  array($this, 'bsk_pdf_manager_help') );
		}
	}
	
	function bsk_pdf_manager_categories(){
		global $current_user;
		

		$categories_curr_view = 'list';
		if(isset($_GET['view']) && $_GET['view']){
			$categories_curr_view = trim($_GET['view']);
		}
		if(isset($_POST['view']) && $_POST['view']){
			$categories_curr_view = trim($_POST['view']);
		}
		
		$category_base_page = admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['base'] );
		if ($categories_curr_view == 'list'){
            $_bsk_pdfm_OBJ_categories = new BSKPDFMPro_Dashboard_Categories();

			//Fetch, prepare, sort, and filter our data...
			$_bsk_pdfm_OBJ_categories->prepare_items();
			
			$category_add_new_page = add_query_arg( 'view', 'addnew', $category_base_page );
	
			echo '<div class="wrap">
					<div id="icon-edit" class="icon32"><br/></div>
					<h2>BSK PDF Categories<a href="'.$category_add_new_page.'" class="add-new-h2">Add New</a></h2>
					<form id="bsk_pdf_manager_categories_form_id" method="post" action="'.$category_base_page.'">';
						$_bsk_pdfm_OBJ_categories->views();
						$_bsk_pdfm_OBJ_categories->display();
			echo '  </form>
				  </div>';
		}else if ( $categories_curr_view == 'addnew' || $categories_curr_view == 'edit'){
			$category_id = -1;
			if(isset($_GET['categoryid']) && $_GET['categoryid']){
				$category_id = trim($_GET['categoryid']);
				$category_id = intval($category_id);
			}	
			echo '<div class="wrap">
					<div id="icon-edit" class="icon32"><br/></div>
					<h2>BSK PDF Category</h2>
					<form id="bsk_pdf_manager_categories_form_id" method="post" action="'.$category_base_page.'">';
					self::$_bsk_pdfm_OBJ_category->bsk_pdf_manager_category_edit( $category_id );
			echo   '<p style="margin-top:20px;"><input type="button" id="bsk_pdf_manager_category_save" class="button-primary" value="Save" /></p>'."\n";
			echo '	</form>
				  </div>';
		}
	}
	
	function bsk_pdf_manager_pdfs(){
		global $current_user;
		
		$lists_curr_view = 'list';
		if(isset($_GET['view']) && $_GET['view']){
			$lists_curr_view = trim($_GET['view']);
		}
		if(isset($_POST['view']) && $_POST['view']){
			$lists_curr_view = trim($_POST['view']);
		}
		
		if ($lists_curr_view == 'list'){
			global $wpdb;
			
			if( (isset($_POST['action']) && $_POST['action'] == 'changecat') || 
			    (isset($_POST['action2']) && $_POST['action2'] == 'changecat') ){
				
				$selected_PDFs = isset($_POST['bsk-pdf-manager-pdfs']) ? $_POST['bsk-pdf-manager-pdfs'] : '';
				$selected_PDFs_to_hidden = '';

				$url_cat_parameter = isset($_REQUEST['cat']) ? '&cat='.$_REQUEST['cat'] : '';
				$action_url = admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['pdf'].$url_cat_parameter );
				?>
				<div class="wrap">
                <h2>Change Category</h2>
                <form id="bsk_pdf_manager_pdfs_change_category_form_id" method="post" action="<?php echo $action_url; ?>" enctype="multipart/form-data">
                <?php
				if( $selected_PDFs && is_array($selected_PDFs) && count($selected_PDFs) > 0 ){
					$selected_PDFs_to_hidden = implode(',', $selected_PDFs);
				?>
                <div>
                    <h4>Choose action to do</h4>
                    <p>
                    	<label>
                        	<input type="radio" name="bsk_pdf_manager_pdfs_change_category_action_to_do" value="add" checked="checked" class="bsk-pdf-manger-pdfs-change-category-action-radio" />Add
                        </label>
                        <label style="margin-left:10px;">
                        	<input type="radio" name="bsk_pdf_manager_pdfs_change_category_action_to_do" value="remove" class="bsk-pdf-manger-pdfs-change-category-action-radio" />Remove
                        </label>
                        <label style="margin-left:10px;">
                        	<input type="radio" name="bsk_pdf_manager_pdfs_change_category_action_to_do" value="update_to" class="bsk-pdf-manger-pdfs-change-category-action-radio" />Update to
                        </label>
                    </p>
                    <h4>Choose category to be managed</h4>
                    <p id="bsk_pdfm_batch_update_category_choose_error_message_ID" style="color: #FF0000;"></p>
                    <?php
                    echo BSKPDFMPro_Common_Backend::get_category_hierarchy_checkbox( 'bsk_pdf_manager_pdfs_categories_to_manager[]', 
                                                                                                                         'bsk-pdfm-bactch-update-category-checkbox',
                                                                                                                         NULL);
                    ?>
                </div>
                <?php
				}else{
					echo '<p>No PDF items choosen.</p>';
				}
				$_nonce = wp_create_nonce( 'bsk_pdf_manager_bulk_update_pdf_category_nonce' );
				?>
                <p>
				    <input type="hidden" name="_nonce" value="<?php echo $_nonce; ?>" />
                	<input type="hidden" name="bsk_pdf_manager_action" id="bsk_pdf_manager_action_id" value="" />
                    <input type="hidden" name="bsk_pdf_manager_pdf_items_id_hidden" value="<?php echo $selected_PDFs_to_hidden; ?>" />
                	<input type="button" class="button-primary" value="Cancel" id="bsk_pdf_manager_pdfs_categories_change_cancel_id" />
                    <?php if( $selected_PDFs && count($selected_PDFs) > 0 ){ ?>
                    <input type="button" class="button-primary" value="Submit" id="bsk_pdf_manager_pdfs_categories_change_submit_id" style="margin-left: 15px;" />
					<?php } ?>
                </p>
                </form>
              </div>
              <?php
			}else{
				$bsk_pdfm_pdfs_list_page_url = admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['pdf'] );
				
				$current_category_id = 0;
				if( isset($_REQUEST['cat']) ){
					$current_category_id = $_REQUEST['cat'];
					$current_category_id = intval( $current_category_id );
				}

				$add_new_page = add_query_arg( 'view', 'addnew', $bsk_pdfm_pdfs_list_page_url );
				if( $current_category_id ){
					$add_new_page = add_query_arg( 'cat', $current_category_id, $add_new_page );
					$bsk_pdfm_pdfs_list_page_url = add_query_arg( 'cat', $current_category_id, $bsk_pdfm_pdfs_list_page_url );
				}
                
                $_bsk_pdfm_OBJ_pdfs = new BSKPDFMPro_Dashboard_PDFs();
				//Fetch, prepare, sort, and filter our data...
				$_bsk_pdfm_OBJ_pdfs->prepare_items();
                ?>
                <div class="wrap">
                <div id="icon-edit" class="icon32"><br/></div>
                <h2>BSK PDF Documents<a href="<?php echo $add_new_page; ?>" class="add-new-h2">Add New</a></h2>
                
				<form id="bsk-pdf-manager-pdfs-form-id" method="post" action="<?php echo $bsk_pdfm_pdfs_list_page_url; ?>">
				<input type="hidden" name="page" value="<?php echo self::$_bsk_pdfm_pro_pages['pdf']; ?>" />
                <?php
                $_bsk_pdfm_OBJ_pdfs->search_box( 'search', 'bsk-pdf-manager-pdfs' );
                $_bsk_pdfm_OBJ_pdfs->views();
                $_bsk_pdfm_OBJ_pdfs->display();

                if( $current_category_id ){
                ?>
                    <p>Shortocde to show this category in list: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-category-ul id="<?php echo $current_category_id; ?>"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-pdfs-by-category-in-list/" target="_blank">click here for more shortcode attributes</a></p>
                    <p>Shortocde to show this category in columns: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-category-columns id="<?php echo $current_category_id; ?>" columns="2"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-pdfs-by-category-in-columns/" target="_blank">click here for more shortcode attributes</a></p>
                    <p>Shortocde to show this category in dropdown: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-category-dropdown id="<?php echo $current_category_id; ?> target="_blank"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-pdfs-by-category-in-dropdown/" target="_blank">click herefor more shortcode attributes</a> </p>
                <?php
                }else{
                ?>
                    <p>Shortocde to show PDFs / Files in list: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-pdfs-ul id="1,2,3,4"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-specific-pdfs-in-list/" target="_blank">click here for more shortcode attributes</a></p>
                    <p>Shortocde to show PDFs / Files in columns: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-pdfs-columns id="1,2,3,4" columns="2" target="_blank"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-specific-pdfs-in-columns/" target="_blank">click here for more shortcode attributes</a></p>
                    <p>Shortocde to show PDFs / Files in dropdown: <span class="bsk-pdf-documentation-attr">[bsk-pdfm-pdfs-dropdown id="1,2,3,4"  target="_blank"]</span>, <a href="https://www.bannersky.com/document/bsk-pdf-manager-documentatio-v2/display-specific-pdfs-in-dropdown/" target="_blank">click here for more shortcode attributes</a></p>
                <?php
                }
                $ajax_nonce = wp_create_nonce( 'bsk_pdf_manager_pdfs_page_ajax-oper-nonce' );
                ?>
				<input type="hidden" id="bsk_pdf_manager_pdfs_page_ajax_nonce_ID" value="<?php echo $ajax_nonce; ?>" />
				</form>
                </div>
                <?php
			}
		}else if ( $lists_curr_view == 'addnew' || $lists_curr_view == 'edit'){
			$pdf_id = -1;
			if(isset($_GET['pdfid']) && $_GET['pdfid']){
				$pdf_id = trim($_GET['pdfid']);
				$pdf_id = intval($pdf_id);
			}	
			echo '<div class="wrap">
					<div id="icon-edit" class="icon32"><br/></div>
					<h2>BSK PDF Document</h2>
					<form id="bsk-pdf-manager-pdfs-form-id" method="post" enctype="multipart/form-data" action="'.admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['pdf'] ).'">
					<input type="hidden" name="page" value="'.self::$_bsk_pdfm_pro_pages['pdf'].'" />';
					self::$_bsk_pdfm_OBJ_pdf->pdf_edit( $pdf_id );
			echo '  <p style="margin-top:20px;"><input type="button" id="bsk_pdf_manager_pdf_save_form" class="button-primary" value="Save" /></p>'."\n";
			echo '	</form>
				  </div>';
		}
	}
	
	function bsk_pdf_manager_settings_support(){
		global $current_user;
		
		//read plugin settings
		$plugin_settings = get_option( BSKPDFManagerPro::$_plugin_settings_option, '' );
		$author_access_pdf_category = false;
		if( $plugin_settings && is_array($plugin_settings) && count($plugin_settings) > 0 ){
			if( isset($plugin_settings['author_access_pdf_category']) ){
				$author_access_pdf_category = $plugin_settings['author_access_pdf_category'];
			}
		}
		
		if ( !$this->bsk_pdf_manager_current_user_can() && $author_access_pdf_category ){
			//for authors
			self::$_bsk_pdfm_OBJ_settings->show_help();
			
			return;
		}
		
		
		self::$_bsk_pdfm_OBJ_settings->show_settings();
	}
    
    function bsk_pdf_manager_help(){
		self::$_bsk_pdfm_OBJ_help->show_help();
	}
	
	function bsk_pdf_manager_current_user_can(){
		global $current_user;
		
		if ( current_user_can('level_3') ){
			return true;
		}else{
			/*
			//get role;
			$user_roles = $current_user->roles;
			$user_role = array_shift($user_roles);
			
			if ($user_role == 'spcial role'){
				return true;
			}
			*/
		}
		return false;
	}
	
	function bsk_pdf_manager_pdfs_add_by_ftp_interface(){
		global $current_user;
		
		if (!$this->bsk_pdf_manager_current_user_can()){
			wp_die( __('You do not have sufficient permissions to access this page.') );
		}
		
	
		echo '<div class="wrap">
				<div id="icon-edit" class="icon32"><br/></div>
				<h2>BSK PDF Add by FTP</h2>';
		echo '	<form id="bsk-pdf-manager-add-by-ftp-form-id" method="post" enctype="multipart/form-data">';
		echo '	<input type="hidden" name="page" value="'.self::$_bsk_pdfm_pro_pages['add_by_ftp'].'" />';
		
		self::$_bsk_pdfm_OBJ_ftp->bsk_pdf_manager_pdfs_add_by_ftp();
		
		echo '	</form>';
		
		echo '</div>';
	}
	
	function bsk_pdf_manager_license_n_update(){
		$action_url = admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['base'] );
		$license = get_option( self::$_plugin_license, NULL );
		$license_status = get_option( self::$_plugin_license_stauts, NULL );
		$license_actived = get_option( self::$_plugin_license_actived, NULL );
        $license_actived_manually = get_option( self::$_plugin_license_activated_manually, NULL );
            
		$read_only_str = ''; 
		if( trim($license) != "" && $license_status == 'VALID' ) {
			$read_only_str = 'readonly';
		}
		?>
		<form action="<?php echo $action_url; ?>" method="POST" id="bsk_pdf_manager_pro_license_form_ID">
        <h2>Plugin License Activation</h2>
        <p style="margin-top:40px;">In the field below please enter your license key to activate this plugin</p>
        <p style="margin-top:40px;">
            <input id="bskpmp_license_key_id" name="bskpmp_license" type="text" value="<?php echo $license; ?>" size="50" <?php echo $read_only_str; ?> />
            <?php
            if( $license_actived_manually == NULL ){
                if( $license_status == 'VALID' && $license_actived == 'ACTIVED' ) {
                    echo '<span style="color:green;">Active</span>';
                    echo '<input type="submit" class="button-secondary" name="bskpmp_license_deactivate" value="Deactivate License" style="margin-left:20px;" />';
                }else{
                    echo '<input type="submit" class="button-secondary" name="bskpmp_license_activate" value="Activate License" style="margin-left:20px;" />';
                }
            }
            wp_nonce_field( 'bsk_pdf_manager_license_nonce' );
            ?>	
        </p>
        <?php
        $activation_return = get_option( self::$_plugin_license_activation_return, NULL );
        if( $license_status != 'VALID' && $license_actived != 'ACTIVED' && 
            $activation_return && is_array($activation_return) && isset($activation_return['success']) && !$activation_return['success']) {
            echo '<p class="bsk-pdfm-error">'.$activation_return['error'].'</p>'; 
        } 
        ?>
        </form>
        <!--always show update center-->
        <h2 style="margin-top:40px;">Plugin Update Centre</h2>
        <?php
        if( self::$_bsk_pdfm_OBJ_update_helper ){
            self::$_bsk_pdfm_OBJ_update_helper->bsk_pdfm_plugin_update_center();
            if( $license_status == 'EXPIRED' ){
                self::$_bsk_pdfm_OBJ_update_helper->bsk_pdfm_update_center_show_expired( $license );
            }else if( $license_status == 'DISABLED' ){
                self::$_bsk_pdfm_OBJ_update_helper->bsk_pdfm_update_center_show_disabled();
            }else if( $license_status != 'VALID' ){
                self::$_bsk_pdfm_OBJ_update_helper->bsk_pdfm_update_center_show_purchase( $license_status );
            }
        }
	}//end of function
		
	function bsk_pdf_manager_activate_license() {
		if( !isset( $_POST['bskpmp_license_activate'] ) ) {
			return;
		}

		if( ! wp_verify_nonce( $_POST['_wpnonce'], 'bsk_pdf_manager_license_nonce' ) ) {
     		die( 'Security check' ); 
		}

		$license = trim( $_POST['bskpmp_license'] );
			
		// data to send in our API request
		$api_params = array( 
			'bskddaction'=> 'activate_license', 
			'license' 	=> $license, 
			'product_id' => BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_product_id,
			'site' => site_url()
		);
		
		update_option( self::$_plugin_license, $license );
		$response = wp_remote_get( add_query_arg( $api_params, BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_home_url ), 
                                                   array( 'timeout' => 60, 'sslverify' => false ) 
                                                );
		if( is_wp_error( $response ) ){
            update_option( self::$_plugin_license_activation_return, array( 'success' => false, 'error' => $response->get_error_message() ) );
			return false;
		}
		// decode the license data
		$license_data = json_decode( wp_remote_retrieve_body( $response ) );
		if( $license_data->license_status == 'VALID' ){
			update_option( self::$_plugin_license_actived, 'ACTIVED' );
            delete_option( self::$_plugin_license_activation_return );
		}else{
            delete_option( self::$_plugin_license_actived );
            update_option( self::$_plugin_license_activation_return, 
                                   array( 'success' => false, 'error' => 'License Status: '.$license_data->license_status ) 
                                );
        }
        update_option( self::$_plugin_license_stauts, $license_data->license_status );
		
		wp_redirect( admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['base'] ) );
	}

	function bsk_pdf_manager_deactivate_license() {
		if( !isset( $_POST['bskpmp_license_deactivate'] ) ) {
			return;
		}
		if( ! wp_verify_nonce( $_POST['_wpnonce'], 'bsk_pdf_manager_license_nonce' ) ) {
     		die( 'Security check' ); 
		}

		$license = trim( $_POST['bskpmp_license'] );
		
		// data to send in our API request
		$api_params = array( 
			'bskddaction'=> 'deactivate_license', 
			'license' 	=> $license, 
			'product_id' => BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_product_id,
			'site' => site_url()
		);
		
		$response = wp_remote_get( add_query_arg( $api_params, BSKPDFMPro_Dashboard_Update_Helper::$_bsk_pdfm_plugin_home_url ), 
                                                   array( 'timeout' => 15, 'sslverify' => false ) );
		
		delete_option( self::$_plugin_license );
        delete_option( self::$_plugin_license_actived );
        update_option( self::$_plugin_license_stauts, 'NONE EXISTS' );
		
		wp_redirect( admin_url( 'admin.php?page='.self::$_bsk_pdfm_pro_pages['base'] ) );
	}
    
    function bsk_pdf_manager_pro_upgrade_done_notice_fun(){
        if( ! isset( $_GET[ 'upgrade' ] ) || 
            $_GET[ 'upgrade' ] != 'yes' ){
            return;
        } 
        ?>
        <div class="notice notice-success is-dismissible">
            <p>Congratulations!</p>
            <p>You have upgraded to Pro version successfully, the free version has been deactivated. To avoid confusion we suggest you delete free version instantly.</p>
            <p><a href="<?php echo admin_url( 'plugins.php?s=BSK%20PDF%20Manager&plugin_status=all' ); ?>">Go to delete free version</a></p>
        </div>
        <?php
    }
}
