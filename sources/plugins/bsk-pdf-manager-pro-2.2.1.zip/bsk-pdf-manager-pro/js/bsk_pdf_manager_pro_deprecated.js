jQuery(document).ready( function($) {
	$(".bsk-pdf-manager-pdfs-select").change(function(){
		var target = $(this).attr("attr_target");
		var url = $(this).val();
		
		target = target == '_blank' ? target : '_self';
		if( url ){
			window.open( url, target);
		}
	});
	
	if( $(".bsk-pdfm-selector-pdfs-dropdown").length > 0 ){
		$(".bsk-pdfm-selector-pdfs-dropdown").on("change", function(){
			var target = $(this).attr("attr_target");
			var url = $(this).val();
			
			target = target == '_blank' ? target : '_self';
			if( url ){
				window.open( url, target);
			}
		});
	}
	
	/*
	 * Selector shortcode
	*/
	$(".bsk-pdfm-list-selector-menu-select").change(function(){
		var cat_id = $(this).val();
		var id = $(this).attr( "id" );
		var id_affix = id.replace( 'bsk_pdfm_list_selector_menu_select_', '' );
		var ajax_loader_id = 'bsk_pdfm_list_selector_ajax_loader_span_' + id_affix;
		var list_container_id = 'bsk_pdfm_list_selector_pdfs_container_' + id_affix;
        var year_month_filter_selector_id = 'bsk_pdfm_list_selector_additional_filter_dropdown_' + id_affix;
		
		var order_by_val = $("#bsk_pdfm_selector_order_by_" + id_affix).val();
		var cat_order_val = $("#bsk_pdfm_selector_cat_order_" + id_affix).val();
		var out_as_dropdown_val = $("#bsk_pdfm_selector_as_dropdown_" + id_affix).val();
		var dropdown_selected_option_val = $("#bsk_pdfm_selector_dropdown_selected_option_" + id_affix).val();
		var category_top_val = $("#bsk_pdfm_selector_category_top_" + id_affix).val();
		var show_ordered_list_val = $("#bsk_pdfm_selector_show_ordered_list_" + id_affix).val();
		var show_thumbnail_val = $("#bsk_pdfm_selector_show_thumbnail_" + id_affix).val();
		var show_thumbnail_size_val = $("#bsk_pdfm_selector_thumbnail_size_" + id_affix).val();
		var thumbnail_with_title_val = $("#bsk_pdfm_selector_thumbnail_with_title_" + id_affix).val();
		var open_target_val = $("#bsk_pdfm_selector_open_target_" + id_affix).val();
		var nofollowtag_val = $("#bsk_pdfm_selector_nofollow_tag_" + id_affix).val();
		var show_date_in_title_val = $("#bsk_pdfm_selector_show_date_in_title_" + id_affix).val();
		var date_format_val = $("#bsk_pdfm_selector_date_format_" + id_affix).val();
		var date_before_title_val = $("#bsk_pdfm_selector_date_before_title_" + id_affix).val();
		var columns_val = $("#bsk_pdfm_selector_columns_" + id_affix).val(); 
		var multicolumn_val = $("#bsk_pdfm_selector_multicolumn_" + id_affix).val();
		var show_empty_message_val = $("#bsk_pdfm_selector_show_empty_message_" + id_affix).val();
		var additional_filter_val = $("#bsk_pdfm_selector_additional_filter_" + id_affix).val();
        
		if( cat_id == 0 ){
			$("#" + list_container_id).slideUp( "slow", function(){
				$("#" + list_container_id).html( "" );
				$("#" + list_container_id).slideDown();
			});
			
			return false;
		}
		
		$("#" + ajax_loader_id).css( "display", "inline-block" );

		//ajax load pdfs data
		var data = { 
					 action: 'selector_get_assoicated_pdfs', 
					 category_id: cat_id,
					 order_by: order_by_val,
					 cat_order: cat_order_val,
					 out_dropdown: out_as_dropdown_val,
					 dropdown_selected: dropdown_selected_option_val,
					 category_top: category_top_val,
					 show_ordered_list: show_ordered_list_val,
					 show_thumbnail: show_thumbnail_val,
					 thumbnail_size: show_thumbnail_size_val,
					 thumbnail_with_title: thumbnail_with_title_val,
					 open_target: open_target_val,
					 nofollowtag: nofollowtag_val,
					 show_date: show_date_in_title_val,
					 date_format: date_format_val,
					 datebeforetitle: date_before_title_val,
					 columns: columns_val,
					 multicolumns: multicolumn_val,
					 show_empty_message: show_empty_message_val,
                     additional_filter: additional_filter_val
				   };
		$.post( bsk_pdf_pro.ajaxurl, data, function(response) {
			var return_data = $.parseJSON( response );
			$("#" + ajax_loader_id).css( "display", "none" );
			$("#" + list_container_id).slideUp( "slow", function(){
				$("#" + list_container_id).html( "" );
				$("#" + list_container_id).html( return_data.list );
                
                if( $("#" + year_month_filter_selector_id).length > 0 ){
                    $("#" + year_month_filter_selector_id).html( return_data.filter_option );
                }
                
				$("#" + list_container_id).slideDown();
			});
		});
	});
	
    
    
    /*
      * Category
      */
	//category password
	$(".bsk-pdf-category-password-verify").on("click", function(){
		var category_id = $(this).attr( "rel" );
		var password = $('#bsk_pdf_category_password_of_cat_' + category_id).val();
		if( password == "" ){
			$('#bsk_pdf_category_password_of_cat_' + category_id).focus();
			return false;
		}
		var rand_val = $(this).attr( "randval" );
		if( rand_val == "" ){
			alert( 'Invalid operation - rand val error' );
			return false;
		}
		
		//get all hidden parameters
		var show_cat_title_val = $("#bsk_pdfm_cat_password_protect_show_cat_title_" + rand_val).val();
		var show_empty_msg_val = $("#bsk_pdfm_cat_password_protect_show_empty_msg_" + rand_val).val();
		var order_by_val = $('#bsk_pdfm_cat_password_protect_order_by_' + rand_val).val();
		var order_val = $('#bsk_pdfm_cat_password_protect_order_' + rand_val).val();
		var output_as_dropdown_val = $('#bsk_pdfm_cat_password_protect_output_as_dropdown_' + rand_val).val();
		var selected_option_text_val = $('#bsk_pdfm_cat_password_protect_dropdown_selected_option_' + rand_val).val();
		var category_top_val = $('#bsk_pdfm_cat_password_protect_category_top_' + rand_val).val();
		var show_as_ordered_list_val = $('#bsk_pdfm_cat_password_protect_show_ordered_list_' + rand_val).val();
		var show_thumbnail_val = $('#bsk_pdfm_cat_password_protect_show_thumbnail_' + rand_val).val();
		var thumbnail_size_val = $('#bsk_pdfm_cat_password_protect_thumbnail_size_' + rand_val).val();
		var show_PDF_title_with_featured_image_val = $('#bsk_pdfm_cat_password_protect_thumbnail_with_title_' + rand_val).val();
		var open_target_val = $('#bsk_pdfm_cat_password_protect_open_target_' + rand_val).val();
		var nofollow_tag_val = $('#bsk_pdfm_cat_password_protect_nofollow_tag_' + rand_val).val();
		var show_date_in_title_val = $('#bsk_pdfm_cat_password_protect_show_date_in_title_' + rand_val).val();
		var date_format_val = $('#bsk_pdfm_cat_password_protect_date_format_' + rand_val).val();
		var date_before_title_val = $('#bsk_pdfm_cat_password_protect_date_before_title_' + rand_val).val();
		var columns_val = $('#bsk_pdfm_cat_password_protect_columns_' + rand_val).val();
		var enable_multi_column_layout_val = $('#bsk_pdfm_cat_password_protect_multicolumn_' + rand_val).val();
		var multi_column_pdf_title_pos_val = $('#bsk_pdfm_cat_password_protect_multicolumn_title_pos_' + rand_val).val();
		var custom_link_text_val = $('#bsk_pdfm_cat_password_protect_custom_link_text_' + rand_val).val();
		
		//ajax load data
		$("#bks_pdf_category_category_password_verify_anchor_of_cat_" + category_id).css( "display", "none" );
		$("#bks_pdf_category_category_password_verify_ajax_loader_of_cat_" + category_id).css( "display", "inline-block" );
		var data = { 
					 action: 'verify_category_password',
					 cat_id: category_id,
					 password_val: password,
					 show_cat_title: show_cat_title_val,
					 show_empty_message: show_empty_msg_val,
					 order_by: order_by_val,
					 order: order_val,
					 output_as_dropdown: output_as_dropdown_val,
					 selected_option_text: selected_option_text_val,
					 category_top: category_top_val,
					 show_as_ordered_list: show_as_ordered_list_val,
					 show_thumbnail: show_thumbnail_val,
					 thumbnail_size: thumbnail_size_val,
					 show_PDF_title_with_featured_image: show_PDF_title_with_featured_image_val,
					 open_target: open_target_val,
					 nofollow_tag: nofollow_tag_val,
					 show_date_in_title: show_date_in_title_val,
					 date_format: date_format_val,
					 date_before_title: date_before_title_val,
					 columns: columns_val,
					 enable_multi_column_layout: enable_multi_column_layout_val,
					 multi_column_title_position: multi_column_pdf_title_pos_val,
					 custom_link_text: custom_link_text_val
				   }
		$.post( bsk_pdf_pro.ajaxurl, data, function(response) {
			var return_data = response;
			$("#bks_pdf_category_category_password_verify_ajax_loader_of_cat_" + category_id).css( "display", "none" );
			if( response.indexOf( 'ERROR' ) != -1 ){
				$("#bks_pdf_category_category_password_verify_error_message_cat_" + category_id).css( "display", "inline-block" );
				$("#bks_pdf_category_category_password_verify_error_message_cat_" + category_id).html( response );
				return false;
			}

			$("#bsk_pdf_category_content_container_ID_" + category_id).html( response );
		});
	});
    
}); //end of jQuery(document).ready( function($) {
