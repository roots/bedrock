jQuery(document).ready( function($) {
    
    /*
      * PDFs Dropdown
      */
    $(".bsk-pdfm-output-container").on("change", ".bsk-pdfm-pdfs-dropdown", function(){
        var target = $(this).data("target");
		var url = $(this).val();
        
        var output_container = $(this).parents(".bsk-pdfm-output-container");
        if( url && output_container.find(".bsk-pdfm-statistics-ajax-nonce").length ){
            var ajax_nonce = output_container.find(".bsk-pdfm-statistics-ajax-nonce").val();
            var pdf_id = $(this).find(":selected").attr("id");
            if( pdf_id == "" ){
                //console.log( 'Invalid PDF id' );
                return;
            }
            var pdf_id_array = pdf_id.split('-');
            var pdf_id_int = parseInt( pdf_id_array[pdf_id_array.length - 1] );
            if( pdf_id_int < 1 ){
                //console.log( 'Invalid PDF id' );
                return;
            }
            var action_val = 'pdfs_statistics_update_download_count';
            var data = { action: action_val, id: pdf_id_int, nonce: ajax_nonce };

            $.post( bsk_pdf_pro.ajaxurl, data, function(response) {
                //do nothing
            });
        }

        target = target == '_blank' ? '_blank' : '_self';
		if( url ){
			window.open( url, target);
		}
    });
    
     /*
      * Search bar
      */
    $(".bsk-pdfm-output-container").on("keypress", ".bsk-pdfm-search-keywords", function( e ){
        if( e.which == 13 ) {
            $(this).parent().find(".bsk-pdfm-search-anchor").click();
        }
    });
    
     /*
      * Category password
      */
    //can only be numbers & letters
    $(".bsk-pdfm-output-container").on("keyup", ".bsk-pdfm-category-password", function( e ){
        //only number & letters
        this.value = this.value.replace(/[^0-9a-zA-Z]/g, '');
    });
    
    $(".bsk-pdfm-output-container").on("keypress", ".bsk-pdfm-category-password", function( e ){
        if( e.which == 13 ) {
            $(this).parent().find(".bsk-pdfm-category-password-verify-anchor").click();
        }
    });
    
    /*
     * PDFs ajax query
     * Pagination, Search
     * Category Password
     */
    $(".bsk-pdfm-output-container").on("click", ".bsk-pdfm-pagination a, .bsk-pdfm-search-input button, .bsk-pdfm-search-results a, .bsk-pdfm-category-password-verify-anchor", function(){
        
        var output_container = $(this).parents(".bsk-pdfm-output-container");
        var shortcode_type = '';
        var output = '';
        if( output_container.hasClass("shortcode-pdfs") ){
            shortcode_type = 'pdfs';
        }else if( output_container.hasClass("shortcode-category") ){
            shortcode_type = 'category';
        }else if( output_container.hasClass("shortcode-selector") ){
            shortcode_type = 'selector';
        }else{
            return;
        }

        if( output_container.hasClass( 'layout-ul' ) ){
            output =  'ul';
        }else if( output_container.hasClass( 'layout-ol' ) ){
            output = 'ol';
        }else if( output_container.hasClass( 'layout-columns' ) ){
            output = 'columns';
        }else if( output_container.hasClass( 'layout-dropdown' ) ){
            output = 'dropdown';
        }else{
            return;
        }

        //clear error message
        output_container.find(".bsk-pdfm-error-message").remove();
        
        /*
          for search bar 
          */
        var keywords_val = '';
        var year_of_val = '';
        var category_id_val = '';
        if( $(this).hasClass("bsk-pdfm-search-anchor") || $(this).hasClass("bsk-pdfm-search-clear-anchor") ){
            var search_input_obj = $(this).parents(".bsk-pdfm-search-bar").find(".bsk-pdfm-search-input");
            
            if( $(this).hasClass("bsk-pdfm-search-clear-anchor") ){
                search_input_obj.find(".bsk-pdfm-search-keywords").val( "" );
                search_input_obj.find(".bsk-pdfm-year-dropdown").val( "" );
                search_input_obj.find(".bsk-pdfm-category-dropdown").val( "" );
            }
            keywords_val = search_input_obj.find(".bsk-pdfm-search-keywords").val();
            keywords_val = $.trim( keywords_val );
            search_input_obj.find(".bsk-pdfm-search-keywords").val( keywords_val ); //the case for blank space entered
            if( search_input_obj.find(".bsk-pdfm-year-dropdown").length ){
                year_of_val = search_input_obj.find(".bsk-pdfm-year-dropdown").val();
            }
            if( search_input_obj.find(".bsk-pdfm-category-dropdown").length ){
                category_id_val = search_input_obj.find(".bsk-pdfm-category-dropdown").val();
            }

            var search_reulsts_label_obj = $(this).parents(".bsk-pdfm-search-bar").find(".bsk-pdfm-search-results");
            search_reulsts_label_obj.css("display", "block");
            search_reulsts_label_obj.find(".bsk-pdfm-searchbar-ajax-loader").css( "display", "inline-block" );
            search_reulsts_label_obj.find(".bsk-pdfm-search-results-desc").css( "display", "none" );
        }
        
        /* 
          * for pagination
          */
        var page_to_show = 1;
        if( $(this).hasClass( "bsk-pdfm-pagination-anchor" ) ){ //pagination anchor
            page_to_show = $(this).data("page");
            if( $(this).parent().hasClass("active") ){
                //click on active pagination anchor
                return;
            }
            
            //under search mode
            if( output_container.find(".bsk-pdfm-search-results-desc").length ){
                var search_input_obj = output_container.find(".bsk-pdfm-search-input");
                keywords_val = search_input_obj.find(".bsk-pdfm-search-keywords").val();
                keywords_val = $.trim( keywords_val );
                year_of_val = search_input_obj.find(".bsk-pdfm-year-dropdown").val();
                category_id_val = search_input_obj.find(".bsk-pdfm-category-dropdown").val();
            }
            
            output_container.find(".bsk-pdfm-pagination-ajax-loader").css( "display", "inline-block" );
        }
        
         /* 
          * for verify password
          */
        if( $(this).hasClass( "bsk-pdfm-category-password-verify-anchor" ) ){ //verify password anchor
            var password = $(this).parent().find(".bsk-pdfm-category-password").val();
            password = $.trim( password );
            if( password == "" ){
                $(this).parent().find(".bsk-pdfm-category-password").val( "" );
                $(this).parent().find(".bsk-pdfm-category-password").focus();
                return;
            }
            var category_id = $(this).parents(".bsk-pdfm-category-password-form").data( "cat-id" );
            var exist_password = output_container.find(".category-password-hidden-feild").val();
            var exist_password_array = new Array();
            var password_updated = false;
            if( exist_password ){
                exist_password_array = exist_password.split(',');
                for( var i_password = 0; i_password < exist_password_array.length; i_password++){
                    var category_n_password = exist_password_array[i_password];
                    if( category_n_password.indexOf(category_id+':') != -1 ){
                        exist_password_array[i_password] = category_id + ':' + password;
                        password_updated = true;
                    }
                }
            }
            if( password_updated == false ){
                exist_password_array.push( category_id + ':' + password );
            }

            var category_password_str = exist_password_array.join(',');
            output_container.find(".category-password-hidden-feild").val( category_password_str );
            $(this).parent().find(".bsk-pdfm-category-password-verify-ajax-loader").css("display", "inline-block")
            
            //has pagination
            if( output_container.find(".bsk-pdfm-pagination").length ){
                var pagination_form = output_container.find(".bsk-pdfm-pagination");
                var active_anchor = pagination_form.find("li.active");
                page_to_show = active_anchor.find("a").data("page");
            }
            
            //under search mode
            if( output_container.find(".bsk-pdfm-search-results-desc").length ){ 
                var search_input_obj = output_container.find(".bsk-pdfm-search-input");
                keywords_val = search_input_obj.find(".bsk-pdfm-search-keywords").val();
                keywords_val = $.trim( keywords_val );
                year_of_val = search_input_obj.find(".bsk-pdfm-year-dropdown").val();
                category_id_val = search_input_obj.find(".bsk-pdfm-category-dropdown").val();
            }
        }

        var ajax_nonce = output_container.find(".bsk-pdfm-" + shortcode_type + "-ajax-nonce").val();
        var action_val = "pdfs_get_" + shortcode_type + "_" + output;
        var data = { action: action_val, layout: output, nonce: ajax_nonce };
        
        //organise ajax parameters
        output_container.find(".bsk-pdfm-shortcode-attr").each(function(index, value ){
            var attr_name = $(this).data("attr_name");
            if( attr_name == 'year_of' && year_of_val ){
                data[attr_name] = year_of_val;
            }else if( attr_name == 'id' && category_id_val ){
                data[attr_name] = category_id_val;
            }else{
                data[attr_name] = $(this).val();
            }
        });
        data['paged'] = page_to_show;
        data['keywords'] = keywords_val;
        
        /*
          * for category selector
          */
        if( shortcode_type == 'selector' ){
            data['cat_id'] = output_container.find(".bsk-pdfm-category-selector-container").find(".bsk-pdfm-category-dropdown").val();
            //unser selector mode for showing PDF results, hierarchical is always closed
            data['hierarchical'] = 'no';
        }
        
        if( category_id_val ){
            //means under search mode
            //in this mode only search PDFs from the selected category so close hierarchical temporarily
            data['hierarchical'] = 'no';
        }

        $.post( bsk_pdf_pro.ajaxurl, data, function(response) {
            console.log( response );
            var return_data = $.parseJSON( response );
            
            /*
              * for pagination
            */
            if( output_container.find(".bsk-pdfm-pagination").length ){
                var pagination_ajax_loader = output_container.find(".bsk-pdfm-pagination").find(".bsk-pdfm-pagination-ajax-loader");
                if( return_data.error_message ){
                    $( return_data.error_message ).insertAfter( pagination_ajax_loader );
                    return;
                }
            }

            /*
              * for search bar
            */
            if( output_container.find(".bsk-pdfm-search-results").length ){
                var search_reulsts_label_obj = output_container.find(".bsk-pdfm-search-results");
                search_reulsts_label_obj.find(".bsk-pdfm-searchbar-ajax-loader").css("display", "none");
                if( return_data.error_message ){
                    search_reulsts_label_obj.find(".bsk-pdfm-search-clear-anchor").css("display", "none");
                    $( return_data.error_message ).insertAfter( output_container.find(".bsk-pdfm-search-bar") );
                    return;
                }

                if( return_data.results_desc ){
                    search_reulsts_label_obj.find(".bsk-pdfm-search-results-desc").html( return_data.results_desc );
                    search_reulsts_label_obj.find(".bsk-pdfm-search-results-desc").css("display", "inline-block");
                }

                if( keywords_val == "" && year_of_val == "" && category_id_val == "" ){
                    search_reulsts_label_obj.css("display", "none");
                }else{
                    search_reulsts_label_obj.find(".bsk-pdfm-search-clear-anchor").css("display", "inline-block");
                }
                
            }
            
            /*
             * output for pdfs
             */
            if( shortcode_type == 'pdfs' ){
                if( output == 'dropdown' ){
                    output_container.append( return_data.pdfs );
                }else if( output == 'ul' || output == 'ol' ){
                    output_container.find(".bsk-pdfm-pdfs-" + output + "-list").html( "" );
                    output_container.find(".bsk-pdfm-date-filter").remove();
                    output_container.find(".bsk-pdfm-pagination").remove();
                    output_container.find(".bsk-pdfm-pdfs-" + output + "-list").html( return_data.pdfs );
                    $( return_data.date_filter ).insertBefore( output_container.find(".bsk-pdfm-pdfs-" + output + "-list") );
                    $( return_data.pagination ).insertAfter( output_container.find(".bsk-pdfm-pdfs-" + output + "-list") );
                }else if( output == 'columns' ){
                    output_container.find(".bsk-pdfm-pdfs-columns-list").html( "" );
                    output_container.find(".bsk-pdfm-date-filter").remove();
                    output_container.find(".bsk-pdfm-pagination").remove();
                    output_container.find(".bsk-pdfm-pdfs-columns-list").html( return_data.pdfs );
                    $( return_data.date_filter ).insertBefore( output_container.find(".bsk-pdfm-pdfs-columns-list") );
                    $( return_data.pagination ).insertAfter( output_container.find(".bsk-pdfm-pdfs-columns-list") );
                    //call function to re-set column height
                    //if have fetured image then need call function when all images loaded
                    if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                        output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                            $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                        });
                    }else{
                        reset_columns_height_in_eacho_row();
                    }
                }
                
                return;
            }
            
            
            
            /*
             * output for category
             */
            if( shortcode_type == 'category' ){
                var obj_insert_before = output_container.find(".bsk-pdfm-category-shortcode-attr");
                if( output_container.find(".bsk-pdfm-credit-link-container").length > 0 ){
                    obj_insert_before = output_container.find(".bsk-pdfm-credit-link-container");
                }
                
                output_container.find(".bsk-pdfm-category-password-form").remove();
                
                if( output == 'dropdown' ){
                    output_container.find(".bsk-pdfm-category-output").remove();
                    output_container.find(".bsk-pdfm-date-filter").remove();
                    output_container.find(".bsk-pdfm-pdfs-dropdown").remove();
                    
                    $( return_data.pdfs ).insertBefore( obj_insert_before );
                }else if( output == 'ul' || output == 'ol' ){
                    output_container.find(".bsk-pdfm-date-filter").remove();
                    output_container.find(".bsk-pdfm-pagination").remove();
                    if( output_container.hasClass("bsk-pdfm-category-single") ){
                        output_container.find(".bsk-pdfm-pdfs-ul-list").remove();
                        
                        if( output_container.find(".bsk-pdfm-search-bar").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-search-bar") );
                        }else if( output_container.find(".bsk-pdfm-category-description").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-category-description") );
                        }else if( output_container.find(".bsk-pdfm-cat-titile").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-cat-titile") );
                        }else{
                            output_container.find(".bsk-pdfm-category-output").html( return_data.pdfs );
                        }
                    }else{
                        output_container.find(".bsk-pdfm-category-output").remove();
                        $( return_data.pdfs ).insertBefore( obj_insert_before );
                    }
                }else if( output == 'columns' ){
                    output_container.find(".bsk-pdfm-date-filter").remove();
                    output_container.find(".bsk-pdfm-pagination").remove();
                    if( output_container.hasClass("bsk-pdfm-category-single") ){
                        output_container.find(".bsk-pdfm-pdfs-columns-list").remove();
                        
                        if( output_container.find(".bsk-pdfm-search-bar").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-search-bar") );
                        }else if( output_container.find(".bsk-pdfm-category-description").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-category-description") );
                        }else if( output_container.find(".bsk-pdfm-cat-titile").length ){
                            $( return_data.pdfs ).insertAfter( output_container.find(".bsk-pdfm-cat-titile") );
                        }else{
                            output_container.find(".bsk-pdfm-category-output").html( return_data.pdfs );
                        }
                    }else{
                        output_container.find(".bsk-pdfm-category-output").remove();
                        $( return_data.pdfs ).insertBefore( obj_insert_before );
                    }
                    //call function to re-set column height
                    //if have fetured image then need call function when all images loaded
                    if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                        output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                            $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                        });
                    }else{
                        reset_columns_height_in_eacho_row();
                    }
                }
                
                return;
            } //end for output for category
            
            /*
             * output for selector
             */
            if( shortcode_type == 'selector' ){
                
                output_container.find(".bsk-pdfm-date-filter").remove();
                output_container.find(".bsk-pdfm-pagination").remove();
                output_container.find(".bsk-pdfm-category-output").remove();
                
                var obj_insert_before = output_container.find(".bsk-pdfm-selector-shortcode-attr");
                if( output_container.find(".bsk-pdfm-credit-link-container").length > 0 ){
                    obj_insert_before = output_container.find(".bsk-pdfm-credit-link-container");
                }
                if( output == 'dropdown' ){
                    $( return_data.date_filter ).insertBefore( obj_insert_before );
                    $( return_data.pdfs ).insertBefore( obj_insert_before );
                }else if( output == 'ul' || output == 'ol' ){
                    
                   if( output_container.find(".bsk-pdfm-search-bar").length < 1 ){
                        /* for the case requries password */
                        $( return_data.search_bar_str ).insertBefore( obj_insert_before );
                    }
                    $( return_data.date_filter ).insertBefore( obj_insert_before );
                    $( return_data.pdfs ).insertBefore( obj_insert_before );
                    $( return_data.pagination ).insertBefore( obj_insert_before );
                    
                    if( output_container.find(".bsk-pdfm-search-bar").length ){
                        output_container.find(".bsk-pdfm-category-empty-message").remove();
                    }
                }else if( output == 'columns' ){
                    $( return_data.date_filter ).insertBefore( obj_insert_before );
                    $( return_data.pdfs ).insertBefore( obj_insert_before );
                    $( return_data.pagination ).insertBefore( obj_insert_before );
                    
                    if( output_container.find(".bsk-pdfm-search-bar").length ){
                        output_container.find(".bsk-pdfm-category-empty-message").remove();
                    }
                    //call function to re-set column height
                    //if have fetured image then need call function when all images loaded
                    if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                        output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                            $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                        });
                    }else{
                        reset_columns_height_in_eacho_row();
                    }
                }
            } //end for output for category
            
       }); /* //$.post */
        
    });
    
    /*
     * date filter
     */
    function set_validate_date_filter( date_filter_container, current_filter_select ){
        /*
          * refresh selects
          * Year -> Month -> Day / Weekday
          * Month -> Day / Weekday
          * Day -> Weekday
          */
        var availabe_filter_select = new Array( 'year', 'month', 'day', 'weekday' );
        var exist_filter_select = new Array();
        var current_filter_select_str = '';
        var current_filter_select_val = '';
        
        for( var i_filter = 0; i_filter < availabe_filter_select.length; i_filter++ ){
            if( date_filter_container.find(".bsk-pdfm-date-" + availabe_filter_select[i_filter]).length ){
                exist_filter_select.push( availabe_filter_select[i_filter] );
            }
        }

        if( exist_filter_select.length < 2 ){
            //do nothing if only one filter
            return;
        }
        
        if( current_filter_select.hasClass("bsk-pdfm-date-year") ){
            current_filter_select_str = 'year';   
        }else if( current_filter_select.hasClass("bsk-pdfm-date-month") ){
            current_filter_select_str = 'month';   
        }else if( current_filter_select.hasClass("bsk-pdfm-date-day") ){
            current_filter_select_str = 'day';   
        }else if( current_filter_select.hasClass("bsk-pdfm-date-weekday") ){
            current_filter_select_str = 'weekday';   
        }
        current_filter_select_val = current_filter_select.val();
        
        //get all valid dates according to what selected
        var valid_dates = new Array();
        var valid_month_options = new Array();
        var valid_day_options = new Array();
        var valid_weekday_options = new Array();
        $(".bsk-pdfm-valid-date").each(function(){
            switch( current_filter_select_str ){
                case 'year':
                    if( current_filter_select_val && current_filter_select_val != $(this).val().substr(0, 4) ){
                        return;
                    }
                break;
                case 'month':
                    if( current_filter_select_val && current_filter_select_val != $(this).val().substr(5, 2) ){
                        return;
                    }
                    //consider year
                    if( date_filter_container.find(".bsk-pdfm-date-year").length ){
                        var year_val = date_filter_container.find(".bsk-pdfm-date-year").val();
                        if( year_val && year_val != $(this).val().substr(0, 4) ){
                            return;
                        }
                    }
                break;
                case 'day':
                    if( current_filter_select_val && current_filter_select_val != $(this).val().substr(8, 2) ){
                        return;
                    }
                    //consider year, month
                    if( date_filter_container.find(".bsk-pdfm-date-year").length ){
                        var year_val = date_filter_container.find(".bsk-pdfm-date-year").val();
                        if( year_val && year_val != $(this).val().substr(0, 4) ){
                            return;
                        }
                    }
                    if( date_filter_container.find(".bsk-pdfm-date-month").length ){
                        var month_val = date_filter_container.find(".bsk-pdfm-date-month").val();
                        if( month_val && month_val != $(this).val().substr(5, 2) ){
                            return;
                        }
                    }
                break;
                case 'weekday':
                    if( current_filter_select_val && current_filter_select_val != $(this).val().substr(11, 3) ){
                        return;
                    }
                    //consider year, month, day
                    if( date_filter_container.find(".bsk-pdfm-date-year").length ){
                        var year_val = date_filter_container.find(".bsk-pdfm-date-year").val();
                        if( year_val && year_val != $(this).val().substr(0, 4) ){
                            return;
                        }
                    }
                    if( date_filter_container.find(".bsk-pdfm-date-month").length ){
                        var month_val = date_filter_container.find(".bsk-pdfm-date-month").val();
                        if( month_val && month_val != $(this).val().substr(5, 2) ){
                            return;
                        }
                    }
                    if( date_filter_container.find(".bsk-pdfm-date-day").length ){
                        var day_val = date_filter_container.find(".bsk-pdfm-date-day").val();
                        if( day_val && day_val != $(this).val().substr(8, 2) ){
                            return;
                        }
                    }
                break;
            }
            valid_dates.push( $(this).val() );
            valid_month_options.push( $(this).val().substr(5, 2) );
            valid_day_options.push( $(this).val().substr(8, 2) );
            valid_weekday_options.push( $(this).val().substr(11, 3) );
        });
        
        /*
          * Year control Month
          * Month control Day and Weekday
          */
        if( current_filter_select_str == 'year' || current_filter_select_str == 'month' || current_filter_select_str == 'day' ){
            var filter_str_to_ctrl = new Array();
            if( current_filter_select_str == 'year' ){
                filter_str_to_ctrl.push( 'month' );
                filter_str_to_ctrl.push( 'day' );
                filter_str_to_ctrl.push( 'weekday' );
            }else if( current_filter_select_str == 'month' ){
                filter_str_to_ctrl.push( 'day' );
                filter_str_to_ctrl.push( 'weekday' );
            }else if( current_filter_select_str == 'day' ){
                filter_str_to_ctrl.push( 'weekday' );
            }
            for( var i_ctrl = 0; i_ctrl < filter_str_to_ctrl.length; i_ctrl++ ){
                if( date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl]).length < 1 ){
                    continue;
                } 
                date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl]).val("");

                /* show first and then hide */
                date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl] + " > option").show();
                switch( filter_str_to_ctrl[i_ctrl] ){
                    case 'month':
                        date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl] + " > option").each(function(){
                            if( $(this).val() == "" ){
                                return;
                            }
                            if( valid_month_options.indexOf( $(this).val() ) == -1 ){
                                $(this).hide();
                            }
                        });
                    break;
                    case 'day':
                        date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl] + " > option").each(function(){
                            if( $(this).val() == "" ){
                                return;
                            }
                            if( valid_day_options.indexOf( $(this).val() ) == -1 ){
                                $(this).hide();
                            }
                        });
                    break;
                    case 'weekday':
                        date_filter_container.find(".bsk-pdfm-date-" + filter_str_to_ctrl[i_ctrl] + " > option").each(function(){
                            if( $(this).val() == "" ){
                                return;
                            }
                            if( valid_weekday_options.indexOf( $(this).val() ) == -1 ){
                                $(this).hide();
                            }
                        });
                    break;
                }
            } //end for select to ctrl
        }
        //
    }
    
    $(".bsk-pdfm-output-container").on("change", ".bsk-pdfm-date-filter select", function(){
        var output_container = $(this).parents(".bsk-pdfm-output-container");
        var date_weekday_filter_container = $(this).parents(".bsk-pdfm-date-filter");
        var current_changed_select = $(this);

        var shortcode_type = '';
        var output = '';
        if( output_container.hasClass("shortcode-pdfs") ){
            shortcode_type = 'pdfs';
        }else if( output_container.hasClass("shortcode-category") ){
            shortcode_type = 'category';
        }else if( output_container.hasClass("shortcode-selector") ){
            shortcode_type = 'selector';
        }else{
            return;
        }

        if( output_container.hasClass( 'layout-ul' ) ){
            output =  'ul';
        }else if( output_container.hasClass( 'layout-ol' ) ){
            output = 'ol';
        }else if( output_container.hasClass( 'layout-columns' ) ){
            output = 'columns';
        }else if( output_container.hasClass( 'layout-dropdown' ) ){
            output = 'dropdown';
        }else{
            return;
        }
        
        /*
          * refresh selects
          * Year -> Month -> Day / Weekday
          * Month -> Day / Weekday
          * Day -> Weekday
          */
        set_validate_date_filter( date_weekday_filter_container, current_changed_select );
        
        //refresh year month day weekday
        var filter_year = $(this).parent().find(".bsk-pdfm-date-year").val();
        var filter_month = $(this).parent().find(".bsk-pdfm-date-month").val();
        var filter_day = $(this).parent().find(".bsk-pdfm-date-day").val();
        var filter_weekday = $(this).parent().find(".bsk-pdfm-date-weekday").val();

        /*
          * process for pdfs
          */
        if( shortcode_type == 'pdfs' ){
            if( output == 'ul' || output == 'ol' ){
                 var ul_or_ol_parent = output_container.find( ".bsk-pdfm-" + shortcode_type + "-output" );
                 process_date_weekday_filter_for_li( ul_or_ol_parent, output, filter_year, filter_month, filter_day, filter_weekday );
            }else if( output == 'dropdown' ){
                 var dropdown_parent = output_container.find( ".bsk-pdfm-" + shortcode_type + "-output" );
                 process_date_weekday_filter_for_dropdown( dropdown_parent, filter_year, filter_month, filter_day, filter_weekday );
             }else if( output == 'columns' ){
                 var column = $(this).parents(".bsk-pdfm-" + shortcode_type + "-output").data("columns");
                 var column_parent = output_container.find( ".bsk-pdfm-" + shortcode_type + "-output" );
                 process_date_weekday_filter_for_column( column_parent, column, filter_year, filter_month, filter_day, filter_weekday );
             }
        }//end for pdfs
                                       
        /*
          * process for category
          */
        if( shortcode_type == 'category' ){
            if( output == 'ul' || output == 'ol' ){
                output_container.find( ".bsk-pdfm-category-output" ).each(function(){
                    var ul_or_ol_parent = $(this);
                    process_date_weekday_filter_for_li( ul_or_ol_parent, output, filter_year, filter_month, filter_day, filter_weekday );
                });
            }else if( output == 'dropdown' ){
                process_date_weekday_filter_for_dropdown( output_container, filter_year, filter_month, filter_day, filter_weekday );
             }else if( output == 'columns' ){
                output_container.find( ".bsk-pdfm-category-output" ).each(function(){
                    var column_parent = $(this);
                    var column = $(this).data("columns");
                    process_date_weekday_filter_for_column( column_parent, column, filter_year, filter_month, filter_day, filter_weekday );
                });
             }
        }//end for category
        
        /*
          * process for selector
          */
        if( shortcode_type == 'selector' ){
            if( output == 'ul' || output == 'ol' ){
                output_container.find( ".bsk-pdfm-category-output" ).each(function(){
                    var ul_or_ol_parent = $(this);
                    process_date_weekday_filter_for_li( ul_or_ol_parent, output, filter_year, filter_month, filter_day, filter_weekday );
                });
            }else if( output == 'dropdown' ){
                output_container.find( ".bsk-pdfm-category-output" ).each(function(){
                    var dropdown_parent = $(this);
                    process_date_weekday_filter_for_dropdown( dropdown_parent, filter_year, filter_month, filter_day, filter_weekday );
                });
             }else if( output == 'columns' ){
                output_container.find( ".bsk-pdfm-category-output" ).each(function(){
                    var column_parent = $(this);
                    var column = $(this).data("columns");
                    process_date_weekday_filter_for_column( column_parent, column, filter_year, filter_month, filter_day, filter_weekday );
                });
             }
        }//end for selector
        
    }); //end of filter listener function
    
    function process_date_weekday_filter_for_li( parent_div, ul_ol, filter_year, filter_month, filter_day, filter_weekday ){
        parent_div.find(".bsk-pdfm-pdfs-" + ul_ol + "-list > li").each( function( index, value ){
            var date = $(this).data("date" );
            if( date == "" ){
                return;
            }
            var pdf_year = date.substr( 0, 4 );
            var pdf_month = date.substr( 5, 2 );
            var pdf_day = date.substr( 8, 2 );
            var pdf_weekday = date.substr( 11, 3 );

            if( filter_year && pdf_year != filter_year ){
                $(this).css("display", "none");
                return;
            }
            if( filter_month && pdf_month != filter_month ){
                $(this).css("display", "none");
                return;
            }
            if( filter_day && pdf_day != filter_day ){
                $(this).css("display", "none");
                return;
            }
            if( filter_weekday && pdf_weekday != filter_weekday ){
                $(this).css("display", "none");
                return;
            }
            $(this).css("display", "list-item");
        }); //end of process pdfs

        //reset list-item class
        var i_list_item = 1;
        parent_div.find(".bsk-pdfm-pdfs-" + ul_ol + "-list > li").each( function( index, value ){
            $(this).removeClass("list-item-odd");
            $(this).removeClass("list-item-even");
            if( $(this).css("display") == "none" ){
                return;
            }
            if( i_list_item % 2 == 0 ){
                $(this).addClass( "list-item-even" );
            }else{
                $(this).addClass( "list-item-odd" );
            }
            i_list_item++;
        });
    }
    
    function process_date_weekday_filter_for_dropdown( parent_div, filter_year, filter_month, filter_day, filter_weekday ){
        var options = null;
        if( parent_div.find(".bsk-pdfm-pdfs-dropdown optgroup").length ){
            options = parent_div.find(".bsk-pdfm-pdfs-dropdown optgroup > option");
        }else{
            options = parent_div.find(".bsk-pdfm-pdfs-dropdown > option");
        }
        $.each( options, function( index, value ) {
            var date = this.id;
            if( date == "" ){
                return;
            }

            var pdf_year = date.substr( 0, 4 );
            var pdf_month = date.substr( 5, 2 );
            var pdf_day = date.substr( 8, 2 );
            var pdf_weekday = date.substr( 11, 3 );

            if( filter_year && pdf_year != filter_year ){
                $(this).hide();
                return;
            }
            if( filter_month && pdf_month != filter_month ){
                $(this).hide();
                return;
            }
            if( filter_day && pdf_day != filter_day ){
                $(this).hide();
                return;
            }
            if( filter_weekday && pdf_weekday != filter_weekday ){
                $(this).hide();
                return;
            }
            $(this).show();
        });
    }

    function process_date_weekday_filter_for_column( parent_div, column, filter_year, filter_month, filter_day, filter_weekday ){
        parent_div.find(".bsk-pdfm-pdfs-columns-list > div").each(function(){
            var date = $(this).data("date");
            if( date == "" ){
                return;
            }

            $(this).removeClass( "bsk-pdfm-first" );

            var pdf_year = date.substr( 0, 4 );
            var pdf_month = date.substr( 5, 2 );
            var pdf_day = date.substr( 8, 2 );
            var pdf_weekday = date.substr( 11, 3 );
            if( filter_year && pdf_year != filter_year ){
                $(this).css("display", "none");
                return;
            }
            if( filter_month && pdf_month != filter_month ){
                $(this).css("display", "none");
                return;
            }
            if( filter_day && pdf_day != filter_day ){
                $(this).css("display", "none");
                return;
            }
            if( filter_weekday && pdf_weekday != filter_weekday ){
                $(this).css("display", "none");
                return;
            }
            $(this).css("display", "block");
        });

        //refresh column display or not
        function reset_columns_class( column_parent_div ){
            var current_index = 0;
            column_parent_div.find(".bsk-pdfm-pdfs-columns-list > div").each(function(){
                if( $(this).css("display") != "block" ){
                    return;
                }
                if( current_index % column == 0 ){
                    $(this).addClass( "bsk-pdfm-first" );
                }
                current_index++;
            });
        }
        $.when( reset_columns_class( parent_div ) ).done(function( x ) {
            //need reset column height, as column height is by row
            reset_columns_height_in_eacho_row();
        });   
    }
    
    /*
      * Category Selector
      */
    $(".bsk-pdfm-category-selector-container .bsk-pdfm-category-dropdown").change(function(){
        var category_to_query = $(this).val();
        var output_container = null;
        var selector_container = $(this).parent();
        var output;
        
        if( $(this).parents(".bsk-pdfm-output-container").length ){
            output_container = $(this).parents(".bsk-pdfm-output-container");
        }else if( $(this).parents(".bsk-pdfm-widget-output-container").length ){
            output_container = $(this).parents(".bsk-pdfm-widget-output-container");
        }else{
            return;
        }
        
        if( output_container.hasClass( 'layout-ul' ) ){
            output =  'ul';
        }else if( output_container.hasClass( 'layout-ol' ) ){
            output = 'ol';
        }else if( output_container.hasClass( 'layout-columns' ) ){
            output = 'columns';
        }else if( output_container.hasClass( 'layout-dropdown' ) ){
            output = 'dropdown';
        }else{
            return;
        }
        
        output_container.find(".bsk-pdfm-error-message").remove();
        output_container.find(".bsk-pdfm-category-description").remove();
        output_container.find(".bsk-pdfm-date-filter").remove();
        output_container.find(".bsk-pdfm-category-output").remove();
        output_container.find(".bsk-pdfm-pagination").remove();
        output_container.find(".bsk-pdfm-search-bar").remove();
        if( category_to_query < 1 ){
            return;
        }
        
        var ajax_nonce = output_container.find(".bsk-pdfm-selector-ajax-nonce").val();
        var action_val = 'pdfs_get_selector_' + output;
        var data = { action: action_val, layout: output, nonce: ajax_nonce };
        output_container.find(".bsk-pdfm-shortcode-attr").each(function(index, value ){
            var attr_name = $(this).data("attr_name");
            data[attr_name] = $(this).val();
        });
        data['cat_id'] = category_to_query;
        data['paged'] = 1;

        selector_container.find(".bsk-pdfm-category-selector-ajax-loader").css( "display", "inline-block" );
        $.post( bsk_pdf_pro.ajaxurl, data, function(response) {
            selector_container.find(".bsk-pdfm-category-selector-ajax-loader").css( "display", "none" );
            
            var return_data = $.parseJSON( response );
            if( return_data.error_message ){
                if( output_container.find(".bsk-pdfm-credit-link-container").length > 0 ){
                     $( return_data.error_message ).insertBefore( output_container.find(".bsk-pdfm-credit-link-container") );
                }else{
                    $( return_data.error_message ).insertBefore( output_container.find(".bsk-pdfm-selector-shortcode-attr") );
                }
                
                return;
            }
            
            var obj_insert_before = output_container.find(".bsk-pdfm-selector-shortcode-attr");
            if( output_container.find(".bsk-pdfm-credit-link-container").length > 0 ){
                obj_insert_before = output_container.find(".bsk-pdfm-credit-link-container");
            }

            if( output == 'dropdown' ){
                
                $( return_data.cat_desc_str ).insertBefore( obj_insert_before );
                $( return_data.date_filter ).insertBefore( obj_insert_before );
                $( return_data.pdfs ).insertBefore( obj_insert_before );
                
            }else if( output == 'ul' || output == 'ol' ){
                $( return_data.cat_desc_str ).insertBefore( obj_insert_before );
                $( return_data.search_bar_str ).insertBefore( obj_insert_before );
                $( return_data.date_filter ).insertBefore( obj_insert_before );
                $( return_data.pdfs ).insertBefore( obj_insert_before );
                $( return_data.pagination ).insertBefore( obj_insert_before );
            }else if( output == 'columns' ){
                $( return_data.cat_desc_str ).insertBefore( obj_insert_before );
                $( return_data.search_bar_str ).insertBefore( obj_insert_before );
                $( return_data.date_filter ).insertBefore( obj_insert_before );
                $( return_data.pdfs ).insertBefore( obj_insert_before );
                $( return_data.pagination ).insertBefore( obj_insert_before );
                //call function to re-set column height
                //if have fetured image then need call function when all images loaded
                if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                    output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                        $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                    });
                }else{
                    reset_columns_height_in_eacho_row();
                }
            }
            
       }); /* //$.post */
    });
    
    /*
      * Columns - make each row have same height
      */
    if( $(".pdfs-in-columns").length > 0 ){
        output_container = $(".pdfs-in-columns").parents(".bsk-pdfm-output-container");
        if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
            output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
            });
        }else{
            reset_columns_height_in_eacho_row();
        }

        $( window ).resize(function() {
            output_container = $(".pdfs-in-columns").parents(".bsk-pdfm-output-container");
            if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                    $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                });
            }else{
                reset_columns_height_in_eacho_row();
            }
        });
        
        var reset_when_scroll = false;
        $( window ).scroll(function() {
            if( reset_when_scroll == false ){
                output_container = $(".pdfs-in-columns").parents(".bsk-pdfm-output-container");
                if( output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").length > 0 ){
                    output_container.find(".bsk-pdfm-pdfs-columns-list").find(".bsk-pdfm-pdf-link-for-featured-image img").each(function(){
                        $(this).on('load', function() { reset_columns_height_in_eacho_row(); /*console.log("image loaded correctly");*/ });
                    });
                }else{
                    reset_columns_height_in_eacho_row();
                }
                reset_when_scroll = true;
            }
        });
    }
    
    function reset_columns_height_in_eacho_row(){
        $(".pdfs-in-columns").each(function(){
            var columns = $(this).data( "columns" );
            if( columns < 2 ){
                return;
            }
            //get first
            $(this).find(".bsk-pdfm-first").each(function(){
                // reset the height
                $(this).css({'height':'auto'});
                var first_column_height = $(this).height();
                var max_height = first_column_height;
                //get others in the row
                var temp_obj = $(this);
                while( temp_obj.next(".bsk-pdfm-columns-single").length && !temp_obj.next(".bsk-pdfm-columns-single").hasClass("bsk-pdfm-first") ){
                    temp_obj = temp_obj.next(".bsk-pdfm-columns-single");
                    if( temp_obj.css("display") != "block" ){
                        continue;
                    }
                    temp_obj.css({'height':'auto'});
                    //console.log( temp_obj.height() );
                    if( temp_obj.height() > max_height ){
                        max_height = temp_obj.height();
                    }
                }

                //set height to the row
                $(this).height( max_height );
                var temp_obj = $(this);
                while( temp_obj.next(".bsk-pdfm-columns-single").length && !temp_obj.next(".bsk-pdfm-columns-single").hasClass("bsk-pdfm-first") ){
                    temp_obj = temp_obj.next(".bsk-pdfm-columns-single");
                    if( temp_obj.css("display") != "block" ){
                        continue;
                    }
                    temp_obj.height( max_height );
                }
            });
        });
    }
    
    /*
      * Download / Open statistics
      */
    $(".bsk-pdfm-output-container").on("click", ".bsk-pdfm-pdf-link-for-title, .bsk-pdfm-pdf-link-for-featured-image", function( e ){
        /*var href = $(this).attr('href');
        e.preventDefault();
        console.log( href );*/
        var output_container = $(this).parents(".bsk-pdfm-output-container");
        if( output_container.find(".bsk-pdfm-statistics-ajax-nonce").length < 1 ){
            //console.log( 'No statistics enabled' );
            return;
        }
        var ajax_nonce = output_container.find(".bsk-pdfm-statistics-ajax-nonce").val();
        var pdf_id = 0;
        if( $(this).parents( ".bsk-pdfm-list-item" ).length ){
            pdf_id = $(this).parents( ".bsk-pdfm-list-item" ).data( "id" );
        }else if( $(this).parents( ".bsk-pdfm-columns-single" ).length ){
            pdf_id = $(this).parents( ".bsk-pdfm-columns-single" ).data( "id" );
         }
        
        if( pdf_id < 1 ){
            //console.log( 'Invalid PDF id' );
            return;
        }
        var action_val = 'pdfs_statistics_update_download_count';
        var data = { action: action_val, id: pdf_id, nonce: ajax_nonce };

        $.post( bsk_pdf_pro.ajaxurl, data, function(response) {
            //do nothing
        });
    });
});
