<?php if ( ! defined( 'ABSPATH' ) ) exit;


if ( ! class_exists( 'UM_Unsplash_Functions' ) ) {


	/**
	 * Class UM_Unsplash_Functions
	 */
	class UM_Unsplash_Functions {


		/**
		 * UM_Unsplash_Functions constructor.
		 */
		function __construct() {
			add_action( 'um_cover_area_content', array( $this, 'show_photo_attribution' ), 10, 1 );
			
			add_filter( 'um_profile_completeness_get_field_progress', array( $this, 'profile_completeness' ), 20, 3 );
		}

		
		/**
		 * Compatibility with Profile Completeness
		 *
		 * @since 2.0.2 [2019-11-21]
		 * @uses  UM_Profile_Completeness_API::get_progress()
		 * @uses  /plugins/um-profile-completeness/includes/core/um-profile-completeness-init.php
		 *
		 * @param  boolean $custom
		 * @param  string  $key
		 * @param  int     $user_id
		 * @return boolean
		 */
		function profile_completeness( $custom, $key, $user_id ) {
			if ( 'cover_photo' === $key ) {
				$cover_pic = get_user_meta( $user_id, '_um_unsplash_cover', true );
				$custom = boolval( $cover_pic );
			}

			return $custom;
		}


		/**
		 * Template photo_attribution.php
		 */
		function show_photo_attribution() {
			$cover_pic = get_user_meta( um_profile_id(), '_um_unsplash_cover', true );
			$pic_author = get_user_meta( um_profile_id(), '_um_unsplash_photo_author', true );
			$author_url = get_user_meta( um_profile_id() , '_um_unsplash_photo_author_url', true );
			$download_url = get_user_meta( um_profile_id() , '_um_unsplash_photo_download_url', true );
			$download_url .= '?force=true';

			if ( $cover_pic && $pic_author ) {
				$t_args = compact( 'author_url', 'download_url', 'pic_author' );
				UM()->get_template( 'photo_attribution.php', um_unsplash_plugin, $t_args, true );
			}
		}
	}
}
