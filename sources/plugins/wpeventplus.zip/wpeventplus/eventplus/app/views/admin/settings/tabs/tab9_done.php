<div id="tab9_done" class="tab_content">
    <div class="postbox " >
        <div class="inside">
            <div class="padding">
                <h1 class="cong">
                    <?php _e('Congratulations', 'evrplus_language'); ?>
                    !</h1>
                <p class="congtxt">
                    <?php _e('You have setup your company information. Please click the', 'evrplus_language'); ?>
                    <B>
                        <?php _e('UPDATE COMPANY SETTINGS', 'evrplus_language'); ?>
                    </B>
                    <?php _e('button, below the tabs', 'evrplus_language'); ?>
                    .</p>
            </div>
        </div>
    </div>
</div>