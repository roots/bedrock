<div class="padding">

    <h3>
        <span><?php _e('Please select event to manage items', 'evrplus_language'); ?></span>

    </h3>     

</div>

