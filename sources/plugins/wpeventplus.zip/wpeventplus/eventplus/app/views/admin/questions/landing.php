<div class="padding">

    <h3>
        <span><?php _e('Please select event to manage questions', 'evrplus_language'); ?></span>

    </h3>     

</div>

