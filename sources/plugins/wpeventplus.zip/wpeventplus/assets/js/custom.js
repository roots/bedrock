$(document).ready(function(){
    alert('ttsst');
 });