<?php
/**
 * Plugin Name: Ultimate Member Hook
 * Plugin URI: http://uww.io
 * Description: Insert an Ultimate Member Hook.
 * Version: 1.0
 * Author: Youssef Bouaziz
 * Author URI: http://www.uww.io
 */
	add_filter( 'um_myprofile_edit_menu_items', 'my_myprofile_edit_menu_items', 10, 1 );
	function my_myprofile_edit_menu_items( $items ) {    
	unset( $items['myaccount'] );
	unset( $items['logout'] );
	    return $items;
	}