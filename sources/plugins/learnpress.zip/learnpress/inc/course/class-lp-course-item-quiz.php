<?php
class LP_Course_Item_Quiz extends LP_Course_Item {

}