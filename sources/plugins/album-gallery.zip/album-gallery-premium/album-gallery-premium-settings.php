<?Php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//load settings
$album_gallery_settings = unserialize(base64_decode(get_post_meta( $post->ID, 'awl_ag_settings_'.$post->ID, true)));
$album_gallery_id = $post->ID;

//js
wp_enqueue_script('awl-ag-bootstrap-js',  AG_PLUGIN_URL .'js/bootstrap.js', array( 'jquery' ), '', true  );
wp_enqueue_script('awl-ag-go-to-top-js',  AG_PLUGIN_URL .'js/go-to-top.js', array( 'jquery' ), '', true  );
//css
wp_enqueue_style('awl-ag-styles-css', AG_PLUGIN_URL .'css/styles.css' );
wp_enqueue_style('awl-ag-animate-css', AG_PLUGIN_URL .'css/animate.css' );
wp_enqueue_style('awl-ag-bootstrap-css', AG_PLUGIN_URL .'css/bootstrap.css' );
wp_enqueue_style('awl-ag-go-to-top-css', AG_PLUGIN_URL .'css/go-to-top.css' );
wp_enqueue_style('awl-ag-toogle-button-css', AG_PLUGIN_URL .'css/toogle-button.css' );
wp_enqueue_style('awl-ag-font-awesome-min-css', AG_PLUGIN_URL .'css/font-awesome.min.css' );
wp_enqueue_style('awl-ag-icon-7-stroke-css', AG_PLUGIN_URL . 'css/pe-icon-7-stroke.css');
?>
<style>
.thumbnail {
    margin-bottom: 0px !important;
}
.setting-toggle-div {
	background-color: #FFFFFF;
	padding: 10px;
	margin-bottom: 15px;
	border: 2px solid #CCCCCC;
	border-radius: 3px;
}
.gallery-settings, .hover_stack_effect_settings, .hover_overlay_effect_settings {
	padding: 8px 0px 8px 8px !important;
	margin: 10px 10px 5px 0px !important;
}
.gallery-settings label {
	font-size: 13px !important;
	font-weight: bold;
}
.ag_comment_settings {
	font-size: 16px !important;
	font-family:Geneva;
	padding-left: 4px;
	font: initial;
	margin-top: 5px;
	padding-left:14px;
}
.ag-lower-title {
	background-color: #F4F0EF;
    color: #23282d;
    font-family: icon;
    font-size: 20px;
    font-weight: 500;
    margin-left: 10px;
    padding-left: 10px;
}
.selectbox_position {
	margin-left: 18px !important;
	border-width: 1px 1px 1px 6px !important;
	border-color: #32CC24 !important;
	width: 30% !important; 
}
.wp-color-result {
	height: auto;
	margin: 6px 6px 6px 15px;
}
.wp-picker-container input.wp-color-picker[type="text"] {
	width: 80px !important;
	height: 22px !important;
	float: left;
	font-size: 11px !important;
	margin: 8px 0px 6px 0px
}
.iris-border .iris-palette-container {
	bottom: 6px;
}
.wp-core-ui .button, .wp-core-ui .button.button-large, .wp-core-ui .button.button-small, a.preview, input#publish, input#save-post {
	height: auto !important;
	padding: 0 12px !important;
	margin: 6px;
}
</style>
<!-- Return to Top -->
<a href="javascript:" id="return-to-top"><i class="fa fa-chevron-up"></i></a>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('1. Column Settings', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['column_settings'])) $column_settings = $album_gallery_settings['column_settings']; else $column_settings = "true"; ?>
		<input type="radio" class="form-control" id="column_settings1" name="column_settings" value="true" <?php if($column_settings == "true") echo "checked" ; ?>>
			<label for="column_settings1"><?php _e('Same To All', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="column_settings2" name="column_settings" value="false" <?php if($column_settings == "false") echo "checked" ; ?>> 
			<label for="column_settings2"><?php _e('Individual', AGP_TXTDM); ?></label></br></br></br>					
		<p class="ag_comment_settings"><?php _e('Select if you want to individually apply column settings.', AGP_TXTDM); ?></p>
	</p>
</p>

<div class="column_individual_settings">
	<p class="gallery-settings">
		<p class="ag-lower-title"><?php _e('A. Colums On Large Desktops', AGP_TXTDM); ?></p></br>
		<?php if(isset($album_gallery_settings['col_large_desktops'])) $col_large_desktops = $album_gallery_settings['col_large_desktops']; else $col_large_desktops = "col-lg-6"; ?>
		<select id="col_large_desktops" name="col_large_desktops" class="selectbox_position">
			<option value="col-lg-12" <?php if($col_large_desktops == "col-lg-12") echo "selected=selected"; ?>>1 Column</option>
			<option value="col-lg-6" <?php if($col_large_desktops == "col-lg-6") echo "selected=selected"; ?>>2 Column</option>
			<option value="col-lg-4" <?php if($col_large_desktops == "col-lg-4") echo "selected=selected"; ?>>3 Column</option>
			<option value="col-lg-3" <?php if($col_large_desktops == "col-lg-3") echo "selected=selected"; ?>>4 Column</option>
			<option value="col-lg-2" <?php if($col_large_desktops == "col-lg-2") echo "selected=selected"; ?>>6 Column</option>
			<option value="col-lg-1" <?php if($col_large_desktops == "col-lg-1") echo "selected=selected"; ?>>12 Column</option>
		</select></br></br>
	</p>

	<p class="gallery-settings">
		<p class="ag-lower-title"><?php _e('B. Colums On Desktops', AGP_TXTDM); ?></p></br>
		<?php if(isset($album_gallery_settings['col_desktops'])) $col_desktops = $album_gallery_settings['col_desktops']; else $col_desktops = "col-md-4"; ?>
		<select id="col_desktops" name="col_desktops" class="selectbox_position">
			<option value="col-md-12" <?php if($col_desktops == "col-md-12") echo "selected=selected"; ?>>1 Column</option>
			<option value="col-md-6" <?php if($col_desktops == "col-md-6") echo "selected=selected"; ?>>2 Column</option>
			<option value="col-md-4" <?php if($col_desktops == "col-md-4") echo "selected=selected"; ?>>3 Column</option>
			<option value="col-md-3" <?php if($col_desktops == "col-md-3") echo "selected=selected"; ?>>4 Column</option>
			<option value="col-md-2" <?php if($col_desktops == "col-md-2") echo "selected=selected"; ?>>6 Column</option>
			<option value="col-md-1" <?php if($col_desktops == "col-md-1") echo "selected=selected"; ?>>12 Column</option>
		</select></br></br>
	</p>

	<p class="gallery-settings">
		<p class="ag-lower-title"><?php _e('C. Colums On Tablets', AGP_TXTDM); ?></p></br>
		<?php if(isset($album_gallery_settings['col_tablets'])) $col_tablets = $album_gallery_settings['col_tablets']; else $col_tablets = "col-sm-4"; ?>
		<select id="col_tablets" name="col_tablets" class="selectbox_position">
			<option value="col-sm-12" <?php if($col_tablets == "col-sm-12") echo "selected=selected"; ?>>1 Column</option>
			<option value="col-sm-6" <?php if($col_tablets == "col-sm-6") echo "selected=selected"; ?>>2 Column</option>
			<option value="col-sm-4" <?php if($col_tablets == "col-sm-4") echo "selected=selected"; ?>>3 Column</option>
			<option value="col-sm-3" <?php if($col_tablets == "col-sm-3") echo "selected=selected"; ?>>4 Column</option>
			<option value="col-sm-2" <?php if($col_tablets == "col-sm-2") echo "selected=selected"; ?>>6 Column</option>
		</select></br></br>
	</p>

	<p class="gallery-settings">
		<p class="ag-lower-title"><?php _e('D. Colums On Phones', AGP_TXTDM); ?></p></br>
		<?php if(isset($album_gallery_settings['col_phones'])) $col_phones = $album_gallery_settings['col_phones']; else $col_phones = "col-xs-6"; ?>
		<select id="col_phones" name="col_phones" class="selectbox_position">
			<option value="col-xs-12" <?php if($col_phones == "col-xs-12") echo "selected=selected"; ?>>1 Column</option>
			<option value="col-xs-6" <?php if($col_phones == "col-xs-6") echo "selected=selected"; ?>>2 Column</option>
			<option value="col-xs-4" <?php if($col_phones == "col-xs-4") echo "selected=selected"; ?>>3 Column</option>
			<option value="col-xs-3" <?php if($col_phones == "col-xs-3") echo "selected=selected"; ?>>4 Column</option>
		</select></br></br>
	</p>
</div>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('2. Gallery Thumb Size', AGP_TXTDM); ?></p></br>
	<?php if(isset($album_gallery_settings['gal_thumb_size'])) $gal_thumb_size = $album_gallery_settings['gal_thumb_size']; else $gal_thumb_size = "medium"; ?>
	<select id="gal_thumb_size" name="gal_thumb_size" class="selectbox_position">
		<option value="thumbnail" <?php if($gal_thumb_size == "thumbnail") echo "selected=selected"; ?>>Thumbnail – 150 × 150</option>
		<option value="medium" <?php if($gal_thumb_size == "medium") echo "selected=selected"; ?>>Medium – 300 × 169</option>
		<option value="large" <?php if($gal_thumb_size == "large") echo "selected=selected"; ?>>Large – 840 × 473</option>
		<option value="full" <?php if($gal_thumb_size == "full") echo "selected=selected"; ?>>Full Size – 1280 × 720</option>
	</select></br></br>
	<p class="ag_comment_settings"><?php _e('Select gallery thumnails size to display into gallery', AGP_TXTDM); ?></p>
</p>

<p>
	<p class="ms-title"><?php _e('3. Album Title Settings', AGP_TXTDM); ?></p>	
	<p class="switch-field em_size_field">
		<p class="ag-lower-title"><?php _e('A. Album Title', AGP_TXTDM); ?></p>&nbsp;&nbsp;
		<p class="switch-field em_size_field">
			<?php if(isset($album_gallery_settings['album_title'])) $album_title = $album_gallery_settings['album_title']; else $album_title = "yes"; ?>
			<input type="radio" class="form-control" id="album_title_yes" name="album_title" value="yes" <?php if($album_title == "yes") echo "checked" ; ?>>
				<label for="album_title_yes"><?php _e('Yes', AGP_TXTDM); ?></label>
			<input type="radio" class="form-control" id="album_title_no" name="album_title" value="no" <?php if($album_title == "no") echo "checked" ; ?>> 
				<label for="album_title_no"><?php _e('No', AGP_TXTDM); ?></label></br></br></br>
			<p class="ag_comment_settings"><?php _e('Select Yes if you want to show album title.', AGP_TXTDM); ?></p>
		</p>
	</p>
</p>

<p>
	<p class="ag-lower-title"><?php _e('B. Title Color', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['title_color'])) $title_color = $album_gallery_settings['title_color']; else $title_color = "#000000"; ?>
	<input type="text" class="form-control" id="title_color" name="title_color" placeholder="#000000" value="<?php echo $title_color; ?>" >
	<p class="ag_comment_settings"><?php _e('Select the color for album title', AGP_TXTDM); ?>
</p>

<p>
	<p class="ag-lower-title"><?php _e('C. Title Font Size', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['title_font_size'])) $title_font_size = $album_gallery_settings['title_font_size']; else $title_font_size = "20"; ?></br>
	<input type="range" class="range-slider__range" id="title_font_size" name="title_font_size" value="<?php echo $title_font_size; ?>" min="8" max="32" step="1" style="width: 300px !important; margin-left: 20px;">
	<span class="range-slider__value">20px</span></br></br>
	<p class="ag_comment_settings"><?php _e('Select the font size.', AGP_TXTDM); ?></p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('3. Loop', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['loop_lightbox'])) $loop_lightbox = $album_gallery_settings['loop_lightbox']; else $loop_lightbox = "false"; ?>
		<input type="radio" class="form-control" id="loop_lightbox1" name="loop_lightbox" value="true" <?php if($loop_lightbox == "true") echo "checked" ; ?>>
			<label for="loop_lightbox1"><?php _e('Yes', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="loop_lightbox2" name="loop_lightbox" value="false" <?php if($loop_lightbox == "false") echo "checked" ; ?>> 
			<label for="loop_lightbox2"><?php _e('No', AGP_TXTDM); ?></label></br></br></br>					
		<p class="ag_comment_settings"><?php _e('Select if the album gallery is loopable.', AGP_TXTDM); ?></p>
	</p>
</p>

<p class="gallery-settings range-slider">
	<p class="ms-title"><?php _e('4. Hide Bars Delay', AGP_TXTDM); ?></p></br>
	<?php if(isset($album_gallery_settings['hide_bars_delay'])) $hide_bars_delay = $album_gallery_settings['hide_bars_delay']; else $hide_bars_delay = 3000; ?>	
	<input type="range" class="range-slider__range" id="hide_bars_delay" name="hide_bars_delay" value="<?php echo $hide_bars_delay; ?>" min="500" max="10000" step="100" style="width: 300px !important; margin-left: 10px;">
	<span class="range-slider__value">3000</span></br></br></br>
	<p class="ag_comment_settings"><?php _e('Sets the hide bars Delay time in seconds.', AGP_TXTDM); ?></p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('5. Hide Close Button On Mobile', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['hide_close_btn_mobile'])) $hide_close_btn_mobile = $album_gallery_settings['hide_close_btn_mobile']; else $hide_close_btn_mobile = "false"; ?>
		<input type="radio" class="form-control" id="hide_close_btn_mobile1" name="hide_close_btn_mobile" value="true" <?php if($hide_close_btn_mobile == "true") echo "checked" ; ?>>
			<label for="hide_close_btn_mobile1"><?php _e('Hide', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="hide_close_btn_mobile2" name="hide_close_btn_mobile" value="false" <?php if($hide_close_btn_mobile == "false") echo "checked" ; ?>> 
			<label for="hide_close_btn_mobile2"><?php _e('Show', AGP_TXTDM); ?></label></br></br></br>					
		<p class="ag_comment_settings"><?php _e('Select if the Close Button is displayed on mobile.', AGP_TXTDM); ?></p>
	</p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('6. Remove Bars On Mobile', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['remove_bars_mobile'])) $remove_bars_mobile = $album_gallery_settings['remove_bars_mobile']; else $remove_bars_mobile = "true"; ?>
		<input type="radio" class="form-control" id="remove_bars_mobile1" name="remove_bars_mobile" value="true" <?php if($remove_bars_mobile == "true") echo "checked" ; ?>>
			<label for="remove_bars_mobile1"><?php _e('Yes', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="remove_bars_mobile2" name="remove_bars_mobile" value="false" <?php if($remove_bars_mobile == "false") echo "checked" ; ?>> 
			<label for="remove_bars_mobile2"><?php _e('No', AGP_TXTDM); ?></label></br></br></br>					
		<p class="ag_comment_settings"><?php _e('Select if the gallery bars are displayed on mobile.', AGP_TXTDM); ?></p>
	</p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('7. Animation', AGP_TXTDM); ?></p></br>
	<?php if(isset($album_gallery_settings['animations'])) $animations = $album_gallery_settings['animations']; else $animations = "wobble"; ?>
	<select id="animations" name="animations" class="selectbox_position">
		<option value="none" <?php if($animations == "none") echo "selected=selected"; ?>>Wobble</option>
		<option value="wobble" <?php if($animations == "wobble") echo "selected=selected"; ?>>Wobble</option>
		<option value="bounce" <?php if($animations == "bounce") echo "selected=selected"; ?>>Bounce</option>
		<option value="flash" <?php if($animations == "flash") echo "selected=selected"; ?>>Flash</option>
		<option value="jello" <?php if($animations == "jello") echo "selected=selected"; ?>>Jello</option>
		<option value="pulse" <?php if($animations == "pulse") echo "selected=selected"; ?>>Pulse</option>
		<option value="rubberBand" <?php if($animations == "rubberBand") echo "selected=selected"; ?>>Rubber Band</option>
		<option value="shake" <?php if($animations == "shake") echo "selected=selected"; ?>>Shake</option>
		<option value="tada" <?php if($animations == "tada") echo "selected=selected"; ?>>Tada</option>
		<option value="swing" <?php if($animations == "swing") echo "selected=selected"; ?>>Swing</option>
		<option value="rollIn" <?php if($animations == "rollIn") echo "selected=selected"; ?>>Roll In</option>
	</select></br></br>
	<p class="ag_comment_settings"><?php _e('Select to apply animation on gallery.', AGP_TXTDM); ?></p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('8. Hover Effects', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['hover_effects'])) $hover_effects = $album_gallery_settings['hover_effects']; else $hover_effects = "none"; ?>
		<input type="radio" class="form-control" id="hover_effects1" name="hover_effects" value="stacks" <?php if($hover_effects == "stacks") echo "checked" ; ?>>
			<label for="hover_effects1"><?php _e('Stacks', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="hover_effects2" name="hover_effects" value="none" <?php if($hover_effects == "none") echo "checked" ; ?>> 
			<label for="hover_effects2"><?php _e('None', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="hover_effects3" name="hover_effects" value="overlay" <?php if($hover_effects == "overlay") echo "checked" ; ?>> 
			<label for="hover_effects3"><?php _e('Overlay', AGP_TXTDM); ?></label></br></br></br>
		<div class="hover_stack_effect_settings">
			<?php if(isset($album_gallery_settings['hover_stack_effect'])) $hover_stack_effect = $album_gallery_settings['hover_stack_effect']; else $hover_stack_effect = "stack"; ?>
			<select id="hover_stack_effect" name="hover_stack_effect" class="selectbox_position">
				<option value="stack" <?php if($hover_stack_effect == "stack") echo "selected=selected"; ?>>Stack</option>
				<option value="rotated" <?php if($hover_stack_effect == "rotated") echo "selected=selected"; ?>>Stack Rotated</option>
				<option value="twisted" <?php if($hover_stack_effect == "twisted") echo "selected=selected"; ?>>Stack Twisted</option>
				<option value="rotated-left" <?php if($hover_stack_effect == "rotated-left") echo "selected=selected"; ?>>Stack Rotated-Left</option>
				<option value="rotated-right" <?php if($hover_stack_effect == "rotated-right") echo "selected=selected"; ?>>Stack Rotated-Right</option>
			</select></br></br>
		</div>
		<div class="hover_overlay_effect_settings">
			<?php if(isset($album_gallery_settings['hover_overlay_effect'])) $hover_overlay_effect = $album_gallery_settings['hover_overlay_effect']; else $hover_overlay_effect = "second-effect"; ?>
			<select id="hover_overlay_effect" name="hover_overlay_effect" class="selectbox_position">
				<!--<option value="effect" <?php if($hover_overlay_effect == "effect") echo "selected=selected"; ?>>Envlope</option>-->
				<option value="second-effect" <?php if($hover_overlay_effect == "second-effect") echo "selected=selected"; ?>>Box In</option>
				<option value="sixth-effect" <?php if($hover_overlay_effect == "sixth-effect") echo "selected=selected"; ?>>Box Out</option>
				<option value="third-effect" <?php if($hover_overlay_effect == "third-effect") echo "selected=selected"; ?>>Blur</option>
				<option value="fourth-effect" <?php if($hover_overlay_effect == "fourth-effect") echo "selected=selected"; ?>>Curtains</option>				
				<option value="fifth-effect" <?php if($hover_overlay_effect == "fifth-effect") echo "selected=selected"; ?>>Double </option>
				<option value="seventh-effect" <?php if($hover_overlay_effect == "seventh-effect") echo "selected=selected"; ?>>Fade Out</option>
				<option value="ninth-effect" <?php if($hover_overlay_effect == "ninth-effect") echo "selected=selected"; ?>>Shade In</option>
				<option value="eighth-effect" <?php if($hover_overlay_effect == "eighth-effect") echo "selected=selected"; ?>>Shade Out</option>
			</select></br></br>
		</div>
		<p class="ag_comment_settings"><?php _e('Select the hover effect to apply.', AGP_TXTDM); ?></p>
	</p>
</p>

<p>
	<p class="ms-title"><?php _e('9. Titlebar Settings', AGP_TXTDM); ?></p>	
	<p class="ag-lower-title"><?php _e('A. Color', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['titlebar_color'])) $titlebar_color = $album_gallery_settings['titlebar_color']; else $titlebar_color = "#000000"; ?>
	<input type="text"  class="form-control" id="titlebar_color" name="titlebar_color" placeholder="chose form color" value="<?php echo $titlebar_color; ?>" default-color="<?php echo $titlebar_color; ?>"></br>
	<p class="ag_comment_settings"><?php _e('Select the color of the title bar.', AGP_TXTDM); ?></p>
</p>

<p>
	<p class="ag-lower-title"><?php _e('B. Font Color', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['titlebar_font_color'])) $titlebar_font_color = $album_gallery_settings['titlebar_font_color']; else $titlebar_font_color = "#FFFFFF"; ?>
	<input type="text" class="form-control" id="titlebar_font_color" name="titlebar_font_color" placeholder="type color name / code" value="<?php echo $titlebar_font_color; ?>" default-color="<?php echo $titlebar_font_color; ?>">
	<p class="ag_comment_settings"><?php _e('Select the color of the font.', AGP_TXTDM); ?>
</p>

<p>
	<p class="ag-lower-title"><?php _e('C. Font Size', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['titlebar_font_size'])) $titlebar_font_size = $album_gallery_settings['titlebar_font_size']; else $titlebar_font_size = "15"; ?></br>
	<input type="range" class="range-slider__range" id="titlebar_font_size" name="titlebar_font_size" value="<?php echo $titlebar_font_size; ?>" min="8" max="32" step="1" style="width: 300px !important; margin-left: 20px;">
	<span class="range-slider__value">15px</span></br></br>
	<p class="ag_comment_settings"><?php _e('Select the font size.', AGP_TXTDM); ?></p>
</p>

<p>
	<p class="ag-lower-title"><?php _e('D. Icon Color', AGP_TXTDM); ?></p>&nbsp;&nbsp;
	<?php if(isset($album_gallery_settings['titlebar_icon_color'])) $titlebar_icon_color = $album_gallery_settings['titlebar_icon_color']; else $titlebar_icon_color = "icons-red"; ?></br>
	<select id="titlebar_icon_color" name="titlebar_icon_color" class="selectbox_position">
		<option value="red" <?php if($titlebar_icon_color == "red") echo "selected=selected"; ?>>Red</option>
		<option value="white" <?php if($titlebar_icon_color == "white") echo "selected=selected"; ?>>White</option>
		<option value="black" <?php if($titlebar_icon_color == "black") echo "selected=selected"; ?>>Black</option>
		<option value="blue" <?php if($titlebar_icon_color == "blue") echo "selected=selected"; ?>>Blue</option>
		<option value="green" <?php if($titlebar_icon_color == "green") echo "selected=selected"; ?>>Green</option>				
		<option value="purple" <?php if($titlebar_icon_color == "purple") echo "selected=selected"; ?>>Purple</option>
		<option value="orange" <?php if($titlebar_icon_color == "orange") echo "selected=selected"; ?>>Orange </option>
	</select></br></br>
	<p class="ag_comment_settings"><?php _e('Selec the color of the icon of titlebar', AGP_TXTDM); ?></p>
</p>

<p class="gallery-settings range-slider">
	<p class="ms-title"><?php _e('10. Video Max-Width', AGP_TXTDM); ?></p></br>
	<?php if(isset($album_gallery_settings['video_maxwidth'])) $video_maxwidth = $album_gallery_settings['video_maxwidth']; else $video_maxwidth = 1140; ?>	
	<input type="range" class="range-slider__range" id="video_maxwidth" name="video_maxwidth" value="<?php echo $video_maxwidth; ?>" min="0" max="3000" step="10" style="width: 300px !important; margin-left: 10px;">
	<span class="range-slider__value">1140</span></br></br></br>
	<p class="ag_comment_settings"><?php _e('Sets the max-width with for the video.', AGP_TXTDM); ?></p>
</p>

<p class="gallery-settings">
	<p class="ms-title"><?php _e('11. Video AutoPlay', AGP_TXTDM); ?></p></br>
	<p class="switch-field em_size_field">
		<?php if(isset($album_gallery_settings['video_autoplay'])) $video_autoplay = $album_gallery_settings['video_autoplay']; else $video_autoplay = "false"; ?>
		<input type="radio" class="form-control" id="video_autoplay1" name="video_autoplay" value="true" <?php if($video_autoplay == "true") echo "checked" ; ?>>
			<label for="video_autoplay1"><?php _e('Enable', AGP_TXTDM); ?></label>
		<input type="radio" class="form-control" id="video_autoplay2" name="video_autoplay" value="false" <?php if($video_autoplay == "false") echo "checked" ; ?>> 
			<label for="video_autoplay2"><?php _e('Disable', AGP_TXTDM); ?></label></br></br></br>					
		<p class="ag_comment_settings"><?php _e('Select if video autoplay is enabled.', AGP_TXTDM); ?></p>
	</p>
</p>

<p>
	<p class="bg-title"><?php _e('12. Custom CSS', LGP_TXTDM); ?></p></br>
	<?php if(isset($album_gallery_settings['custom_css'])) $custom_css = $album_gallery_settings['custom_css']; else $custom_css = ""; ?>
	<textarea name="custom-css" id="custom-css" style="width: 80%; height: 120px; margin-left: 10px;" placeholder="Type direct CSS code here. Don't use <style>...</style> tag."><?php echo $custom_css; ?></textarea><br>
	<p class="gal_settings"><?php _e('Apply own css and dont use style tag', AGP_TXTDM); ?></p><br>
</p>

<hr>
<?php
	// syntax: wp_nonce_field( 'name_of_my_action', 'name_of_nonce_field' );
	wp_nonce_field( 'ag_save_settings', 'ag_save_nonce' );
?>
<script>
// start pulse on page load
function pulseEff() {
   jQuery('#shortcode').fadeOut(600).fadeIn(600);
};
var Interval;
Interval = setInterval(pulseEff,1500);

// stop pulse
function pulseOff() {
	clearInterval(Interval);
}
// start pulse
function pulseStart() {
	Interval = setInterval(pulseEff,2000);
}
	
//range slider
var rangeSlider = function(){
  var slider = jQuery('.range-slider'),
	  range = jQuery('.range-slider__range'),
	  value = jQuery('.range-slider__value');
	
  slider.each(function(){

	value.each(function(){
	  var value = jQuery(this).prev().attr('value');
	  jQuery(this).html(value);
	});

	range.on('input', function(){
	  jQuery(this).next(value).html(this.value);
	});
  });
};
rangeSlider();
	
//on load 
var hover_effects = jQuery('input[name="hover_effects"]:checked').val();
var column_settings = jQuery('input[name="column_settings"]:checked').val();
if(column_settings == "true"){
	jQuery('.column_individual_settings').hide();
}
if(column_settings == "false"){
	jQuery('.column_individual_settings').show();
}
if(hover_effects == "stacks"){
	jQuery('.hover_stack_effect_settings').show();
	jQuery('.hover_overlay_effect_settings').hide();
}
if(hover_effects == "none"){
	jQuery('.hover_stack_effect_settings').hide();
	jQuery('.hover_overlay_effect_settings').hide();
}
if(hover_effects == "overlay"){
	jQuery('.hover_overlay_effect_settings').show();
	jQuery('.hover_stack_effect_settings').hide();
}
	
//on change
jQuery(document).ready(function() {
	jQuery('input[name="column_settings"]').change(function(){
		var column_settings = jQuery('input[name="column_settings"]:checked').val();
		if(column_settings == "true"){
			jQuery('.column_individual_settings').hide();
		}
		if(column_settings == "false"){
			jQuery('.column_individual_settings').show();
		}
	});
	
	jQuery('input[name="hover_effects"]').change(function(){
		var hover_effects = jQuery('input[name="hover_effects"]:checked').val();
		if(hover_effects == "stacks"){
			jQuery('.hover_stack_effect_settings').show();
			jQuery('.hover_overlay_effect_settings').hide();
		}
		if(hover_effects == "none"){
			jQuery('.hover_stack_effect_settings').hide();
			jQuery('.hover_overlay_effect_settings').hide();
		}
		if(hover_effects == "overlay"){
			jQuery('.hover_overlay_effect_settings').show();
			jQuery('.hover_stack_effect_settings').hide();
		}
	});
});

//color-picker
(function( jQuery ) {
	jQuery(function() {
		// Add Color Picker 
		jQuery('#titlebar_color').wpColorPicker();
		jQuery('#titlebar_font_color').wpColorPicker();
		jQuery('#title_color').wpColorPicker();
	});
})( jQuery );
jQuery(document).ajaxComplete(function() {
	jQuery('#titlebar_color, #titlebar_font_color, #title_color').wpColorPicker();
});	
</script>