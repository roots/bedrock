<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

//js
wp_enqueue_script('jquery');
wp_enqueue_script('awl-jquery-swipebox-js',  AG_PLUGIN_URL .'js/jquery.swipebox.js', array( 'jquery' ), '', true);
wp_enqueue_script('awl-isotope-js', AG_PLUGIN_URL .'js/isotope.pkgd.js', array('jquery'), '' , true);

//css
wp_enqueue_style('awl-swipebox-css', AG_PLUGIN_URL .'css/awl-swipebox.css');
wp_enqueue_style('awl-animate-css', AG_PLUGIN_URL .'css/awl-animate.css');
wp_enqueue_style('awl-hover-stack-style-css', AG_PLUGIN_URL .'css/awl-hover-stack-style.css');
wp_enqueue_style('awl-hover-overlay-effects-css', AG_PLUGIN_URL .'css/awl-hover-overlay-effects.css');
wp_enqueue_style('awl-hover-overlay-effects-style-css', AG_PLUGIN_URL .'css/awl-hover-overlay-effects-style.css');
 
$album_gallery_id = $post_id['id'];
 
$all_albums = array(  'p' => $album_gallery_id, 'post_type' => 'album_gallery', 'orderby' => 'ASC');
$loop = new WP_Query( $all_albums );

while ( $loop->have_posts() ) : $loop->the_post();

	$post_id = get_the_ID();
	$album_gallery_settings = unserialize(base64_decode(get_post_meta( $post_id, 'awl_ag_settings_'.$post_id, true)));
	$album_gallery_column_settings = unserialize(base64_decode(get_option('album_gallery_column_settings')));
	//main settings
	if(isset($album_gallery_settings['column_settings'])) $column_settings = $album_gallery_settings['column_settings']; else $column_settings = "true";
	if(isset($album_gallery_settings['gal_thumb_size'])) $gal_thumb_size = $album_gallery_settings['gal_thumb_size']; else $gal_thumb_size = "medium";
	if(isset($album_gallery_settings['loop_lightbox'])) $loop_lightbox = $album_gallery_settings['loop_lightbox']; else $loop_lightbox = "false";
	if(isset($album_gallery_settings['hide_bars_delay'])) $hide_bars_delay = $album_gallery_settings['hide_bars_delay']; else $hide_bars_delay = 3000;
	if(isset($album_gallery_settings['hide_close_btn_mobile'])) $hide_close_btn_mobile = $album_gallery_settings['hide_close_btn_mobile']; else $hide_close_btn_mobile = "false";
	if(isset($album_gallery_settings['remove_bars_mobile'])) $remove_bars_mobile = $album_gallery_settings['remove_bars_mobile']; else $remove_bars_mobile = "true";
	if(isset($album_gallery_settings['video_maxwidth'])) $video_maxwidth = $album_gallery_settings['video_maxwidth']; else $video_maxwidth = 1144;
	if(isset($album_gallery_settings['video_autoplay'])) $video_autoplay = $album_gallery_settings['video_autoplay']; else $video_autoplay = "false";
	if(isset($album_gallery_settings['animations'])) $animations = $album_gallery_settings['animations']; else $animations = "wobble";
	if(isset($album_gallery_settings['hover_effects'])) $hover_effects = $album_gallery_settings['hover_effects']; else $hover_effects = "none";
	if(isset($album_gallery_settings['hover_stack_effect'])) $hover_stack_effect = $album_gallery_settings['hover_stack_effect']; else $hover_stack_effect = "stack";
	if(isset($album_gallery_settings['hover_overlay_effect'])) $hover_overlay_effect = $album_gallery_settings['hover_overlay_effect']; else $hover_overlay_effect = "second-effect";
	if(isset($album_gallery_settings['titlebar_icon_color'])) $titlebar_icon_color = $album_gallery_settings['titlebar_icon_color']; else $titlebar_icon_color = "icons-red";
	
	//titlebar
	if(isset($album_gallery_settings['titlebar_color'])) $titlebar_color = $album_gallery_settings['titlebar_color']; else $titlebar_color = "true";
	if(isset($album_gallery_settings['titlebar_font_color'])) $titlebar_font_color = $album_gallery_settings['titlebar_font_color']; else $titlebar_font_color = "true";
	if(isset($album_gallery_settings['titlebar_font_size'])) $titlebar_font_size = $album_gallery_settings['titlebar_font_size']; else $titlebar_font_size = "true";
	if(isset($album_gallery_settings['titlebar_icon_color'])) $titlebar_icon_color = $album_gallery_settings['titlebar_icon_color']; else $titlebar_icon_color = "true";
	if(isset($album_gallery_settings['custom_css'])) $custom_css = $album_gallery_settings['custom_css']; else $custom_css = "";
	
	//title
	if(isset($album_gallery_settings['album_title'])) $album_title = $album_gallery_settings['album_title']; else $album_title = "yes";
	if(isset($album_gallery_settings['title_color'])) $title_color = $album_gallery_settings['title_color']; else $title_color = "#000000";
	if(isset($album_gallery_settings['title_font_size'])) $title_font_size = $album_gallery_settings['title_font_size']; else $title_font_size = "20";
	
	
	//columns settings
	 if($column_settings == "false") {
		if(isset($album_gallery_settings['col_large_desktops'])) $col_large_desktops = $album_gallery_settings['col_large_desktops']; else $col_large_desktops = "col-lg-6";
		if(isset($album_gallery_settings['col_desktops'])) $col_desktops = $album_gallery_settings['col_desktops']; else $col_desktops = "col-md-4";
		if(isset($album_gallery_settings['col_tablets'])) $col_tablets = $album_gallery_settings['col_tablets']; else $col_tablets = "col-sm-4";
		if(isset($album_gallery_settings['col_phones'])) $col_phones = $album_gallery_settings['col_phones']; else $col_phones = "col-xs-6";
	} else if($column_settings == "true") {
		if(isset($album_gallery_column_settings['col_large_desktops'])) $col_large_desktops = $album_gallery_column_settings['col_large_desktops']; else $col_large_desktops = "col-lg-4";
		if(isset($album_gallery_column_settings['col_desktops'])) $col_desktops = $album_gallery_column_settings['col_desktops']; else $col_desktops = "col-md-4";
		if(isset($album_gallery_column_settings['col_tablets'])) $col_tablets = $album_gallery_column_settings['col_tablets']; else $col_tablets = "col-sm-4";
		if(isset($album_gallery_column_settings['col_phones'])) $col_phones = $album_gallery_column_settings['col_phones']; else $col_phones = "col-xs-6";
	}
	
	
	?>
	<div id="album_gallery_<?php echo $album_gallery_id; ?>" class="album_gallery_single text-center <?php echo $col_large_desktops; ?> <?php echo $col_desktops; ?> <?php echo $col_tablets; ?> <?php echo $col_phones; ?>">
	<?php if($album_title == "yes") { 
	$ag_title = get_the_title();
	?>
	<div class="album_title_div">
		<p class="album_title"><?php echo $ag_title; ?></p>
	</div>
	<?php } ?>
		<?php
			if(isset($album_gallery_settings['image-slide-ids']) && count($album_gallery_settings['image-slide-ids']) > 0) {
				$count = 0;
				foreach($album_gallery_settings['image-slide-ids'] as $attachment_id) {
					$thumb = wp_get_attachment_image_src($attachment_id, 'thumb', true);
					$thumbnail = wp_get_attachment_image_src($attachment_id, 'thumbnail', true);
					$medium = wp_get_attachment_image_src($attachment_id, 'medium', true);
					$large = wp_get_attachment_image_src($attachment_id, 'large', true);
					$full = wp_get_attachment_image_src($attachment_id, 'full', true);
					$attachment_details = get_post( $attachment_id );
					$title = $attachment_details->post_title;
					$slide_type =  $album_gallery_settings['image-slide-type'][$count];
					$slide_link =  $album_gallery_settings['image-slide-link'][$count];
					
					//set thumbnail size
					if($gal_thumb_size == "thumbnail") { $thumbnail_url = $thumbnail[0]; }
					if($gal_thumb_size == "medium") { $thumbnail_url = $medium[0]; }
					if($gal_thumb_size == "large") { $thumbnail_url = $large[0]; }
					if($gal_thumb_size == "full") { $thumbnail_url = $full[0]; }
					?>
					<div class="swipebox-pos  <?php if($count > 0) { echo "hidden"; }?>">
						<?php if($hover_effects == "none") { ?>
							<!-- None Effect -->
							<a href="<?php if($slide_type == "i") { echo $full[0]; } else if($slide_type == "v") { echo $slide_link; } ?>" class="swipebox-<?php echo $album_gallery_id; ?>" title="<?php echo $title; ?>">
								<img src="<?php echo $thumbnail_url; ?>" class=" animated <?php echo $animations; ?>">
							</a>
						<?php } else if($hover_effects == "stacks") { ?>
							<!-- Stacks Hover Effect -->
							<a href="<?php if($slide_type == "i") { echo $full[0]; } else if($slide_type == "v") { echo $slide_link; } ?>" class="swipebox-<?php echo $album_gallery_id; ?>" title="<?php echo $title; ?>">
								<div class="group">
									<div class="stack <?php if($hover_stack_effect != "stack") { echo $hover_stack_effect; } ?>  animated <?php echo $animations; ?>">
										<img src="<?php echo $thumbnail_url; ?>">
									</div>
								</div>
							</a>
						<?php } else if($hover_effects == "overlay") { ?>
							<!-- Overlay Hover Effect -->
							<a class="swipebox-<?php echo $album_gallery_id; ?>" href="<?php if($slide_type == "i") { echo $full[0]; } else if($slide_type == "v") { echo $slide_link; } ?>" title="<?php echo $title; ?>">
								<div class="view <?php echo $hover_overlay_effect; ?> animated <?php echo $animations; ?>">
									<img src="<?php echo $thumbnail_url; ?>">
									<div class="mask"></div>
								</div>
							</a>
						<?php } ?>
					</div>
					
					<?php
					$count++;
				}// end of attachment foreach
			} else {
				_e('Sorry! No images found in album gallery', AGP_TXTDM);
				echo ": [AGAL id=$post_id]";
			} // end of if else of images available check into album
		?>	
	</div>	
	<?php
	endwhile;
	?>
<style>
.album_title {
	color:<?php echo $title_color; ?> !important;
	font-size:<?php echo $title_font_size; ?>px !important;
	font-weight:700 !important;
}

.swipebox-pos {
	margin : 0 0 5% 0;
}

.view {
	<?php if($col_large_desktops == "col-lg-12") { ?> margin: 0 0 0 36.5%; <?php } 
	 else if($col_large_desktops == "col-lg-6") { ?> margin: 0 0 0 22%; <?php } 
	 else if($col_large_desktops == "col-lg-4") { ?> margin: 0 0 0 6.5%; <?php } 
	 else if($col_large_desktops == "col-lg-3") { ?> margin: 0 0 0 1%; <?php } ?>
	 
	<?php if($col_desktops == "col-md-12") { ?> margin: 0 0 0 33.5%; <?php } 
	 else if($col_desktops == "col-md-6") { ?> margin: 0 0 0 16%; <?php } 
	 else if($col_desktops == "col-md-4") { ?> margin: 0 0 0 0%; <?php } 
	 else if($col_desktops == "col-md-3") { ?> margin: 0 0 0 0%; <?php } ?>
}

.swipebar-top-<?php echo $album_gallery_id; ?>, .swipebar-bottom-<?php echo $album_gallery_id; ?> {
	background: <?php echo $titlebar_color; ?> !important;
	opacity: 0.95;
	text-shadow: 1px 1px 1px #000;
}

.swipebar-top-<?php echo $album_gallery_id; ?> {
	color: <?php echo $titlebar_font_color; ?> !important;
	font-family: Helvetica,Arial,sans-serif;
	font-size: <?php echo $titlebar_font_size; ?>px !important;
	line-height: 43px;
}

.swipebox-icon-prev-<?php echo $album_gallery_id; ?>,
.swipebox-icon-next-<?php echo $album_gallery_id; ?>,
.swipebox-icon-close-<?php echo $album_gallery_id; ?> {
	<?php if($titlebar_icon_color == "red") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-red.png) !important;
	<?php } elseif($titlebar_icon_color == "white") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-white.png) !important;
	<?php } elseif($titlebar_icon_color == "black") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-black.png) !important;
	<?php } elseif($titlebar_icon_color == "blue") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-blue.png) !important;
	<?php } elseif($titlebar_icon_color == "green") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-green.png) !important;
	<?php } elseif($titlebar_icon_color == "purple") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-purple.png) !important;
	<?php } elseif($titlebar_icon_color == "orange") { ?>
		background-image: url(<?php echo AG_PLUGIN_URL ?>/img/icons-orange.png) !important;
	<?php } ?>
}
	
.mask {
	cursor : pointer;
}

<?php echo $custom_css; ?>

</style>
<script type="application/javascript">
//Swipe Box JS Options
jQuery( document ).ready(function() {
	
	jQuery(".album_gallery_single").parent().addClass('album_gallery_main');
	
	jQuery( '.swipebox-<?php echo $album_gallery_id; ?>' ).swipebox( {
		autoplayVideos : <?php echo $video_autoplay; ?>,
		useCSS : true, // false will force the use of jQuery for animations
		useSVG : true, // false to force the use of png for buttons
		initialIndexOnArray : 0, // which image index to init when a array is passed
		hideCloseButtonOnMobile : <?php echo $hide_close_btn_mobile; ?>, // true will hide the close button on mobile devices
		removeBarsOnMobile : <?php echo $remove_bars_mobile; ?>, // false will show top bar on mobile devices
		hideBarsDelay : <?php echo $hide_bars_delay; ?>, // delay before hiding bars on desktop
		videoMaxWidth : <?php echo $video_maxwidth; ?>,
		beforeOpen: function() {}, // called before opening
		afterOpen: null, // called after opening
		afterClose: function() {}, // called after closing
		loopAtEnd: <?php echo $loop_lightbox; ?>, // true will return to the first image after the last image is reached
	});
	
	// isotope effect function
	// Method 1 - Initialize Isotope, then trigger layout after each image loads.
	var $grid = jQuery('.album_gallery_main').isotope({
		// options...
		itemSelector: '.album_gallery_single',
	});
	// layout Isotope after each image loads
	$grid.imagesLoaded().progress( function() {
		$grid.isotope('layout');
	});	
	
});
</script>