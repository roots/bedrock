<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * video Gallery Premium Shortcode
 */
add_shortcode('AGAL', 'awl_album_gallery_shortcode');
function awl_album_gallery_shortcode($post_id) {
	wp_enqueue_style('awl-ms-bootstrap-css', AG_PLUGIN_URL .'css/album-gallery-bootstrap.css');
	ob_start();
	
	$album_gallery_settings = unserialize(base64_decode(get_post_meta( $post_id['id'], 'awl_lg_settings_'.$post_id['id'], true)));
	$album_gallery_id = $post_id['id'];

	if(isset($album_gallery_settings['titlebar_color'])) $titlebar_color = $album_gallery_settings['titlebar_color']; else $titlebar_color = "#000000";
	if(isset($album_gallery_settings['titlebar_font_color'])) $titlebar_font_color = $album_gallery_settings['titlebar_font_color']; else $titlebar_font_color = "#ffffff";
	if(isset($album_gallery_settings['titlebar_font_size'])) $titlebar_font_size = $album_gallery_settings['titlebar_font_size']; else $titlebar_font_size = "15";
	if(isset($album_gallery_settings['titlebar_icon_color'])) $titlebar_icon_color = $album_gallery_settings['titlebar_icon_color']; else $titlebar_icon_color = "red";

	//output code file
	require("output-code.php");
	wp_reset_query();
	return ob_get_clean();
}
?>