<?php
/**
 * WP JSON Media API class.
 *
 * Copied from JSON REST API, with a modification so we don't unset the attachment ID
 * This allows us to overwrite existing Media Library Images
 *
 * @since 1.0.0
 *
 * @package Envira_Lightroom
 * @author  Envira Team
 */
class WP_JSON_Envira_Media extends WP_JSON_Posts {
	/**
	 * Register the media-related routes
	 *
	 * @param array $routes Existing routes
	 * @return array Modified routes
	 */
	public function register_routes( $routes ) {

		$media_routes = array(
			'/envira-media'             => array(
				array( array( $this, 'upload_attachment' ), WP_JSON_Server::CREATABLE ),
			),
			'/envira-media/(?P<id>\d+)/delete_gallery_image' => array(
				array( array( $this, 'delete_gallery_image' ), WP_JSON_Server::CREATABLE ),
			),
			'/envira-media/(?P<id>\d+)/delete_gallery' => array(
				array( array( $this, 'delete_gallery' ), WP_JSON_Server::CREATABLE ),
			),
		);
		return array_merge( $routes, $media_routes );
	}

	/**
	 * Delete an attachment
	 *
	 * @see WP_JSON_Posts::delete_post()
	 */
	public function delete_gallery_image( $id, $force = false ) {

		$id = (int) $id;

		if ( empty( $id ) ) {
			return new WP_Error( 'json_post_invalid_id', __( 'Invalid post ID.' ), array( 'status' => 404 ) );
		}

		$post = get_post( $id, ARRAY_A );

		if ( $post['post_type'] !== 'attachment' ) {
			return new WP_Error( 'json_post_invalid_type', __( 'Invalid post type' ), array( 'status' => 400 ) );
		}

		// Setup contextual vars
		$gallery_id = $post['post_parent'];
		$image_id = $id;

		// Check if the image has a gallery ID
		if ( $gallery_id > 0 ) {
			$gallery_data = get_post_meta( $gallery_id, '_eg_gallery_data', true );
			$in_gallery   = get_post_meta( $gallery_id, '_eg_in_gallery', true );
			$has_gallery  = get_post_meta( $image_id, '_eg_has_gallery', true );

			// Unset the image from the gallery, in_gallery and has_gallery checkers.
			unset( $gallery_data['gallery'][ $image_id ] );

			if ( ( $key = array_search( $image_id, (array) $in_gallery ) ) !== false ) {
				unset( $in_gallery[ $key ] );
			}

			if ( ( $key = array_search( $gallery_id, (array) $has_gallery ) ) !== false ) {
				unset( $has_gallery[ $key ] );
			}

			// Update metadata
			update_post_meta( $gallery_id, '_eg_gallery_data', $gallery_data );
			update_post_meta( $gallery_id, '_eg_in_gallery', $in_gallery );
			update_post_meta( $image_id, '_eg_has_gallery', $has_gallery );

			// Run hook before finishing the reponse.
			do_action( 'envira_gallery_ajax_remove_images', $image_id, $gallery_id );

			// Flush the gallery cache.
			Envira_Gallery_Common::get_instance()->flush_gallery_caches( $gallery_id );
		}

		return parent::delete_post( $id, $force );

	}

	/**
	 * Delete a Gallery Post
	 *
	 * @see WP_JSON_Posts::delete_post()
	 */
	public function delete_gallery( $id, $force = false ) {

		$id = (int) $id;

		if ( empty( $id ) ) {
			return new WP_Error( 'json_post_invalid_id', __( 'Invalid post ID.' ), array( 'status' => 404 ) );
		}

		$post = get_post( $id, ARRAY_A );

		if ( $post['post_type'] !== 'envira' ) {
			return new WP_Error( 'json_post_invalid_type', __( 'Invalid post type' ), array( 'status' => 400 ) );
		}

		// Setup vars
		$gallery_id = $id;
		$gallery_data = get_post_meta( $gallery_id, '_eg_gallery_data', true );

		// Check the gallery has images
		if ( isset( $gallery_data['gallery'] ) && count( $gallery_data['gallery'] ) > 0 ) {
			foreach ( $gallery_data['gallery'] as $image_id => $image ) {
				// Delete the Media Library Image
				parent::delete_post( $image_id, $force );
			}
		}

		// Delete the gallery
		return parent::delete_post( $id, $force );

	}

	/**
	 * Upload a new attachment
	 *
	 * Creating a new attachment is done in two steps: uploading the data, then
	 * setting the post. This is achieved by first creating an attachment, then
	 * editing the post data for it.
	 *
	 * @param array $_files Data from $_FILES
	 * @param array $_headers HTTP headers from the request
	 * @return array|WP_Error Attachment data or error
	 */
	public function upload_attachment( $_files, $_headers, $post_id = 0 ) {

		$post_type = get_post_type_object( 'attachment' );

		if ( $post_id == 0 ) {
			$post_parent_type = get_post_type_object( 'post' );
		} else {
			$post_parent_type = get_post_type_object( get_post_type( $post_id ) );
		}

		// Make sure we have an int or 0
		$post_id = (int) $post_id;

		if ( ! $post_type ) {
			return new WP_Error( 'json_invalid_post_type', __( 'Invalid post type' ), array( 'status' => 400 ) );
		}

		// Permissions check - Note: "upload_files" cap is returned for an attachment by $post_type->cap->create_posts
		if ( ! current_user_can( $post_type->cap->create_posts ) || ! current_user_can( $post_type->cap->edit_posts ) ) {
			return new WP_Error( 'json_cannot_create', __( 'Sorry, you are not allowed to post on this site.' ), array( 'status' => 400 ) );
		}

		// If a user is trying to attach to a post make sure they have permissions. Bail early if post_id is not being passed
		if ( $post_id !== 0 && ! current_user_can( $post_parent_type->cap->edit_post, $post_id ) ) {
			return new WP_Error( 'json_cannot_edit', __( 'Sorry, you are not allowed to edit this post.' ), array( 'status' => 401 ) );
		}

		// Get the file via raw data
		$file = $this->upload_from_data( $_files, $_headers );
		if ( is_wp_error( $file ) ) {
			return $file;
		}

		// Get headers and prepare the image metadata
		$headers    = envira_lightroom_get_all_headers();
		$gallery_id = absint( $headers['X-Envira-Lightroom-Gallery-Id'] );
		$title      = ( isset( $headers['X-Envira-Lightroom-Image-Title'] ) ? $headers['X-Envira-Lightroom-Image-Title'] : '' );
		$caption    = ( isset( $headers['X-Envira-Lightroom-Image-Caption'] ) ? $headers['X-Envira-Lightroom-Image-Caption'] : '' );
		$tags       = ( isset( $headers['X-Envira-Lightroom-Image-Tags'] ) ? $headers['X-Envira-Lightroom-Image-Tags'] : '' );

		// If no Title exists, fallback to the filename or EXIF/IPTC data
		if ( empty( $title ) ) {
			$name       = basename( $file['file'] );
			$name_parts = pathinfo( $name );
			$title       = trim( substr( $name, 0, -( 1 + strlen( $name_parts['extension'] ) ) ) );

			// use image exif/iptc data for title and caption defaults if possible
			if ( $image_meta = @wp_read_image_metadata( $file['file'] ) ) {
				if ( trim( $image_meta['title'] ) && ! is_numeric( sanitize_title( $image_meta['title'] ) ) ) {
					$title = $image_meta['title'];
				}
			}
		}

		// Construct the attachment array
		$post_data  = array();
		$attachment = array(
			'guid'           => $file['url'],
			'post_mime_type' => $file['type'],
			'post_title'     => utf8_encode( $title ), // Required for accented characters to work
			'post_content'   => '',
			'post_status'    => 'inherit',
			'post_excerpt'   => utf8_encode( $caption ), // Required for accented characters to work
		);

		// Check if we are uploading a new attachment or replacing an existing attachment
		if ( isset( $headers['X-Envira-Lightroom-Image-Id'] ) ) {
			// Check that the attachment we want to replace actually exists in the Media Library
			// If not, we're not overwriting an attachment
			$old_attachment = get_post( absint( $headers['X-Envira-Lightroom-Image-Id'] ) );
			if ( ! empty( $old_attachment ) ) {
				// Ovewrite existing attachment
				$attachment['ID'] = absint( $headers['X-Envira-Lightroom-Image-Id'] );
			}
		}

		// Save the data
		$attachment_id = wp_insert_attachment( $attachment, $file['file'], $gallery_id );
		if ( ! $attachment_id ) {
			return new WP_Error( 'json_upload_attachment_failed', __( 'Could not upload the image to the WordPress Media Library' ), array( 'status' => 500 ) );
		}

		// Generate attachment metadata
		$attachment_metadata = wp_generate_attachment_metadata( $attachment_id, $file['file'] );
		wp_update_attachment_metadata( $attachment_id, $attachment_metadata );

		// Assign the image to the Gallery
		if ( isset( $gallery_id ) && ! empty( $gallery_id ) ) {

			// Set post meta to show that this image is attached to one or more Envira galleries.
			$has_gallery = get_post_meta( $attachment_id, '_eg_has_gallery', true );
			if ( empty( $has_gallery ) ) {
				$has_gallery = array();
			}
			$has_gallery[] = $gallery_id;
			update_post_meta( $attachment_id, '_eg_has_gallery', $has_gallery );

			// Set post meta to show that this image is attached to a gallery on this page.
			$in_gallery = get_post_meta( $gallery_id, '_eg_in_gallery', true );
			if ( empty( $in_gallery ) ) {
				$in_gallery = array();
			}

			$in_gallery[] = $attachment_id;
			update_post_meta( $gallery_id, '_eg_in_gallery', $in_gallery );

			// Set data and order of image in gallery.
			$gallery_data = get_post_meta( $gallery_id, '_eg_gallery_data', true );
			if ( empty( $gallery_data ) ) {
				$gallery_data = array();
			}

			// If no gallery ID has been set, set it now.
			if ( empty( $gallery_data['id'] ) ) {
				$gallery_data['id'] = $gallery_id;
			}

			// Set data and update the meta information.
			$gallery_data = Envira_Lightroom_Attachment::get_instance()->prepare_gallery_data( $gallery_data, $attachment_id, $tags );
			update_post_meta( $gallery_id, '_eg_gallery_data', $gallery_data );

		}

		$headers = array( 'Location' => json_url( '/media/' . $attachment_id ) );

		return new WP_JSON_Response( $this->get_post( $attachment_id, 'edit' ), 201, $headers );

	}

	/**
	 * Handle an upload via raw POST data
	 *
	 * @param array $_files Data from $_FILES. Unused.
	 * @param array $_headers HTTP headers from the request
	 * @return array|WP_Error Data from {@see wp_handle_sideload()}
	 */
	protected function upload_from_data( $_files, $_headers ) {

		$data = $this->server->get_raw_data();

		if ( empty( $data ) ) {
			return new WP_Error( 'json_upload_no_data', __( 'No data supplied' ), array( 'status' => 400 ) );
		}

		if ( empty( $_headers['CONTENT_TYPE'] ) ) {
			return new WP_Error( 'json_upload_no_type', __( 'No Content-Type supplied' ), array( 'status' => 400 ) );
		}

		if ( empty( $_headers['CONTENT_DISPOSITION'] ) ) {
			return new WP_Error( 'json_upload_no_disposition', __( 'No Content-Disposition supplied' ), array( 'status' => 400 ) );
		}

		// Get the filename
		$disposition_parts = explode( ';', $_headers['CONTENT_DISPOSITION'] );
		$filename = null;

		foreach ( $disposition_parts as $part ) {
			$part = trim( $part );

			if ( strpos( $part, 'filename' ) !== 0 ) {
				continue;
			}

			$filenameparts = explode( '=', $part );
			$filename      = trim( $filenameparts[1] );
		}

		if ( empty( $filename ) ) {
			return new WP_Error( 'json_upload_invalid_disposition', __( 'Invalid Content-Disposition supplied' ), array( 'status' => 400 ) );
		}

		if ( ! empty( $_headers['CONTENT_MD5'] ) ) {
			$expected = trim( $_headers['CONTENT_MD5'] );
			$actual   = md5( $data );

			if ( $expected !== $actual ) {
				return new WP_Error( 'json_upload_hash_mismatch', __( 'Content hash did not match expected' ), array( 'status' => 412 ) );
			}
		}

		// Get the content-type
		$type = $_headers['CONTENT_TYPE'];

		// Save the file
		$tmpfname = wp_tempnam( $filename );

		$fp = fopen( $tmpfname, 'w+' );

		if ( ! $fp ) {
			return new WP_Error( 'json_upload_file_error', __( 'Could not open file handle' ), array( 'status' => 500 ) );
		}

		fwrite( $fp, $data );
		fclose( $fp );

		// Now, sideload it in
		$file_data = array(
			'error' => null,
			'tmp_name' => $tmpfname,
			'name' => $filename,
			'type' => $type,
		);
		$overrides = array(
			'test_form' => false,
		);
		$sideloaded = wp_handle_sideload( $file_data, $overrides );

		if ( isset( $sideloaded['error'] ) ) {
			@unlink( $tmpfname );
			return new WP_Error( 'json_upload_sideload_error', $sideloaded['error'], array( 'status' => 500 ) );
		}

		return $sideloaded;

	}

	/**
	 * Retrieve a attachment
	 *
	 * @see WP_JSON_Posts::get_post()
	 */
	public function get_post( $id, $context = 'view' ) {

		$id = (int) $id;

		if ( empty( $id ) ) {
			// This is getting fired after uploading an attachment?
			return new WP_Error( 'json_post_invalid_id', __( 'Invalid post ID.' ), array( 'status' => 404 ) );
		}

		$post = get_post( $id, ARRAY_A );

		if ( $post['post_type'] !== 'attachment' ) {
			return new WP_Error( 'json_post_invalid_type', __( 'Invalid post type' ), array( 'status' => 400 ) );
		}

		return parent::get_post( $id, $context );

	}

}
