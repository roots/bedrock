<?php
/**
 * WP REST API v1 class.
 *
 * Requires https://wordpress.org/plugins/json-rest-api/ to be installed and active,
 * and adds filters / actions for Envira-specific requests.
 *
 * @since 1.0.0
 *
 * @package Envira_Lightroom
 * @author  Envira Team
 */
class Envira_Lightroom_WP_REST_API {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.0
	 *
	 * @var object
	 */
	public static $instance;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Determine the User ID whenever an authenticated request is made
		add_filter( 'determine_current_user', array( $this, 'determine_current_user' ), 20 );

		// For any endpoints that require WordPress User authentication, filter that process to auth by access token
		add_filter( 'authenticate', array( $this, 'authenticate' ) );

		// v1 REST API hooks
		if ( defined( 'JSON_API_VERSION' ) ) {
			// v1 API: Test the access token in Lightroom (user clicks 'Authenticate' in Lightroom)
			add_filter( 'json_authentication_errors', array( $this, 'v1_json_authentication_errors' ) );

			// v1 API: Add the Envira Post Type to the available Post Types in the Rest API
			// We do this because if the user does not use the Standalone Addon, the Post Type isn't public
			// and therefore will not appear in the API for us to work with in Lightroom
			add_action( 'registered_post_type', array( $this, 'v1_show_in_json' ), 11, 2 );
		} else {
			// v2 REST API hooks
			// v2 API: Register endpoint specifically to test the access token in Lightroom (user clicks 'Authenticate' in Lightroom)
			add_action( 'rest_api_init', array( $this, 'v2_register_rest_routes' ) );

			// v2 API: Add the Envira Post Type to the available Post Types in the Rest API
			add_filter( 'init', array( $this, 'v2_show_in_json' ), 11 );
		}

	}

	/**
	 * Called whenever an API action requiring WordPress User access is run.
	 *
	 * Checks the validity of the supplied Envira Lightroom Access Token,
	 * and if valid returns the User ID to run this action as.
	 *
	 * This will then honor roles and capabilities that the user has for the
	 * requested task, ensuring e.g. a Subscriber cannot create a Post.
	 *
	 * @since 1.0
	 *
	 * @param   array $user     User
	 * @return  mixed               null | User ID
	 */
	public function determine_current_user( $user ) {

		// Check request
		$headers = envira_lightroom_get_all_headers();
		if ( ! isset( $headers['X-Envira-Lightroom-Access-Token'] ) ) {
			return $user;
		}

		// Authenticate Access Token
		$result = $this->authenticate_access_token( $headers['X-Envira-Lightroom-Access-Token'] );

		// If Access Token auth failed, bail
		if ( is_wp_error( $result ) ) {
			return null;
		}

		// If here, access token is valid
		// Get User ID
		$user_id = get_option( 'envira_lightroom_user_id' );

		// Return
		return $user_id;

	}

	/**
	 * Called whenever authentication is run.
	 * Note: This function is run on any authentication screen (including wp-login.php)
	 *
	 * @since 1.0
	 *
	 * @return  mixed                   WP_Error | User
	 */
	public function authenticate() {

		// Check if request is an Envira Lightroom Auth request
		$headers = envira_lightroom_get_all_headers();
		if ( ! isset( $headers['X-Envira-Lightroom-Access-Token'] ) ) {
			// No need to authenticate
			return false;
		}

		// Authenticate Access Token
		$result = $this->authenticate_access_token( $headers['X-Envira-Lightroom-Access-Token'] );

		// If Access Token auth failed, return the WP_Error object
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// If here, access token is valid
		// Get User ID
		$user_id = get_option( 'envira_lightroom_user_id' );

		// Return User
		return get_user_by( 'id', $user_id );

	}

	/**
	 * v1 API: Called if authentication failed.  We still check the Envira Lightroom Access Token header,
	 * as we want every call to be authenticated, so we can tell Lightroom whether the access token
	 * is valid or not.
	 *
	 * @since 1.0
	 *
	 * @param  mixed $error  Error
	 * @return mixed         WP_Error | true
	 */
	public function v1_json_authentication_errors( $error ) {

		// Check request
		$headers = envira_lightroom_get_all_headers();
		if ( ! isset( $headers['X-Envira-Lightroom-Access-Token'] ) ) {
			return $error;
		}

		// Passthrough other errors
		if ( ! empty( $error ) ) {
			return $error;
		}

		// Authenticate Access Token
		return $this->authenticate_access_token( $headers['X-Envira-Lightroom-Access-Token'] );

	}

	/**
	 * v2 API: Register the /wp-json/envira/v2/authenticate endpoint, which Lightroom can use
	 * to test the supplied access token
	 *
	 * @since 1.0.2
	 */
	public function v2_register_rest_routes() {

		// Register route at /wp-json/envira/v2/authenticate
		register_rest_route(
			'envira/v2',
			'/authenticate',
			array(
				'methods'  => 'GET',
				'callback' => array( $this, 'authenticate' ),
			)
		);

	}

	/**
	 * Attempts access token authentication if an Envira Lightroom Access Token has been specified in the header
	 *
	 * @since 1.0
	 *
	 * @param mixed $obj Original object (WP_User|WP_Error)
	 * @return bool Success
	 */
	private function authenticate_access_token( $supplied_access_token ) {

		// Get access token for this WordPress web site
		$access_token = get_option( 'envira_lightroom_access_token' );

		// Bail if there is no access token
		if ( empty( $access_token ) ) {
			return new WP_Error( 'invalid_token', __( 'The Access Token supplied is invalid. Please double check your access token, which can be found in your WordPress web site\'s  Administration Interface > Envira > Settings > Lightroom', 'envira-lightroom' ), array( 'status' => 403 ) );
		}

		// If here, request included X-Envira-Lightroom-Access-Token
		// Validate the access token
		if ( $supplied_access_token != base64_encode( $access_token ) ) {
			// This message is displayed in the Lightroom Dialog Box
			return new WP_Error( 'invalid_token', __( 'The Access Token supplied is invalid. Please double check your access token, which can be found in your WordPress web site\'s  Administration Interface > Envira > Settings > Lightroom', 'envira-lightroom' ), array( 'status' => 403 ) );
		}

		// Access Token OK
		return true;

	}

	/**
	 * v1: The WP REST API uses its json_register_post_type() function to define each Post Type Object's show_in_json
	 * property, based on the publicly_queryable parameter of register_post_type
	 *
	 * Because, by default, we don't let Envira Galleries be publicly_queryable (unless Standalone is enabled), we
	 * need to override this behaviour for Envira CPTs
	 *
	 * This means that Envira CPTs can then be read via JSON, which is required even when creating an Envira CPT through
	 * the JSON API
	 *
	 * @since 1.0
	 *
	 * @global array $wp_post_types Post types list.
	 *
	 * @param string   $post_type Post type to register.
	 * @param stdClass $args      Post type arguments.
	 */
	public function v1_show_in_json( $post_type, $args ) {

		global $wp_post_types;

		// If we're registering the Envita CPT, set show_in_json = true
		if ( $post_type == 'envira' ) {
			$type               = &$wp_post_types[ $post_type ];
			$type->show_in_json = true;
		}

	}

	/**
	 * v2: Show the Envira Post Type in the REST API
	 *
	 * @since 1.0.2
	 *
	 * @return null
	 */
	public function v2_show_in_json() {

		global $wp_post_types;

		if ( isset( $wp_post_types['envira'] ) ) {
			$wp_post_types['envira']->show_in_rest          = true;
			$wp_post_types['envira']->rest_base             = 'envira';
			$wp_post_types['envira']->rest_controller_class = 'WP_REST_Posts_Controller';
		}

	}

	/**
	 * Checks for the existence of the X-Envira-Lightroom-Image-ID header.
	 *
	 * If it exists, we need to overwrite an existing Media Library Attachment
	 * by setting the ID parameter to the image ID
	 *
	 * json-rest-api/lib/class-wp-json-media.php::261 will unset any POSted ID, so
	 * we need to inject the ID this way
	 *
	 * @since 1.0
	 *
	 * @param array $data       Sanitized Post Data
	 * @param array $postarr    Unsanitized Post Data
	 * @return array                Sanitized Post Data
	 */
	public function maybe_overwrite_existing_attachment( $data, $postarr ) {

		// Check for the required header
		$headers = envira_lightroom_get_all_headers();
		if ( ! isset( $headers['X-Envira-Lightroom-Image-Id'] ) ) {
			return $data;
		}

		// Header exists
		// Check if a Media Library Image already exists
		$id         = absint( $headers['X-Envira-Lightroom-Image-Id'] );
		$attachment = get_post( $id );
		if ( empty( $attachment ) ) {
			// No existing image ID exists, so there's nothing to overwrite
			return $data;
		}

		// Set ID parameter so we overwrite an existing image
		$data['ID'] = $id;
		return $data;

	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.0
	 *
	 * @return object The Envira_Lightroom_WP_REST_API object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Envira_Lightroom_WP_REST_API ) ) {
			self::$instance = new Envira_Lightroom_WP_REST_API();
		}

		return self::$instance;

	}

}

// Load the WP REST API class.
$envira_lightroom_wp_rest_api = Envira_Lightroom_WP_REST_API::get_instance();
