<?php
/**
 * WP REST API v2 attachment class
 *
 * Used for the WP REST API v2 when:
 * - Media is uploaded from Lightroom to the Media Library & Envira Gallery,
 * - Media is deleted from Lightroom.
 *
 * @since 1.0.4
 *
 * @package Envira_Lightroom
 * @author  Envira Team
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP REST API v2 attachment class
 *
 * Used for the WP REST API v2 when:
 * - Media is uploaded from Lightroom to the Media Library & Envira Gallery,
 * - Media is deleted from Lightroom.
 *
 * @since 1.0.4
 *
 * @package Envira_Lightroom
 * @author  Envira Team
 */
class Envira_Lightroom_Attachment {

	/**
	 * Holds the class object.
	 *
	 * @since 1.0.4
	 *
	 * @var object
	 */
	public static $instance;


	/**
	 * Constructor
	 *
	 * @since 1.0.4
	 */
	public function __construct() {

		add_action( 'rest_insert_attachment', array( $this, 'save_meta' ), 10, 3 );
		add_action( 'rest_delete_attachment', array( $this, 'remove_image_from_gallery' ), 10, 3 );
		add_filter( 'rest_attachment_trashable', array( $this, 'enable_attachment_deletion' ), 10, 2 );

	}

	/**
	 * Reads header data and updates the Media Library attachment
	 * and Envira Gallery metadata with the supplied title, caption
	 * and tags.
	 *
	 * The attachment can safely be assumed to be in the Media Library,
	 * but the image may not be in the gallery's meta data (i.e. if
	 * uploading a new image from Lightroom)
	 *
	 * @since 1.0.4
	 *
	 * @param   object $attachment     Image.
	 * @param   array  $request        Request.
	 * @param   bool   $created        Image is new and created (false = image is updated).
	 */
	public function save_meta( $attachment, $request, $created ) {

		if ( is_array( $attachment ) ) {
			return; }

		// Get headers and prepare the image metadata.
		$headers       = envira_lightroom_get_all_headers();
		$gallery_id    = absint( $headers['X-Envira-Lightroom-Gallery-Id'] );
		$title         = ( isset( $headers['X-Envira-Lightroom-Image-Title'] ) ? $headers['X-Envira-Lightroom-Image-Title'] : '' );
		$caption       = ( isset( $headers['X-Envira-Lightroom-Image-Caption'] ) ? $headers['X-Envira-Lightroom-Image-Caption'] : '' );
		$tags          = ( isset( $headers['X-Envira-Lightroom-Image-Tags'] ) ? $headers['X-Envira-Lightroom-Image-Tags'] : '' );
		$attachment_id = $attachment->ID;

		// Update the attachment's title and caption.
		if ( ! empty( $title ) ) {
			$attachment->post_title = ( false === mb_detect_encoding( $title, 'UTF-8', true ) ) ? utf8_encode( $title ) : $title;
		}
		if ( ! empty( $caption ) ) {
			$attachment->post_excerpt = ( false === mb_detect_encoding( $caption, 'UTF-8', true ) ) ? utf8_encode( $caption ) : $caption;
		}

		// Save the attachment.
		wp_update_post( $attachment );

		// Set post meta to show that this image is attached to one or more Envira galleries.
		$has_gallery = get_post_meta( $attachment_id, '_eg_has_gallery', true );
		if ( empty( $has_gallery ) ) {
			$has_gallery = array();
		}
		if ( ! in_array( $attachment_id, $has_gallery ) ) {
			$has_gallery[] = $gallery_id;
		}
		update_post_meta( $attachment_id, '_eg_has_gallery', $has_gallery );

		// Set post meta to show that this image is attached to a gallery on this page.
		$in_gallery = get_post_meta( $gallery_id, '_eg_in_gallery', true );
		if ( empty( $in_gallery ) ) {
			$in_gallery = array();
		}
		if ( ! in_array( $attachment_id, $in_gallery ) ) {
			$in_gallery[] = $attachment_id;
		}

		update_post_meta( $gallery_id, '_eg_in_gallery', $in_gallery );

		// Set data and order of image in gallery.
		$gallery_data = get_post_meta( $gallery_id, '_eg_gallery_data', true );
		if ( empty( $gallery_data ) ) {
			$gallery_data = array();
		}

		// If no gallery ID has been set, set it now.
		if ( empty( $gallery_data['id'] ) ) {
			$gallery_data['id'] = $gallery_id;
		}

		// Set data and update the meta information.
		$gallery_data = $this->prepare_gallery_data( $gallery_data, $attachment_id, $tags );
		update_post_meta( $gallery_id, '_eg_gallery_data', $gallery_data );

	}

	/**
	 * Helper function to prepare the metadata for an image in a gallery.
	 *
	 * @since 1.0.0
	 *
	 * @param   array  $gallery_data   Array of data for the gallery.
	 * @param   int    $id             The attachment ID to prepare data for.
	 * @param   string $tags           Image Tags.
	 * @return  array   $gallery_data   Amended gallery data with updated image metadata.
	 */
	public function prepare_gallery_data( $gallery_data, $id, $tags ) {

		$attachment = get_post( $id );
		$url        = wp_get_attachment_image_src( $id, 'full' );
		$alt_text   = get_post_meta( $id, '_wp_attachment_image_alt', true );
		$image      = array(
			'status'  => 'active',
			'src'     => isset( $url[0] ) ? esc_url( $url[0] ) : '',
			'title'   => get_the_title( $id ),
			'link'    => isset( $url[0] ) ? esc_url( $url[0] ) : '',
			'alt'     => ! empty( $alt_text ) ? $alt_text : basename( $url[0] ),
			'caption' => ! empty( $attachment->post_excerpt ) ? $attachment->post_excerpt : '',
			'thumb'   => '',
		);

		// Allow Addons to filter the image array.
		$image = apply_filters( 'envira_lightroom_prepare_gallery_data', $image, $gallery_data, $id, $tags );

		// If gallery data is not an array (i.e. we have no images), just add the image to the array.
		if ( ! isset( $gallery_data['gallery'] ) || ! is_array( $gallery_data['gallery'] ) ) {
			$gallery_data['gallery']        = array();
			$gallery_data['gallery'][ $id ] = $image;
		} else {
			// Add this image to the start or end of the gallery, depending on the setting.
			$media_position = get_option( 'envira_gallery_media_position' );

			switch ( $media_position ) {
				case 'before':
					// Add image to start of images array
					// Store copy of images, reset gallery array and rebuild.
					$images                         = $gallery_data['gallery'];
					$gallery_data['gallery']        = array();
					$gallery_data['gallery'][ $id ] = $image;
					foreach ( $images as $old_image_id => $old_image ) {
						$gallery_data['gallery'][ $old_image_id ] = $old_image;
					}
					break;
				case 'after':
				default:
					// Add image, this will default to the end of the array.
					$gallery_data['gallery'][ $id ] = $image;
					break;
			}
		}

		// Return.
		return $gallery_data;

	}

	/**
	 * Removes the now deleted Media Library image from the given Envira Gallery
	 * included in the Lightroom request
	 *
	 * @since 1.0.8
	 *
	 * @param   WP_Post          $post       Attachment Post.
	 * @param   WP_REST_Response $response   The response data.
	 * @param   WP_REST_Request  $request    The request sent to the API.
	 */
	public function remove_image_from_gallery( $post, $response, $request ) {

		// Get all Envira Galleries that might contain this image.
		$gallery_ids = get_post_meta( $post->ID, '_eg_has_gallery', true );

		// Iterate through each Gallery, getting its metadata and removing the image
		// if it's there.
		foreach ( (array) $gallery_ids as $gallery_id ) {

			// Get gallery data.
			$data = get_post_meta( $gallery_id, '_eg_gallery_data', true );

			// Skip if no images in this gallery.
			if ( ! isset( $data['gallery'] ) ) {
				continue;
			}

			// Skip if the image doesn't exist in this gallery.
			if ( ! isset( $data['gallery'][ $post->ID ] ) ) {
				continue;
			}

			// If here, the image exists in the Gallery. Remove it.
			unset( $data['gallery'][ $post->ID ] );
			update_post_meta( $gallery_id, '_eg_gallery_data', $data );

		}

	}

	/**
	 * Supports trashing / deletion of attachments.
	 *
	 * If we don't enable this, users may get a "The Post does not support Trashing"
	 * error in Lightroom.
	 *
	 * @since 1.0.8
	 *
	 * @param   bool    $supports_trash     Supports Trashing.
	 * @param   WP_Post $post               Attachment Post.
	 * @return  bool                        Supports Trashing
	 */
	public function enable_attachment_deletion( $supports_trash, $post ) {

		return true;

	}

	/**
	 * Returns the singleton instance of the class.
	 *
	 * @since 1.0.4
	 *
	 * @return object The Envira_Lightroom_Attachment object.
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Envira_Lightroom_Attachment ) ) {
			self::$instance = new Envira_Lightroom_Attachment();
		}

		return self::$instance;

	}

}

// Load the attachment class.
$envira_lightroom_attachment = Envira_Lightroom_Attachment::get_instance();
