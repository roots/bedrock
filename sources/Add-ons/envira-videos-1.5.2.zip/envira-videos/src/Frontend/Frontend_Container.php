<?php

namespace Envira\Videos\Frontend;

use Envira\Videos\Frontend\Shortcode;

class Frontend_Container {

	public function __construct() {

		$shortcode = new Shortcode();

	}

}
