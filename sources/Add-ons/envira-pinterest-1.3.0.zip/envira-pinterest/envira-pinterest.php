<?php
/**
 * Plugin Name: Envira Gallery - Pinterest Addon
 * Plugin URI:  http://enviragallery.com
 * Description: Enables Pinterest "Pin It" buttons for Envira galleries.
 * Author:      Envira Gallery Team
 * Author URI:  http://enviragallery.com
 * Version:     1.3.0
 * Text Domain: envira-pinterest
 * Domain Path: languages
 *
 * Envira Gallery is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Envira Gallery is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Envira Gallery. If not, see <http://www.gnu.org/licenses/>.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define necessary addon constants.
define( 'ENVIRA_PINTEREST_PLUGIN_NAME', 'Envira Gallery - Pinterest Addon' );
define( 'ENVIRA_PINTEREST_PLUGIN_VERSION', '1.3.0' );
define( 'ENVIRA_PINTEREST_PLUGIN_SLUG', 'envira-pinterest' );

add_action('admin_notices', 'envira_pinterest_general_admin_notice');
/**
 * Ensures the full Envira Gallery plugin is active before proceeding.
 *
 * @since 1.0.0
 *
 * @return null Return early if Envira Gallery is not active.
 */
function envira_pinterest_general_admin_notice(){
    global $pagenow;
    if ( $pagenow == 'plugins.php' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>The Pinterest Addon has been moved into the Envira Social Addon permanently. Please install and activate the <a href="https://enviragallery.com/docs/social-addon/">Envira Social Addon</a> to set up your galleries in order to use Pinterest for sharing your gallery and lightbox images.</p>
         </div>';
    }
}



add_action( 'plugins_loaded', 'envira_pinterest_plugins_loaded' );
/**
 * Ensures the full Envira Gallery plugin is active before proceeding.
 *
 * @since 1.0.0
 *
 * @return null Return early if Envira Gallery is not active.
 */
function envira_pinterest_plugins_loaded() {

    // Bail if the main class does not exist.
    if ( ! class_exists( 'Envira_Gallery' ) ) {
        return;
    }

    // Fire up the addon.
    add_action( 'envira_gallery_init', 'envira_pinterest_plugin_init' );

    // Load the plugin textdomain.
    load_plugin_textdomain( ENVIRA_PINTEREST_PLUGIN_SLUG, false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );

}

/**
 * Loads all of the addon hooks and filters.
 *
 * @since 1.0.0
 */
function envira_pinterest_plugin_init() {

    add_action( 'envira_gallery_updater'            , 'envira_pinterest_updater' );
    add_filter( 'envira_gallery_defaults'           , 'envira_pinterest_defaults', 10, 2 );
    add_filter( 'envira_gallery_tab_nav'            , 'envira_pinterest_tab_nav' );
    add_action( 'envira_gallery_tab_pinterest'      , 'envira_pinterest_settings' );
    add_filter( 'envira_gallery_save_settings'      , 'envira_pinterest_save', 10, 2 );
    add_filter( 'envira_gallery_output_start'       , 'envira_pinterest_style', 10, 2 ); // was envira_gallery_output_start
    // add_filter( 'envira_gallery_output_link_attr'   , 'envira_pinterest_lightbox_attr', 10, 5 );
    add_action( 'envira_gallery_api_end'            , 'envira_pinterest_event' );
    // add_action( 'envira_gallery_api_before_show'    , 'envira_pinterest_lightbox' );
    add_action( 'envira_gallery_mobile_box'         , 'envira_pinterest_mobile_tab' );



    // Album

    add_filter( 'envira_albums_tab_nav'             , 'envira_pinterest_tab_nav' );
    add_action( 'envira_albums_tab_pinterest'       , 'envira_pinterest_settings' );
    add_filter( 'envira_albums_save_settings'       , 'envira_pinterest_album_settings_save', 10, 2 );
    add_action( 'envira_albums_api_end'             , 'envira_pinterest_event' );
    add_action( 'envira_albums_api_before_show'     , 'envira_pinterest_lightbox' );

    add_action( 'envira_gallery_metabox_scripts'    , 'envira_pinterest_metabox_scripts' );

    add_action( 'wp_enqueue_scripts'    , 'envira_pinterest_gallery_output_css_js', 99 );

}



function pinterest_gallery_output_lightbox_on_update( $data ) {

    // If the $post variable is not set, set the URL to the home page of the site.
    $instance = Envira_Gallery_Shortcode::get_instance();
    global $post;
    if ( isset( $post ) ) {
        $url = get_permalink( $post->ID );
    } else {
        $url = trailingslashit( get_home_url() );
    }
    $url = apply_filters( 'envira_pinterest_url', $url, $data );

    $updated_href = urlencode('http://pinterest.com/pin/create/button/?url='.esc_url( $url ).'&description={desc}&media={media}');

    ?>

    /* console.log( 'envira-pinterest-share: ' + $('.envira-pinterest-share').attr('href') ); */
    $('.envira-pinterest-share').attr('href', '<?php echo $updated_href; ?>');

    var media = $('.envirabox-overlay img.envirabox-image').attr('src');
    var description = $('.envirabox-overlay img.envirabox-image').data('envira-caption') !== '' ? $('.envirabox-overlay img.envirabox-image').data('envira-caption') : $('.envirabox-overlay img.envirabox-image').attr('title');

    var href = decodeURIComponent($('a.envira-pinterest-share').attr('href'));
    $('a.envira-pinterest-share').attr('href', href.replace(/\{media\}/g, media).replace(/\{desc\}/g, description));

    <?php

}

function pinterest_gallery_output_lightbox_html( $template, $data, $position = null ) {

    $instance = Envira_Gallery_Shortcode::get_instance();

    // Check if Pinterest Button output is enabled
    if ( ! $instance->get_config( 'pinterest', $data ) ) {
        return $template;
    }

    $is_mobile = envira_mobile_detect()->isMobile();

    // Check if Pinterest Button output is enabled for mobile, if we are on mobile

    if ( $is_mobile && $instance->get_config( 'pinterest', $data ) && ! $instance->get_config( 'mobile_pinterest_lightbox', $data ) ) {
        return $template;
    }

    if ( $position ) {
        $position = str_replace( '-', '_', $position );
        // for some reason there is a dash and an underscore in config and passed $position (do a var dump)
    }

    // Check position
    if ( $instance->get_config( 'pinterest_position', $data ) !== $position ) {
        return $template;
    }

    // Get Button
    $button = get_lightbox_pinterest_button( $data, $position );

    return $template . $button;

}

/**
 * Adds the proper attributes to images for Pinterest output in the lightbox.
 *
 * @since 1.0.0
 *
 * @param string $attr  String of link attributes.
 * @param int $id       The current gallery ID.
 * @param array $item   Array of slide data.
 * @param array $data   Array of gallery data.
 * @param int $i        The current position in the gallery.
 * @return string $attr Amended string of link attributes.
 */
function get_lightbox_pinterest_button( $data, $position ) {

    // If the $post variable is not set, set the URL to the home page of the site.
    $instance = Envira_Gallery_Shortcode::get_instance();
    global $post;
    if ( isset( $post ) ) {
        $url = get_permalink( $post->ID );
    } else {
        $url = trailingslashit( get_home_url() );
    }
    $url = apply_filters( 'envira_pinterest_url', $url, $data, $position );

    // Set the style for the Pin It button.
    $style = '';
    switch ( $position ) {
        case 'top_left' :
        default :
            $style = 'top:10px;left:10px;';
            break;
        case 'top_right' :
            $style = 'top:10px;right:10px;';
            break;
        case 'bottom_right' :
            $style = 'bottom:10px;right:10px;';
            break;
        case 'bottom_left' :
            $style = 'bottom:10px;left:10px;';
            break;
    }

    // Append the button to the image with styles.
    $output = '<div class="envira-pinterest-button"><a class="envira-pinterest-share envira-pinterest-' . $instance->get_config( 'pinterest_color', $data ) . '" href="'.urlencode('http://pinterest.com/pin/create/button/?url=' . esc_url( $url )) . '&description={desc}&media={media}" rel="nofollow" style="width:56px;height:28px;display:block;outline:none;' . $style . '"></a></div>';
    $output = apply_filters( 'envira_pinterest_output', $output, $data );

    return apply_filters( 'envira_pinterest_attr', $output, $data, $position );

}

function envira_pinterest_gallery_output_css_js() {

    global $post;

    if ( isset( $post ) ) {
        $url = get_permalink( $post->ID );
    } else {
        $url = trailingslashit( get_home_url() );
    }

    wp_register_script( ENVIRA_PINTEREST_PLUGIN_SLUG . '-script', plugins_url( 'assets/js/envira-pinterest.js', __FILE__  ), array( 'jquery' ), ENVIRA_PINTEREST_PLUGIN_VERSION, true );
    wp_enqueue_script ( ENVIRA_PINTEREST_PLUGIN_SLUG . '-script' );
    wp_localize_script( ENVIRA_PINTEREST_PLUGIN_SLUG . '-script', 'envira_pinterest', array(
        'envira_pinterest_url' => $url,
        'debug'             => ( defined( 'ENVIRA_DEBUG' ) && ENVIRA_DEBUG ? true : false ),
    ) );

}

/**
 * Initializes scripts for the metabox admin.
 *
 * @since 1.0.5
 *
 * @param string $key The user license key.
 */
function envira_pinterest_metabox_scripts() {

    // Conditional Fields
    wp_register_script( ENVIRA_PINTEREST_PLUGIN_SLUG . '-conditional-fields-script', plugins_url( 'assets/js/min/conditional-fields-min.js', __FILE__ ), array( 'jquery', Envira_Gallery::get_instance()->plugin_slug . '-conditional-fields-script' ), ENVIRA_PINTEREST_PLUGIN_VERSION, true );
    wp_enqueue_script ( ENVIRA_PINTEREST_PLUGIN_SLUG . '-conditional-fields-script' );

}

/**
 * Initializes the addon updater.
 *
 * @since 1.0.0
 *
 * @param string $key The user license key.
 */
function envira_pinterest_updater( $key ) {

    $args = array(
        'plugin_name' => ENVIRA_PINTEREST_PLUGIN_NAME,
        'plugin_slug' => ENVIRA_PINTEREST_PLUGIN_SLUG,
        'plugin_path' => plugin_basename( __FILE__ ),
        'plugin_url'  => trailingslashit( WP_PLUGIN_URL ) . ENVIRA_PINTEREST_PLUGIN_SLUG,
        'remote_url'  => 'https://enviragallery.com/',
        'version'     => ENVIRA_PINTEREST_PLUGIN_VERSION,
        'key'         => $key
    );

    $updater = new Envira_Gallery_Updater( $args );

}

/**
 * Applies a default to the addon setting.
 *
 * @since 1.0.0
 *
 * @param array $defaults  Array of default config values.
 * @param int $post_id     The current post ID.
 * @return array $defaults Amended array of default config values.
 */
function envira_pinterest_defaults( $defaults, $post_id ) {

    // Pinterest addon defaults.
    $defaults['pinterest']                      = 0;
    $defaults['pinterest_position']             = 'top_left';
    $defaults['pinterest_color']                = 'gray';
    $defaults['mobile_pinterest_lightbox']      = 1;
    return $defaults;

}

/**
 * Filters in a new tab for the addon.
 *
 * @since 1.0.0
 *
 * @param array $tabs  Array of default tab values.
 * @return array $tabs Amended array of default tab values.
 */
function envira_pinterest_tab_nav( $tabs ) {

    $tabs['pinterest'] = __( 'Pinterest', 'envira-pinterest' );
    return $tabs;

}

/**
 * Adds addon setting to the Pinterest tab.
 *
 * @since 1.0.0
 *
 * @param object $post The current post object.
 */
function envira_pinterest_settings( $post ) {

    // Get post type so we load the correct metabox instance and define the input field names
    // Input field names vary depending on whether we are editing a Gallery or Album
    $post_type = get_post_type( $post );
    switch ( $post_type ) {
        /**
        * Gallery
        */
        case 'envira':
            $instance = Envira_Gallery_Metaboxes::get_instance();
            $key = '_envira_gallery';
            break;
        case 'envira_album':
            $instance = Envira_Albums_Metaboxes::get_instance();
            $key = '_eg_album_data[config]';
            break;

    }

    if ( 'envira' == $post_type || 'envira_album' == $post_type ) {

    ?>
    <div id="envira-pinterest">
        <p class="envira-intro">
            <?php _e( 'Pinterest Settings', 'envira-pinterest' ); ?>
            <small>
                <?php _e( 'The settings below adjust the Pinterest settings for the gallery.', 'envira-pinterest' ); ?>
                <br/>
                <?php _e( 'Need some help?', 'envira-gallery' ); ?>
                <a href="http://enviragallery.com/docs/pinterest-addon/" class="envira-doc" target="_blank">
                    <?php _e( 'Read the Documentation', 'envira-pinterest' ); ?>
                </a>
                or
                <a href="https://www.youtube.com/embed/unbtSAgMg5M/?rel=0" class="envira-video" target="_blank">
                    <?php _e( 'Watch a Video', 'envira-pinterest' ); ?>
                </a>
            </small>
        </p>
        <table class="form-table">
            <tbody>
                <tr id="envira-config-pinterest-box">
                    <th scope="row">
                        <label for="envira-config-pinterest"><?php _e( 'Enable Pin It Button?', 'envira-pinterest' ); ?></label>
                    </th>
                    <td>
                        <input id="envira-config-pinterest" type="checkbox" name="_envira_gallery[pinterest]" value="<?php echo $instance->get_config( 'pinterest', $instance->get_config_default( 'pinterest' ) ); ?>" <?php checked( $instance->get_config( 'pinterest', $instance->get_config_default( 'pinterest' ) ), 1 ); ?> />
                        <span class="description"><?php _e( 'Enables or disables the Pinterest "Pin It" button for gallery lightbox images.', 'envira-pinterest' ); ?></span>
                    </td>
                </tr>
                <tr id="envira-config-pinterest-position-box">
                    <th scope="row">
                        <label for="envira-config-pinterest-position"><?php _e( 'Pinterest Position', 'envira-pinterest' ); ?></label>
                    </th>
                    <td>
                        <select id="envira-config-pinterest-position" name="_envira_gallery[pinterest_position]">
                            <?php foreach ( (array) envira_pinterest_positions() as $i => $data ) : ?>
                                <option value="<?php echo $data['value']; ?>"<?php selected( $data['value'], $instance->get_config( 'pinterest_position', $instance->get_config_default( 'pinterest_position' ) ) ); ?>><?php echo $data['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php _e( 'Sets the position of the Pinterest button on the gallery lightbox images.', 'envira-pinterest' ); ?></p>
                    </td>
                </tr>
                <tr id="envira-config-pinterest-color-box">
                    <th scope="row">
                        <label for="envira-config-pinterest-color"><?php _e( 'Pinterest Button Color', 'envira-pinterest' ); ?></label>
                    </th>
                    <td>
                        <select id="envira-config-pinterest-color" name="_envira_gallery[pinterest_color]">
                            <?php foreach ( (array) envira_pinterest_colors() as $i => $data ) : ?>
                                <option value="<?php echo $data['value']; ?>"<?php selected( $data['value'], $instance->get_config( 'pinterest_color', $instance->get_config_default( 'pinterest_color' ) ) ); ?>><?php echo $data['name']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description"><?php _e( 'Sets the color of the Pin It button.', 'envira-pinterest' ); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php

    }

}

/**
 * Saves the addon's settings for Galleries.
 *
 * @since 1.0.0
 *
 * @param array $settings  Array of settings to be saved.
 * @param int $pos_tid     The current post ID.
 * @return array $settings Amended array of settings to be saved.
 */
function envira_pinterest_save( $settings, $post_id ) {

    $settings['config']['pinterest']                    = isset( $_POST['_envira_gallery']['pinterest'] ) ? 1 : 0;
    $settings['config']['pinterest_position']           = isset( $_POST['_envira_gallery']['pinterest'] ) ? esc_attr( $_POST['_envira_gallery']['pinterest_position'] ) : false;
    $settings['config']['pinterest_color']              = isset( $_POST['_envira_gallery']['pinterest'] ) ? esc_attr( $_POST['_envira_gallery']['pinterest_color'] ) : false;
    $settings['config']['mobile_pinterest_lightbox']    = isset( $_POST['_envira_gallery']['mobile_pinterest_lightbox'] ) ? 1 : 0;

    return $settings;

}

/**
 * Saves the addon's settings for Albums.
 *
 * @since 1.0.6
 *
 * @param array $settings  Array of settings to be saved.
 * @param int $pos_tid     The current post ID.
 * @return array $settings Amended array of settings to be saved.
 */
function envira_pinterest_album_settings_save( $settings, $post_id ) {


    $settings['config']['pinterest']                    = isset( $_POST['_envira_gallery']['pinterest'] ) ? 1 : 0;
    $settings['config']['pinterest_position']           = isset( $_POST['_envira_gallery']['pinterest'] ) ? esc_attr( $_POST['_envira_gallery']['pinterest_position'] ) : false;
    $settings['config']['pinterest_color']              = isset( $_POST['_envira_gallery']['pinterest'] ) ? esc_attr( $_POST['_envira_gallery']['pinterest_color'] ) : false;
    $settings['config']['mobile_pinterest_lightbox']    = isset( $_POST['_envira_gallery']['mobile_pinterest_lightbox'] ) ? 1 : 0;

    return $settings;

}

/**
 * Outputs the Pinterest button styles.
 *
 * @since 1.0.0
 *
 * @param string $output  The gallery HTML output.
 * @param array $data     Array of gallery data.
 * @return string $output Amended gallery HTML output.
 */
function envira_pinterest_style( $output, $data ) {

    // Determine whether data is for a gallery or album
    $post_type = get_post_type( $data['id'] );

    // If post type is false, we're probably on a dynamic gallery/album
    // Grab the ID from the config
    if ( ! $post_type && isset( $data['config']['id'] ) ) {
        $post_type = get_post_type( $data['config']['id'] );
    }

    $instance = false;

    switch ( $post_type ) {
        case 'envira':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
        case 'envira_album':
            $instance = Envira_Albums_Shortcode::get_instance();
            break;
        default:
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
    }

    // If there's no instance, bail or risk fatal error
    if ( !$instance || ( ! $instance instanceof Envira_Gallery_Shortcode && ! $instance instanceof Envira_Albums_Shortcode ) ) {
       return $output;
    }

    // Since this CSS only needs to be defined once on a page, use static flag to help keep track.
    static $envira_pinterest_css_flag = false;

    // If the tag has been set to true, return the default output.
    if ( $envira_pinterest_css_flag ) {
        return $output;
    }

    // check the setting
    if ( empty( $data['config']['pinterest'] ) ) {
        return $output;
    }

    // Build out our custom CSS.
    $css  = '<style type="text/css">';
        // Apply a base reset for all items in the filter list to avoid as many conflicts as possible.
        $css .= '.envirabox-wrap .envira-pinterest-share { background-color: transparent; transition: none; -moz-transition: none; -webkit-transition: none; }';
        $css .= '.envirabox-wrap .envira-pinterest-share:hover { background-position: 0 -28px; }';
        $css .= '.envirabox-wrap .envira-pinterest-share:active { background-position: 0 -56px; }';
        $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-gray { background-image: url(' . plugins_url( 'images/pinterest-gray.png', __FILE__ ) . '); }';
        $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-red { background-image: url(' . plugins_url( 'images/pinterest-red.png', __FILE__ ) . '); }';
        $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-white { background-image: url(' . plugins_url( 'images/pinterest-white.png', __FILE__ ) . '); }';

        $css .= '.envira-pinterest-button { display: inline-block; z-index: 988041; } ';
        $css .= '.envira-pinterest-button a.envira-pinterest-share { display: inline; float: left; position: relative; z-index: 988041; } ';
        $css .= '.envirabox-inner .envira-gallery-top-left .envira-pinterest-button { margin: 0px 15px 20px 5px; } ';


        $css .= '@media only screen and (-webkit-min-device-pixel-ratio: 2),only screen and (min--moz-device-pixel-ratio: 2),only screen and (-o-min-device-pixel-ratio: 2/1), only screen and (min-device-pixel-ratio: 2),only screen and (min-resolution: 192dpi),only screen and (min-resolution: 2dppx) {';
            $css .= '.envirabox-wrap .envira-pinterest-share { background-size: 56px 84px; }';
            $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-gray { background-image: url(' . plugins_url( 'images/pinterest-gray@2x.png', __FILE__ ) . '); }';
            $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-red { background-image: url(' . plugins_url( 'images/pinterest-red@2x.png', __FILE__ ) . '); }';
            $css .= '.envirabox-wrap .envira-pinterest-share.envira-pinterest-white { background-image: url(' . plugins_url( 'images/pinterest-white@2x.png', __FILE__ ) . '); }';
        $css .= '}';
    $css .= '</style>';

    // Set our flag to true.
    $envira_pinterest_css_flag = true;

    // Return the minified CSS.
    $minify = $instance->minify( $css );
    return $css . $output;

}


/**
 * Adds the proper attributes to images for Pinterest output in the lightbox.
 *
 * @since 1.0.0
 *
 * @param string $attr  String of link attributes.
 * @param int $id       The current gallery ID.
 * @param array $item   Array of slide data.
 * @param array $data   Array of gallery data.
 * @param int $i        The current position in the gallery.
 * @return string $attr Amended string of link attributes.
 */
function envira_pinterest_lightbox_attr( $attr, $id, $item, $data, $i ) {

    // Determine whether data is for a gallery or album
    $post_type = get_post_type( $data['id'] );

    // If post type is false, we're probably on a dynamic gallery/album
    // Grab the ID from the config
    if ( ! $post_type && isset( $data['config']['id'] ) ) {
        $post_type = get_post_type( $data['config']['id'] );
    }

    switch ( $post_type ) {
        case 'envira':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
        case 'envira_album':
            $instance = Envira_Albums_Shortcode::get_instance();
            break;
        case 'post':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
    }

    // If there's no instance, bail or risk fatal error
    if ( !$instance || ( ! $instance instanceof Envira_Gallery_Shortcode && ! $instance instanceof Envira_Albums_Shortcode ) ) {
       return $output;
    }

    // If the $post variable is not set, set the URL to the home page of the site.
    global $post;
    if ( isset( $post ) ) {
        $url = get_permalink( $post->ID );
    } else {
        $url = trailingslashit( get_home_url() );
    }
    $url = apply_filters( 'envira_pinterest_url', $url, $id, $item, $data );

    // Set the style for the Pin It button.
    $style = '';
    switch ( $instance->get_config( 'pinterest_position', $data ) ) {
        case 'top_left' :
        default :
            $style = 'top:10px;left:10px;';
            break;
        case 'top_right' :
            $style = 'top:10px;right:10px;';
            break;
        case 'bottom_right' :
            $style = 'bottom:10px;right:10px;';
            break;
        case 'bottom_left' :
            $style = 'bottom:10px;left:10px;';
            break;
    }

    // Set the description for the image.

    $description = $media = false;
    $media = false;

    switch ( $post_type ) {
        case 'envira':
            $title       = ! empty( $item['caption'] ) ? $item['caption'] : $item['title'];
            $description = apply_filters( 'envira_pinterest_description', $title, $id, $item, $data );
            if ( isset( $item['src'] ) ) {
                $media       = $item['src'];
            }
            break;
        case 'envira_album':
            $title       = ! empty( $item['caption'] ) ? $item['caption'] : $item['title'];
            $description = apply_filters( 'envira_pinterest_description', $title, $id, $item, $data );
            if ( isset( $item['cover_image_url'] ) ) {
                $media       = $item['cover_image_url'];
            }
            break;
    }

    // Append the button to the image with styles.
    $output = '<a class="envira-pinterest-share envira-pinterest-' . $instance->get_config( 'pinterest_color', $data ) . '" href="http://pinterest.com/pin/create/button/?url=' . esc_url( $url ) . '&description=' . urlencode( strip_tags( $description ) ) . '&media=' . esc_url( $media ) . '" rel="nofollow" style="width:56px;height:28px;display:block;outline:none;position:absolute;z-index:9999999;' . $style . '"></a>';
    $output = apply_filters( 'envira_pinterest_output', $output, $id, $item, $data );
    $attr .= ' data-envira-pinterest="' . esc_attr( $output ) . '"';

    return apply_filters( 'envira_pinterest_attr', $attr, $id, $item, $data, $i );

}

/**
 * Output the JS to have the button click open in a new window.
 *
 * @since 1.0.0
 *
 * @param array $data Data for the gallery.
 */
function envira_pinterest_event( $data ) {

    // Determine whether data is for a gallery or album
    $post_type = get_post_type( $data['id'] );

    $instance = false;

    // If post type is false, we're probably on a dynamic gallery/album
    // Grab the ID from the config
    if ( ! $post_type && isset( $data['config']['id'] ) ) {
        $post_type = get_post_type( $data['config']['id'] );
    }

    switch ( $post_type ) {
        case 'envira':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
        case 'envira_album':
            $instance = Envira_Albums_Shortcode::get_instance();
            break;
        case 'post':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
    }

    // If there's no instance, bail or risk fatal error
    if ( !$instance || ( ! $instance instanceof Envira_Gallery_Shortcode && ! $instance instanceof Envira_Albums_Shortcode ) ) {
       return;
    }

    // If there is no Pinterest button, do nothing.
    if ( ! $instance->get_config( 'pinterest', $data ) ) {
        return;
    }

    // Output JS to open button click in a new window.
    ob_start();
    ?>
    $(document).on('click', '.envira-pinterest-share', function(e){
        e.preventDefault();
        window.open($(this).attr('href'), 'envira-pinterest', 'menubar=1,resizable=1,width=760,height=360');
    });
    <?php
    echo ob_get_clean();

}

/**
 * Enables Pinterest inside lightboxes if it is enabled.
 *
 * @since 1.0.0
 *
 * @param array $data Data for the gallery.
 */
function envira_pinterest_lightbox( $data ) {

    // Determine whether data is for a gallery or album
    $post_type = get_post_type( $data['id'] );

    // If post type is false, we're probably on a dynamic gallery/album
    // Grab the ID from the config
    if ( ! $post_type && isset( $data['config']['id'] ) ) {
        $post_type = get_post_type( $data['config']['id'] );
    }

    switch ( $post_type ) {
        case 'envira':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
        case 'envira_album':
            $instance = Envira_Albums_Shortcode::get_instance();
            break;
        case 'post':
            $instance = Envira_Gallery_Shortcode::get_instance();
            break;
    }

    // If there's no instance, bail or risk fatal error
    if ( !isset($instance) || ( ! $instance instanceof Envira_Gallery_Shortcode && ! $instance instanceof Envira_Albums_Shortcode ) ) {
       return;
    }

    // If there is no Pinterest button for the lightbox, do nothing.
    if ( ! $instance->get_config( 'pinterest', $data ) ) {
        return;
    }

    ob_start();
    ?>

    if ( typeof this.element === 'undefined' ) {
        $pinterest_link = $('.envira-album-gallery-' + this.group[ this.index ].gallery_id  + '.envira-gallery-link');
        if ( $pinterest_link.data('envira-pinterest') ) {
            $(this.inner).append($pinterest_link.data('envira-pinterest'));
        }
        else {
            var description = this.group[ this.index ].caption !== '' ? this.group[ this.index ].caption : this.group[ this.index ].title, media = this.group[ this.index ].href, href = decodeURIComponent($('a.envira-pinterest-share').attr('href'));
            $('a.envira-pinterest-share').attr('href', href.replace(/\{media\}/g, media).replace(/\{desc\}/g, description));
        }
    } else {
        if ( $(this.element).data('envira-pinterest') ) {
            $(this.inner).append($(this.element).data('envira-pinterest'));
        }
        else {
            var description = $(this.element).data('envira-caption') !== '' ? $(this.element).data('envira-caption') : $(this.element).attr('title');
            var media = $(this.element).find('img').attr('src');
            if ( media === 'undefined' ) {
                media = $(this.element).attr('src');
            }
            if ( media.indexOf('data:image/gif') !== -1 ) {
                /* this might be a result of lazy load, so we should find the image elsewhere */
                /* alert ( 'srcset: ' + $(this.element).find('img').attr('srcset') ); */
                media = $(this.element).find('img').attr('srcset') ;

            }
            var href = decodeURIComponent($('a.envira-pinterest-share').attr('href'));
            $('a.envira-pinterest-share').attr('href', href.replace(/\{media\}/g, media).replace(/\{desc\}/g, description));
        }
    }


    <?php
    echo ob_get_clean();

}

/**
 * Returns the available Pinterest positions on the gallery.
 *
 * @since 1.0.0
 *
 * @return array Array of Pinterest positions.
 */
function envira_pinterest_positions() {

    $positions = array(
        array(
            'value' => 'top_left',
            'name'  => __( 'Top Left', 'envira-pinterest' )
        ),
        array(
            'value' => 'top_right',
            'name'  => __( 'Top Right', 'envira-pinterest' )
        ),
        array(
            'value' => 'bottom_left',
            'name'  => __( 'Bottom Left', 'envira-pinterest' )
        ),
        array(
            'value' => 'bottom_right',
            'name'  => __( 'Bottom Right', 'envira-pinterest' )
        )
    );

    return apply_filters( 'envira_pinterest_positions', $positions );

}

/**
 * Returns the available Pinterest colors.
 *
 * @since 1.0.0
 *
 * @return array Array of Pinterest colors.
 */
function envira_pinterest_colors() {

    $colors = array(
        array(
            'value' => 'gray',
            'name'  => __( 'Gray', 'envira-pinterest' )
        ),
        array(
            'value' => 'red',
            'name'  => __( 'Red', 'envira-pinterest' )
        ),
        array(
            'value' => 'white',
            'name'  => __( 'White', 'envira-pinterest' )
        )
    );

    return apply_filters( 'envira_pinterest_colors', $colors );

}

/**
 * Adds addon settings UI to the Mobile tab
 *
 * @since 1.1.0
 *
 * @param object $post The current post object.
 */
function envira_pinterest_mobile_tab( $post ) {

    // Get post type so we load the correct metabox instance and define the input field names
    // Input field names vary depending on whether we are editing a Gallery or Album
    $post_type = get_post_type( $post );
    switch ( $post_type ) {
        /**
        * Gallery
        */
        case 'envira':
            $instance = Envira_Gallery_Metaboxes::get_instance();
            $key = '_envira_gallery';
            $term = __( 'Images', 'envira-pagination' );
            break;

        /**
        * Album
        */
        case 'envira_album':
            $instance = Envira_Albums_Metaboxes::get_instance();
            $key = '_eg_album_data[config]';
            $term = __( 'Galleries', 'envira-pagination' );
            break;
    }
    ?>

    <tr id="envira-config-pinterest-mobile-box">
        <th scope="row">
            <label for="envira-config-pinterest-mobile-box-enable"><?php echo sprintf( __( 'Enable Pinterest?', 'envira-pinterest' ) ); ?></label>
        </th>
        <td>
            <input id="envira-config-pinterest-mobile-box-enable" type="checkbox" name="<?php echo $key; ?>[mobile_pinterest_lightbox]" value="<?php echo $instance->get_config( 'mobile_pinterest_lightbox', $instance->get_config_default( 'mobile_pinterest_lightbox' ) ); ?>" <?php checked( $instance->get_config( 'mobile_pinterest_lightbox', $instance->get_config_default( 'mobile_pinterest_lightbox' ) ), 1 ); ?> />
            <span class="description"><?php _e( 'Enables or disables the Pinterest share button in lightboxes on mobile devices.', 'envira-gallery' ); ?></span>
        </td>
    </tr>

    <?php

}