/**
* Handles showing and hiding fields conditionally
*/
jQuery( document ).ready( function( $ ) {

	// Show/hide elements as necessary when a conditional field is changed
	$( '#envira-albums-settings input:not([type=hidden]), #envira-albums-settings select, #envira-gallery-settings input:not([type=hidden]), #envira-gallery-settings select' ).conditions( 
		[

			{  // Main Pinterest Elements
				conditions: {
					element: '[name="_envira_gallery[pinterest]"], [name="_eg_album_data[config][pinterest]"]',
					type: 'checked',
					operator: 'is'
				},
				actions: {
					if: {
						element: '#envira-config-pinterest-position-box, #envira-config-pinterest-color-box',
						action: 'show'
					},
					else: {
						element: '#envira-config-pinterest-position-box, #envira-config-pinterest-color-box',
						action: 'hide'
					}
				}
			}

		]
	);

} );