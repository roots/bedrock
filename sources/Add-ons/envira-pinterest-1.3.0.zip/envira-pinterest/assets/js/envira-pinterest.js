jQuery(document).ready(function($) {

	var socialElement = false;

    /******* FANCYBOX *********/

    $(document).on( 'envirabox_api_after_show', function( e, obj, instance, current ){  

    	// Initial social div or cloned? We use cloned for certain LB actions
      	if ( socialElement === undefined || socialElement === false ) {

	    	// Set the style for the Pin It button.
	    	var style = '';
		    switch ( obj.get_config( 'pinterest_position' ) ) {
		        case 'top_left' :
		        default :
		            style = 'top:10px;left:10px;';
		            break;
		        case 'top_right' :
		            style = 'top:10px;right:10px;';
		            break;
		        case 'bottom_right' :
		            style = 'bottom:10px;right:10px;';
		            break;
		        case 'bottom_left' :
		            style = 'bottom:10px;left:10px;';
		            break;
		    }

		    // description is title, media is image url

      		var pinterest_color = ( obj.get_config( 'pinterest_color' ) ? obj.get_config( 'pinterest_color' ) : 'gray' ),
      			pinterest_title = current.caption,
      			pinterest_media = current.src,
      			button_href = 'http://pinterest.com/pin/create/button/?url=' + envira_pinterest.envira_pinterest_url + '&description=' + pinterest_title + '&media=' + pinterest_media;

      		socialElement = $('<div class="envira-pinterest-button" style="position:absolute;' + style + '"><a target="_blank" class="envira-pinterest-share envira-pinterest-' + pinterest_color + '" href="' + button_href + '" rel="nofollow" style="width:56px;height:28px;display:block;outline:none;"></a></div>');
      	}

		socialElement.prependTo('.envirabox-stage .envirabox-slide--current .envirabox-image-wrap').addClass('social-active');

   		// Assign SocialDiv so we can use this later
		socialDiv = $('.envirabox-inner div.envira-social-buttons-exterior').clone();

		// $updated_href = urlencode('http://pinterest.com/pin/create/button/?url='.esc_url( $url ).'&description={desc}&media={media}');

	    /* console.log( 'envira-pinterest-share: ' + $('.envira-pinterest-share').attr('href') ); */
	    // $('.envira-pinterest-share').attr('href', '<?php echo $updated_href; ?>');

	    // var media = $('.envirabox-overlay img.envirabox-image').attr('src');   
	    // var description = $('.envirabox-overlay img.envirabox-image').data('envira-caption') !== '' ? $('.envirabox-overlay img.envirabox-image').data('envira-caption') : $('.envirabox-overlay img.envirabox-image').attr('title');

	    // var href = decodeURIComponent($('a.envira-pinterest-share').attr('href'));
	    // $('a.envira-pinterest-share').attr('href', href.replace(/\{media\}/g, media).replace(/\{desc\}/g, description));

	});


});