envira-pinterest
================

The Pinterest Addon for Envira allows images to be pinned to your favorite Pinterest boards.
