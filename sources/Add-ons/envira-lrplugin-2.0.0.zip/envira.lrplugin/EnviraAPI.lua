--[[----------------------------------------------------------------------------

EnviraAPI.lua
Common code to initiate Envira API requests with the WordPress REST API
------------------------------------------------------------------------------]]

-- Lightroom SDK
local LrApplication = import "LrApplication"
local LrDialogs = import 'LrDialogs'
local LrFileUtils = import 'LrFileUtils'
local LrFunctionContext = import 'LrFunctionContext'
local LrHttp = import 'LrHttp'
local LrPathUtils = import 'LrPathUtils'
local LrStringUtils = import 'LrStringUtils'
local LrTasks = import 'LrTasks'
local LrErrors = import "LrErrors"

--Debugging - use LrLogger:info( inspect( var ) )
local LrLogger = import 'LrLogger'( 'EnviraLightroom' )
LrLogger:enable( 'logfile' ) -- See /Documents/EnviraAPI.log
local inspect = require 'inspect'

-- JSON parser
local JSON = require 'json'

--The require minumum version of the Envira Lightroom Addon
local REQUIRED_MIN_VERSION 		= '2.0.0'

--API Endpoints
local AUTH_TOKEN_ENDPOINT 		= "/wp-json/envira-lightroom/v3/authenticate"
local VERION_CHECK_ENDPOINT 	= "/wp-json/envira-lightroom/v3/version-check"
local GALLERY_ENDPOINT 			= "/wp-json/envira-lightroom/v3/insert-gallery"
local DELTE_GALLERY_ENDPOINT 	= "/wp-json/envira-lightroom/v3/delete-gallery"
local INSERT_IMAGE_ENDPOINT 	= "/wp-json/envira-lightroom/v3/insert-image"
local DELETE_IMAGE_ENDPOINT 	= "/wp-json/envira-lightroom/v3/delete-image"
--local SYNC_ENDPOINT				= "/wp-json/envira-lightroom/v3/sync"

--============================================================================--
-- Properties
--============================================================================--

-- Setup API object
EnviraAPI = {}

--============================================================================--
-- Functions
--============================================================================--

-- If decoding fails make sure we throw an error
function JSON:onDecodeError( message, text, char )
	LrErrors.throwUserError( "Something went wrong, please contact Envira Support. Error Code: 1001" )
end
-- Make sure we have a json response
local function isJsonResponse( headers )

	-- Check if the returned data is application/json
	-- If not, this means WordPress doesn't have Lightroom Addon and JSON REST API enabled
	for i, header in pairs( headers ) do
		if header.field == 'Content-Type' then
			if string.find( header.value, 'application/json' ) == nil then

				return false

			end

			-- Response is JSON
			return true
		end
	end

end
-- Calls rest request and returns
local function call_it( propertyTable, method, url, params )

		if propertyTable.accessToken == '' then
			LrErrors.throwUserError( "Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 2002")
		end

		-- Define X-Envira-Lightroom-Access-Token Header
		local requestHeaders = {
			{ field = 'X-Envira-Lightroom-Access-Token', value = LrStringUtils.encodeBase64( propertyTable.accessToken ) },
			{ field = 'Content-Type', value = 'application/json' },
		}

		if method == "POST" then
			return LrHttp.post( url, params, requestHeaders )
		else
			return LrHttp.get( url, params, requestHeaders )
		end

end

local function call_rest_method( propertyTable, method, path, params )
	
	-- Throw an error if no url is entered
	if propertyTable.url == '' then
		LrDialogs.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 2001')
		return
	end
	
	local url = propertyTable.url .. path

	local response, headers = call_it( propertyTable , method, url, params )

	local isJson = isJsonResponse( headers )

	if not isJson then
		LrDialogs.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1002')
		return
	end

	if not headers.status then
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1003' )
		return
	end

	if headers.status >= 500 then
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1004' )
		return
	end
	if headers.status >= 401 then
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1005' )
		return
	end

	if headers.status == 200 then
		return headers.status, JSON:decode( response )
	end



end

-- Make a request to check
function EnviraAPI.checkVersion( propertyTable, showDialogs, type )

	local args = {}

	-- Checks the version for the addon for compatibility or gets the lightroom plugin version
	if type == 'addon' then
		args.type = 'addon'
	else
		args.type = 'plugin'
	end

	local status, response = call_rest_method( propertyTable, 'POST', VERION_CHECK_ENDPOINT, args )
	
	if response then
		
		LrDialogs.message( response )

	else 
	
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
		
		return
	end
	
end

-- Creates a new Envira Custom Post Type in WordPress, if the Envira Gallery does not already exist
-- If the Envira Gallery exists, updates the title
--
-- @param table  	propertyTable 	Properties (URL, Access Token)
-- @param string 	title 			Post Title (i.e. Lightroom Published Collection Name)
-- @param mixed 	galleryID  		Envira Gallery ID | nil
-- @return mixed Gallery ID | Error Message
function EnviraAPI.createOrUpdateGallery( propertyTable, title, galleryID )

	-- Define vars
	local args = {}
	args.title = title
	args.gallery_id = galleryID
	
	if tonumber(galleryID) ~= nil then
		return galleryID
	else
		local status, response = call_rest_method( propertyTable, 'POST', GALLERY_ENDPOINT , JSON:encode( args ) )

		-- The remote gallery ID to return
		if response then
			
			local remoteGalleryID = inspect(response.id)
	
			LrLogger:info( inspect( response.id ) )

			return remoteGalleryID
	
		else 
		
			LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
			return
			
		end
	end
end

-- Deletes an Envira Gallery
--
-- @param table 	propertyTable 	Properties (URL, Access Token)
-- @param int       galleryID 		Envira Gallery ID to delete
function EnviraAPI.deleteGallery( propertyTable, galleryID )

	-- Send a GET request to the WordPress REST API
	LrTasks.startAsyncTask( function()

		-- Define vars
		local args = {}
		args.gallery_id = galleryID

		local status, response = call_rest_method( propertyTable, 'POST', DELTE_GALLERY_ENDPOINT , JSON:encode( args ) )
		
		-- Check if response is nil
		if response then
			
			return response.message
	
		else 
		
			LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
			return
			
		end

	end ) -- /async

end

-- Upload an image to the WordPress Media Library
--
-- @param table 	propertyTable 	Properties (URL, Access Token)
-- @param string 	pathOrMessage 	Path to Photo to Upload
-- @param string 	title 			Image Title
-- @param string 	caption			Image Caption
-- @param string 	keywords 		Image Keywords (Tags in Envira)
-- @param int       galleryID 		Envira Gallery ID to assign this image to
-- @param int 		remoteImageID 	(optional) The WordPress Media Library ID to overwrite
-- @return mixed    				Image ID | Error Message
function EnviraAPI.uploadImage( propertyTable, pathOrMessage, title, caption, keywords, galleryID, remoteImageID )

	-- Define filename
	local filename = LrPathUtils.leafName( pathOrMessage )
	-- Define vars
	local args = {}
	args.filename = filename
	args.title = title
	args.caption = caption
	args.keywords = keywords
	args.remote_id = remoteImageID
	args.gallery_id = galleryID
	args.file_data = LrStringUtils.encodeBase64 ( LrFileUtils.readFile( pathOrMessage ) )
	
	local status, response = call_rest_method( propertyTable, 'POST', INSERT_IMAGE_ENDPOINT , JSON:encode( args ) )
	-- Check if response is nil
	if response then
			
		imageID = inspect( response.image_id )
		
		return imageID	
		
	else 
		
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
		return
			
	end	
	
end

-- Deletes an image from the WordPress Media Library
--
-- @param table 	propertyTable 	Properties (URL, Access Token)
-- @param int 		remoteImageID 	(optional) The WordPress Media Library ID to delete
-- @return mixed    bool|string
function EnviraAPI.deleteImage( propertyTable, remoteImageID )

	-- Define vars
	local args = {}
	
	args.image_id = title
	args.gallery_id = galleryID
	args.image_id = remoteImageID
	
	local status, response = call_rest_method( propertyTable, 'POST', DELETE_IMAGE_ENDPOINT , JSON:encode( args ) )
	
	-- Check if response is nil
	if response then
					
		message = inspect( response.message )
		return message
		
	else 
		
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
		return
			
	end		

end

-- Login to WordPress
function EnviraAPI.login( propertyTable )

	LrFunctionContext.postAsyncTaskWithContext( "Envira login", function( context )

		LrDialogs.attachErrorDialogToFunctionContext( context )
		
		local args = {}
		args.url = propertyTable.url
		args.accessToken = propertyTable.accessToken
		
		local auth = EnviraAPI.auth( args )
		
--		local user_id = response.ID
		propertyTable.loginValid = true
		propertyTable.loginButtonEnabled = false	
			
	end )
		
end

function EnviraAPI.auth( args )
	
	-- Define WP-API URL
	local status, response = call_rest_method( args, 'POST', AUTH_TOKEN_ENDPOINT , JSON:encode( args ) )
	-- Check if response is nil
	if response then
		
		if type( message ) ~= 'boolean' then
		
		end				
		local message = inspect( response.message )

		LrDialogs.message( 'You have sucuessfully authenticated with Envira.' )

		return message
		
	else 
		
		LrErrors.throwUserError( 'Something went wrong, please contact Envira Support admin@enviragallery.com. Error Code: 1006' )
		return
			
	end			
		
end

-- Logout by deleting loginValid flag
--
-- @param table 	propertyTable 	Properties (URL, Access Token)
-- @return nil
function EnviraAPI.logout( propertyTable )

	-- Mark login details as invalid
	propertyTable.loginValid = false
	propertyTable.loginButtonEnabled = true

end
