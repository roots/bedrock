envira-albums
=============

Albums addon for Envira Gallery.
