/**
 * You'll need to use CodeKit or similar, as this file is a placeholder to combine
 * the following JS files into min/metabox-min.js:
 *
 * - gallery-search.js
 * - gallery-sort.js
 */
// @codekit-append "gallery-delete.js";
// @codekit-append "gallery-edit.js";
// @codekit-append "gallery-insert.js";
// @codekit-append "gallery-search.js";
// @codekit-append "gallery-sort.js";
// @codekit-append "conditional-fields.js";
// @codekit-append "gallery-help.js";
