soliloquy-schedule
==================

The Schedule addon for Soliloquy allows you to schedule slides to display at specific intervals.
