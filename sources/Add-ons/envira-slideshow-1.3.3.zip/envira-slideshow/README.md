envira-slideshow
================

Slideshow addon for Envira Gallery.
